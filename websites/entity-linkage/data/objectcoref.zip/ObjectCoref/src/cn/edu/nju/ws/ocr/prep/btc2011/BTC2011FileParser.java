package cn.edu.nju.ws.ocr.prep.btc2011;

import java.io.*;
import java.sql.*;
import java.util.zip.*;
import org.apache.log4j.*;
import org.semanticweb.yars.nx.*;
import org.semanticweb.yars.nx.parser.*;
import org.semanticweb.yars.nx.util.*;
import cn.edu.nju.ws.ocr.datab.*;

public class BTC2011FileParser 
{
	static Logger logger = Logger.getLogger(BTC2011FileParser.class);
	
	private String filepath;
	
	public BTC2011FileParser(String fp) { this.filepath = fp; }
	
	public void parse()
	{
		try {
			Connection connBTC2011 = DBConnPool.getBTC2011();
			String sqlstr1 = "INSERT INTO quadruple(s,p,o,lang,datatype,c) VALUES(?,?,?,?,?,?);";
			PreparedStatement stmt1 = connBTC2011.prepareStatement(sqlstr1);
			
			BufferedReader reader = new BufferedReader(
					new InputStreamReader(
							new GZIPInputStream(
									new FileInputStream(filepath))));
			
			NxParser parser = new NxParser(reader);
		
			Node[] nodes = null;
			while (parser.hasNext()) {
				nodes = parser.next();
				
				int count = parser.lineNumber();
				if (count <= 0) { // skip some lines from last time
					logger.debug(count);
					continue;
				} else {
						String s = parseSubject(nodes[0]);
						String p = parsePredicate(nodes[1]);
						String o[] = parseObject(nodes[2]);
						int c = parseDocument(nodes[3]);
					
						stmt1.setString(1, s);
						stmt1.setString(2, p);
						stmt1.setString(3, o[0]); // o
						stmt1.setString(4, o[1]); // lang
						stmt1.setString(5, o[2]); // datatype
						stmt1.setInt(6, c);
						stmt1.addBatch();
						
						logger.debug(String.format("%d %s %s %s %s %s %d .", count, s, p, o[0], o[1], o[2], c));
						
					if (count % 100 == 0) {
						try {
							stmt1.executeBatch();
						} catch (Throwable e) { 
							logger.error(filepath + " " + count + " " + e.getMessage());
							continue;
						}
					}
				}
			}
			stmt1.executeBatch();
			stmt1.close();
			
			reader.close();	
			connBTC2011.close();
		} catch (Throwable e) {
			logger.error(e.getMessage());
		} 
	}
	
	private int parseURI(String uri)
	{
		Connection connBTC2011 = null;
		PreparedStatement stmt1 = null, stmt2 = null;
		ResultSet rs1 = null, rs2 = null;
		
		try {
			connBTC2011 = DBConnPool.getBTC2011();
			
			String sqlstr1 = "SELECT uri_id FROM uri WHERE uri=?;";
			stmt1 = connBTC2011.prepareStatement(sqlstr1);
			
			stmt1.setString(1, uri);
			int uriID = 0;
			rs1 = stmt1.executeQuery();
			while (rs1.next()) 
				uriID = rs1.getInt(1);
			
			if (uriID != 0) {
				return uriID;
			} else {
				String sqlstr2 = "INSERT INTO uri(uri,localname) VALUES(?,?);";
				stmt2 = connBTC2011.prepareStatement(sqlstr2);
				stmt2.setString(1, uri);
				stmt2.setString(2, localname(uri));
				stmt2.executeUpdate();
				
				stmt1.setString(1, uri); // for parallel safety
				rs2 = stmt1.executeQuery();
				while (rs2.next())
					uriID = rs2.getInt(1);
				
				return uriID;
			}
		} catch (Throwable e) {
			logger.error(e.getMessage());
			return 0;
		} finally {
		    try { rs1.close(); } catch (Exception e) {}
		    try { rs2.close(); } catch (Exception e) {}
		    try { stmt1.close(); } catch (Exception e) {}
		    try { stmt2.close(); } catch (Exception e) {}
		    try { connBTC2011.close(); } catch (Exception e) {}
		}
	}
	
	private String localname(String uri)
	{
		String localname = null;
		int index = uri.lastIndexOf("#");
		if (index != -1) {
			localname = uri.substring(index + 1);
		} else {
			index = uri.lastIndexOf("/");
			if (index != -1) {
				localname = uri.substring(index + 1);
			} else {
				index = uri.lastIndexOf(":");
				if (index != -1)
					localname = uri.substring(index + 1);
			}
		}
		return localname;
	}
	
	private int parseDoc(String url)
	{
		Connection connBTC2011 = null;
		PreparedStatement stmt1 = null, stmt2 = null;
		ResultSet rs1 = null, rs2 = null;
		
		try {
			connBTC2011 = DBConnPool.getBTC2011();
			
			String sqlstr1 = "SELECT doc_id FROM doc WHERE url=?;";
			stmt1 = connBTC2011.prepareStatement(sqlstr1);
			
			stmt1.setString(1, url);
			int docID = 0;
			rs1 = stmt1.executeQuery();
			while (rs1.next()) 
				docID = rs1.getInt(1);
			
			if (docID != 0) {
				return docID;
			} else {
				String sqlstr2 = "INSERT INTO doc(url) VALUES(?);";
				stmt2 = connBTC2011.prepareStatement(sqlstr2);
				stmt2.setString(1, url);
				stmt2.executeUpdate();
				
				stmt1.setString(1, url); // for parallel safety
				rs2 = stmt1.executeQuery();
				while (rs2.next())
					docID = rs2.getInt(1);
				
				return docID;
			}
		} catch (Throwable e) {
			logger.error(e.getMessage());
			return 0;
		} finally {
		    try { rs1.close(); } catch (Exception e) {}
		    try { rs2.close(); } catch (Exception e) {}
		    try { stmt1.close(); } catch (Exception e) {}
		    try { stmt2.close(); } catch (Exception e) {}
		    try { connBTC2011.close(); } catch (Exception e) {}
		}
	}
	
	private String parseSubject(Node s)
	{
		String sstr = s.toN3();
		
		if (sstr.startsWith("<")) {
			int index = sstr.length() - 1;
			if (index > 1) {
				String uri = sstr.substring(1, index);
				return "u" + parseURI(uri);
			} else return "u0";
		} else return "b" + NxUtil.unescape(sstr.substring(2));
	}
	
	private String parsePredicate(Node p)
	{
		String pstr = p.toN3();
		int index = pstr.length() - 1;
		if (index > 1) {
			String uri = pstr.substring(1, index);
			return "u" + parseURI(uri);
		} else return "u0";
	}
	
	private String[] parseObject(Node o)
	{
		String ostr = o.toN3();

		if (ostr.startsWith("<")) {
			int index = ostr.length() - 1;
			if (index > 1) {
				String uri = ostr.substring(1, index);
				String olt[] = {"u" + parseURI(uri), null, null};
				return olt;
			} else {
				String olt[] = {"u0", null, null};
				return olt;
			}
		} else if (ostr.startsWith("_:")) {
			String olt[] = {"b" + NxUtil.unescape(ostr.substring(2)), null, null};
			return olt;
		} else { 
			int typeIndex = ostr.lastIndexOf("^^");
			if (typeIndex > 1) {
				String value = ostr.substring(1, typeIndex - 1);
				if ((typeIndex + 3) < (ostr.length() - 1)) {
					String olt[] = {"l" + NxUtil.unescape(value), null, ostr.substring(typeIndex + 3, ostr.length() - 1)};
					return olt;
				} else {
					String olt[] = {"l" + NxUtil.unescape(value), null, null};
					return olt;
				}
			}
				
			int langIndex = ostr.lastIndexOf("@");
			if (langIndex > 1) {
				String value = ostr.substring(1, langIndex - 1);
				if ((langIndex + 1) < ostr.length()) {
					String olt[] = {"l" + NxUtil.unescape(value), ostr.substring(langIndex + 1), null};
					return olt;
				} else {
					String olt[] = {"l" + NxUtil.unescape(value), null, null};
					return olt;
				}
			} 
			
			String value = ostr.substring(1, ostr.length() - 1);
			String olt[] = {"l" + NxUtil.unescape(value), null, null};
			return olt;
		}
	}
	
	private int parseDocument(Node c)
	{
		String cstr = c.toN3();
		int index = cstr.length() - 1;
		if (index > 1) {
			String url = cstr.substring(1, index);
			return parseDoc(url);
		} else return 0;
	}
	
	public static void main(String args[]) throws Throwable
	{
		PropertyConfigurator.configure(BTC2011FileParser.class.getResource("/config/log4j.properties"));
		DBParam.init();

		/* String[] fps = { "" };
		
		for (String fp : fps) {
			BTC2011FileParser bfp = new BTC2011FileParser(fp);
			bfp.parse();
		} */
	}
}

