package cn.edu.nju.ws.ocr.eval;

import java.io.*;
import java.util.*;
import org.apache.log4j.*;

public class AlignmentWriter 
{
	static Logger logger = Logger.getLogger(AlignmentWriter.class);
	
	private Alignment alignment;
    private RandomAccessFile raf;
    private List<String> writeList;

    public AlignmentWriter(Alignment align, String filepath)
    {
        alignment = align;
        try {
            File file = new File(filepath);
            if (file.exists()) 
                file.delete();
            
            raf = new RandomAccessFile(filepath, "rw");
            writeList = new ArrayList<String>();
        } catch (Throwable e) {
            logger.error(e.getMessage());
        }
    }

    public void write(String onto1, String onto2)
    {
        writeNamespace();
        writeStart("yes", "0", "**", onto1, onto2);
        for (int i = 0, n = alignment.size(); i < n; i++) {
            Mapping map = alignment.mapping(i);
            String e1 = map.entity1().toString();
            String e2 = map.entity2().toString();
            String measure = Double.toString(map.measure());
            writeElement(e1, e2, measure);

        }
        writeEnd();
        writeToFile();
        try {
            raf.close();
        } catch (Throwable e) {
            logger.error(e.getMessage());
        }
    }

    public void writeNamespace()
    {
        String tmp = "<?xml version='1.0' encoding='utf-8' standalone='no'?>\n" 
        		   + "<rdf:RDF xmlns='http://knowledgeweb.semanticweb.org/heterogeneity/alignment' \n" 
        		   + "         xmlns:rdf='http://www.w3.org/1999/02/22-rdf-syntax-ns#' \n" 
        		   + "         xmlns:xsd='http://www.w3.org/2001/XMLSchema#' \n"
        		   + "         xmlns:align='http://knowledgeweb.semanticweb.org/heterogeneity/alignment#'>";
        writeList.add(tmp);
    }

    public void writeStart(String xml, String lvl, String type, String onto1, String onto2)
    {
        String tmp = "<Alignment>\n" 
                   + "  <xml>" + xml + "</xml>\n" 
                   + "  <level>" + lvl + "</level>\n"
                   + "  <type>" + type + "</type>\n" 
                   + "  <onto1>\n" 
                   + "    <Ontology rdf:about=\"" + onto1 + "\"/>\n" 
                   + "  </onto1>\n" 
                   + "  <onto2>\n" 
                   + "    <Ontology rdf:about=\"" + onto2 + "\"/>\n"
                   + "  </onto2>";
        writeList.add(tmp);
    }

    public void writeEnd()
    {
        String tmp = "  </Alignment>\n</rdf:RDF>";
        writeList.add(tmp);
    }

    public void writeElement(String res1, String res2, String measure)
    {
        String tmp = "  <map>\n" 
        		   + "    <Cell>\n" 
        		   + "      <entity1 rdf:resource=\"" + res1 + "\"/>\n" 
        		   + "      <entity2 rdf:resource=\"" + res2 + "\"/>\n" 
        		   + "      <relation>=</relation>\n" 
        		   + "      <measure rdf:datatype=\"http://www.w3.org/2001/XMLSchema#float\">" + measure + "</measure>\n" 
        		   + "    </Cell>\n" 
        		   + "  </map>";
        writeList.add(tmp);
    }

    public void writeElement(String res1, String res2, String measure, String r)
    {
        String tmp = "  <map>\n" 
        		   + "    <Cell>\n" 
        		   + "      <entity1 rdf:resource=\"" + res1 + "\"/>\n" 
        		   + "      <entity2 rdf:resource=\"" + res2 + "\"/>\n"
                   + "      <relation>" + r + "</relation>\n"
                   + "      <measure rdf:datatype=\"http://www.w3.org/2001/XMLSchema#float\">" + measure + "</measure>\n"             
                   + "    </Cell>\n" 
                   + "  </map>";
        writeList.add(tmp);
    }

    public void writeToFile()
    {
        try {
            for (int i = 0, n = writeList.size(); i < n; i++) {
                raf.seek(raf.length());
                raf.writeBytes(writeList.get(i) + "\r\n");
            }
        } catch (Throwable e) {
            logger.error(e.getMessage());
        }
    }
}
