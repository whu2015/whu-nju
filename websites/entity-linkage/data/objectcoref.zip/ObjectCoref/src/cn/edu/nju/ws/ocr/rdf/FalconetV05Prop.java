package cn.edu.nju.ws.ocr.rdf;

import java.sql.*;
import org.apache.log4j.*;
import cn.edu.nju.ws.ocr.datab.*;

// update on 2014-8-4
public class FalconetV05Prop extends SpecialProp
{
	static Logger logger = Logger.getLogger(FalconetV05Prop.class);
	
	// http://www.w3.org/2002/07/owl#sameAs
	public static final int OWL_sameAs_ID = 195;
	
	// http://www.w3.org/2002/07/owl#InverseFunctionalProperty
	public static final int OWL_IFP_ID = 266;
	
	// http://www.w3.org/2002/07/owl#FunctionalProperty
	public static final int OWL_FP_ID = 99;
	
	// http://www.w3.org/2004/02/skos/core#exactMatch
	public static final int SKOS_exactMatch_ID = 607005; 
	
	// http://www.w3.org/2004/02/skos/core#closeMatch
	public static final int SKOS_closeMatch_ID = 547705;
	
	// http://www.geneontology.org/formats/oboInOwl#hasExactSynonym
	public static final int OBO_hasExactSynonym_ID = 544;
	
	// http://open.vocab.org/terms/similarTo
	public static final int OV_similarTo_ID = 256005;
	
	// http://www.rkbexplorer.com/ontologies/coref#coreferenceData
	public static final int COREF_coreferenceData_ID = 32805;
	
	// http://umbel.org/umbel/sc/isLike
	// public static final int UMBEL_isLike_ID = 0;
	
	// http://www.w3.org/2002/07/owl#hasKey
	public static final int OWL_hasKey_ID = 320431;
	
	// http://www.w3.org/2002/07/owl#cardinality
	public static final int OWL_cardinality_ID = 105;
	
	// http://www.w3.org/2002/07/owl#maxCardinality
	public static final int OWL_maxCardinality_ID = 268;
	
	// http://www.w3.org/2002/07/owl#qualifiedCardinality
	public static final int OWL_qualifiedCardinality_ID = 320421;
	
	// http://www.w3.org/2002/07/owl#maxQualifiedCardinality
	public static final int OWL_maxQualifiedCardinality_ID = 320437;
	
	// http://www.w3.org/2002/07/owl#onProperty
	public static final int OWL_onProperty_ID = 104; 
	
	// http://www.w3.org/2002/07/owl#Restriction
	public static final int OWL_Restriction_ID = 106;
	
	// http://www.w3.org/1999/02/22-rdf-syntax-ns#type
	public static final int RDF_type_ID = 10;
	
	// http://www.w3.org/2000/01/rdf-schema#subClassOf
	public static final int RDFS_subClassOf_ID = 101;
	
	// http://www.w3.org/2000/01/rdf-schema#domain
	public static final int RDFS_domain_ID = 93;
	
	// http://www.w3.org/2000/01/rdf-schema#range
	public static final int RDFS_range_ID = 92;
	
	// http://www.w3.org/2000/01/rdf-schema#label
	public static final int RDFS_label_ID = 90;
	
	// http://www.w3.org/2002/07/owl#equivalentClass
	public static final int OWL_equivalentClass_ID = 114;
	
	// http://purl.org/dc/elements/1.1/title
	public static final int DC_title_ID = 22;
	
	// http://xmlns.com/foaf/0.1/name
	public static final int FOAF_name_ID = 16;
	
	// http://xmlns.com/foaf/0.1/mbox
	public static final int FOAF_mbox_ID = 602;

	// http://xmlns.com/foaf/0.1/mbox_sha1sum
	public static final int FOAF_mbox_sha1sum_ID = 18;
	
	// http://xmlns.com/foaf/0.1/homepage
	public static final int FOAF_homepage_ID = 17;
	
	// XSD datatypes, see http://www.w3.org/TR/xmlschema-2/type-hierarchy.gif
	public static final int XSD_float_ID = 214014;
	public static final int XSD_double_ID = 140291;
	
	public static final int XSD_decimal_ID = 497056;
	public static final int XSD_integer_ID = 140289;
	public static final int XSD_nonPositiveInteger_ID = 1109810;
	public static final int XSD_negativeInteger_ID = 1109801;
	public static final int XSD_long_ID = 485046;
	public static final int XSD_int_ID = 115076;
	public static final int XSD_short_ID = 620700;
	public static final int XSD_byte_ID = 867747;
	public static final int XSD_nonNegativeInteger_ID = 146215;
	public static final int XSD_positiveInteger_ID = 493532;
	public static final int XSD_unsignedLong_ID = 1109799;
	public static final int XSD_unsignedInt_ID = 1109798;
	public static final int XSD_unsignedShort_ID = 1109806;
	public static final int XSD_unsignedByte_ID = 867719;
	
	public static final int XSD_duration_ID = 484986;
	public static final int XSD_dateTime_ID = 140292;
	public static final int XSD_time_ID = 999640;
	public static final int XSD_date_ID = 213851;
	public static final int XSD_gYearMonth_ID = 498759;
	public static final int XSD_gYear_ID = 521880;
	public static final int XSD_gMonthDay_ID = 923048;
	public static final int XSD_gDay_ID = 521907;
	public static final int XSD_gMonth_ID = 521933;
	
	public static final int XSD_string_ID = 140299;
	public static final int XSD_normalizedString_ID = 1109804;
	public static final int XSD_token_ID = 498725;
	public static final int XSD_language_ID = 521904;
	public static final int XSD_Name_ID = 621659;
	public static final int XSD_NMTOKEN_ID = 1109805;
	public static final int XSD_NCName_ID = 910468;
	public static final int XSD_ID_ID = 1109807;
	public static final int XSD_IDREF_ID = 1109803;
	public static final int XSD_ENTITY_ID = 1109811;
	
	public static final int XSD_boolean_ID = 109041;
	public static final int XSD_base64Binary_ID = 545782;
	public static final int XSD_hexBinary_ID = 982233;
	
	public static final int XSD_anyURI_ID = 327560;
	public static final int XSD_QName_ID = 1109809;
	
	public static final int XSD_NOTATION_ID = 1109802;
	public static final int OWL_Thing_ID = 103;
	
	void findSpecialProp()
	{
		try {
			Connection connFalconetV05 = DBConnPool.getFalconetV05();
			String sqlstr1 = "SELECT DISTINCT s,c FROM " + DatasetType.FALCONETV05_QUADRUPLE + " WHERE o=? AND p=?";
			PreparedStatement stmt1 = connFalconetV05.prepareStatement(sqlstr1);
			
			Connection connObjectCoref = DBConnPool.getObjectCoref();
			String sqlstr2 = "INSERT INTO special_property(property,c,category,source) VALUES(?,?,?,?)";
			PreparedStatement stmt2 = connObjectCoref.prepareStatement(sqlstr2);
			
			// OWL_IFP_ID
			stmt1.setString(1, "u" + OWL_IFP_ID);
			stmt1.setString(2, "u" + RDF_type_ID);
				
			ResultSet rs1 = stmt1.executeQuery();
			while (rs1.next()) {
				String s = rs1.getString(1);
				int c = rs1.getInt(2);
				
				stmt2.setString(1, s);
				stmt2.setInt(2, c);
				stmt2.setString(3, "ifp"); // "ifp"=InverseFunctionalProperty
				stmt2.setString(4, DatasetType.FALCONETV05);
				stmt2.executeUpdate();
			}
			rs1.close();
			
			// OWL_FP_ID
			stmt1.setString(1, "u" + OWL_FP_ID);
			stmt1.setString(2, "u" + RDF_type_ID);
							
			ResultSet rs2 = stmt1.executeQuery();
			while (rs2.next()) {
				String s = rs2.getString(1);
				int c = rs2.getInt(2);
							
				stmt2.setString(1, s);
				stmt2.setInt(2, c);
				stmt2.setString(3, "fp"); // "fp"=FunctionalProperty
				stmt2.setString(4, DatasetType.FALCONETV05);
				stmt2.executeUpdate();
			}
			rs2.close();
			
			stmt1.close();
			stmt2.close();
			connFalconetV05.close();
			connObjectCoref.close();
		} catch (Throwable e) {
			logger.error(e.getMessage());
		}
	}
	
	void updateDerefDoc()
	{
		try {
			Connection connObjectCoref = DBConnPool.getObjectCoref();
			String sqlstr1 = "SELECT DISTINCT property FROM special_property WHERE property LIKE 'u%' AND source=?";
			PreparedStatement stmt1 = connObjectCoref.prepareStatement(sqlstr1);
			
			Connection connFalconetV05 = DBConnPool.getFalconetV05();
			String sqlstr2 = "SELECT uri,dereference_doc_uri_id FROM " + DatasetType.FALCONETV05_URI + " WHERE id=?";
			PreparedStatement stmt2 = connFalconetV05.prepareStatement(sqlstr2);
			
			String sqlstr3 = "SELECT dereference_doc_uri_id FROM " + DatasetType.FALCONETV05_URI + " WHERE uri=?";
			PreparedStatement stmt3 = connFalconetV05.prepareStatement(sqlstr3);
			
			String sqlstr4 = "UPDATE special_property SET deref_doc=? WHERE property=? AND source=?";
			PreparedStatement stmt4 = connObjectCoref.prepareStatement(sqlstr4);
			
			stmt1.setString(1, DatasetType.FALCONETV05);
			ResultSet rs1 = stmt1.executeQuery();
			while (rs1.next()) {
				String p = rs1.getString(1);
				stmt2.setInt(1, Integer.parseInt(p.substring(1)));
				
				ResultSet rs2 = stmt2.executeQuery();
				while (rs2.next()) {
					String puri = rs2.getString(1);
					int c = rs2.getInt(2);
					if (c == 0 && puri.contains("#")) {
						int index = puri.lastIndexOf("#");
						stmt3.setString(1, puri.substring(0, index));
						ResultSet rs3 = stmt3.executeQuery();
						while (rs3.next())
							c = rs3.getInt(1);
						rs3.close();
					}
					stmt4.setInt(1, c);
					stmt4.setString(2, p);
					stmt4.setString(3, DatasetType.FALCONETV05);
					stmt4.executeUpdate();
				}
				rs2.close();
			}
			rs1.close();
			
			stmt1.close();
			stmt2.close();
			stmt3.close();
			stmt4.close();
			connObjectCoref.close();
			connFalconetV05.close();
		} catch (Throwable e) {
			logger.error(e.getMessage());
		}
	}
	
	void decideTrustworthy()
	{
		// UPDATE special_property SET trustworthy=1 WHERE c=deref_doc AND source='falconet_v05';
	}
	
	public static void main(String args[])
	{
		PropertyConfigurator.configure(FalconetV05Prop.class.getResource("/config/log4j.properties"));
		DBParam.init();
		
		//new FalconetV05Prop().findSpecialProp();
		//new FalconetV05Prop().updateDerefDoc();
		// DELETE FROM special_property WHERE trustworthy<>1 AND source='falconet_v05';
		// SELECT property FROM special_property WHERE category='ifp' AND trustworthy=1 AND source='falconet_v05';
	}
}
