package cn.edu.nju.ws.ocr.train;

import org.apache.log4j.*;
import cn.edu.nju.ws.ocr.datab.*;
import cn.edu.nju.ws.ocr.train.btc2011.*;
//import cn.edu.nju.ws.ocr.train.falconetV05.*;

public class NameFinderFactory 
{
	static Logger logger = Logger.getLogger(NameFinderFactory.class);

	private static NameFinderFactory instance = null;
	
	private NameFinderFactory() {}
	
	synchronized public static NameFinderFactory getInstance() 
	{
		if (instance == null) 
			instance = new NameFinderFactory();
		return instance;
	}

	public INameFinder getNameFinder(String source)
	{
		if (source.equalsIgnoreCase(DatasetType.FALCONETV05)) {
			//return FalconetV05NameFinder.getInstance();
			return null; // due to the crash of Falcons
		} else if (source.equalsIgnoreCase(DatasetType.BTC2011)) {
			return BTC2011NameFinder.getInstance();
		} else return null;
	}
}
