package cn.edu.nju.ws.ocr.eval;

import java.io.*;
import java.util.*;
import org.apache.log4j.*;
import org.dom4j.*;
import org.dom4j.io.*;

public class AlignmentReader 
{
	static Logger logger = Logger.getLogger(AlignmentReader.class);
	
	@SuppressWarnings("unchecked")
	public Alignment read(String filepath) 
	{
		try {
			File file = new File(filepath);
			SAXReader reader = new SAXReader();
			Document doc = reader.read(file);
			
			Element root = doc.getRootElement();
			Element align = root.element("Alignment");
			Iterator<Element> map = align.elementIterator("map");
			if (map.hasNext()) {
				Alignment alignment = new Alignment();
				while (map.hasNext()) {
					Element cell = map.next().element("Cell");
					if (cell != null) {
						String e1 = cell.element("entity1").attributeValue("resource");
						String e2 = cell.element("entity2").attributeValue("resource");
						double sim = Double.parseDouble(cell.elementText("measure"));
						String rel = cell.elementText("relation");
						
						// create a mapping
						Mapping mapping = new Mapping(e1, e2, rel, sim);
						alignment.addMapping(mapping);
					}
				}
				return alignment;
			} 
			return null;
		} catch (Throwable e) {
			logger.error(e.getMessage());
			return null;
		}
	}
}
