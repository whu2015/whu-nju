package cn.edu.nju.ws.ocr.kernel.btc2011;

import java.sql.*;
import java.util.*;
import org.apache.log4j.*;
import cn.edu.nju.ws.ocr.datab.*;
import cn.edu.nju.ws.ocr.rdf.*;

public class CloseMatchFinder extends Thread
{
	static Logger logger = Logger.getLogger(CloseMatchFinder.class);
	
	private RDFInst inst;
	
	private List<RDFInst> rmQueue;
	private Map<Integer, RDFInst> instances;
	
	public CloseMatchFinder(RDFInst i, List<RDFInst> removeQueue, Map<Integer, RDFInst> instances) 
	{
		this.inst = i;
		this.rmQueue = removeQueue;
		this.instances = instances;
	}	

	private int indexOf(int uriID)
	{
		for (int i = 0; i < rmQueue.size(); ++i) {
			RDFInst inst = rmQueue.get(i);
			if (inst.getURIID() == uriID)
				return i;
		}
		return -1;
	}
	
	private void addInst(int uriID, int grp, int lvl, RDFStmt stmt)
	{
		int idx = indexOf(uriID);
		RDFInst i = null;
		if (idx == -1) {
			i = RDFFactory.getInstance().createRDFInst(uriID);
			rmQueue.add(i);
		} else i = rmQueue.get(idx); 
		
		if (stmt != null)
			i.addSnippet(stmt);
		
		RDFInst inst = instances.get(uriID);
		if (inst == null) {
			inst = i.clone();
			instances.put(uriID, inst);
		}
		inst.setGroup(RDFInst.CLOSEMATCH_IDX, grp);
		inst.setLevel(RDFInst.CLOSEMATCH_IDX, lvl);
		inst.setSnippets(i.getSnippets());
	}
	
	public void run() 
	{
		try {
			int uriID = inst.getURIID();
			logger.debug("BTC2011_CloseMatch_uriID=" + uriID);
			
			Connection connBTC2011 = DBConnPool.getBTC2011();
			
			String sqlstr1 = "SELECT DISTINCT o FROM " + DatasetType.BTC2011_QUADRUPLE + " WHERE s=? AND p=?";
			PreparedStatement stmt1 = connBTC2011.prepareStatement(sqlstr1);	
			
			String sqlstr2 = "SELECT DISTINCT s FROM " + DatasetType.BTC2011_QUADRUPLE + " WHERE o=? AND p=?";
			PreparedStatement stmt2 = connBTC2011.prepareStatement(sqlstr2);
			
			stmt1.setString(1, "u" + uriID);
			stmt1.setString(2, "u" + BTC2011Prop.SKOS_closeMatch_ID);
			
			ResultSet rs1 = stmt1.executeQuery();
			while (rs1.next()) {
				String o = rs1.getString(1);
				if (o.startsWith("u")) {
					int oURIID = Integer.parseInt(o.substring(1));
					
					RDFStmt rdfStmt1 = RDFFactory.getInstance().createRDFStmt(
							"lthis", "u" + BTC2011Prop.SKOS_closeMatch_ID, o);
					rdfStmt1.setPredicateURI(SpecialProp.SKOS_closeMatch);
					rdfStmt1.setPredicateName(SpecialProp.SKOS_closeMatch_qname);
						
					if (oURIID != uriID) 
						addInst(oURIID, 1, RDFInst.LVL1, rdfStmt1);
				}
			}
			stmt1.close();
			
			stmt2.setString(1, "u" + uriID);
			stmt2.setString(2, "u" + BTC2011Prop.SKOS_closeMatch_ID);
			
			ResultSet rs2 = stmt2.executeQuery();
			while (rs2.next()) {
				String s = rs2.getString(1);		
				if (s.startsWith("u")) {
					int sURIID = Integer.parseInt(s.substring(1));
					
					RDFStmt rdfStmt1 = RDFFactory.getInstance().createRDFStmt(
							s, "u" + BTC2011Prop.SKOS_closeMatch_ID, "lthis");
					rdfStmt1.setPredicateURI(SpecialProp.SKOS_closeMatch);
					rdfStmt1.setPredicateName(SpecialProp.SKOS_closeMatch_qname);
						
					if (sURIID != uriID)
						addInst(sURIID, 1, RDFInst.LVL1, rdfStmt1);
				}
			}
			stmt2.close();
			connBTC2011.close();
		} catch (Throwable e) {
			logger.error(e.getMessage());
		}
	}
}
