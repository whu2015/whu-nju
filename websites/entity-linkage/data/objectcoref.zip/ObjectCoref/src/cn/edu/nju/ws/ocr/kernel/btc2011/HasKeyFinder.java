package cn.edu.nju.ws.ocr.kernel.btc2011;

import java.sql.*;
import java.util.*;
import org.apache.log4j.*;
import cn.edu.nju.ws.ocr.datab.*;
import cn.edu.nju.ws.ocr.rdf.*;

public class HasKeyFinder extends Thread
{
	static Logger logger = Logger.getLogger(HasKeyFinder.class);
	
	private RDFInst inst;
	
	private List<RDFInst> rmQueue;
	private Map<Integer, RDFInst> instances;
	
	public HasKeyFinder(RDFInst i, List<RDFInst> removeQueue, Map<Integer, RDFInst> instances) 
	{
		this.inst = i;
		this.rmQueue = removeQueue;
		this.instances = instances;
	}	
	
	private int indexOf(int uriID)
	{
		for (int i = 0; i < rmQueue.size(); ++i) {
			RDFInst inst = rmQueue.get(i);
			if (inst.getURIID() == uriID)
				return i;
		}
		return -1;
	}
	
	private void addInst(int uriID, int grp, int lvl, RDFStmt stmt)
	{
		int idx = indexOf(uriID);
		RDFInst i = null;
		if (idx == -1) {
			i = RDFFactory.getInstance().createRDFInst(uriID);
			rmQueue.add(i);
		} else i = rmQueue.get(idx); 
		
		if (stmt != null)
			i.addSnippet(stmt);
		
		RDFInst inst = instances.get(uriID);
		if (inst == null) {
			inst = i.clone();
			instances.put(uriID, inst);
		}
		inst.setGroup(RDFInst.HASKEY_IDX, grp);
		inst.setLevel(RDFInst.HASKEY_IDX, lvl);
		inst.setSnippets(i.getSnippets());
	}
	
	public void run()
	{
		try {
			int uriID = inst.getURIID();
			logger.debug("BTC2011_HasKey_uriID=" + uriID);
			
			Connection connBTC2011 = DBConnPool.getBTC2011();
			
			String sqlstr1 = "SELECT DISTINCT p,o FROM " + DatasetType.BTC2011_QUADRUPLE + " WHERE s=?";
			PreparedStatement stmt1 = connBTC2011.prepareStatement(sqlstr1);
			
			String sqlstr2 = "SELECT DISTINCT s FROM " + DatasetType.BTC2011_QUADRUPLE + " WHERE o=? AND p=?";
			PreparedStatement stmt2 = connBTC2011.prepareStatement(sqlstr2);
			
			String sqlstr3 = "SELECT DISTINCT s FROM " + DatasetType.BTC2011_QUADRUPLE + " WHERE o=? AND p=? AND s!=?";
			PreparedStatement stmt3 = connBTC2011.prepareStatement(sqlstr3);
			
			String sqlstr4 = "SELECT DISTINCT s FROM " + DatasetType.BTC2011_QUADRUPLE + " WHERE p=? AND o=?";
			PreparedStatement stmt4 = connBTC2011.prepareStatement(sqlstr4);

			stmt1.setString(1, "u" + uriID);
			ResultSet rs1 = stmt1.executeQuery();
			while (rs1.next()) {
				String p = rs1.getString(1);
				String o = rs1.getString(2);
			
				stmt2.setString(1, p);
				stmt2.setString(2, "u" + BTC2011Prop.OWL_hasKey_ID);
				
				ResultSet rs2 = stmt2.executeQuery();
				while (rs2.next()) {
					String type = rs2.getString(1);
					
					stmt3.setString(1, o);
					stmt3.setString(2, p);
					stmt3.setString(3, "u" + uriID);
					
					ResultSet rs3 = stmt3.executeQuery();
					while (rs3.next()) {
						String s3 = rs3.getString(1);
							
						if (!s3.startsWith("u"))
							continue;
						
						stmt4.setString(1, "u" + BTC2011Prop.RDF_type_ID);
						stmt4.setString(2, type);
						
						ResultSet rs4 = stmt4.executeQuery();
						while (rs4.next()) {
							int uriID2 = Integer.parseInt(rs4.getString(1).substring(1));
							RDFStmt stmt = RDFFactory.getInstance().createRDFStmt(
									"lthis", "u" + BTC2011Prop.OWL_hasKey_ID, o);
							stmt.setPredicateURI(SpecialProp.OWL_hasKey);
							stmt.setPredicateName(SpecialProp.OWL_hasKey_qname);
							addInst(uriID2, 1, RDFInst.LVL1, stmt);
						}
						rs4.close();
					}
					rs3.close();
				}
				rs2.close();
			}
			rs1.close();
			stmt1.close();
			stmt2.close();
			stmt3.close();
			connBTC2011.close();
		} catch (Throwable e) {
			logger.error(e.getMessage());
		}
	}

}
