package cn.edu.nju.ws.ocr.train;

import java.util.*;
import org.apache.log4j.*;
import cn.edu.nju.ws.ocr.rdf.*;

public class Sorter 
{
	static Logger logger = Logger.getLogger(Sorter.class);
			
	private int inputURIID;

	public Sorter(int inputURIID) { this.inputURIID = inputURIID; }
	
	public List<RDFInst> sort(Map<Integer, RDFInst> instances, Map<Integer, RDFInst> kernel)
	{
		List<RDFInst> outputInstances = new ArrayList<RDFInst>();
		outputInstances.add(instances.get(inputURIID));
		
		List<RDFInst> sortedInstances = new ArrayList<RDFInst>();
		for (Integer uriID : instances.keySet()) {
			if (kernel.containsKey(uriID) && inputURIID != uriID) {
				sortedInstances.add(instances.get(uriID));
			}
		}
		Collections.sort(sortedInstances);
		
		List<RDFInst> sortedRestInstances = new ArrayList<RDFInst>();
		Iterator<Integer> iter = instances.keySet().iterator();
		while (iter.hasNext()) {
			int uriID = iter.next();
			if (!kernel.containsKey(uriID) && inputURIID != uriID) 
				sortedRestInstances.add(instances.get(uriID));
		}
		Collections.sort(sortedRestInstances);
		
		outputInstances.addAll(sortedInstances);
		outputInstances.addAll(sortedRestInstances);
		return outputInstances;
	}

	public List<RDFInst> sort(Map<Integer, RDFInst> instances,
							  Map<Integer, RDFInst> kernel1, 
							  Map<Integer, RDFInst> kernel2,
							  Map<Integer, RDFInst> kernel3) 
	{
		List<RDFInst> outputInstances = new ArrayList<RDFInst>();
		outputInstances.add(instances.get(inputURIID));
		
		List<RDFInst> sortedInstances1 = new ArrayList<RDFInst>();
		List<RDFInst> sortedInstances2 = new ArrayList<RDFInst>();
		List<RDFInst> sortedInstances3 = new ArrayList<RDFInst>();
		for (Integer uriID : instances.keySet()) {
			if (kernel1.containsKey(uriID) && this.inputURIID != uriID) 
				sortedInstances1.add(instances.get(uriID));
			
			if (kernel2.containsKey(uriID) && this.inputURIID != uriID) 
				sortedInstances2.add(instances.get(uriID));
			
			if (kernel3.containsKey(uriID) && this.inputURIID != uriID) 
				sortedInstances3.add(instances.get(uriID));
		}
		Collections.sort(sortedInstances1);
		Collections.sort(sortedInstances2);
		Collections.sort(sortedInstances3);
		
		List<RDFInst> sortedRestInstances = new ArrayList<RDFInst>();
		Iterator<Integer> iter = instances.keySet().iterator();
		while (iter.hasNext()) {
			int uriID = iter.next();
			if (inputURIID != uriID
					&& !kernel1.containsKey(uriID)
					&& !kernel2.containsKey(uriID)
					&& !kernel3.containsKey(uriID)) 
				sortedRestInstances.add(instances.get(uriID));
		}
		Collections.sort(sortedRestInstances);
		
		outputInstances.addAll(sortedInstances1);
		outputInstances.addAll(sortedInstances2);
		outputInstances.addAll(sortedInstances3);
		outputInstances.addAll(sortedRestInstances);
		return outputInstances;
	}
}
