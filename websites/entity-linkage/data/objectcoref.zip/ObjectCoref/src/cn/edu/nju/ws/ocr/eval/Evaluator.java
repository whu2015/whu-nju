package cn.edu.nju.ws.ocr.eval;

import org.apache.log4j.*;

public class Evaluator
{
	static Logger logger = Logger.getLogger(Evaluator.class);
	
	public static Metrics compare(Alignment align1, Alignment align2)
    {
        if (align1 == null || align2 == null) 
            return null;
        
        int found = align1.size();
        int exist = align2.size();
       
        if (found == 0 || exist == 0) 
            return null;
       
        int correct = 0;
        
        Metrics result = new Metrics();
        Alignment errorAlign = new Alignment();
        Alignment correctAlign = new Alignment();
        Alignment lostAlign = new Alignment();
        
        for (int i = 0; i < found; i++) {
            Mapping map1 = align1.mapping(i);
            boolean flag = true;
            for (int j = 0; j < exist; j++) {
                Mapping map2 = align2.mapping(j);
                if (map1.equals(map2)) {
                    correct++;
                    correctAlign.addMapping(map1);
                    flag = false;
                    break;
                }
            }
            if (flag == true) 
                errorAlign.addMapping(map1);
        }
        
        for (int i = 0; i < exist; i++) {
            Mapping map1 = align2.mapping(i);
            boolean flag = true;
            for (int j = 0; j < found; j++) {
                Mapping map2 = align1.mapping(j);
                if (map1.equals(map2)) {
                    flag = false;
                    break;
                }
            }
            if (flag == true) 
                lostAlign.addMapping(map1);
        }
        
        // System.out.println("Found=" + found + ", Existing=" + exist + ", Correct=" + correct);

        double prec = (double) correct / found;
        double rec = (double) correct / exist;
        // F1-measure
        double fm = 2 * prec * rec / (prec + rec);
        System.out.println("Precision="  + Math.round(prec * 1000) / 1000.0 
        			   + ", Recall="     + Math.round(rec * 1000)  / 1000.0 
        			   + ", F1-Measure=" + Math.round(fm * 1000)   / 1000.0);

        result.setFound(found);
        result.setExist(exist);
        result.setCorrect(correct);
        
        result.setPrecision(prec);
        result.setRecall(rec);
        result.setFMeasure(fm);
        
        result.setCorrectAlignment(correctAlign);
        result.setErrorAlignment(errorAlign);
        result.setLostAlignment(lostAlign);
        
        return result;
    }
}
