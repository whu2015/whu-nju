package cn.edu.nju.ws.ocr.train;

public enum TrainMode 
{
	SelfTrainer, SelfTrainerFPC, SelfTrainerFPC_CC, SelfTrainer_CC
}
