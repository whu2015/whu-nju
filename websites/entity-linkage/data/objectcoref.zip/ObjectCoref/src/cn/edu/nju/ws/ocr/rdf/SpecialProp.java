package cn.edu.nju.ws.ocr.rdf;

import org.apache.log4j.*;

public abstract class SpecialProp
{
	static Logger logger = Logger.getLogger(SpecialProp.class);
	
	public static final String OWL_sameAs = "http://www.w3.org/2002/07/owl#sameAs";
	public static final String OWL_sameAs_qname = "owl:sameAs";
	
	public static final String OWL_IFP = "http://www.w3.org/2002/07/owl#InverseFunctionalProperty";
	public static final String OWL_IFP_qname = "owl:IFP";
	
	public static final String OWL_FP = "http://www.w3.org/2002/07/owl#FunctionalProperty";
	public static final String OWL_FP_qname = "owl:FP";
	
	public static final String SKOS_exactMatch = "http://www.w3.org/2004/02/skos/core#exactMatch";
	public static final String SKOS_exactMatch_qname = "skos:exactMatch";
	
	public static final String SKOS_closeMatch = "http://www.w3.org/2004/02/skos/core#closeMatch";
	public static final String SKOS_closeMatch_qname = "skos:closeMatch";
	
	public static final String OBO_hasExactSynonym = "http://www.geneontology.org/formats/oboInOwl#hasExactSynonym";
	public static final String OBO_hasExactSynonym_qname = "obo:hasExactSynonym";
	
	public static final String OV_similarTo = "http://open.vocab.org/terms/similarTo";
	public static final String OV_similarTo_qname = "vocab:similarTo";
	
	public static final String COREF_coreferenceData = "http://www.rkbexplorer.com/ontologies/coref#coreferenceData";
	public static final String COREF_coreferenceData_qname = "coref:coreferenceData";
	
	// public static final String UMBEL_isLike = "http://umbel.org/umbel/sc/isLike";
	// public static final String UMBEL_isLike_qname = "umbel:isLike";
	
	public static final String OWL_hasKey = "http://www.w3.org/2002/07/owl#hasKey";
	public static final String OWL_hasKey_qname = "owl:hasKey";
	
	public static final String OWL_cardinality = "http://www.w3.org/2002/07/owl#cardinality";
	public static final String OWL_cardinality_qname = "owl:cardinality";
	
	public static final String OWL_maxCardinality = "http://www.w3.org/2002/07/owl#maxCardinality";
	public static final String OWL_maxCardinality_qname = "owl:maxCardinality";
	
	public static final String OWL_qualifiedCardinality = "http://www.w3.org/2002/07/owl#qualifiedCardinality";
	public static final String OWL_qualifiedCardinality_qname = "owl:qualifiedCardinality";
	
	public static final String OWL_maxQualifiedCardinality = "http://www.w3.org/2002/07/owl#maxQualifiedCardinality";
	public static final String OWL_maxQualifiedCardinality_qname = "owl:maxQualifiedCardinality";
	
	public static final String OWL_onProperty = "http://www.w3.org/2002/07/owl#onProperty";
	public static final String OWL_onProperty_qname = "owl:onProperty";
	
	public static final String OWL_Restriction = "http://www.w3.org/2002/07/owl#Restriction";
	public static final String OWL_Restriction_qname = "owl:Restriction";
	
	public static final String RDF_type = "http://www.w3.org/1999/02/22-rdf-syntax-ns#type";
	public static final String RDF_type_qname = "rdf:type";
	
	public static final String RDFS_subClassOf = "http://www.w3.org/2000/01/rdf-schema#subClassOf";
	public static final String RDF_subClassOf_qname = "rdfs:subClassOf";
	
	public static final String RDFS_domain = "http://www.w3.org/2000/01/rdf-schema#domain";
	public static final String RDFS_domain_qname = "rdfs:domain";
	
	public static final String RDFS_range = "http://www.w3.org/2000/01/rdf-schema#range";
	public static final String RDFS_range_qname = "rdfs:range";
	
	public static final String RDFS_label = "http://www.w3.org/2000/01/rdf-schema#label";
	public static final String RDFS_label_qname = "rdfs:label";
	
	public static final String OWL_equivalentClass = "http://www.w3.org/2002/07/owl#equivalentClass";
	public static final String OWL_equivalentClass_qname = "owl:equivalentClass";
	
	public static final String DC_title = "http://purl.org/dc/elements/1.1/title";
	public static final String DC_title_qname = "dc:title";
	
	public static final String FOAF_name = "http://xmlns.com/foaf/0.1/name";
	public static final String FOAF_name_qname = "foaf:name";
	
	public static final String FOAF_mbox = "http://xmlns.com/foaf/0.1/mbox";
	public static final String FOAF_mbox_qname = "foaf:mbox";
	
	public static final String FOAF_mbox_sha1sum = "http://xmlns.com/foaf/0.1/mbox_sha1sum";
	public static final String FOAF_mbox_sha1sum_qname = "foaf:mbox_sha1sum";
	
	public static final String FOAF_homepage = "http://xmlns.com/foaf/0.1/homepage";
	public static final String FOAF_homepage_qname = "foaf:homepage";
	
	abstract void findSpecialProp();
	
	abstract void updateDerefDoc();
	
	abstract void decideTrustworthy();
}
