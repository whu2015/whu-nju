package cn.edu.nju.ws.ocr.cache;

import java.sql.*;
import java.util.*;
import org.apache.log4j.*;
import cn.edu.nju.ws.ocr.datab.*;
import cn.edu.nju.ws.ocr.rdf.*;

public class CacheWriter 
{
	static Logger logger = Logger.getLogger(CacheWriter.class);

	// source={ DatasetType.FALCONETV05, DatasetType.BTC2011 }
	synchronized public static void write(List<RDFInst> instances, String source)
	{
		// at least reflexive
		if (instances == null || instances.size() == 0)
			return;
		
		try {
			Connection connObjectCoref = DBConnPool.getObjectCoref();
			
			String sqlstr1 = "SELECT MAX(group_id) FROM cache";
			PreparedStatement stmt1 = connObjectCoref.prepareStatement(sqlstr1);
			
			String sqlstr2 = "INSERT INTO cache VALUES(?,?,?,?,?)";
			PreparedStatement stmt2 = connObjectCoref.prepareStatement(sqlstr2);
			
			String sqlstr3 = "INSERT INTO cache_stmt VALUES(?,?,?,?,?)";
			PreparedStatement stmt3 = connObjectCoref.prepareStatement(sqlstr3);
			
			int newGroupID = 0;
			ResultSet rs1 = stmt1.executeQuery();
			while (rs1.next())
				newGroupID = rs1.getInt(1) + 1;
			rs1.close();
			stmt1.close();
			
			for (int rankID = 0; rankID < instances.size(); ++rankID) {
				RDFInst inst = instances.get(rankID);
				int uriID = inst.getURIID();
				
				stmt2.setInt(1, newGroupID);
				stmt2.setInt(2, uriID);
				stmt2.setInt(3, rankID);
				stmt2.setFloat(4, (float) inst.getSimilarity());
				stmt2.setString(5, source);
				stmt2.executeUpdate();
				
				List<RDFStmt> list = inst.getSnippets();
				for (int j = 0; j < list.size(); ++j) {
					RDFStmt stmt = list.get(j);
					
					stmt3.setInt(1, newGroupID);
					stmt3.setInt(2, uriID);
					stmt3.setString(3, stmt.getSubject());
					stmt3.setString(4, stmt.getPredicate());
					stmt3.setString(5, stmt.getObject());
					stmt3.addBatch();
				}
				stmt3.executeBatch();
			}
			stmt2.close();
			stmt3.close();
			connObjectCoref.close();
		} catch (Throwable e) {
			logger.error(e.getMessage());
		}
	}
}
