package cn.edu.nju.ws.ocr.train.btc2011;

import java.io.*;
import java.sql.*;
import java.util.*;
import org.apache.log4j.*;
import cn.edu.nju.ws.ocr.datab.*;
import cn.edu.nju.ws.ocr.kernel.btc2011.*;
import cn.edu.nju.ws.ocr.rdf.*;


public class BTC2011Negatives 
{
	public static Logger logger = Logger.getLogger(BTC2011Negatives.class);

	public static int roundSize = 1000;
	public static int maxRound = 10;
	
	public static List<Integer> generateNegExamples(String uriID, int size) {
		String curURI = getURIByID(uriID);
		logger.debug(curURI);
		Map<String, Integer> negs = generateNegExample(uriID, size);
		if(negs.size() == 0) {
			negs = generateNegExample2(uriID, size);
		}
		List<String> sortedURIList = new ArrayList<String> (negs.keySet());
		Collections.sort(sortedURIList, new LocalnameComparator(curURI));
		List<Integer> sortedURIIDList = new ArrayList<Integer> ();
		for(String uri : sortedURIList) {
			if(sortedURIIDList.size() >= size) break;
			if(!uri.equals(curURI))
				sortedURIIDList.add(negs.get(uri));
		}
		
		return sortedURIIDList;
	}

	public static List<Integer> generateNegExamples(int inputURIID, Collection<Integer> posSet, int size) {
		String curURI = getURIByID(String.valueOf(inputURIID));
		logger.debug(curURI);
		if(size < 10) size = 10;
		Map<String, Integer> negs = generateNegExamplesOfPosSet(posSet, size);
		List<String> sortedURIList = new ArrayList<String> (negs.keySet());
		Collections.sort(sortedURIList, new LocalnameComparator(curURI));
		List<Integer> sortedURIIDList = new ArrayList<Integer> ();
		for(String uri : sortedURIList) {
			if(sortedURIIDList.size() >= size) break;
			if(!uri.equals(curURI))// && !getPLD(uri).equals(getPLD(curURI)))
				sortedURIIDList.add(negs.get(uri));
		}
		
		return sortedURIIDList;
	}	

	public static Map<String, Integer> generateNegExamplesOfPosSet(Collection<Integer> posSet, int size) {
		Map<String, Integer> negs = new HashMap<String, Integer> ();
		//Type set of all positive examples
		Set<String> types = new HashSet<String>();
		//PLD set of all positive examples 
		Set<String> PLDs = new HashSet<String>();

        for(int pos : posSet) {
        	logger.debug(getURIByID(String.valueOf(pos)));
        	Set<String> curTypes = getTypes(String.valueOf(pos));
        	for(String type : curTypes) {
        	        logger.debug("\t" + getURIByID(type.substring(1)));
        	}
        	types.addAll(curTypes);
        	PLDs.add(getPLD(getURIByID(String.valueOf(pos))));
        }

		int round = 0;
		//Get types and PLDs of all positive examples
		while(round < maxRound) {
			if(size < types.size()) size = types.size();
			int typeSize = size / types.size();
			logger.debug("*********typeSize:" + typeSize);
			for(String type : types) {			
				//if(getURIByID(type.substring(1)).startsWith("http://dbpedia.org")) continue;
				logger.debug("Current Type:" + getURIByID(type.substring(1)));
				List<String> insts = getURIsWithType(type, round);
				int typeCount = 0;
				for(String instID : insts) {
					String curURI = getURIByID(instID);
					String curPLD = getPLD(curURI);
					if(PLDs.contains(curPLD)) {
						negs.put(curURI, Integer.valueOf(instID));
						typeCount++;
						logger.debug(curURI);
					}
					if(typeCount >= typeSize) break;
				}
				if(negs.size() >= size) break;
			}
			if(negs.size() >= size) break;
			round++;
		}
		//found negative examples are not enough
		if(negs.size() < size) {
			int rest = size - negs.size();
			for(int pos : posSet) {
				negs.putAll(generateNegExample2(String.valueOf(pos), rest));
				if(negs.size() >= size) break;
			}
		}
		return negs;
	}

	public static Map<String, Integer> generateNegExample(String uriID, int size) {
		Map<String, Integer> negs = new HashMap<String, Integer> ();
		int round = 0;
		List<String> uris = null;
		do {
			uris = getURIsWithSameType(uriID, round ++);			
			logger.debug(String.format("Round %s: found %s.", round, negs.size()));
			String namespace = getNamespace(getURIByID(uriID));
			for(String uriIDs : uris) {
				String uri = getURIByID(uriIDs);
				String n = getNamespace(uri);
				if(n != null && n.equals(namespace)) {
//					System.out.println(uri);
					if(uriIDs != uriID)	//neg is not the input URI
						negs.put(uri, Integer.valueOf(uriIDs));
				}
			}
		} while(negs.size() < size && uris.size() > 0 && round < maxRound);
		return negs;
	}
	
	public static Map<String, Integer> generateNegExample2(String uriID, int size) {
		Map<String, Integer> negs = new HashMap<String, Integer> ();
		Set<String> uris = Collections.emptySet();
		List<String> prefixes = getPrefixes(getURIByID(uriID));
		
		
		for(String prefix : prefixes) {
			int round = 0;
			do {
				uris = getURIsWithPrefix(prefix, round++);
                logger.debug(String.format("Prefix:[%s] Round %s: found %s.", prefix, round, negs.size()));
				Set<String> types = getTypes(uriID);
				for(String uriIDs : uris) {
					String uri = getURIByID(uriIDs);
					Set<String> t = getTypes(uriIDs);
					if(t.isEmpty()) continue;
					t.retainAll(types);
					if(!t.isEmpty() && uriIDs != uriID) {
						negs.put(uri, Integer.valueOf(uriIDs));
					}
				}
			} while(negs.size() < size && uris.size() > 0 && round < maxRound);
			if(negs.size() >= size) break;
		}

		return negs;
	}
	public static Map<String, Integer> generateNegExample3(String uriID, int size) {
		Map<String, Integer> negs = new HashMap<String, Integer> ();
		Set<String> uris = Collections.emptySet();
		List<String> prefixes = getPrefixes(getURIByID(uriID));
		
		
		for(String prefix : prefixes) {
			int round = 0;
			do {
				uris = getURIsWithPrefix(prefix, round++);
//				System.out.println(String.format("Prefix[%s] Round %s: found %s.", prefix, round, negs.size()));
				for(String uriIDs : uris) {
					String uri = getURIByID(uriIDs);
					negs.put(uri, Integer.valueOf(uriIDs));
				}
			} while(negs.size() < size && uris.size() > 0);
			if(negs.size() >= size) break;
		}
		
		return negs;
	}
	
	public static Set<String> getURIsWithPrefix(String prefix, int round) {
		Set<String> uris = new HashSet<String> ();
		Connection conn = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		try {
			String sql = "select uri_id from uri where uri like ? limit ?,?";
			conn = DBConnPool.getBTC2011();
			pstmt = conn.prepareStatement(sql);
			pstmt.setString(1, prefix + "%");
			pstmt.setInt(2, round * roundSize);
			pstmt.setInt(3, roundSize);
			rs = pstmt.executeQuery();
			while(rs.next()) {
				String curUri = rs.getString(1);
				uris.add(curUri);
			}
		} catch (Throwable e) {
			e.printStackTrace();
		} finally {
			close(rs, pstmt, conn);	
		}
		return uris;
	}
	
	public static List<String> getURIsWithSameNamespace(String uriID, int page) {
		List<String> uris = new ArrayList<String> ();
		Connection conn = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		try {
			String sql = "select uri_id from uri where uri like ? limit ?,?";
			conn = DBConnPool.getBTC2011();
			pstmt = conn.prepareStatement(sql);
			String namespace = getNamespace(getURIByID(uriID));
			pstmt.setString(1, namespace + "%");
			pstmt.setInt(2, page * roundSize);
			pstmt.setInt(3, roundSize);
			rs = pstmt.executeQuery();
			while(rs.next()) {
				String curUri = rs.getString(1);
				uris.add(curUri);
			}
		} catch (Throwable e) {
			e.printStackTrace();
		} finally {
			close(rs, pstmt, conn);	
		}
		return uris;
	}
	
	public static List<String> getURIsWithType(String type, int page) {
		List<String> uris = new ArrayList<String> ();
		Connection conn = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		try {
			String sql = "select s from quadruple where p = 'u2' and o = ? limit ?,?";
			conn = DBConnPool.getBTC2011();
			pstmt = conn.prepareStatement(sql);
			pstmt.setString(1, type);
			pstmt.setInt(2, page * roundSize);
			pstmt.setInt(3, roundSize);
			rs = pstmt.executeQuery();
			while(rs.next()) {
                String curUri = rs.getString(1);
                if(curUri.startsWith("u"))
                        uris.add(curUri.substring(1));
            }
		} catch(Throwable e) {
			e.printStackTrace();
		} finally {
			close(rs, pstmt, conn);
		}
		return uris;
	}

	public static List<String> getURIsWithSameType(String uriID, int page) {
		List<String> uris = new ArrayList<String> ();
		Connection conn = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		try {
			String sql = "select s from quadruple where p = 'u2' and o = ? limit ?,?";
			conn = DBConnPool.getBTC2011();
			Set<String> types = getTypes(uriID);
			logger.debug(String.format("Types: %s", types));
			for(String type : types) {
				pstmt = conn.prepareStatement(sql);
				pstmt.setString(1, type);
				pstmt.setInt(2, page * roundSize);
				pstmt.setInt(3, roundSize);
				rs = pstmt.executeQuery();
				while(rs.next()) {
					String curUri = rs.getString(1);
					if(curUri.startsWith("u"))
						uris.add(curUri.substring(1));
				}
			}
		} catch(Throwable e) {
			e.printStackTrace();
		} finally {
			close(rs, pstmt, conn);
		}
		return uris;
	}

	
	public static String getIDByURI(String uri) {
		String id = null;
		Connection conn = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		try {
			String sql = "select uri_id from uri where uri = ?";
			conn = DBConnPool.getBTC2011();
			pstmt = conn.prepareStatement(sql);
			pstmt.setString(1, uri);
			rs = pstmt.executeQuery();
			while(rs.next()) {
				id = rs.getString(1);
			}
		} catch (Throwable e) {
			e.printStackTrace();
		} finally {
			close(rs, pstmt, conn);	
		}
		return id;
	}
	
	public static String getURIByID(String uriID) {
		String uri = null;
		Connection conn = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		try {
			String sql = "select uri from uri where uri_id = ?";
			conn = DBConnPool.getBTC2011();
			pstmt = conn.prepareStatement(sql);
			pstmt.setString(1, uriID);
			rs = pstmt.executeQuery();
			while(rs.next()) {
				uri = rs.getString(1);
			}
		} catch (Throwable e) {
			e.printStackTrace();
		} finally {
			close(rs, pstmt, conn);	
		}
		return uri;
	}
	
	public static String getNamespace(String uri) {
		if(uri == null || !uri.startsWith("http://")) return null;
		int thirdSlashIndex = uri.substring(7).indexOf("/");
		String namespace = null;
		if(thirdSlashIndex < 0) 
			namespace = uri;
		else
			namespace = uri.substring(0, thirdSlashIndex + 7);
		return namespace;
	}
	
	public static List<String> getPrefixes(String uri) {
		List<String> prefixes = new ArrayList<String> ();
		if(uri == null || !uri.startsWith("http://")) return prefixes;
		String tmpStr = uri.substring(7);
		int lastIndexOfSlash = tmpStr.length();
		while(lastIndexOfSlash > 0) {
			tmpStr = tmpStr.substring(0, lastIndexOfSlash);
			prefixes.add("http://" + tmpStr);
			lastIndexOfSlash = tmpStr.lastIndexOf("/");
		}
		return prefixes;
	}
	
	public static String getPLD(String uri) {
		String prefix = null;
		if(uri == null || !uri.startsWith("http://")) return prefix;
		String tmpStr = uri.substring(7);
		int indexOfSlash = tmpStr.indexOf("/");
		if(indexOfSlash > 0) {
			tmpStr = tmpStr.substring(0, indexOfSlash);
		}
		prefix = "http://" + tmpStr;
		return prefix;
	}

	public static Set<String> getTypes(String uriID) {
		Connection conn = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		Set<String> typeList = new HashSet<String> ();
		try {
			String sql = "select o from quadruple where p = 'u2' and s = ?";
			conn = DBConnPool.getBTC2011();
			pstmt = conn.prepareStatement(sql);
			pstmt.setString(1, "u" + uriID);
			rs = pstmt.executeQuery();
			while(rs.next()) {
				String o = rs.getString(1);
				if(o.equals("u1007")) continue; //owl#Thing
				typeList.add(o);
			}
			
		} catch (Throwable e) {
			e.printStackTrace();
		} finally {
			close(rs, pstmt, conn);
		}
		return typeList;
	}
	
	public static void close(ResultSet rs, PreparedStatement pstmt, Connection conn) {
		if(rs != null) {
			try {
				rs.close();
			} catch (Exception e) {}
		}
		if(pstmt != null) {
			try {
				pstmt.close();
			} catch (Exception e) {}
		}
		if(conn != null) {
			try {
				conn.close();
			} catch (Exception e) {}
		}
	}
	
	
	public static List<String> readURIsFromFile() {
		List<String> uris = new ArrayList<String> ();
		Scanner input = null;
		File file = null;
		try {
			file = new File("btc20/exp_btc20.txt");
			input = new Scanner(file);
			while(input.hasNext()) {
				String line = input.nextLine().trim();
				if(line.startsWith("http://")) {
					uris.add(line);
				}
			}
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			if(input != null) {
				input.close();
			}
		}
		return uris;
	}
	
	public static void exp_btc20() {
		List<String> uris = readURIsFromFile();
//		List<String> uris = new ArrayList<String>();
//		uris.add("http://dbpedia.org/resource/SPARQL");
		int count = 0;
		for(String uri : uris) {
			int inputURIID = Integer.valueOf(getIDByURI(uri));
			BTC2011KernelBuilder kb = new BTC2011KernelBuilder(inputURIID);
			kb.query();
			Map<Integer, RDFInst> kernelMap = kb.getKernel();
			Set<Integer> kernelSet = kernelMap.keySet(); 
			int kernelSize = kernelSet.size();
			int size = (kernelSize > 20) ? 200 : kernelSize * (kernelSize - 1) / 2; 
			List<Integer> negs = generateNegExamples(inputURIID, kernelSet, size);
			
			logger.debug(String.format("[%s] %s %s", uri, kernelSize, size));
			for(int neg : negs) {
				logger.debug("neg:" + getURIByID(String.valueOf(neg)));
			}
			writeNegsToFile(uri, negs, "btc20/" + count);
			count ++;
		}
	}
	
	public static void writeNegsToFile(String inputURI, List<Integer> negs, String fileName) {
		PrintWriter output = null;
		try {
			output = new PrintWriter(new File(fileName));
			output.println("Input URI: " + inputURI);
			output.flush();
			for(int neg : negs) {
				String negURI = getURIByID(String.valueOf(neg));
				output.println(negURI);
				output.flush();
			}
		} catch(Exception e) {
			e.printStackTrace();
		} finally {
			if(output != null) output.close();
		}
	}
	
	public static void main(String[] args) {		

		PropertyConfigurator.configure(BTC2011Negatives.class.getResource("/config/log4j.properties"));
		DBParam.init();
		exp_btc20();
//		int size = 10;
////		List<String> uris = readURIsFromFile();
//		List<String> uris = new ArrayList<String>(Arrays.asList(new String[]{"http://dbpedia.org/resource/Ireland"}));
//		

//		String uri = "http://dbpedia.org/resource/Berlin";
//		Collections.shuffle(uris);
//		for(int i = 0; i < uris.size(); i++) {
//			String uri = uris.get(i);
//			long start = System.currentTimeMillis();
//			List<Integer> negs = generateNegExamples(getIDByURI(uri), size);
//			if(!negs.isEmpty()) {
//				Iterator<Integer> iter = negs.iterator();
//				List<String> negURIs = new ArrayList<String> ();
//				
//				while(iter.hasNext()) {
//					String negID = String.valueOf(iter.next());
//					System.out.print("\t" + getURIByID(negID) + "\t");
//					Set<String> types = getTypes(negID);
//					for(String type : types) {
//						System.out.print(getURIByID(type.substring(1)) + "\t");
//					}
//					System.out.println();
//				}
//			}
//			long end = System.currentTimeMillis();
//			System.out.println(String.format("[%s] %s Time: %s s", uri, negs.size(), (end - start) / 1000.0));
//		}
		

	}
}

//Compare EDIT DISTANCE of local name of input URIs
class LocalnameComparator implements Comparator<String> {
	
	private String inputLocalname;
	
    private int minimum(int a, int b, int c) {
        return Math.min(Math.min(a, b), c);
	}
	
	public int editDistance(String str1,String str2) {
	        int[][] distance = new int[str1.length() + 1][str2.length() + 1];
	
	        for (int i = 0; i <= str1.length(); i++)
	                distance[i][0] = i;
	        for (int j = 1; j <= str2.length(); j++)
	                distance[0][j] = j;
	
	        for (int i = 1; i <= str1.length(); i++)
	                for (int j = 1; j <= str2.length(); j++)
	                        distance[i][j] = minimum(
	                                        distance[i - 1][j] + 1,
	                                        distance[i][j - 1] + 1,
	                                        distance[i - 1][j - 1]+ ((str1.charAt(i - 1) == str2.charAt(j - 1)) ? 0 : 1));
	
	        return distance[str1.length()][str2.length()];    
	}
	
	public static String getLocalname(String uri) {
		if(uri == null || !uri.startsWith("http://")) return "";
		String localname = "";
		while (uri.endsWith("/")) uri = uri.substring(0, uri.length() - 1);
 		int lastSlashIndex = uri.lastIndexOf("/");
		if(lastSlashIndex > 0 && lastSlashIndex < uri.length() - 1) {
			localname = uri.substring(lastSlashIndex + 1);
		}
		return localname;
	}
	public static String getPLD(String uri) {
		String prefix = null;
		if(uri == null || !uri.startsWith("http://")) return prefix;
		String tmpStr = uri.substring(7);
		int indexOfSlash = tmpStr.indexOf("/");
		if(indexOfSlash > 0) {
			tmpStr = tmpStr.substring(0, indexOfSlash);
		}
		prefix = "http://" + tmpStr;
		return prefix;
	}
		
	public LocalnameComparator(String input) {
		this.inputLocalname = getLocalname(input);
	}
	
	private int editDistWithInput(String uri) {
		if(getLocalname(uri) == null) {
			return Integer.MAX_VALUE;
		}
		return editDistance(getLocalname(uri), inputLocalname);
	}

	@Override
	public int compare(String arg0, String arg1) {
		return editDistWithInput(arg0) - editDistWithInput(arg1);
	}

}
