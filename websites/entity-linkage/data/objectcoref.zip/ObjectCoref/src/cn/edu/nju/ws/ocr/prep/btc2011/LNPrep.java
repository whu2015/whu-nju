package cn.edu.nju.ws.ocr.prep.btc2011;

import java.sql.*;
import java.util.concurrent.*;
import org.apache.log4j.*;
import cn.edu.nju.ws.ocr.datab.*;

public class LNPrep 
{
	static Logger logger = Logger.getLogger(LNPrep.class);
	
	public void execLN1()
	{
		BlockingQueue<Runnable> queue = new LinkedBlockingQueue<Runnable>();  
		ThreadPoolExecutor exec = new ThreadPoolExecutor(4, 5, 7, TimeUnit.DAYS, queue);   
			
		int begin = 90000001, end = 103052869; // max(uri_id)=103,052,869
		while (begin <= end) {
			LNThread1 lnt1 = new LNThread1(begin);
			exec.execute(lnt1);
			++begin;
		}
		exec.shutdown();
	}
	
	public static void main(String args[])
	{
		PropertyConfigurator.configure(LNPrep.class.getResource("/config/log4j.properties"));
		DBParam.init();
		
		//LNPrep lnp = new LNPrep();
		//lnp.execLN1();
	}
	
	public class LNThread1 implements Runnable
	{
		private int uriID;
		
		public LNThread1(int id) { this.uriID = id; }
		
		public void run()
		{
			try {
				logger.debug("uri_id=" + uriID);
				
				Connection connBTC2011 = DBConnPool.getBTC2011();
				
				String sqlstr1 = "SELECT localname FROM " + DatasetType.BTC2011_URI + " WHERE uri_id=?";
				PreparedStatement stmt1 = connBTC2011.prepareStatement(sqlstr1);
				
				String localname = null;
				stmt1.setInt(1, uriID);
				ResultSet rs1 = stmt1.executeQuery();
				while (rs1.next()) 
					localname = rs1.getString(1);
				rs1.close();
				stmt1.close();
				
				String sqlstr2 = "INSERT INTO " + DatasetType.BTC2011_LOCALNAME_TIMES 
							   + " (localname,times) VALUES(?,?) ON DUPLICATE KEY UPDATE times=times+1";
				PreparedStatement stmt2 = connBTC2011.prepareStatement(sqlstr2);
				
				if (localname != null && !localname.trim().equals("")) {
					stmt2.setString(1, localname);
					stmt2.setInt(2, 1);
					stmt2.executeUpdate();
				}
				stmt2.close();
				connBTC2011.close();
			} catch (Throwable e) {
				logger.error(e.getMessage());
			}
		}
	}
}
