package cn.edu.nju.ws.ocr.fpc;

import java.sql.*;
import java.util.*;
import java.util.concurrent.*;
import org.apache.log4j.*;
import cn.edu.nju.ws.ocr.datab.*;

/**
 * @author Nathan Magnus, under the supervision of Howard Hamilton
 * Copyright: University of Regina, Nathan Magnus and Su Yibin, June 2009.
 *            No reproduction in whole or part without maintaining this copyright notice
 *            and imposing this condition on any subsequent users.
 *
 * File:
 * Input files needed:
 *      1. config.txt - three lines, each line is an integer
 *             line 1 - number of items per transaction
 *             line 2 - number of transactions
 *             line 3 - minimum support
 *      2. transa.txt - transaction file, each line is a transaction, items are separated by a space
 */

public class Apriori 
{
	static Logger logger = Logger.getLogger(Apriori.class);
	
	public void execApriori1()
	{
		try {
			List<Integer> classes = new ArrayList<Integer>();
			
			Connection connObjectCoref = DBConnPool.getObjectCoref();
			
			String sqlstr1 = "SELECT DISTINCT class_id FROM inst_class WHERE is_sample=1";
			PreparedStatement stmt1 = connObjectCoref.prepareStatement(sqlstr1);
			ResultSet rs1 = stmt1.executeQuery();  
			while(rs1.next()) {
				int classID = rs1.getInt(1);
				classes.add(classID);
			}
			rs1.close();
			stmt1.close();
			connObjectCoref.close();
			
			int taskID = classes.size();
			logger.debug("task_number=" + taskID);
			
			BlockingQueue<Runnable> queue = new LinkedBlockingQueue<Runnable>();  
			ThreadPoolExecutor exec = new ThreadPoolExecutor(1, 1, 7, TimeUnit.DAYS, queue);   
				
			int begin = 0, end = taskID; // size(class_id)=1,721
			while (begin < end) {
				AprioriThread at = new AprioriThread(classes.get(begin));
				exec.execute(at);
				++begin;
			}
			exec.shutdown();
		} catch (Throwable e) {
			logger.debug(e.getMessage());
		}
	}
	
	public static void main(String args[])
	{
		PropertyConfigurator.configure(Apriori.class.getResource("/config/log4j.properties"));
		DBParam.init();
		
		//Apriori a = new Apriori();
		//a.execApriori1();
	}
	
    public class AprioriThread implements Runnable
    {
    	private int classID; // the class of objects

    	private Vector<String> candidates; // the current candidates

    	private int numItems;         // number of items per transaction
    	private int numTransactions;  // number of transactions
    	private double minSup = 0.05; // minimum support for a frequent itemset
    	private String oneVal[];      // array of value per column that will be treated as a '1'
    	private List<String> transactions;
    	private String itemSep = " "; // the separator value for items in the database
    	
    	List<Integer> properties;

    	/*
    	 * CREATE TABLE prop_comb(class_id INT, 
    	 *                        itemset TEXT, 
    	 *                        support DOUBLE, 
    	 *                        level INT,
    	 *                        INDEX index_fpc(class_id, itemset(30)));
    	 */
    	public AprioriThread(int classID) 
    	{ 
    		this.classID = classID; 
    		this.candidates = new Vector<String>();
    		this.transactions = new ArrayList<String>();
    	}

    	public void run() 
    	{
    		// logger.debug("class_id=" + classID);	
    		aprioriProcess();
    		// logger.debug("finish=" + classID);
    	}

    	/************************************************************************
    	 * Method Name : aprioriProcess 
    	 * Purpose     : Generate the apriori itemsets
    	 * Parameters  : None 
    	 * Return      : None
    	 *************************************************************************/
    	public void aprioriProcess() 
    	{
    		int itemsetNumber = 0; // the current itemset being looked at
    		
    		getConfig(); // get configuration

    		// while not complete
    		do {
    			// increase the itemset that is being looked at
    			itemsetNumber++;
    			
    			if (itemsetNumber == 4) // 2 or 3 properties
    				break;
    			
    			// generate the candidates
    			generateCandidates(itemsetNumber);

    			logger.debug("class_id=" + classID 
    					 + ", itemset=" + itemsetNumber 
    					 + ", candidates=" + candidates.size());

    			// determine and display frequent itemsets
    			calculateFrequentItemsets(itemsetNumber);

    			// if there are <=1 frequent items, then it is the end. 
    			// this prevents reading through the database again. 
    			// when there is only one frequent itemset.
    		} while (candidates.size() > 1);
    	}

    	/************************************************************************
    	 * Method Name : getConfig 
    	 * Purpose     : get the configuration information (config filename, transaction filename) 
    	 *             : configFile and transaFile will be change appropriately 
    	 * Parameters  : None 
    	 * Return      : None
    	 *************************************************************************/
    	private void getConfig() 
    	{
    		try {
    			Connection connObjectCoref = DBConnPool.getObjectCoref();
    			
    			properties = new ArrayList<Integer>();
    			List<Integer> instances = new ArrayList<Integer>();
    			
    			String sqlstr1 = "SELECT uri_id FROM inst_class WHERE class_id=? AND is_sample=1";
				PreparedStatement stmt1 = connObjectCoref.prepareStatement(sqlstr1);
				String sqlstr2 = "SELECT prop_id FROM inst_prop WHERE uri_id=?";
				PreparedStatement stmt2 = connObjectCoref.prepareStatement(sqlstr2);
				
				stmt1.setInt(1, classID);
    			ResultSet rs1 = stmt1.executeQuery(); // a focused class
    			while (rs1.next()) {
    				// already discard rdf:type
    				int uriID = rs1.getInt(1);
    				instances.add(uriID);
    				
    				stmt2.setInt(1, uriID);
    				ResultSet rs2 = stmt2.executeQuery();
    				while (rs2.next()) {
    					int propID = rs2.getInt(1);
    					if (!properties.contains(propID))
    						properties.add(propID);
    				}
    				rs2.close();
    			}
    			rs1.close();
    			stmt1.close();
    			
    			for (int i = 0; i < instances.size(); ++i) {
    				Set<Integer> instProp = new HashSet<Integer>();
    				
    				stmt2.setInt(1, instances.get(i));
    				ResultSet rs2 = stmt2.executeQuery();
    				while (rs2.next()) {
    					int propID = rs2.getInt(1);
    					instProp.add(propID);
    				}
    				rs2.close();
    				
    				StringBuffer sb = new StringBuffer();

    				for (int j = 0; j < properties.size(); ++j) {
    					if (instProp.contains(properties.get(j))) {
    						if (sb.length() == 0) {
    							sb.append(1);
    						} else sb.append(" " + 1);
    					} else {
    						if (sb.length() == 0) {
    							sb.append(0);
    						} else sb.append(" " + 0);
    					}
    				}

    				if (sb.length() > 0) 
    					transactions.add(sb.toString());
    			}
    			stmt2.close();
    			connObjectCoref.close();
    			
    			numItems = properties.size(); // number of items
    			numTransactions = transactions.size(); // number of transactions
    			oneVal = new String[numItems];

    			for (int i = 0; i < oneVal.length; i++)
    				oneVal[i] = "1";
    		} catch (Throwable e) { 
    			// if there is an error, print the message
    			logger.error(e.getMessage());
    		}
    	}    	
    	
    	/************************************************************************
    	 * Method Name : generateCandidates 
    	 * Purpose     : Generate all possible candidates for the n-th itemsets 
    	 *             : these candidates are stored in the candidates class vector 
    	 * Parameters  : n - integer value representing the current itemsets to be created 
    	 * Return      : None
    	 *************************************************************************/
    	private void generateCandidates(int n) 
    	{
    		Vector<String> tmpCandidates = new Vector<String>(); // temporary string vector
    		String str1, str2;        // strings that will be used for comparisons
    		StringTokenizer st1, st2; // string tokenizers for the two itemsets being compared

    		// if it's the first set, candidates are just the numbers
    		if (n == 1) {
    			for (int i = 1; i <= numItems; i++) 
    				tmpCandidates.add(Integer.toString(i));
    		} else if (n == 2) { // second itemset is just all combinations of itemset 1
    			// add each itemset from the previous frequent itemsets together
    			for (int i = 0; i < candidates.size(); i++) {
    				st1 = new StringTokenizer(candidates.get(i));
    				str1 = st1.nextToken();
    				for (int j = i + 1; j < candidates.size(); j++) {
    					st2 = new StringTokenizer(candidates.elementAt(j));
    					str2 = st2.nextToken();
    					tmpCandidates.add(str1 + " " + str2);
    				}
    			}
    		} else {
    			// for each itemset
    			for (int i = 0; i < candidates.size(); i++) {
    				// compare to the next itemset
    				for (int j = i + 1; j < candidates.size(); j++) {
    					// create the strings
    					str1 = new String();
    					str2 = new String();
    					// create the tokenizers
    					st1 = new StringTokenizer(candidates.get(i));
    					st2 = new StringTokenizer(candidates.get(j));

    					// make a string of the first n-2 tokens of the strings
    					for (int s = 0; s < n - 2; s++) {
    						str1 = str1 + " " + st1.nextToken();
    						str2 = str2 + " " + st2.nextToken();
    					}

    					// if they have the same n-2 tokens, add them together
    					if (str2.compareToIgnoreCase(str1) == 0)
    						tmpCandidates.add((str1 + " " + st1.nextToken() + " " + st2.nextToken()).trim());
    				}
    			}
    		}
    		// clear the old candidates
    		candidates.clear();
    		// set the new ones
    		candidates = new Vector<String>(tmpCandidates);
    		tmpCandidates.clear();
    	}

    	/************************************************************************
    	 * Method Name : calculateFrequentItemsets 
    	 * Purpose     : Determine which candidates are frequent in the n-th itemsets 
    	 *             : from all possible candidates 
    	 * Parameters  : n - integer representing the current itemsets being evaluated 
    	 * Return      : None
    	 *************************************************************************/
    	private void calculateFrequentItemsets(int n) 
    	{
    		// the frequent candidates for the current itemset
    		Vector<String> frequentCandidates = new Vector<String>(); 

    		StringTokenizer st, stFile; // tokenizer for candidate and transaction
    		boolean match; // whether the transaction has all the items in an itemset
    		// array to hold a transaction so that can be checked
    		boolean trans[] = new boolean[numItems]; 
    		int count[] = new int[candidates.size()]; // the number of successful matches

    		try {
    			// load the transactions from db

    			// for each transaction
    			for (int i = 0; i < numTransactions; i++) {
    				//System.out.println("Got here " + i + " times"); 
    				// useful to debug files that you are unsure of the number of line
    				// read a line from the file to the tokenizer
    				stFile = new StringTokenizer(transactions.get(i), itemSep); 
    				// put the contents of that line into the transaction array
    				for (int j = 0; j < numItems; j++) 
    					trans[j] = (stFile.nextToken().compareToIgnoreCase(oneVal[j]) == 0); 
    					// if it is not a 0, assign the value to true

    				// check each candidate
    				for (int c = 0; c < candidates.size(); c++) {
    					match = false; // reset match to false
    					// tokenize the candidate so that we know what items need to be present for a match
    					st = new StringTokenizer(candidates.get(c));
    					// check each item in the itemset to see if it is present in the transaction
    					while (st.hasMoreTokens()) {
    						match = (trans[Integer.valueOf(st.nextToken()) - 1]);
    						if (!match) // if it is not present in the transaction stop checking
    							break;
    					}
    					if (match) // if at this point it is a match, increase the count
    						count[c]++;
    				}
    			}
    			
    			Connection connObjectCoref = DBConnPool.getObjectCoref();
    			String sqlstr1 = "INSERT INTO prop_comb VALUES(?,?,?,?)";
    			PreparedStatement stmt1 = connObjectCoref.prepareStatement(sqlstr1);
    			
    			for (int i = 0; i < candidates.size(); i++) {
    				// if the count% is larger than the minSup%, 
    				// add to the candidate to the frequent candidates
    				if ((count[i] / (double) numTransactions) >= minSup) {
    					frequentCandidates.add(candidates.get(i));
    					// put the frequent itemset into the output file
    					String itemSetStr = candidates.get(i);
    					StringTokenizer itemSetToken = new StringTokenizer(itemSetStr);
    					String propertySet = Integer.toString(properties.get(Integer.parseInt(itemSetToken.nextToken())-1));
    					while (itemSetToken.hasMoreTokens()) {
    						propertySet += " " + properties.get(Integer.parseInt(itemSetToken.nextToken()) -1);
    					}
    					double support = count[i] / (double) numTransactions;
    	
    					stmt1.setInt(1, classID);
    					stmt1.setString(2, propertySet);
    					stmt1.setDouble(3, support);
    					stmt1.setInt(4, n);
    						
    					stmt1.executeUpdate();
    				}
    			}
    			stmt1.close();
    			connObjectCoref.close();
    		} catch (Throwable e) {  
    			// if error at all in this process, catch it
    			logger.error(e.getMessage());
    		}
    		// clear old candidates
    		candidates.clear();
    		// new candidates are the old frequent candidates
    		candidates = new Vector<String>(frequentCandidates);
    		frequentCandidates.clear();
    	}
    }
}
