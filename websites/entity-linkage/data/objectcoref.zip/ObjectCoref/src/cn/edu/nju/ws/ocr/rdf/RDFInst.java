package cn.edu.nju.ws.ocr.rdf;

import java.util.*;
import org.apache.log4j.*;

public class RDFInst implements Comparable<RDFInst>, Cloneable 
{
	static Logger logger = Logger.getLogger(RDFInst.class);
	
	private int uriID;
	private String uri;
	private Set<String> names;
	private Set<Integer> types;
	
	private int docCnt = 0; // refer to falconet_v05.uri.describing_rdf_doc_num
	private double sim = 1.0;
	private String qname;
	private List<RDFStmt> snippets;
	
	private int cacheRankID = 0; // only be used when cache is available
	
	// group = { external, sameAs, IFP, FP, exactMatch, cardinality, 
	//           closeMatch, hasExactSynonym, similarTo, coreferenceData, isLike, hasKey }
	public static final int SAMEAS_IDX = 1;
	public static final int IFP_IDX = 2;
	public static final int FP_IDX = 3;
	public static final int EXACTMATCH_IDX = 4;
	// less useful
	public static final int CARDINALITY_IDX = 5;
	public static final int CLOSEMATCH_IDX = 6;
	public static final int HASEXACTSYN_IDX = 7;
	public static final int SIMILARTO_IDX = 8;
	public static final int COREFDATA_IDX = 9;
	public static final int ISLIKE_IDX = 10;
	public static final int HASKEY_IDX = 11;
	
	public static final int EXTERNAL_IDX = 0;
	private int group[] = new int[12];
	
	// level = { external, sameAs, IFP, FP, exactMatch, cardinality, 
	//           closeMatch, hasExactSynonym, similarTo, coreferenceData, isLike, hasKey }
	public static final int LVL1 = 2; // LVL1 > LVL2 > LVL3
	public static final int LVL2 = 1; // trustworthy = { 2, 1, 0 }
	public static final int LVL3 = 0;
	private int level[] = new int[12];

	public RDFInst(int uriID) 
	{
		this.uriID = uriID;
		this.snippets = Collections.synchronizedList(new ArrayList<RDFStmt>());
	}

	public RDFInst(String uri) 
	{
		this.uri = uri;
		this.snippets = Collections.synchronizedList(new ArrayList<RDFStmt>());
	}

	public RDFInst(int uriID, Set<String> names) 
	{
		this.uriID = uriID;
		this.names = names; // should be synchronized
		this.snippets = Collections.synchronizedList(new ArrayList<RDFStmt>());
	}

	public RDFInst(int uriID, String uri)
	{
		this.uriID = uriID;
		this.uri = uri;
		this.snippets = Collections.synchronizedList(new ArrayList<RDFStmt>());
	}

	public RDFInst(int uriID, double sim) 
	{
		this.uriID = uriID;
		this.sim = sim;
		this.snippets = Collections.synchronizedList(new ArrayList<RDFStmt>());
	}

	public RDFInst(int uriID, String uri, int docCnt) 
	{
		this.uriID = uriID;
		this.uri = uri;
		this.docCnt = docCnt;
		this.snippets = Collections.synchronizedList(new ArrayList<RDFStmt>());
	}
	
	public RDFInst(int uriID, String uri, double sim) 
	{
		this.uriID = uriID;
		this.uri = uri;
		this.sim = sim;
		this.snippets = Collections.synchronizedList(new ArrayList<RDFStmt>());
	}

	public RDFInst(int uriID, String uri, int docCnt, double sim) 
	{
		this.uriID = uriID;
		this.uri = uri;
		this.docCnt = docCnt;
		this.sim = sim;
		this.snippets = Collections.synchronizedList(new ArrayList<RDFStmt>());
	}

	synchronized public int getURIID() { return this.uriID; }

	synchronized public void addName(String name) 
	{
		if (this.names == null) 
			this.names = Collections.synchronizedSet(new HashSet<String>());
		this.names.add(name);
	}

	synchronized public Set<String> getNames() { return names; }

	synchronized public void setURI(String uri) { this.uri = uri; }

	synchronized public String getURI() { return uri; }

	synchronized public void setDocCnt(int docCnt) { this.docCnt = docCnt; }

	synchronized public int getDocCnt() { return docCnt; }

	synchronized public void setGroup(int idx, int grp) 
	{	
		switch (idx) {
		case SAMEAS_IDX:
			group[RDFInst.SAMEAS_IDX] = grp;
			break;
		case IFP_IDX:
			group[RDFInst.IFP_IDX] = grp;
			break;
		case FP_IDX:
			group[RDFInst.FP_IDX] = grp;
			break;
		case EXACTMATCH_IDX:
			group[RDFInst.EXACTMATCH_IDX] = grp;
			break;
		case CARDINALITY_IDX:
			group[RDFInst.CARDINALITY_IDX] = grp;
			break;
		case CLOSEMATCH_IDX:
			group[RDFInst.CLOSEMATCH_IDX] = grp;
			break;
		case HASEXACTSYN_IDX:
			group[RDFInst.HASEXACTSYN_IDX] = grp;
			break;
		case SIMILARTO_IDX:
			group[RDFInst.SIMILARTO_IDX] = grp;
			break;
		case COREFDATA_IDX:
			group[RDFInst.COREFDATA_IDX] = grp;
			break;
		case ISLIKE_IDX:
			group[RDFInst.ISLIKE_IDX] = grp;
			break;
		case HASKEY_IDX:
			group[RDFInst.HASKEY_IDX] = grp;
			break;
		case EXTERNAL_IDX:
			group[RDFInst.EXTERNAL_IDX] = grp;
			break;
		}
	}

	synchronized public int[] getGroup() { return group; }

	synchronized public int testGroup(int idx) 
	{
		if (idx == RDFInst.SAMEAS_IDX 
				|| idx == RDFInst.IFP_IDX 
				|| idx == RDFInst.FP_IDX
				|| idx == RDFInst.EXACTMATCH_IDX
				|| idx == RDFInst.CARDINALITY_IDX 
				|| idx == RDFInst.CLOSEMATCH_IDX
				|| idx == RDFInst.HASEXACTSYN_IDX
				|| idx == RDFInst.SIMILARTO_IDX
				|| idx == RDFInst.COREFDATA_IDX
				|| idx == RDFInst.ISLIKE_IDX
				|| idx == RDFInst.HASKEY_IDX
				|| idx == RDFInst.EXTERNAL_IDX) {
			return group[idx];
		} else return -1;
	}

	synchronized public void setLevel(int idx, int lvl) 
	{
		switch (idx) {
		case SAMEAS_IDX:
			level[RDFInst.SAMEAS_IDX] = lvl;
			break;
		case IFP_IDX:
			level[RDFInst.IFP_IDX] = lvl;
			break;
		case FP_IDX:
			level[RDFInst.FP_IDX] = lvl;
			break;
		case EXACTMATCH_IDX:
			level[RDFInst.EXACTMATCH_IDX] = lvl;
			break;
		case CARDINALITY_IDX:
			this.level[RDFInst.CARDINALITY_IDX] = lvl;
			break;
		case CLOSEMATCH_IDX:
			this.level[RDFInst.CLOSEMATCH_IDX] = lvl;
			break;
		case HASEXACTSYN_IDX:
			this.level[RDFInst.HASEXACTSYN_IDX] = lvl;
			break;
		case SIMILARTO_IDX:
			this.level[RDFInst.SIMILARTO_IDX] = lvl;
			break;
		case COREFDATA_IDX:
			this.level[RDFInst.COREFDATA_IDX] = lvl;
			break;
		case ISLIKE_IDX:
			this.level[RDFInst.ISLIKE_IDX] = lvl;
			break;
		case HASKEY_IDX:
			this.level[RDFInst.HASKEY_IDX] = lvl;
			break;
		} // no level for external
	}

	synchronized public int[] getLevel() { return level; }

	synchronized public int testLevel(int idx) 
	{
		if (idx == RDFInst.SAMEAS_IDX 
				|| idx == RDFInst.IFP_IDX 
				|| idx == RDFInst.FP_IDX
				|| idx == RDFInst.EXACTMATCH_IDX
				|| idx == RDFInst.CARDINALITY_IDX 
				|| idx == RDFInst.CLOSEMATCH_IDX
				|| idx == RDFInst.HASEXACTSYN_IDX
				|| idx == RDFInst.SIMILARTO_IDX
				|| idx == RDFInst.COREFDATA_IDX
				|| idx == RDFInst.ISLIKE_IDX
				|| idx == RDFInst.HASKEY_IDX) {
			return level[idx];
		} else return -1;
	}

	synchronized public void addSnippet(RDFStmt stmt) 
	{
		boolean flag = true;
		for (int i = 0; i < snippets.size(); ++i) {
			if (snippets.get(i).equlas(stmt)) {
				flag = false;
				break;
			}
		}
		if (flag) 
			snippets.add(stmt);
	}

	synchronized public void addAllSnippets(List<RDFStmt> list)
	{
		for (int i = 0; i < list.size(); ++i) 
			addSnippet(list.get(i));
	}

	// should be synchronized
	synchronized public void setSnippets(List<RDFStmt> snippets) { this.snippets = snippets; }

	synchronized public List<RDFStmt> getSnippets() { return snippets; }

	synchronized public void addType(int typeID) { types.add(typeID); }
	
	synchronized public void setTypes(Set<Integer> types) { this.types = types; }
	
	synchronized public Set<Integer> getTypes() { return types; }

	synchronized public void setSimilarity(double sim) { this.sim = sim; }

	synchronized public double getSimilarity() { return sim; }

	synchronized public void setQName(String dn) { this.qname = dn; }

	synchronized public String getQName() { return qname; }

	synchronized public void setCacheRankID(int rankID) { this.cacheRankID = rankID; }
	
	synchronized public int getCacheRankID() { return cacheRankID; }

	synchronized public boolean equals(RDFInst inst) 
	{
		if (this.uriID == inst.uriID) 
			return true;
		return false;
	}

	public int hashCode() { return uri.hashCode(); }

	synchronized public int compareTo(RDFInst inst) 
	{
		double sim2 = inst.getSimilarity();
		int docCnt2 = inst.docCnt;
		if (this.sim > sim2) {
			return -1;
		} else if (this.sim < sim2) {
			return 1;
		} else {
			if (this.docCnt > docCnt2) {
				return -1;
			} else if (this.docCnt < docCnt2) {
				return 1;
			} else return 0;
		}
	}

	synchronized public String toString() { return qname; }

	synchronized public RDFInst clone() 
	{
		RDFInst newInst = new RDFInst(uriID, uri, docCnt, sim);
		
		if (names != null) {
			newInst.names = Collections.synchronizedSet(new HashSet<String>());
			newInst.names.addAll(this.names);
		}
		if (types != null) {
			newInst.types = Collections.synchronizedSet(new HashSet<Integer>());
			newInst.types.addAll(this.types);
		}
		newInst.qname = qname;
		
		newInst.snippets = Collections.synchronizedList(new ArrayList<RDFStmt>());
		newInst.snippets.addAll(snippets);
		
		newInst.cacheRankID = cacheRankID;

		newInst.group = group;
		newInst.level = level;
	
		return newInst;
	}
}
