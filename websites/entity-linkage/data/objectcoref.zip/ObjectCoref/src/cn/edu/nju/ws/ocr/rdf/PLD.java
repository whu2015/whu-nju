package cn.edu.nju.ws.ocr.rdf;

import java.util.*;
import org.apache.log4j.*;

public class PLD implements Comparable<PLD>, Cloneable 
{
	static Logger logger = Logger.getLogger(PLD.class);
			
	private boolean changeFlag; // false, by default
	
	private double avgLen;
	
	private List<RDFInst> instances;
	private String pldName;

	public PLD() 
	{
		this.instances = new ArrayList<RDFInst>();
		this.changeFlag = true;
	}

	public PLD(List<RDFInst> list) 
	{
		this.instances = new ArrayList<RDFInst>();
		this.instances.addAll(list);
		this.changeFlag = true;
	}

	public String getPLDName() { return pldName; }

	public void setPLDName(String pldName) { this.pldName = pldName; }

	public void add(RDFInst inst)
	{
		instances.add(inst);
		changeFlag = true;
	}

	public void remove(int idx) 
	{
		instances.remove(idx);
		changeFlag = true;
	}

	public void remove(RDFInst inst) 
	{
		Iterator<RDFInst> iter = instances.iterator();
		while (iter.hasNext()) {
			RDFInst tmpInst = iter.next();
			if (tmpInst.equals(inst)) {
				iter.remove();
				changeFlag = true;
				break;
			}
		}
	}
	
	public RDFInst get(int idx) { return instances.get(idx); }

	public List<RDFInst> getRDFInstances() { return instances; }

	public int size() { return instances.size(); }
	
	public void calculateClusterDegree() 
	{
		if (changeFlag) {
			int neighCount = 0;
			double sumLen1 = 0;
			double sumLen2 = 0;
			double neighWeight = 0;
			List<Double> lenArray = new ArrayList<Double>();
			for (RDFInst tmpInst : instances) 
				lenArray.add(tmpInst.getSimilarity());
			
			neighCount = lenArray.size();
			if (neighCount > 0) {
				for (int i = 0; i < neighCount; i++) {
					sumLen1 += lenArray.get(i);
					for (int j = i + 1; j < neighCount; j++) 
						sumLen2 += lenArray.get(i) + lenArray.get(j);
				}
				neighWeight = neighCount * (neighCount + 1) / 2;
			}
			avgLen = (sumLen1 + sumLen2) / neighWeight;
			changeFlag = false;
		}
	}

	public int compareTo(PLD o) 
	{
		if (avgLen > o.avgLen) {
			return -1;
		} else if (avgLen < o.avgLen) {
			return 1;
		} else {
			if (instances.size() > o.instances.size()) {
				return -1;
			} else if (instances.size() < o.instances.size()) {
				return 1;
			} else return 0;
		}
	}

	public PLD clone() 
	{
		PLD newPLD = new PLD();
		
		newPLD.avgLen = avgLen;
		newPLD.changeFlag = changeFlag;
		newPLD.pldName = pldName;
		newPLD.instances = new ArrayList<RDFInst>();
		
		for (RDFInst oldInst : instances) 
			newPLD.instances.add(oldInst.clone());
		
		return newPLD;
	}
}

