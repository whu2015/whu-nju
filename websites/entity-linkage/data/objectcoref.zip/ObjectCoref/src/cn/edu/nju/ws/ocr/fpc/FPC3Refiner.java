package cn.edu.nju.ws.ocr.fpc;

import java.io.*;
import java.sql.*;
import java.util.*;
import org.apache.log4j.*;
import cn.edu.nju.ws.ocr.datab.*;
import cn.edu.nju.ws.ocr.nlp.*;
import cn.edu.nju.ws.ocr.rdf.*;
import cn.edu.nju.ws.ocr.util.*;

public class FPC3Refiner
{
	static Logger logger = Logger.getLogger(FPC3Refiner.class);
	
	private int[] rank(int[] properties)
	{
		int min = properties[0], max = properties[0];
		int minIndex = 0, maxIndex = 0;
		for (int i = 1; i < properties.length; ++i) {
			if (min > properties[i]) {
				min = properties[i];
				minIndex = i;
			}
			if (max < properties[i]) {
				max = properties[i];
				maxIndex = i;
			}
		}
		for (int j = 0; j < properties.length; ++j) {
			if (j != minIndex && j != maxIndex) {
				int[] newOrders = {properties[minIndex], properties[j], properties[maxIndex]};
				return newOrders;
			}
		}
		return null;
	}
	
	public void execFPC1()
	{
		try {
			Connection connObjectCoref = DBConnPool.getObjectCoref();
			
			String sqlstr1 = "SELECT itemset FROM prop_comb WHERE support>=0.98 AND level=3";
			PreparedStatement stmt1 = connObjectCoref.prepareStatement(sqlstr1);
			
			String sqlstr2 = "INSERT IGNORE INTO fpc3(prop_id1,prop_id2,prop_id3) VALUES(?,?,?)";
			PreparedStatement stmt2 = connObjectCoref.prepareStatement(sqlstr2);
			
			List<Itemset3> itemsets = new ArrayList<Itemset3>();
			ResultSet rs1 = stmt1.executeQuery();
			while (rs1.next()) {
				String[] properties = rs1.getString(1).split(" ");
				int p1 = Integer.parseInt(properties[0]);
				int p2 = Integer.parseInt(properties[1]);
				int p3 = Integer.parseInt(properties[2]);
				int[] p = {p1, p2, p3};
				int[] newOrders = rank(p);
				itemsets.add(new Itemset3(newOrders[0], newOrders[1], newOrders[2]));
			}
			rs1.close();
			stmt1.close();
			
			Iterator<Itemset3> iter = itemsets.iterator();
			while (iter.hasNext()) {
				Itemset3 is = iter.next();
				stmt2.setInt(1, is.getProp1());
				stmt2.setInt(2, is.getProp2());
				stmt2.setInt(3, is.getProp3());
				stmt2.executeUpdate();
			}
			stmt2.close();
			connObjectCoref.close();	
		} catch (Throwable e) {
			logger.error(e.getMessage());
		}
	}
	
	public void execFPC2()
	{
		try {
			Connection connObjectCoref = DBConnPool.getObjectCoref();
			
			String sqlstr1 = "SELECT prop_id1,prop_id2,prop_id3 FROM fpc3";
			PreparedStatement stmt1 = connObjectCoref.prepareStatement(sqlstr1);
			
			Connection connFalconetV05 = DBConnPool.getFalconetV05();
			String sqlstr2 = "SELECT uri FROM " + DatasetType.FALCONETV05_URI + " WHERE id=?";
			PreparedStatement stmt2 = connFalconetV05.prepareStatement(sqlstr2);
			
			String sqlstr3 = "UPDATE fpc3 SET not_builtin=1 WHERE prop_id1=? AND prop_id2=? AND prop_id3=?";
			PreparedStatement stmt3 = connObjectCoref.prepareStatement(sqlstr3);
			
			ResultSet rs1 = stmt1.executeQuery();
			while (rs1.next()) {
				int prop1 = rs1.getInt(1), prop2 = rs1.getInt(2), prop3 = rs1.getInt(3);
				String uri1 = null, uri2 = null, uri3 = null;
				stmt2.setInt(1, prop1);
				ResultSet rs2 = stmt2.executeQuery();
				while (rs2.next()) {
					uri1 = rs2.getString(1);
				}
				rs2.close();
				if (uri1.startsWith(SpecialPrefix.RDF) 
						|| uri1.startsWith(SpecialPrefix.RDFS) 
						|| uri1.startsWith(SpecialPrefix.OWL) 
						|| uri1.startsWith(SpecialPrefix.SKOS)
						|| uri1.startsWith(SpecialPrefix.XSD)
						|| uri1.startsWith(SpecialPrefix.DC))  {				
					continue;
				} else {
					stmt2.setInt(1, prop2);
					rs2 = stmt2.executeQuery();
					while (rs2.next()) {
						uri2 = rs2.getString(1);
					}
					rs2.close();
					if (uri2.startsWith(SpecialPrefix.RDF) 
							|| uri2.startsWith(SpecialPrefix.RDFS) 
							|| uri2.startsWith(SpecialPrefix.OWL) 
							|| uri2.startsWith(SpecialPrefix.SKOS)
							|| uri2.startsWith(SpecialPrefix.XSD)
							|| uri2.startsWith(SpecialPrefix.DC))  {				
						continue;
					} else {
						stmt3.setInt(1, prop3);
						rs2 = stmt2.executeQuery();
						while (rs2.next()) {
							uri3 = rs2.getString(1);
						}
						rs2.close();
						if (uri3.startsWith(SpecialPrefix.RDF) 
								|| uri3.startsWith(SpecialPrefix.RDFS) 
								|| uri3.startsWith(SpecialPrefix.OWL) 
								|| uri3.startsWith(SpecialPrefix.SKOS)
								|| uri3.startsWith(SpecialPrefix.XSD)
								|| uri3.startsWith(SpecialPrefix.DC))  {				
							continue;
						} else {
							stmt3.setInt(1, prop1);
							stmt3.setInt(2, prop2);
							stmt3.setInt(3, prop3);
							stmt3.executeUpdate();
						}
					}
				}
			}
			rs1.close();
			stmt1.close();
			stmt2.close();
			stmt3.close();
			connObjectCoref.close();
			connFalconetV05.close();
		} catch (Throwable e) {
			logger.error(e.getMessage());
		}
	}
	
	public void execFPC3()
	{
		try {
			Connection connObjectCoref = DBConnPool.getObjectCoref();
			
			String sqlstr1 = "SELECT prop_id1,prop_id2,prop_id3 FROM fpc3";
			PreparedStatement stmt1 = connObjectCoref.prepareStatement(sqlstr1);
			
			String sqlstr2 = "SELECT range_group,av,ac FROM prop_info WHERE prop_id=?";
			PreparedStatement stmt2 = connObjectCoref.prepareStatement(sqlstr2);
			
			String sqlstr3 = "UPDATE fpc3 SET range_compatible=?,av_compatible=?,ac_compatible=? " 
						   + "WHERE prop_id1=? AND prop_id2=? AND prop_id3=?";
			PreparedStatement stmt3 = connObjectCoref.prepareStatement(sqlstr3);
			
			ResultSet rs1 = stmt1.executeQuery();
			while (rs1.next()) {
				int prop1 = rs1.getInt(1), prop2 = rs1.getInt(2), prop3 = rs1.getInt(3);	
				logger.debug(prop1 + " , " + prop2 + " , " + prop3);
				
				String range1 = null, range2 = null, range3 = null;
				double av1 = 0, ac1= 0, av2 = 0, ac2 = 0, av3 = 0, ac3 = 0;
				
				stmt2.setInt(1, prop1);
				ResultSet rs2 = stmt2.executeQuery();
				while (rs2.next()) {
					range1 = rs2.getString(1);
					av1 = rs2.getDouble(2);
					ac1 = rs2.getDouble(3);
				}
				rs2.close();
				
				stmt2.setInt(1, prop2);
				rs2 = stmt2.executeQuery();
				while (rs2.next()) {
					range2 = rs2.getString(1);
					av2 = rs2.getDouble(2);
					ac2 = rs2.getDouble(3);
				}
				rs2.close();
				
				stmt2.setInt(1, prop3);
				rs2 = stmt2.executeQuery();
				while (rs2.next()) {
					range3 = rs2.getString(1);
					av3 = rs2.getDouble(2);
					ac3 = rs2.getDouble(3);
				}
				rs2.close();
				
				if (range1 == null || range2 == null || range3 == null) {
					if (range1 == null && range2 == null 
							|| range1 == null && range3 == null
							|| range2 == null && range3 == null) {
						stmt3.setInt(1, 1);
					} else if (range1 == null && range2.equals(range3)) {
						stmt3.setInt(1, 1);
					} else if (range2 == null && range1.equals(range3)) {
						stmt3.setInt(1, 1);
					} else if (range3 == null && range1.equals(range2)) {
						stmt3.setInt(1, 1);
					} else stmt3.setInt(1, 0);
				} else if (range1.equals("t") && range2.equals(range3) 
						|| range2.equals("t") && range1.equals(range3) 
						|| range3.equals("t") && range1.equals(range2)) {
					stmt3.setInt(1, 1);
				} else stmt3.setInt(1, 0);
				
				if (Math.abs(av1 - av2) <= 0.1 
						&& Math.abs(av1 - av3) <= 0.1 
						&& Math.abs(av2 - av3) <= 0.1) {
					stmt3.setInt(2, 1);
				} else stmt3.setInt(2, 0);
				
				if (Math.abs(ac1 - ac2) <= 0.1 
						&& Math.abs(ac1 - ac3) <= 0.1 
						&& Math.abs(ac2 - ac3) <= 0.1) {
					stmt3.setInt(3, 1);
				} else stmt3.setInt(3, 0);
				
				stmt3.setInt(4, prop1);
				stmt3.setInt(5, prop2);
				stmt3.setInt(6, prop3);
				stmt3.executeUpdate();
			}
			rs1.close();
			stmt1.close();
			stmt2.close();
			stmt3.close();
			connObjectCoref.close();
		} catch (Throwable e) {
			logger.error(e.getMessage());
		}
	}
	
	public void execFPC4()
	{
		try {
			Connection connObjectCoref = DBConnPool.getObjectCoref();
			
			String sqlstr1 = "SELECT prop_id1,prop_id2,prop_id3 FROM fpc3 "
						   + "WHERE range_compatible=1 AND av_compatible=1 AND ac_compatible=1 AND not_builtin=1 "
						   + "ORDER BY prop_id1,prop_id2,prop_id3";
			PreparedStatement stmt1 = connObjectCoref.prepareStatement(sqlstr1);
			
			Connection connFalconetV05 = DBConnPool.getFalconetV05();
			
			String sqlstr2 = "SELECT uri FROM " + DatasetType.FALCONETV05_URI + " WHERE id=?";
			PreparedStatement stmt2 = connFalconetV05.prepareStatement(sqlstr2);
			
			int count = 0;
			BufferedWriter bw = new BufferedWriter(new FileWriter("fpc3.txt"));
			ResultSet rs1 = stmt1.executeQuery();
			while (rs1.next()) {
				int prop1 = rs1.getInt(1), prop2 = rs1.getInt(2), prop3 = rs1.getInt(3);
				String uri1 = null, uri2 = null, uri3 = null;
				stmt2.setInt(1, prop1);
				ResultSet rs2 = stmt2.executeQuery();
				while (rs2.next()) {
					uri1 = rs2.getString(1);
				}
				rs2.close();
				
				stmt2.setInt(1, prop2);
				rs2 = stmt2.executeQuery();
				while (rs2.next()) {
					uri2 = rs2.getString(1);
				}
				rs2.close();
				
				stmt2.setInt(1, prop3);
				rs2 = stmt2.executeQuery();
				while (rs2.next()) {
					uri3 = rs2.getString(1);
				}
				rs2.close();
				
				String[] qname1 = URIHelper.namespace_localname(uri1);
				String[] qname2 = URIHelper.namespace_localname(uri2);
				String[] qname3 = URIHelper.namespace_localname(uri3);
				if (qname1[0].equals(qname2[0]) && qname2[0].equals(qname3[0])) {
					StringSplitter ss = StringSplitter.getStringSplitter();
					String ln1 = ss.splitByDelimit(qname1[1]);
					String ln2 = ss.splitByDelimit(qname2[1]);
					String ln3 = ss.splitByDelimit(qname3[1]);
					// at least have a few common words
					if (Jaccard.getSimilarity(ln1, ln2) > 0.1 
							&& Jaccard.getSimilarity(ln1, ln2) > 0.1 
							&& Jaccard.getSimilarity(ln2, ln3) > 0.1) 
						bw.write((++count) + " " + prop1 + " " + uri1 + " , " + prop2 + " " + uri2 + " , " + prop3 + " " + uri3 + "\r\n");
				}
			}
			rs1.close();
			bw.close();
			stmt1.close();
			stmt2.close();
			connObjectCoref.close();
			connFalconetV05.close();
		} catch (Throwable e) {
			logger.error(e.getMessage());
		}
	}
	
	public static void main(String args[])
	{
		PropertyConfigurator.configure(FPC3Refiner.class.getResource("/config/log4j.properties"));
		DBParam.init();
		
		//FPC3Refiner fpcr = new FPC3Refiner();
		//fpcr.execFPC1();
		//fpcr.execFPC2();
		//fpcr.execFPC3();
		//fpcr.execFPC4();
	}
}
