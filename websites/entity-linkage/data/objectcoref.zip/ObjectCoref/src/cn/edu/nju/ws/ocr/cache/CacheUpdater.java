package cn.edu.nju.ws.ocr.cache;

import java.sql.*;
import java.util.*;
import org.apache.log4j.*;
import cn.edu.nju.ws.ocr.datab.*;
import cn.edu.nju.ws.ocr.rdf.*;
import cn.edu.nju.ws.ocr.util.*;

// occasionally used
public class CacheUpdater 
{
	static Logger logger = Logger.getLogger(CacheUpdater.class);
	
	// source={ DatasetType.FALCONETV05, DatasetType.BTC2011 }
	synchronized public static void update(String uri, List<RDFInst> instances, String source)
	{
		if (uri == null || uri.equals(""))
			return;
		
		int uriID = URIHelper.uriID(uri, source);
		update(uriID, instances, source);
	}

	synchronized public static void update(int uriID, List<RDFInst> instances, String source) 
	{
		// at least reflexive
		if (uriID <= 0)
			return;
		
		delete(uriID, source);
		write(instances, source);
	}
	
	synchronized private static void write(List<RDFInst> instances, String source)
	{
		CacheWriter.write(instances, source);
	}

	synchronized private static void delete(int uriID, String source)
	{
		String sqlInClause = convertGroupsToClause(getGroups(uriID, source));
		if (sqlInClause.length() < 2) // length<2 indicates ")"
			return;
		
		try {
			Connection connObjectCoref = DBConnPool.getObjectCoref();
			
			String sqlstr1 = "DELETE FROM cache WHERE group_id IN " + sqlInClause;
			PreparedStatement stmt1 = connObjectCoref.prepareStatement(sqlstr1);
			
			stmt1.executeUpdate();
			stmt1.close();
			
			String sqlstr2 = "DELETE FROM cache_stmt WHERE group_id IN " + sqlInClause;
			PreparedStatement stmt2 = connObjectCoref.prepareStatement(sqlstr2);
			
			stmt2.executeUpdate();
			stmt2.close();
			
			connObjectCoref.close();
		} catch (Throwable e) {
			logger.error(e.getMessage());
		}
	}

	synchronized private static List<Integer> getGroups(int uriID, String source) 
	{
		try {
			Connection connObjectCoref = DBConnPool.getObjectCoref();
			
			String sqlstr1 = "SELECT group_id FROM cache "
						   + "WHERE uri_id=? AND source=? AND rank_id=0";
			PreparedStatement stmt1 = connObjectCoref.prepareStatement(sqlstr1);
			
			stmt1.setInt(1, uriID);
			stmt1.setString(2, source);
			
			List<Integer> groups = new ArrayList<Integer>();
			ResultSet rs1 = stmt1.executeQuery();
			while (rs1.next()) 
				groups.add(rs1.getInt(1));
			rs1.close();
			stmt1.close();
			connObjectCoref.close();
			
			return groups;
		} catch (Throwable e) {
			logger.error(e.getMessage());
			return null;
		}
	}

	synchronized private static String convertGroupsToClause(List<Integer> groups) 
	{
		if (groups == null || groups.size() == 0)
			return "";
		
		String sqlInClause = "(";
		for (int i = 0; i < groups.size(); ++i) 
			sqlInClause += groups.get(i) + ",";
		
		sqlInClause = sqlInClause.substring(0, sqlInClause.length() - 1) + ")";
		return sqlInClause;
	}
}
