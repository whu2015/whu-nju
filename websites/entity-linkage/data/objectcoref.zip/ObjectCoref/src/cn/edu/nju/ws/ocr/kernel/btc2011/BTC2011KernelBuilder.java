package cn.edu.nju.ws.ocr.kernel.btc2011;

import java.util.*;
import org.apache.log4j.*;
import cn.edu.nju.ws.ocr.datab.*;
import cn.edu.nju.ws.ocr.kernel.*;
import cn.edu.nju.ws.ocr.rdf.*;
import cn.edu.nju.ws.ocr.util.*;

public class BTC2011KernelBuilder implements IKernelBuilder 
{
	static Logger logger = Logger.getLogger(BTC2011KernelBuilder.class);
	
	private List<RDFInst> rmQueue;
	private Map<Integer, RDFInst> instances;
	
	public BTC2011KernelBuilder(String uri) 
	{
		if (uri == null || uri.trim().equals(""))
			return;
		
		rmQueue = Collections.synchronizedList(new LinkedList<RDFInst>());
		instances = Collections.synchronizedMap(new LinkedHashMap<Integer, RDFInst>());
		
		int uriID = URIHelper.uriID(uri, DatasetType.BTC2011);
		logger.debug("input_uri=" + uriID);
				
		RDFInst inst = RDFFactory.getInstance().createRDFInst(uriID, uri, 1.0);
		inst.setGroup(RDFInst.SAMEAS_IDX, 1);
		inst.setGroup(RDFInst.IFP_IDX, 1);
		inst.setGroup(RDFInst.FP_IDX, 1);
		inst.setGroup(RDFInst.EXACTMATCH_IDX, 1);
		//inst.setGroup(RDFInst.CARDINALITY_IDX, 1);
		inst.setGroup(RDFInst.EXTERNAL_IDX, 1);
				
		inst.setLevel(RDFInst.SAMEAS_IDX, RDFInst.LVL1);
		inst.setLevel(RDFInst.IFP_IDX, RDFInst.LVL1);	
		inst.setLevel(RDFInst.FP_IDX, RDFInst.LVL1);	
		inst.setLevel(RDFInst.EXACTMATCH_IDX, RDFInst.LVL1);	
		//inst.setLevel(RDFInst.CARDINALITY_IDX, RDFInst.LVL1);
				
		rmQueue.add(inst);
		instances.put(uriID, inst);
	}
	
	public BTC2011KernelBuilder(int uriID) 
	{
		if (uriID <= 0)
			return;
		
		rmQueue = Collections.synchronizedList(new LinkedList<RDFInst>());
		instances = Collections.synchronizedMap(new LinkedHashMap<Integer, RDFInst>());
		
		String uri = URIHelper.uri(uriID, DatasetType.BTC2011);
		logger.debug("input_uri=" + uriID);
				
		RDFInst inst = RDFFactory.getInstance().createRDFInst(uriID, uri, 1.0);
		inst.setGroup(RDFInst.SAMEAS_IDX, 1);
		inst.setGroup(RDFInst.IFP_IDX, 1);
		inst.setGroup(RDFInst.FP_IDX, 1);
		inst.setGroup(RDFInst.EXACTMATCH_IDX, 1);
		//inst.setGroup(RDFInst.CARDINALITY_IDX, 1);
		inst.setGroup(RDFInst.EXTERNAL_IDX, 1);
				
		inst.setLevel(RDFInst.SAMEAS_IDX, RDFInst.LVL1);
		inst.setLevel(RDFInst.IFP_IDX, RDFInst.LVL1);	
		inst.setLevel(RDFInst.FP_IDX, RDFInst.LVL1);	
		inst.setLevel(RDFInst.EXACTMATCH_IDX, RDFInst.LVL1);
		//inst.setLevel(RDFInst.CARDINALITY_IDX, RDFInst.LVL1);	
				
		rmQueue.add(inst);
		instances.put(uriID, inst);
	}
	
	public Map<Integer, RDFInst> getKernel() { return instances; }
	
	public void query()
	{
		int i = 0;
		while (i < rmQueue.size()) { // multi-threads, order by numbers
			logger.debug("kernel_size=" + instances.size());
			RDFInst inst = rmQueue.get(i);
			
			Thread[] threads = new Thread[4];	
			threads[0] = new SameAsFinder(inst, rmQueue, instances);
			threads[1] = new ExactMatchFinder(inst, rmQueue, instances);
			threads[2] = new IFPFinder(inst, rmQueue, instances);				
			threads[3] = new FPFinder(inst, rmQueue, instances);
			//threads[4] = new CardFinder(inst, rmQueue, instances);
			
			for (int j = 0; j < threads.length; ++j)
				threads[j].start();
			
			done: while (true) {
				boolean done = true;
				for (int k = 0; k < threads.length; ++k) {
					Thread thread = threads[k];
					if (thread != null && thread.isAlive()) {
						done = false;
						break;
					}
				}
				if (done) 
					break done;
				
				try {
					Thread.sleep(10);
				} catch (Throwable e) {
					logger.error(e.getMessage());
				}
			}
			threads = null;

			++i;
		}
	}
	
	public static void main(String args[])
	{
		PropertyConfigurator.configure(BTC2011KernelBuilder.class.getResource("/config/log4j.properties"));
		DBParam.init();		
		
		String uri = "http://dbpedia.org/resource/Semantic_Web";
		IKernelBuilder ikb = KernelBuilderFactory.getInstance().createKernelBuilder(uri, DatasetType.BTC2011);
		ikb.query();
		
		Iterator<RDFInst> i = ikb.getKernel().values().iterator();
		while (i.hasNext()) {
			RDFInst inst = i.next();
			System.out.println(inst.getURIID() + "\t" + URIHelper.uri(inst.getURIID(), DatasetType.BTC2011));
			List<RDFStmt> snippets = inst.getSnippets();
			if (snippets != null) {
				Iterator<RDFStmt> j = snippets.iterator();
				while (j.hasNext())
					System.out.println(" -> " + j.next());
			}
		}
		System.out.println("Total_size=" + ikb.getKernel().size());
	}
}
