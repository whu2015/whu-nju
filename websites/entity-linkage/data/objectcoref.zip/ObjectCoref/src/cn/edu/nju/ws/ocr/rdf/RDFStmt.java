package cn.edu.nju.ws.ocr.rdf;

import org.apache.log4j.*;

public class RDFStmt implements Cloneable
{
	static Logger logger = Logger.getLogger(RDFStmt.class);
	
	private String s, p, o; // internal use
	private String sname, pname, oname;
	private String suri, puri, ouri;
	
	private int source = 0;
	private String sourceURL;

	public RDFStmt(String s, String p, String o)
	{
		this.s = s;
		this.p = p;
		this.o = o;
	}

	public String getSubject() { return s; }

	public String getPredicate() { return p; }

	public String getObject() { return o; }

	public void setSubject(String s) { this.s = s; }

	public void setPredicate(String p) { this.p = p; }

	public void setObject(String o) { this.o = o; }

	public String getSubjectName() { return sname; }

	public String getPredicateName() { return pname; }

	public String getObjectName() { return oname; }

	public void setSubjectName(String sname) { this.sname = sname; }

	public void setPredicateName(String pname) { this.pname = pname; }

	public void setObjectName(String oname) { this.oname = oname; }

	public String getSubjectURI() { return suri; }

	public String getPredicateURI() { return puri; }

	public String getObjectURI() { return ouri; }

	public void setSubjectURI(String suri) { this.suri = suri; }

	public void setPredicateURI(String puri) { this.puri = puri; }

	public void setObjectURI(String ouri) { this.ouri = ouri; }

	public int getSource() { return source; }

	public void setSource(int src) { this.source = src; }

	public String getSourceURL() { return sourceURL; }

	public void setSourceURL(String srcURL) { this.sourceURL = srcURL; }
	
	public String toString() 
	{
		//return sname + "  " + pname + "  " + oname;
		return s + "  " + p + "  " + o;
	}

	public boolean equlas(RDFStmt stmt) 
	{
		if (this.s.equals(stmt.s) 
				&& this.p.equals(stmt.p)
				&& this.o.equals(stmt.o)) 
			return true;
		return false;
	}

	public RDFStmt clone()
	{
		RDFStmt newStmt = new RDFStmt(s, p, o);
		
		newStmt.sname = sname;
		newStmt.suri = suri;
		newStmt.pname = pname;
		newStmt.puri = puri;
		newStmt.oname = oname;
		newStmt.ouri = ouri;

		newStmt.source = source;
		newStmt.sourceURL = sourceURL;
		
		return newStmt;
	}
}
