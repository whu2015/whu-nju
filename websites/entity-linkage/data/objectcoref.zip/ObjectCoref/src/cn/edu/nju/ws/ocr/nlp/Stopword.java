package cn.edu.nju.ws.ocr.nlp;

import java.io.*;
import java.util.*;
import org.apache.log4j.*;

public class Stopword 
{
	static Logger logger = Logger.getLogger(Stopword.class);
			
	private List<String> stopwordlist;
	
	private static Stopword sw;

	private Stopword()
	{
		try {
			stopwordlist = new ArrayList<String>();
			// stopwords_less.txt or stopwords_more.txt
			String stopwordPath =  (Stopword.class.getResource("/config/stopwords_less.txt").getFile()).replaceAll("%20", " ");

	        BufferedReader br = new BufferedReader(new FileReader(stopwordPath));
	        String s = br.readLine();
	        while (s != null) {
	        	stopwordlist.add(s.trim());
	            s = br.readLine();
	        }
	        br.close();
	    } catch (Throwable e) {
	        logger.error(e.getMessage());
	    }
	}
	
	public static Stopword getStopword()
	{
		if (sw == null) 
			sw = new Stopword();
		
		return sw;
	}

	public String removeStopword(String src)
	{
		String[] s = removeStopword(src.split(" "));
		if (s.length < 1)
			return "";
		String ss = s[0];
		for (int i = 1; i < s.length; ++i)
			ss += " " + s[i];
		return ss;
	}
	
	public String[] removeStopword(String src[])
	{
	    int length = src.length;
	    if (length == 1) {
	    	return src;
	    } else {
	        List<String> tmp = new ArrayList<String>();
	        for (int i = 0; i < src.length; i++) {
	            if (!stopwordlist.contains(src[i])) 
	                tmp.add(src[i]);
	        }
	        String des[] = new String[tmp.size()];
	        for (int i = 0; i < tmp.size(); i++) 
	            des[i] = tmp.get(i);
	        return des;
	    }
	}
}
