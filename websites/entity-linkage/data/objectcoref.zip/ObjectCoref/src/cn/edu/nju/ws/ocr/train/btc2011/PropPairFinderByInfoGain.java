package cn.edu.nju.ws.ocr.train.btc2011;

import java.sql.*;
import java.util.*;
import java.util.concurrent.*;
import org.apache.log4j.*;
import cn.edu.nju.ws.ocr.datab.*;
import cn.edu.nju.ws.ocr.fpc.*;
import cn.edu.nju.ws.ocr.nlp.*;
import cn.edu.nju.ws.ocr.rdf.*;
import cn.edu.nju.ws.ocr.util.*;

public class PropPairFinderByInfoGain 
{
	static Logger logger = Logger.getLogger(PropPairFinderByInfoGain.class);
	
	private List<Integer> negURIs;
	private Set<PropPair> pairs;
	private List<Integer> uris;
	private Set<String> ifps;
	private List<Itemset2> fpc2;
	
	private Set<String> PV;
	private Map<Integer, Map<String, List<String>>> tmpInstances;
	private Map<String, Double> maxSims;
	
	private StringSplitter ss;
	private Stopword sw;
	private int inputURIID;
	private boolean withNeg;
	
	private Set<PropPair> negPairs;
	double threshold = 0.95;
	String type;
	String pld;
	private double infoD = 0;
	int negNum;
    int posNum;
    int sumNum;
    
    PriorityQueue<PropPair> queue = new PriorityQueue<PropPair>(1, new Comparator<PropPair>() {
		public int compare(PropPair a, PropPair b) {
			if (a.infoGain < b.infoGain){
				return 1;
            } else if (a.infoGain == b.infoGain) {
                return 0;
            } else return -1;
        }
    });
    
    public Set<PropPair> getPropPairs() { return pairs; }
    
	private void generateNegExamples() {
		negURIs = new ArrayList<Integer> ();
		if (!withNeg) return;
		//int size = (uris.size() - 1) / 2;
		negURIs.addAll(BTC2011Negatives.generateNegExamples(inputURIID, uris, this.negNum));
		for(int neg : negURIs) {
			logger.debug(BTC2011Negatives.getURIByID(String.valueOf(neg)));
		}
	}

	
	public PropPairFinderByInfoGain(int inputURIID, List<Integer> uris, 
						  Set<String> ifps, List<Itemset2> fpc2, Set<String> PV,
			              Map<Integer, Map<String, List<String>>> tmpInstances,
			              Map<String, Double> maxSims, boolean withNeg) throws SQLException
	{
		this.uris = uris;
		this.ifps = ifps;
		this.fpc2 = fpc2;
		this.withNeg = withNeg;
		
		this.PV = PV;
		this.tmpInstances = tmpInstances;
		this.maxSims = maxSims;
		this.pairs = Collections.synchronizedSet(new LinkedHashSet<PropPair>());
		this.negPairs = Collections.synchronizedSet(new LinkedHashSet<PropPair>());
			
		ss = StringSplitter.getStringSplitter();
		sw = Stopword.getStopword();
		
		this.posNum = this.negNum = uris.size()*(uris.size()-1)/2;
//		this.negNum = 10;
		this.sumNum = this.posNum + this.negNum;
		this.infoD =  -((double)posNum/sumNum)*Math.log((double)posNum/sumNum) - ((double)negNum/sumNum)*Math.log((double)negNum/sumNum);
		this.inputURIID = inputURIID;
		
		generateNegExamples();
	}
	
	public void execPropPair1()
	{
		BlockingQueue<Runnable> queue = new LinkedBlockingQueue<Runnable>();  
		ThreadPoolExecutor exec = new ThreadPoolExecutor(4, 8, 7, TimeUnit.HOURS, queue);
		//find positive property pairs
//		logger.debug(String.format("pos size and neg size: %s\t%s" , uris.size(), negURIs.size()));
		for (int i = 0; i < uris.size(); ++i) {
			int uriID1 = uris.get(i);
			for (int j = i + 1; j < uris.size(); ++j) {
				int uriID2 = uris.get(j);
				PropPairThread1 peppt1 = new PropPairThread1(uriID1, uriID2, pairs, ifps, fpc2, PV, tmpInstances, maxSims, false);
				exec.execute(peppt1);
			}
		}
		//find negative property pairs
		for (int i = 0; i < negURIs.size(); ++i) {			
			int uriID = negURIs.get(i);
				PropPairThread1 peppt1 = 
					new PropPairThread1(inputURIID, uriID, negPairs, 
							ifps, fpc2, PV, tmpInstances, maxSims, true);
				exec.execute(peppt1);
		}
		exec.shutdown();
		
		
		while (true) {
			try {
				Thread.sleep(1000);
//				logger.debug(negPairs.size() + "\t" + pairs.size());
				if (exec.getActiveCount() == 0) 
					break;
			} catch (Throwable e) {
				logger.error(e.getMessage());
			}
		}
	}
	
	private PropPair contains(int propID1, int propID2) {
		synchronized (pairs) {
			Iterator<PropPair> iter = pairs.iterator();
			while (iter.hasNext()) {
				PropPair pp = iter.next();
				if (pp.propID1 == propID1 && pp.propID2 == propID2)
					return pp;
			}
			return null;
		}
	}
	
	private PropPair negContains(int propID1, int propID2) {
		synchronized (negPairs) {
			Iterator<PropPair> iter = negPairs.iterator();
			while (iter.hasNext()) {
				PropPair pp = iter.next();
				if (pp.propID1 == propID1 && pp.propID2 == propID2)
					return pp;
			}
			return null;
		}
	}
	
	public double info(int propURIID1, int propURIID2)
	{		
		PropPair pp = (propURIID1 <= propURIID2) ? contains(propURIID1, propURIID2) : contains(propURIID2, propURIID1);
		
		int posNumP = pp.times;
		int posNumN = posNum - posNumP;
		
		PropPair negpp = (propURIID1 <= propURIID2) ? negContains(propURIID1, propURIID2) : negContains(propURIID2, propURIID1);
		int negNumP = 0;
		if (negpp != null) 
			negNumP = negpp.times;
		
		int negNumN = negNum - negNumP;
		
		int sumNumP = posNumP + negNumP;
		int sumNumN = posNumN + negNumN;
//		logger.debug(String.format("Pos: %d, %d, %d", posNumP, posNumN, posNum));
//		logger.debug(String.format("Neg: %d, %d, %d", negNumP, negNumN, negNum));
		
		if (posNumP != 0 && negNumP != 0 && posNumN != 0 && negNumN != 0) {			
			return ((double) sumNumP / sumNum) * (-((double) posNumP / sumNumP) * Math.log((double) posNumP / sumNumP) - ((double) negNumP / sumNumP) * Math.log((double) negNumP / sumNumP)) 
				 + ((double) sumNumN / sumNum) * (-((double) posNumN / sumNumN) * Math.log((double) posNumN / sumNumN) - ((double) negNumN / sumNumN) * Math.log((double) negNumN / sumNumN));
		} else if (posNumP != 0 && negNumP != 0) {
			return ((double) sumNumP / sumNum) * (-((double) posNumP / sumNumP) * Math.log((double) posNumP / sumNumP) - ((double) negNumP / sumNumP) * Math.log((double) negNumP / sumNumP));
		} else if (posNumN != 0 && negNumN != 0) {
			return ((double) sumNumN / sumNum) * (-((double) posNumN / sumNumN) * Math.log((double) posNumN / sumNumN) - ((double) negNumN / sumNumN) * Math.log((double) negNumN / sumNumN));
		} else return 0;	
	}
	
	public void genPropPQ()
	{
		Iterator<PropPair> iter = pairs.iterator();
		while (iter.hasNext()) {
			PropPair pp = iter.next();
//			logger.debug(pp);
			pp.infoGain = infoD - info(pp.propID1, pp.propID2);
		}
	}
	
	public class PropPairThread1 extends Thread
	{
		private int uriID1 = 0, uriID2 = 0;
		private Set<PropPair> pairs;
		private Set<String> ifps;
		private List<Itemset2> fpc2;
		
		private Set<String> PV;
		private Map<Integer, Map<String, List<String>>> tmpInstances;
		private Map<String, Double> maxSims;
		private boolean isNegFinder;
		
		public PropPairThread1(int uriID1, int uriID2, Set<PropPair> pairs, 
							   Set<String> ifps, List<Itemset2> fpc2, Set<String> PV, 
							   Map<Integer, Map<String, List<String>>> tmpInstances,
							   Map<String, Double> maxSims, boolean isNegFinder)
		{
			this.uriID1 = uriID1;
			this.uriID2 = uriID2;
			this.pairs = pairs;
			this.ifps = ifps;
			this.fpc2 = fpc2;
			
			this.PV = PV;
			this.tmpInstances = tmpInstances;
			this.maxSims = maxSims;
			this.isNegFinder = isNegFinder;
		}
		
		public String debugGetObjectListString(Map<String, List<String>> objectList) 
		{
			StringBuilder sb = new StringBuilder();
			for(String key : objectList.keySet()) {
				if(key.equals("l0")) sb.append("localname");
				else sb.append(BTC2011Negatives.getURIByID(key.substring(1)));
				sb.append(":");
				List<String> objList = objectList.get(key);
				for(String obj : objList) {
					if(obj.startsWith("u")) sb.append(BTC2011Negatives.getURIByID(obj.substring(1)));
					else sb.append(obj.substring(1));
					sb.append("\t");
				}
				sb.append("\n");
			}
			return sb.toString();
		}
		
		public void run()
		{
			try {
//				logger.debug(uriID1 + " " + uriID2 + " started.");
				Connection connBTC2011 = DBConnPool.getBTC2011();
				String sqlstr1 = "SELECT times FROM " + DatasetType.BTC2011_LOCALNAME_TIMES + " WHERE localname=?";
				PreparedStatement stmt1 = connBTC2011.prepareStatement(sqlstr1);

				String ln1 = null;
				if (tmpInstances.containsKey(uriID1)) {
					List<String> list1 = tmpInstances.get(uriID1).get("l0");
					if (list1 != null)
						ln1 = list1.get(0).substring(1);
				} else {
					ln1 = URIHelper.localname(uriID1, DatasetType.BTC2011);		
					if (ln1 != null && !ln1.trim().equals("")) {
						stmt1.setString(1, ln1);
						ResultSet rs1 = stmt1.executeQuery();
						while (rs1.next()) {
							int times = rs1.getInt(1);
							if (times > 100) 
								ln1 = null;
						}
						rs1.close();
					}
				}
				String ln2 = null;
				if (tmpInstances.containsKey(uriID2)) {
					List<String> list2 = tmpInstances.get(uriID2).get("l0");
					if (list2 != null)
						ln2 = list2.get(0).substring(1);
				} else {
					ln2 = URIHelper.localname(uriID2, DatasetType.BTC2011);
					if (ln2 != null && !ln2.trim().equals("")) {
						stmt1.setString(1, ln2);
						ResultSet rs1 = stmt1.executeQuery();
						while (rs1.next()) {
							int times = rs1.getInt(1);
							if (times > 100)
								ln2 = null;
						}
						rs1.close();
					}
				}
				stmt1.close();
				
//				logger.debug(uriID1 + " " + uriID2 + " " + ln1 + " " + ln2);
	
				String sqlstr2 = "SELECT DISTINCT p,o FROM " + DatasetType.BTC2011_QUADRUPLE + " WHERE s=?";
				PreparedStatement stmt2 = connBTC2011.prepareStatement(sqlstr2);
				
				Map<String, List<String>> objList1 = null;
				if (tmpInstances.containsKey(uriID1)) {
					objList1 = tmpInstances.get(uriID1);
				} else {
					objList1 = new LinkedHashMap<String, List<String>>();
					stmt2.setString(1, "u" + uriID1);
					ResultSet rs2 = stmt2.executeQuery();
					while (rs2.next()) {
						String pred1 = rs2.getString(1);
						
						if (pred1.equals("u" + BTC2011Prop.RDF_type_ID) || 
								pred1.equals("u" + BTC2011Prop.OWL_sameAs_ID) ||
								pred1.equals("u" + BTC2011Prop.SKOS_exactMatch_ID) ||
								ifps.contains(pred1))
							continue;
						
						String obj1 = rs2.getString(2);
						if (obj1.startsWith("b")) 
							continue;
						// else obj1 = obj1.substring(1);
						
						if (obj1 != null && !obj1.trim().equals("l")) {
							if (objList1.containsKey(pred1)) {
								List<String> list = objList1.get(pred1);
								list.add(obj1);
							} else {
								List<String> list = new ArrayList<String>();
								list.add(obj1);
								objList1.put(pred1, list);
							}
						}
					}
					rs2.close();
					if (ln1 != null) {
						List<String> list1 = new ArrayList<String>();
						list1.add("l" + ln1);
						objList1.put("l" + "0", list1); // localname
					}
					tmpInstances.put(uriID1, objList1);
				}
//				logger.debug(debugGetObjectListString(objList1));
//				logger.debug("is NegFinder:" + isNegFinder + "\n" + debugGetObjectListString(objList1));
				Map<String, List<String>> objList2 = null;
				if (tmpInstances.containsKey(uriID2)) {
					objList2 = tmpInstances.get(uriID2);
				} else {
					objList2 = new LinkedHashMap<String, List<String>>();
					stmt2.setString(1, "u" + uriID2);
					ResultSet rs2 = stmt2.executeQuery();
					while (rs2.next()) {
						String pred2 = rs2.getString(1);
						
						if (pred2.equals("u" + BTC2011Prop.RDF_type_ID) || 
								pred2.equals("u" + BTC2011Prop.OWL_sameAs_ID) ||
								pred2.equals("u" + BTC2011Prop.SKOS_exactMatch_ID) ||
								ifps.contains(pred2))
							continue;
						
						String obj2 = rs2.getString(2);
						if (obj2.startsWith("b")) 
							continue;
						// else obj2 = obj2.substring(1);
						
						if (obj2 != null && !obj2.trim().equals("l")) {
							if (objList2.containsKey(pred2)) {
								List<String> list = objList2.get(pred2);
								list.add(obj2);
							} else {
								List<String> list = new ArrayList<String>();
								list.add(obj2);
								objList2.put(pred2, list);
							}
						}
					}
					rs2.close();
					if (ln2 != null) {
						List<String> list2 = new ArrayList<String>();
						list2.add("l" + ln2);
						objList2.put("l" + "0", list2); // localname
					}
					tmpInstances.put(uriID2, objList2);
				}
				stmt2.close();
				connBTC2011.close();
				
//				logger.debug("is NegFinder:" + isNegFinder + "\n" + debugGetObjectListString(objList2));
				Iterator<String> iter1 = objList1.keySet().iterator();
//				logger.debug(uriID1 + "\t" + objList1);
//				logger.debug(uriID2 + "\t" + objList2);
				while (iter1.hasNext()) {
					String pred1 = iter1.next();
					int p1 = Integer.parseInt(pred1.substring(1));
					List<String> obj1 = objList1.get(pred1);
					Iterator<String> iter2 = objList2.keySet().iterator();
					while (iter2.hasNext()) {
						String pred2 = iter2.next();
						int p2 = Integer.parseInt(pred2.substring(1));
						List<String> obj2 = objList2.get(pred2);
						double maxSim = 0;
						String maxSimKey = uriID1 + ":" + p1 + ":" + uriID2 + ":" + p2;
						if (uriID1 > uriID2)
							maxSimKey = uriID2 + ":" + p2 + ":" + uriID1 + ":" + p1;
						if (maxSims.containsKey(maxSimKey)) {
							maxSim = maxSims.get(maxSimKey);
						} else {
							for (int i = 0; i < obj1.size(); ++i) {
								String o1 = obj1.get(i);
								String s1 = sw.removeStopword(ss.splitByDelimit(o1.substring(1)));
								for (int j = 0; j < obj2.size(); ++j) {
									String o2 = obj2.get(j);
									
									if (PV.contains(pred1 + ":" + o1) && 
											PV.contains(pred2 + ":" + o2))
										continue;
									
									String s2 = sw.removeStopword(ss.splitByDelimit(o2.substring(1)));
									// EditDistance, ISub, Jaccard, TF_IDF
									double sim = TF_IDF.getSimilarity(s1, s2);
									if (sim > maxSim)
										maxSim = sim;
								}
							}
							maxSims.put(maxSimKey, maxSim);
						}
						
						if (maxSim > 0.8) {
							PropPair pp = null;
							if(isNegFinder) {
								pp = (p1 <= p2) ? negContains(p1, p2) : negContains(p2, p1);
							}
							else {
								pp = (p1 <= p2) ? contains(p1, p2) : contains(p2, p1);
							}
							if (pp == null) {
								pp = (p1 <= p2) ? new PropPair(p1, p2, 1) : new PropPair(p2, p1, 1);
								pairs.add(pp);
							} else pp.times++;
							
							pp.addTerm(uriID1, obj1);
							pp.addTerm(uriID2, obj2);
							
							int p3 = -1, p4 = -1;
							List<String> counterObj1 = null, counterObj2 = null;
							for (int k = 0; k < fpc2.size(); ++k) {
								Itemset2 is = fpc2.get(k);
								if (p1 == is.getProp1()) {
									p3 = is.getProp2();
									counterObj1 = objList1.get("u" + p3);
								} else if (p1 == is.getProp2()) {
									p3 = is.getProp1();
									counterObj1 = objList1.get("u" + p3);
								}
								if (counterObj1 != null)
									break;
							}
							for (int k = 0; k < fpc2.size(); ++k) {
								Itemset2 is = fpc2.get(k);
								if (p2 == is.getProp1()) {
									p4 = is.getProp2();
									counterObj2 = objList1.get("u" + p4);
								} else if (p2 == is.getProp2()) {
									p4 = is.getProp1();
									counterObj2 = objList1.get("u" + p4);
								}
								if (counterObj2 != null)
									break;
							}
							if (p3 != -1 && p4 != -1) {
								//List<String> counterObj1 = objList1.get("u" + p3);
								//List<String> counterObj2 = objList2.get("u" + p4);
								//if (counterObj1 != null || counterObj2 != null) {
								PropPair counter = null;
									if(isNegFinder) {
										counter = (p3 <= p4) ? negContains(p3, p4) : negContains(p4, p3);
									}
									else {
										counter = (p3 <= p4) ? contains(p3, p4) : contains(p4, p3);
									}
									//logger.debug(p3 + " |||| " + p4);
									if (counter == null) {
										counter = (p3 <= p4) ? new PropPair(p3, p4, 1) : new PropPair(p4, p3, 1);
										pairs.add(counter);
									} else counter.times++;
											
									if (counterObj1 != null) 
										counter.addTerm(uriID1, counterObj1);
									if (counterObj2 != null) 
										counter.addTerm(uriID2, counterObj2);
								//}
							}
						}
					}
				}
			} catch (Throwable e) {
				e.printStackTrace();
				logger.error(e.getMessage());
			}
		}
		
		public Set<PropPair> getPropPairs() { return pairs; }
	}
}
