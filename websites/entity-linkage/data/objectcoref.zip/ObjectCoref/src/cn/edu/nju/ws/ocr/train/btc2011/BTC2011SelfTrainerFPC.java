package cn.edu.nju.ws.ocr.train.btc2011;

import java.io.*;
import java.sql.*;
import java.util.*;
import org.apache.log4j.*;
import cn.edu.nju.ws.ocr.datab.*;
import cn.edu.nju.ws.ocr.fpc.*;
import cn.edu.nju.ws.ocr.kernel.btc2011.*;
import cn.edu.nju.ws.ocr.rdf.*;
import cn.edu.nju.ws.ocr.train.*;
import cn.edu.nju.ws.ocr.util.*;

public class BTC2011SelfTrainerFPC extends SelfTrainerThread
{
	static Logger logger = Logger.getLogger(BTC2011SelfTrainerFPC.class);
	
	private int inputURIID;
	private Map<Integer, RDFInst> instances;
	private Map<Integer, Map<String, List<String>>> tmpInstances;
	private Map<String, Double> maxSims;
	private Set<String> ifps;
	private List<Itemset2> fpc2;
	private int iteration;
	private boolean withNeg;
	private boolean withFPC;
	
	public BTC2011SelfTrainerFPC(Map<Integer, RDFInst> inst, int inputURIID)
	{
		this.instances = inst;
		this.inputURIID = inputURIID;
		this.withFPC = true;
		this.withNeg = true;
		this.tmpInstances = Collections.synchronizedMap(new LinkedHashMap<Integer, Map<String, List<String>>>());
		this.maxSims = Collections.synchronizedMap(new HashMap<String, Double>());
		this.ifps = Collections.synchronizedSet(new HashSet<String>());
		
		storeSpecialProp();
		fpc2 = new FPC2Finder().btc2011_fpc2();
	}
	
	public BTC2011SelfTrainerFPC withoutFPC() 
	{
		this.withFPC = false;
		return this;
	}
	
	public BTC2011SelfTrainerFPC withoutNeg() 
	{
		this.withNeg = false;
		return this;
	}
	
	public void run()
	{	
		try {
			iteration = 0;
			Set<String> PP = Collections.synchronizedSet(new HashSet<String>());
			Set<String> PV = Collections.synchronizedSet(new HashSet<String>());
			while(iteration < 10){
				
				logger.info("iteration: " + iteration);
				logger.debug(debugGenInstancesString(instances.keySet()));
				
				Set<PropPair> pairs = getPropPairs(PV);
				logger.debug("size of found property pairs: " + pairs.size());
				logger.debug(debugGetPropertyPairsString(pairs, PP));
				
				PropPair maxPropPair = getMaxProp(pairs, PP);
				PropPair maxPropPairFPC = null; 
				Set<Integer> counterPropID1 = new HashSet<Integer>();
				Set<Integer> counterPropID2 = new HashSet<Integer>();
				if (maxPropPair == null) {
					break;
				} else if(withFPC) {
					maxPropPairFPC = getMaxPropFPC(maxPropPair, counterPropID1, counterPropID2, pairs);
				}
				logger.debug(String.format("***********max prop pair: %s", maxPropPair));
					
				String maxTerm = getMaxTerm(maxPropPair, PV);
				if (maxTerm == null) {
					String key = maxPropPair.propID1 + ":" + maxPropPair.propID2;
					PP.add(key);
					continue;
				}
				PV.add(maxPropPair.propID1 + ":" + maxTerm);
				PV.add(maxPropPair.propID2 + ":" + maxTerm);
				String maxTermFPC = getMaxFPCTerm(maxPropPairFPC, PP);
				logger.info(maxPropPair.propID1 + " | " + maxPropPair.propID2 + " : " + maxTerm);
				if (maxPropPairFPC != null)
					logger.info(" &" + maxPropPairFPC.propID1 + " | " + maxPropPairFPC.propID2 + " : " + maxTermFPC);
				
				int lnCount = getLocalNameCount(maxTerm.substring(1));
				if (maxPropPair.propID1 == 0 || maxPropPair.propID2 == 0) {
					logger.debug("localname");
					if(putInstanceByLocalName(lnCount, maxPropPair, maxTerm) == false) 
						break;
				} else {
					lnCount = 0;
				}
				if (maxPropPairFPC == null || maxTermFPC == null){
					logger.debug("NonFPC");
					if(putInstance(lnCount, maxPropPair, maxTerm) == false)
						break;
				} else {
					logger.debug("FPC");
					if(putInstanceFPC(lnCount, maxPropPair, maxTerm, maxPropPairFPC, maxTermFPC) == false)
						break;
				}
				
				iteration++;
			}
		}
		catch (Throwable e) {
			e.printStackTrace();
		}
	}
	
	private String debugGenInstancesString(Set<Integer> insts)
	{
		StringBuilder sb = new StringBuilder();
		for(int instID : insts) {
			String uri = BTC2011Negatives.getURIByID(String.valueOf(instID));
			if(uri != null) {
				sb.append(uri);
				sb.append("\n");
			}
		}
		return sb.toString();
	}
	
	private String debugGetPropertyPairsString(Set<PropPair> pairs, Set<String> PP) 
	{		
		List<PropPair> sortedPairs = new ArrayList<PropPair>(pairs);
		Collections.sort(sortedPairs);
		StringBuilder sb = new StringBuilder();
		int count = 0;
		for(PropPair pair : sortedPairs) {
			if(!PP.contains(pair.propID1 + ":" + pair.propID2)) {
				if(count ++ > 10) break;
				sb.append(pair);
				sb.append("\n");
			}
		}
		return sb.toString();
	}
	
	synchronized public Map<Integer, RDFInst> getInstances() { return instances; }
	
	private void storeSpecialProp()
	{
		try {
			Connection connBTC2011 = DBConnPool.getBTC2011();
			
			String sqlstr1 = "SELECT property FROM special_property WHERE category='i'";
			PreparedStatement stmt1 = connBTC2011.prepareStatement(sqlstr1);
			
			ResultSet rs1 = stmt1.executeQuery();
			while (rs1.next())
				ifps.add(rs1.getString(1));
			rs1.close();
			stmt1.close();
			connBTC2011.close();
					
		} catch (Throwable e) {
			logger.error(e.getMessage());
		}
	}
	
	private Set<PropPair> getPropPairs(Set<String> PV) throws SQLException
	{
		if (instances.size() > 20) {
			List<Integer> keys = new ArrayList<Integer>(instances.keySet());
			Random r = new Random(keys.size());
			List<Integer> samples = new ArrayList<Integer>(20);
			while (samples.size() < 20) {
				int uriID = keys.remove(r.nextInt(keys.size()));
				samples.add(uriID);
			}
			PropPairFinderByInfoGain ppf = new PropPairFinderByInfoGain(inputURIID, samples, ifps, 
					fpc2, PV, tmpInstances, maxSims, withNeg);
			ppf.execPropPair1();
			ppf.genPropPQ();
			return ppf.getPropPairs();

		} else {
			List<Integer> keys = new ArrayList<Integer>(instances.keySet());
			PropPairFinderByInfoGain ppf = new PropPairFinderByInfoGain(inputURIID, keys, ifps, 
					fpc2, PV, tmpInstances, maxSims, withNeg);
			ppf.execPropPair1();
			ppf.genPropPQ();
			return ppf.getPropPairs();
		}
	}
	
	private PropPair getMaxProp(Set<PropPair> pairs, Set<String> PP)
	{
		PropPair max = null;
		double maxInfoGain = 0;
		Iterator<PropPair> i = pairs.iterator();
		while (i.hasNext()) {
			PropPair pp = i.next();
			String key = pp.propID1 + ":" + pp.propID2;
			double infoGain = pp.infoGain;
			if(!withNeg) infoGain = pp.times;
			if (infoGain > maxInfoGain && !PP.contains(key)) {
				max = pp;
				maxInfoGain = infoGain;
			}
		}
		return max;
	}
	
	private PropPair getMaxPropFPC(PropPair max, Set<Integer> counterPropID1, Set<Integer> counterPropID2, Set<PropPair> pairs)
	{
		PropPair max2 = null;
		for (int k = 0; k < fpc2.size(); ++k) {
			Itemset2 is = fpc2.get(k);
			if (max.propID1 == is.getProp1()) {
				counterPropID1.add(is.getProp2());
			} else if (max.propID1 == is.getProp2()) {
				counterPropID1.add(is.getProp1());
			}		
			if (max.propID2 == is.getProp1()) {
				counterPropID2.add(is.getProp2());
			} else if (max.propID2 == is.getProp2()) {
				counterPropID2.add(is.getProp1());
			}
		}
		if (!counterPropID1.isEmpty() && !counterPropID2.isEmpty() ) {
			for (PropPair pp : pairs) {
				if (counterPropID1.contains(pp.propID1) &&  counterPropID2.contains(pp.propID2) ||
						counterPropID1.contains(pp.propID2) &&  counterPropID2.contains(pp.propID1)) {
					max2 = pp;
					break;
				}
			}
		}
		return max2;
	}
	
	private String getMaxTerm(PropPair max, Set<String> PV)
	{
		String maxTerm = null;
		int maxFreq = 0;
		for (String term : max.terms.keySet()) {	
			String key1 = max.propID1 + ":" + term;
			String key2 = max.propID2 + ":" + term;
			int freq = max.terms.get(term).size();
			//logger.info(max.propID1 + " | " + max.propID2 + " : " + term + " : " + freq);
			double pop = instances.keySet().size() > 20? (double) freq / 20: (double) freq / instances.keySet().size();
			if (freq > maxFreq && pop >= 0.1 && (!PV.contains(key1) || !PV.contains(key2))) {
				maxTerm = term;
				maxFreq = freq;
			}
		}
		return maxTerm;
	}
	
	private String getMaxFPCTerm(PropPair max2, Set<String> PP)
	{
		String maxTerm2 = null;
		int maxFreq2 = 0;
		if (max2 != null) {
			for (String term2 : max2.terms.keySet()) {
				int freq2 = max2.terms.get(term2).size();
				if (freq2 > maxFreq2) { 
					maxTerm2 = term2;
					maxFreq2 = freq2;
				}
			}
			if (maxTerm2 == null) {
				String key = max2.propID1 + ":" + max2.propID2;
				PP.add(key);
			}
		}
		return maxTerm2;
	}
	
	private int getLocalNameCount(String localname) throws Throwable
	{
		Connection connBTC2011 = DBConnPool.getBTC2011();
		
		int lnCount = 0;
		String sqlstr1 = "SELECT times FROM ln_times WHERE localname=?";
		PreparedStatement stmt1 = connBTC2011.prepareStatement(sqlstr1);
		stmt1.setString(1, localname);
		ResultSet rs1 = stmt1.executeQuery();
		while (rs1.next())
			lnCount = rs1.getInt(1);
		rs1.close();
		stmt1.close();
		connBTC2011.close();
		return lnCount;
	}
	
	private boolean putInstanceByLocalName(int lnCount, PropPair max, String maxTerm) throws Throwable
	{
		double discr = 0;
		if (lnCount != 0) {
			int maxFreq = max.terms.get(maxTerm).size();
			discr =(double) maxFreq /  lnCount;
			logger.info(max.propID1 + " | " + max.propID2 + " : " + maxTerm + " : " + discr + " : " + lnCount);
			if (discr < 0.1 && iteration != 0) {
				return false;
			} else {
				Connection connBTC2011 = DBConnPool.getBTC2011();
				String sqlstr2 = "SELECT uri_id FROM uri WHERE localname=?";
				PreparedStatement stmt2 = connBTC2011.prepareStatement(sqlstr2);
				stmt2.setString(1, maxTerm.substring(1));
				ResultSet rs2 = stmt2.executeQuery();
				while (rs2.next()) {
					int uriID = rs2.getInt(1);
					if (!instances.containsKey(uriID)) {
						//logger.debug("add instantce: "+nameFinder.uri(uriID));
						RDFInst inst = RDFFactory.getInstance().createRDFInst(uriID);
						inst.setGroup(RDFInst.EXTERNAL_IDX, 1);
						inst.setSimilarity(discr);
						instances.put(uriID, inst);
					} else {
						RDFInst inst = instances.get(uriID);
						if (inst.getSimilarity() < discr)
							inst.setSimilarity(discr);
					}
				}
				rs2.close();
				stmt2.close();
				connBTC2011.close();
			}
		}
		return true;
	}
	
	private boolean putInstance(int lnCount, PropPair max, String maxTerm) throws Throwable
	{
		Connection connBTC2011 = DBConnPool.getBTC2011();
		
		String sqlstr3 = "SELECT COUNT(DISTINCT s) FROM quadruple " +
				 "WHERE o=? AND (p=? OR p=?) AND s LIKE 'u%'";
		PreparedStatement stmt3 = connBTC2011.prepareStatement(sqlstr3);
		
		stmt3.setString(1, maxTerm);
		stmt3.setString(2, "u" + max.propID1);
		stmt3.setString(3, "u" + max.propID2);
		ResultSet rs3 = stmt3.executeQuery();
		int count = 0;
		while (rs3.next())
			count = rs3.getInt(1);
		rs3.close();
		stmt3.close();
		
		double discr = 0;
		if (count != 0) {
			int maxFreq = max.terms.get(maxTerm).size();
			discr = maxFreq / (double) (count + lnCount);
			logger.debug("Discr = " + max.propID1 + " | " + max.propID2 + " : " + maxTerm + ", " + maxFreq + ", " + (count + lnCount));
			if (discr < 0.1 && iteration != 0) 
				return false;
		}
		
		String sqlstr4 = "SELECT DISTINCT s FROM quadruple WHERE o=? AND p=? AND s LIKE 'u%'";
		PreparedStatement stmt4 = connBTC2011.prepareStatement(sqlstr4);
		stmt4.setString(1, maxTerm);
		stmt4.setString(2, "u" + max.propID1);
		ResultSet rs4 = stmt4.executeQuery();
		while (rs4.next()) {
			int uriID = Integer.parseInt(rs4.getString(1).substring(1));
			if (instances.containsKey(uriID)) {
				RDFInst inst = instances.get(uriID);
				inst.addSnippet(new RDFStmt("lthis", "u" + max.propID1, maxTerm));
				if (inst.getSimilarity() < discr)
					inst.setSimilarity(discr);
			} else {
				RDFInst inst = RDFFactory.getInstance().createRDFInst(uriID);
				inst.setGroup(RDFInst.EXTERNAL_IDX, 1);
				inst.addSnippet(new RDFStmt("lthis", "u" + max.propID1, maxTerm));
				inst.setSimilarity(discr);
				instances.put(uriID, inst);
				//logger.debug("add instantce: "+nameFinder.uri(uriID));
			}
		}
		rs4.close();
		
		stmt4.setString(1, maxTerm);
		stmt4.setString(2, "u" + max.propID2);
		rs4 = stmt4.executeQuery();
		while (rs4.next()) {
			int uriID = Integer.parseInt(rs4.getString(1).substring(1));
			if (instances.containsKey(uriID)) {
				RDFInst inst = instances.get(uriID);
				inst.addSnippet(new RDFStmt("lthis", "u" + max.propID2, maxTerm));
				if (inst.getSimilarity() < discr)
					inst.setSimilarity(discr);
			} else {
				RDFInst inst = RDFFactory.getInstance().createRDFInst(uriID);
				inst.setGroup(RDFInst.EXTERNAL_IDX, 1);
				inst.addSnippet(new RDFStmt("lthis", "u" + max.propID2, maxTerm));
				inst.setSimilarity(discr);
				instances.put(uriID, inst);
				//logger.debug("add instantce: "+nameFinder.uri(uriID));
			}
		}
		rs4.close();
		stmt4.close();
		connBTC2011.close();
		return true;
	}
	
	private boolean putInstanceFPC(int lnCount, PropPair max, String maxTerm, PropPair max2, String maxTerm2) throws Throwable
	{
		Connection connBTC2011 = DBConnPool.getBTC2011();
		
		String sqlstr3 = "SELECT DISTINCT s FROM quadruple " +
				 "WHERE o=? AND (p=? OR p=?) AND s LIKE 'u%'";
		
		PreparedStatement stmt3 = connBTC2011.prepareStatement(sqlstr3);
		stmt3.setString(1, maxTerm);
		stmt3.setString(2, "u" + max.propID1);
		stmt3.setString(3, "u" + max.propID2);
		Set<String> set1 = new HashSet<String>();
		ResultSet rs3 = stmt3.executeQuery();
		while (rs3.next())
			set1.add(rs3.getString(1));
		rs3.close();
		
		stmt3.setString(1, maxTerm2);
		stmt3.setString(2, "u" + max2.propID1);
		stmt3.setString(3, "u" + max2.propID2);
		Set<String> set2 = new HashSet<String>();
		rs3 = stmt3.executeQuery();
		while (rs3.next())
			set2.add(rs3.getString(1));
		rs3.close();
		stmt3.close();
		
		int count = 0;
		for (String s : set1) {
			if (set2.contains(s))
				count++;
		}
		double discr = 0;
		if (count != 0) {
			int combCount = 0;
			for (int maxURIID : max.terms.get(maxTerm).keySet()) {
				if (max2.terms.get(maxTerm2).containsKey(maxURIID))
					combCount++;
			}
							
			discr = combCount / (double) count;
			logger.debug("Discr = " + max.propID1 + " | " + max.propID2 + " : (" + maxTerm + "," + maxTerm2 + "), (" + combCount + "), " + count);
			if (discr < 0.1 && iteration != 0) 
				return false;
		}
		
		String sqlstr4 = "SELECT DISTINCT s FROM quadruple WHERE o=? AND p=? AND s LIKE 'u%'";
		PreparedStatement stmt4 = connBTC2011.prepareStatement(sqlstr4);
		String sqlstr5 = "SELECT COUNT(*) FROM quadruple WHERE s=? AND p=? AND o=?";
		PreparedStatement stmt5 = connBTC2011.prepareStatement(sqlstr5);
		
		stmt4.setString(1, maxTerm);
		stmt4.setString(2, "u" + max.propID1);
		ResultSet rs4 = stmt4.executeQuery();
		while (rs4.next()) {
			String s = rs4.getString(1);
			stmt5.setString(1, s);
			stmt5.setString(2, "u" + max2.propID1);
			stmt5.setString(3, maxTerm2);
			int exists = 0;
			ResultSet rs5 = stmt5.executeQuery();
			while (rs5.next()) 
				exists = rs5.getInt(1);
			rs5.close();
			if (exists > 0) {
				int uriID = Integer.parseInt(s.substring(1));
				if (instances.containsKey(uriID)) {
					RDFInst inst = instances.get(uriID);
					inst.addSnippet(new RDFStmt("lthis", "u" + max.propID1, maxTerm));
					inst.addSnippet(new RDFStmt("lthis", "u" + max2.propID1, maxTerm2));
					if (inst.getSimilarity() < discr)
						inst.setSimilarity(discr);
				} else {
					RDFInst inst = RDFFactory.getInstance().createRDFInst(uriID);
					inst.setGroup(RDFInst.EXTERNAL_IDX, 1);
					inst.addSnippet(new RDFStmt("lthis", "u" + max.propID1, maxTerm));
					inst.addSnippet(new RDFStmt("lthis", "u" + max2.propID1, maxTerm2));
					inst.setSimilarity(discr);
					instances.put(uriID, inst);
					//logger.debug("add instantce: "+nameFinder.uri(uriID));
				}
			}
		}

		rs4.close();
		
		stmt4.setString(1, maxTerm);
		stmt4.setString(2, "u" + max.propID2);
		rs4 = stmt4.executeQuery();
		while (rs4.next()) {
			String s = rs4.getString(1);
			stmt5.setString(1, s);
			stmt5.setString(2, "u" + max2.propID2);
			stmt5.setString(3, maxTerm2);
			int exists = 0;
			ResultSet rs5 = stmt5.executeQuery();
			while (rs5.next())
				exists = rs5.getInt(1);
			rs5.close();
			if (exists > 0) {
				int uriID = Integer.parseInt(s.substring(1));
				if (instances.containsKey(uriID)) {
					RDFInst inst = instances.get(uriID);
					inst.addSnippet(new RDFStmt("lthis", "u" + max.propID2, maxTerm));
					inst.addSnippet(new RDFStmt("lthis", "u" + max2.propID2, maxTerm2));
					if (inst.getSimilarity() < discr)
						inst.setSimilarity(discr);
				} else {
					RDFInst inst = RDFFactory.getInstance().createRDFInst(uriID);
					inst.setGroup(RDFInst.EXTERNAL_IDX, 1);
					inst.addSnippet(new RDFStmt("lthis", "u" + max.propID2, maxTerm));
					inst.addSnippet(new RDFStmt("lthis", "u" + max2.propID2, maxTerm2));
					inst.setSimilarity(discr);
					instances.put(uriID, inst);
					//logger.debug("add instantce: "+nameFinder.uri(uriID));
				}
			}
		}
		rs4.close();
		stmt4.close();
		stmt5.close();
		connBTC2011.close();
		return true;
	}

	public static List<String> kernel(String inputURI) 
	{
		List<String> corefed = new ArrayList<String> ();
		PropertyConfigurator.configure(BTC2011SelfTrainerFPC.class.getResource("/config/log4j.properties"));
		DBParam.init();
		
		long start = System.currentTimeMillis();
		
		int inputURIID = URIHelper.uriID(inputURI, DatasetType.BTC2011);
		BTC2011KernelBuilder kb = new BTC2011KernelBuilder(inputURIID);
		kb.query();
		Map<Integer, RDFInst> instances = kb.getKernel();
		
		long end = System.currentTimeMillis();
		int i = 0;
		for (int instID : instances.keySet()) {
			String corefedURI = String.format("%d %s", (++i), URIHelper.uri(instID, DatasetType.BTC2011));
			System.out.println(corefedURI);
			corefed.add(corefedURI);
		}
		System.out.println("running_time=" + (end - start));
		corefed.add(0, "time:" + (end - start) / 1000.0);
		return corefed;
	}

	public static List<String> sameas_org(String inputURI) 
	{
		List<String> corefed = new ArrayList<String> ();
		PropertyConfigurator.configure(BTC2011SelfTrainerFPC.class.getResource("/config/log4j.properties"));
		DBParam.init();
		
		long start = System.currentTimeMillis();
		
		int inputURIID = URIHelper.uriID(inputURI, DatasetType.BTC2011);
		sameas_org kb = new sameas_org(inputURIID);
		kb.query();
		Map<Integer, RDFInst> instances = kb.getInstances();
		
		long end = System.currentTimeMillis();
		int i = 0;
		for (int instID : instances.keySet()) {
			String corefedURI = String.format("%d %s", (++i), URIHelper.uri(instID, DatasetType.BTC2011));
			System.out.println(corefedURI);
			corefed.add(corefedURI);
		}
		System.out.println("running_time=" + (end - start));
		corefed.add(0, "time:" + (end - start) / 1000.0);
		return corefed;
	}
	
	public static List<String> coref(String inputURI, boolean withFPC, boolean withNeg) 
	{
		List<String> corefed = new ArrayList<String> ();
		PropertyConfigurator.configure(BTC2011SelfTrainerFPC.class.getResource("/config/log4j.properties"));
		DBParam.init();
		
		long start = System.currentTimeMillis();
		
		int inputURIID = URIHelper.uriID(inputURI, DatasetType.BTC2011);
		
		Map<Integer, RDFInst> instances = new LinkedHashMap<Integer, RDFInst>();
		
		BTC2011KernelBuilder kb = new BTC2011KernelBuilder(inputURIID);
		kb.query();
	
		Map<Integer, RDFInst> instances1 = kb.getKernel();
		
		logger.debug(instances1.size());
	
	
		for (Integer uriID : instances1.keySet()) 
			instances.put(uriID, instances1.get(uriID));		
	
		//logger.debug(instances.size());
	
		BTC2011SelfTrainerFPC st = new BTC2011SelfTrainerFPC(instances, inputURIID);
		if(!withFPC)
			st.withoutFPC();
		if(!withNeg)
			st.withoutNeg();
		st.run();
	
		long end = System.currentTimeMillis();
		int i = 0;
		for (RDFInst inst : st.getInstances().values()) {
			String corefedURI = String.format("%d %s", (++i), URIHelper.uri(inst.getURIID(), DatasetType.BTC2011));
			System.out.println(corefedURI);
			corefed.add(corefedURI);
		}
		System.out.println("running_time=" + (end - start));
		corefed.add(0, "time:" + (end - start) / 1000.0);
		return corefed;
	}
	
	public static void printResult(String fileName, List<String> results) {
		PrintWriter output = null;
		try {
			output = new PrintWriter(new File(fileName));
			for(String result : results) {
				output.println(result);
				output.flush();
			}
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			if(output != null) output.close();
		}
	}
	
	public static void startCoref(boolean withFPC, boolean withNeg, boolean kernel) {
		List<String> uris = readURIsFromFile();
		for(int i = 0; i < uris.size(); i++) {
			String uri = uris.get(i);
			List<String> corefed = null;
			String path = "2014/ocr";
			if(kernel) {
				corefed = kernel(uri);
                path += "_kernel";
			} else {
                corefed = coref(uri, withFPC, withNeg);
                if (withFPC)
                	path += "_FPC";
                if (withNeg)
                	path += "_NEG";
			}
			printResult(path + "/" + i, corefed);
		}
	}
	
	public static void startSameas() {
		List<String> uris = readURIsFromFile();
		for(int i = 0; i < uris.size(); i++) {
			String uri = uris.get(i);
			List<String> corefed = sameas_org(uri);
			String path = "2014/sameas_org";
			printResult(path + "/" + i, corefed);
		}
	}
	
	public static List<String> readURIsFromFile() {
		List<String> uris = new ArrayList<String> ();
		Scanner input = null;
		File file = null;
		try {
			file = new File("btc2011_top50_query_uris.txt");
			input = new Scanner(file);
			while(input.hasNext()) {
				String line = input.nextLine().trim();
				if(line.startsWith("http://")) {
					uris.add(line);
				}
			}
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			if(input != null) {
				input.close();
			}
		}
		return uris;
	}

	
	public static void main(String args[]) throws SQLException 
	{
		startCoref(true, true, true);
	}
}
