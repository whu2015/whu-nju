package cn.edu.nju.ws.ocr.datab;

import java.net.*;
import java.util.*;
import org.apache.log4j.*;
import com.hp.hpl.jena.ontology.*;
import com.hp.hpl.jena.query.*;
import com.hp.hpl.jena.rdf.model.*;

public class FalconsAPI 
{
	static Logger logger = Logger.getLogger(FalconsAPI.class);
	
	public static final String FalconsAPI_URL = "http://ws.nju.edu.cn/falcons/api/objectsearch.jsp?";
	
	// top-100 objects matched with a keyword query, under a specific type (optional).
	public static List<String> search(String keyword)
	{
		if (keyword == null || keyword.equals(""))
			return null;
		
		HttpURLConnection conn = null;
		try {
			String qstr = String.format("query=%s", URLEncoder.encode(keyword, "UTF-8"));
			conn = (HttpURLConnection) new URL(FalconsAPI_URL + qstr).openConnection();
			
			if (conn.getResponseCode() != 200) // OK
				return null;
				
			OntDocumentManager mgr = new OntDocumentManager();
			mgr.setProcessImports(false);
		    OntModelSpec spec = new OntModelSpec(OntModelSpec.RDFS_MEM);
		    spec.setDocumentManager(mgr);
		    
		    OntModel model = ModelFactory.createOntologyModel(spec, null);
		    model.read(conn.getInputStream(), "");
		    
		    String querystr = " PREFIX rdf: <http://www.w3.org/1999/02/22-rdf-syntax-ns#> " 
        					+ " SELECT ?o "
        					+ " WHERE { ?s rdf:type rdf:Seq ; ?p ?o . "
        					+ " FILTER regex(Str(?p), \"http://www.w3.org/1999/02/22-rdf-syntax-ns#_[0-9]+\", \"i\") } "
        					+ " ORDER BY ?p";
		    Query query = QueryFactory.create(querystr);
		    QueryExecution qe = QueryExecutionFactory.create(query, model);
		    
		    List<String> uris = new ArrayList<String>();
		    ResultSet rs = qe.execSelect();
		    while (rs.hasNext()) {
		    	QuerySolution qs = rs.nextSolution();
		    	uris.add(qs.getResource("o").getURI());
		    }
		    qe.close();
		    model.close();
		    
		    return uris;
		} catch (Throwable e) {
			logger.error(e.getMessage());
			return null;
		} finally {
			conn.disconnect();
		}
	}
	
	public static void main(String args[])
	{
		PropertyConfigurator.configure(FalconsAPI.class.getResource("/config/log4j.properties"));
		
		String keyword = "Wikipedia";
		
		List<String> uris = FalconsAPI.search(keyword);		
		for (int i = 0; i < uris.size(); ++i) 
			System.out.println(i + " " + uris.get(i));
	} 
}
