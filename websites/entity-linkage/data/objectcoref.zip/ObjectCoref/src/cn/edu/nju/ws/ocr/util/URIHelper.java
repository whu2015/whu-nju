package cn.edu.nju.ws.ocr.util;

import java.sql.*;
import org.apache.log4j.*;
import cn.edu.nju.ws.ocr.cache.*;
import cn.edu.nju.ws.ocr.datab.*;
import cn.edu.nju.ws.ocr.rdf.*;

public class URIHelper
{
	static Logger logger = Logger.getLogger(URIHelper.class);
	
	public static String uri(int uriID, String source)
	{
		if (uriID <= 0)
			return null;
		
		try {
			Connection conn = null;
			PreparedStatement stmt1 = null;
			
			if (source.equalsIgnoreCase(DatasetType.FALCONETV05)) {
				conn = DBConnPool.getFalconetV05();
				String sqlstr1 = "SELECT uri FROM " + DatasetType.FALCONETV05_URI + " WHERE id=?";
				stmt1 = conn.prepareStatement(sqlstr1);
			} else if (source.equalsIgnoreCase(DatasetType.BTC2011)) {
				conn = DBConnPool.getBTC2011();
				String sqlstr1 = "SELECT uri FROM " + DatasetType.BTC2011_URI + " WHERE uri_id=?";
				stmt1 = conn.prepareStatement(sqlstr1);
			} else return null;

			stmt1.setInt(1, uriID);
			
			String uri = null;
			ResultSet rs1 = stmt1.executeQuery();
			while (rs1.next()) 
				uri = rs1.getString(1);	
			rs1.close();
			stmt1.close();
			conn.close();
			
			return uri;
		} catch (Throwable e) {
			logger.error(e.getMessage());
			return null;
		}
	}
	
	public static int uriID(String uri, String source)
	{
		if (uri == null || uri.equals(""))
			return 0;
		
		try {
			Connection conn = null;
			PreparedStatement stmt1 = null;
			
			if (source.equalsIgnoreCase(DatasetType.FALCONETV05)) {
				conn = DBConnPool.getFalconetV05();
				String sqlstr1 = "SELECT id FROM " + DatasetType.FALCONETV05_URI + " WHERE uri=?";
				stmt1 = conn.prepareStatement(sqlstr1);
			} else if (source.equalsIgnoreCase(DatasetType.BTC2011)) {
				conn = DBConnPool.getBTC2011();
				String sqlstr1 = "SELECT uri_id FROM " + DatasetType.BTC2011_URI + " WHERE uri=?";
				stmt1 = conn.prepareStatement(sqlstr1);
			} else return 0;
			
			stmt1.setString(1, uri);
			
			int uriID = 0;
			ResultSet rs1 = stmt1.executeQuery();
			while (rs1.next()) 
				uriID = rs1.getInt(1);
			rs1.close();
			stmt1.close();
			conn.close();
			
			return uriID;
		} catch (Throwable e) {
			logger.error(e.getMessage());
			return 0;
		}
	}
	
	public static String namespace(int uriID, String source)
	{
		String uri = uri(uriID, source);
		return namespace(uri);
	}
	
	public static String namespace(String uri) 
	{ 
		String[] ns_ln = namespace_localname(uri);
		if (ns_ln != null) 
			return ns_ln[0];
		return null;
	}
	
	public static String localname(int uriID, String source)
	{
		String uri = uri(uriID, source);
		return localname(uri);
	}
	
	public static String localname(String uri) 
	{ 
		String[] ns_ln = namespace_localname(uri);
		if (ns_ln != null) 
			return ns_ln[1];
		return null;
	}
	
	// ns_ln[] = { namespace, localname }
	public static String[] namespace_localname(int uriID, String source)
	{
		String uri = uri(uriID, source);
		return namespace_localname(uri);
	}
	
	// ns_ln[] = { namespace, localname }
	public static String[] namespace_localname(String uri)
	{
		if (uri == null || uri.equals("")) {
			return null;
		} else {
			String ns = null, ln = null;
			int index = uri.lastIndexOf("#");
			if (index != -1) {
				ns = uri.substring(0, index + 1);
				ln = uri.substring(index + 1);
			} else { // sometimes too aggressive, never perfect
				index = uri.lastIndexOf("/");
				if (index != -1) {
					ns = uri.substring(0, index + 1);
					ln = uri.substring(index + 1);
				} else {
					index = uri.lastIndexOf(":");
					if (index != -1) {
						ns = uri.substring(0, index + 1);
						ln = uri.substring(index + 1);
					} else ns = uri; // default
				}
			}
			String[] ns_ln = {ns, ln};
			return ns_ln;
		}
	}
	
	public static String qname(int uriID, String source)
	{
		String uri = uri(uriID, source);
		return qname(uri);
	}

	public static String qname(String uri)
	{
		String[] ns_ln = namespace_localname(uri);
		if (ns_ln != null) {
			// in-memory
			String prefix = SpecialPrefix.specialPrefix(ns_ln[0]);
			if (prefix != null) {
				return prefix + ":" + ns_ln[1];
			} else {
				// local database
				// but may (stupidly) call PrefixAPI if nonexistent
				// thus will be time-consuming, and often lead to nothing/ambiguity
				prefix = PrefixLogger.write(ns_ln[0]);
				if (prefix != null) {
					return prefix + ":" + ns_ln[1];	
				} else return uri; // no qname
			}
		}
		return null;
	}
	
	public static void main(String args[])
	{
		PropertyConfigurator.configure(URIHelper.class.getResource("/config/log4j.properties"));
		
		String uri = "http://ws.nju.edu.cn/~whu";
		String uri2 = "http://ws.nju.edu.cn/";
		String uri3 = "http://ws.nju.edu.cn";
		String uri4 = "ws.nju.edu.cn";
		
		System.out.println(namespace_localname(uri)[0]);
		System.out.println(namespace_localname(uri2)[0]);
		System.out.println(namespace_localname(uri3)[0]);
		System.out.println(namespace_localname(uri4)[0]);
	}
}
