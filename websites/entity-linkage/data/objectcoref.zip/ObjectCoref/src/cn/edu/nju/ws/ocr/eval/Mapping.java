package cn.edu.nju.ws.ocr.eval;

import org.apache.log4j.*;

public class Mapping
{
	static Logger logger = Logger.getLogger(Mapping.class);
	
    private String entity1;
    private String entity2;
    private String relation;
    private double measure;

    public Mapping(String e1, String e2, String r, double sim)
    {
        entity1 = e1;
        entity2 = e2;
        relation = r;
        measure = sim;
    }

    public Mapping(String e1, String e2, double sim)
    {
        entity1 = e1;
        entity2 = e2;
        relation = "=";
        measure = sim;
    }

    public Mapping(String e1, String e2)
    {
        entity1 = e1;
        entity2 = e2;
        relation = "=";
        measure = 1.0;
    }

    public String entity1() { return entity1; }

    public void setEntity1(String e1) { entity1 = e1; }

    public String entity2() { return entity2; }

    public void setEntity2(String e2) { entity2 = e2; }
    
    public double measure() { return measure; }

    public void setMeasure(double sim) { measure = sim; }

    public String relation() { return relation; }

    public void setRelation(String r) { relation = r; }
    
    public boolean equals(Mapping mapping) // symmetric
    {
        if (entity1.equals(mapping.entity1()) 
        		&& entity2.equals(mapping.entity2())) 
            return true;
        return false;
    }
    
    public String toString() { return entity1 + " : " + entity2; }
}
