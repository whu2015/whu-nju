package cn.edu.nju.ws.ocr.fpc;

import org.apache.log4j.*;

public class Itemset3
{
	static Logger logger = Logger.getLogger(Itemset3.class);
	
	private int prop1, prop2, prop3;
	
	public Itemset3(int p1, int p2, int p3)
	{
		this.prop1 = p1;
		this.prop2 = p2;
		this.prop3 = p3;
	}
	
	public int getProp1() { return prop1; }
	
	public int getProp2() { return prop2; }
	
	public int getProp3() { return prop3; }
}
