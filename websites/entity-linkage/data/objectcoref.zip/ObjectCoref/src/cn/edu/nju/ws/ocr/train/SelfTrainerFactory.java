package cn.edu.nju.ws.ocr.train;

import java.util.*;
import org.apache.log4j.*;
import cn.edu.nju.ws.ocr.datab.*;
import cn.edu.nju.ws.ocr.rdf.*;
import cn.edu.nju.ws.ocr.train.btc2011.*;
//import cn.edu.nju.ws.ocr.train.falconetV05.*;

public class SelfTrainerFactory 
{	
	static Logger logger = Logger.getLogger(SelfTrainerFactory.class);
	
	private static SelfTrainerFactory instance;
	
	synchronized public static SelfTrainerFactory getInstance() 
	{
		if (instance == null) 
			instance = new SelfTrainerFactory();
		return instance;
	}
	
	private SelfTrainerFactory() {}
	
	public SelfTrainerThread createSelfTrainer(int inputURIID, 
			Map<Integer, RDFInst> inst, String source, TrainMode mode) 
	{
		SelfTrainerThread selfTrainerThread = null;
		if (source.equalsIgnoreCase(DatasetType.FALCONETV05)) {
			/* switch (mode) {
			case SelfTrainer:
				selfTrainerThread = new FalconetV05SelfTrainer(inst);
				break;
			case SelfTrainerFPC:
				selfTrainerThread = new FalconetV05SelfTrainerFPC(inst);
				break;
			case SelfTrainer_CC:
				selfTrainerThread = new FalconetV05SelfTrainer_CC(inst.get(inputURIID), inst);
				break;
			case SelfTrainerFPC_CC:
				selfTrainerThread = new FalconetV05SelfTrainerFPC_CC(inst.get(inputURIID), inst);
				break;
			} */ // due to the crash of Falcons
		} else if (source.equalsIgnoreCase(DatasetType.BTC2011)) {
			selfTrainerThread = new BTC2011SelfTrainerFPC(inst, inputURIID);
		}
		return selfTrainerThread;
	}
}
