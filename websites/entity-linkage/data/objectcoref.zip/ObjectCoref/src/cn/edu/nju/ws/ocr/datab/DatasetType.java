package cn.edu.nju.ws.ocr.datab;

import org.apache.log4j.*;

public class DatasetType
{
	static Logger logger = Logger.getLogger(DatasetType.class);
	
	public static final String OBJECTCOREF = "objectcoref";
	
	public static final String FALCONETV05 = "falconet_v05";
	
	public static final String FALCONETV05_URI = FALCONETV05 + ".uri";
	
	public static final String FALCONETV05_QUADRUPLE = FALCONETV05 + ".quadruple";
	
	public static final String FALCONETV05_TYPE = FALCONETV05 + ".type";
	
	// "range" is a reserved keyword in MySQL
	public static final String FALCONETV05_RANGE = FALCONETV05 + ".range";

	public static final String FALCONETV05_LOCALNAME_TIMES = OBJECTCOREF + ".ln_times";
	
	/* -------------------- */
	
	public static final String BTC2011 = "btc2011";
	
	public static final String BTC2011_URI = BTC2011 + ".uri";
	
	public static final String BTC2011_DOC = BTC2011 + ".doc";
	
	public static final String BTC2011_QUADRUPLE = BTC2011 + ".quadruple";
	
	public static final String BTC2011_CARDINALITY = BTC2011 + ".cardinality";
	
	public static final String BTC2011_CARDINALITY_TRIPLE = BTC2011 + ".card_triple";
	
	public static final String BTC2011_FUNCTIONAL_PROPERTY_TRIPLE = BTC2011 + ".fp_triple";
	
	public static final String BTC2011_INVERSE_FUNCTIONAL_PROPERTY_TRIPLE = BTC2011 + ".ifp_triple";
	
	public static final String BTC2011_HAS_KEY_TRIPLE = BTC2011 + ".haskey_triple";
	
	public static final String BTC2011_SAME_AS = BTC2011 + ".sameas";
	
	public static final String BTC2011_CLOSE_MATCH = BTC2011 + ".closematch";
	
	public static final String BTC2011_EXACT_MATCH = BTC2011 + ".exactmatch";
	
	public static final String BTC2011_SIMILAR_TO = BTC2011 + ".similarto";
	
	public static final String BTC2011_HAS_EXACT_SYNONYM = BTC2011 + ".hasexactsynonym";
	
	public static final String BTC2011_LOCALNAME_TIMES = BTC2011 + ".ln_times";
}
