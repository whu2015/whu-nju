package cn.edu.nju.ws.ocr.fpc;

import java.sql.*;
import java.util.*;
import java.util.concurrent.*;
import org.apache.log4j.*;
import cn.edu.nju.ws.ocr.datab.*;
import cn.edu.nju.ws.ocr.rdf.*;

public class DatatypeGrouper 
{
	static Logger logger = Logger.getLogger(DatatypeGrouper.class);
	
	public Map<String, List<Integer>> groups;
	
	public DatatypeGrouper()
	{
		this.groups = new HashMap<String, List<Integer>>();
		
		// XSD datatypes, see http://www.w3.org/TR/xmlschema-2/type-hierarchy.gif
		
		List<Integer> floats = new ArrayList<Integer>();
		floats.add(FalconetV05Prop.XSD_float_ID); 
		floats.add(FalconetV05Prop.XSD_double_ID);
		groups.put("f", floats);
		
		List<Integer> ints = new ArrayList<Integer>();
		ints.add(FalconetV05Prop.XSD_decimal_ID); 
		ints.add(FalconetV05Prop.XSD_integer_ID); 
		ints.add(FalconetV05Prop.XSD_nonPositiveInteger_ID); 
		ints.add(FalconetV05Prop.XSD_negativeInteger_ID); 
		ints.add(FalconetV05Prop.XSD_long_ID); 
		ints.add(FalconetV05Prop.XSD_int_ID); 
		ints.add(FalconetV05Prop.XSD_short_ID); 
		ints.add(FalconetV05Prop.XSD_byte_ID); 
		ints.add(FalconetV05Prop.XSD_nonNegativeInteger_ID); 
		ints.add(FalconetV05Prop.XSD_positiveInteger_ID); 
		ints.add(FalconetV05Prop.XSD_unsignedLong_ID);
		ints.add(FalconetV05Prop.XSD_unsignedInt_ID);
		ints.add(FalconetV05Prop.XSD_unsignedShort_ID);
		ints.add(FalconetV05Prop.XSD_unsignedByte_ID);
		groups.put("i", ints);
		
		List<Integer> dates = new ArrayList<Integer>();
		dates.add(FalconetV05Prop.XSD_duration_ID); 
		dates.add(FalconetV05Prop.XSD_dateTime_ID); 
		dates.add(FalconetV05Prop.XSD_time_ID); 
		dates.add(FalconetV05Prop.XSD_date_ID); 
		dates.add(FalconetV05Prop.XSD_gYearMonth_ID); 
		dates.add(FalconetV05Prop.XSD_gYear_ID); 
		dates.add(FalconetV05Prop.XSD_gMonthDay_ID); 
		dates.add(FalconetV05Prop.XSD_gDay_ID); 
		dates.add(FalconetV05Prop.XSD_gMonth_ID); 
		groups.put("d", dates);
		
		List<Integer> strings = new ArrayList<Integer>();
		strings.add(FalconetV05Prop.XSD_string_ID); 
		strings.add(FalconetV05Prop.XSD_normalizedString_ID); 
		strings.add(FalconetV05Prop.XSD_token_ID); 
		strings.add(FalconetV05Prop.XSD_language_ID);
		strings.add(FalconetV05Prop.XSD_Name_ID);  
		strings.add(FalconetV05Prop.XSD_NMTOKEN_ID); 
		strings.add(FalconetV05Prop.XSD_NCName_ID); 
		strings.add(FalconetV05Prop.XSD_ID_ID); 
		strings.add(FalconetV05Prop.XSD_IDREF_ID); 
		strings.add(FalconetV05Prop.XSD_ENTITY_ID);
		groups.put("s", strings);
		
		List<Integer> binaries = new ArrayList<Integer>();
		binaries.add(FalconetV05Prop.XSD_boolean_ID);
		binaries.add(FalconetV05Prop.XSD_base64Binary_ID); 
		binaries.add(FalconetV05Prop.XSD_hexBinary_ID);
		groups.put("b", binaries);
		
		List<Integer> uris = new ArrayList<Integer>();
		uris.add(FalconetV05Prop.XSD_anyURI_ID); 
		uris.add(FalconetV05Prop.XSD_QName_ID);
		groups.put("u", uris);
		
		List<Integer> things = new ArrayList<Integer>();
		things.add(FalconetV05Prop.XSD_NOTATION_ID); 
		things.add(FalconetV05Prop.OWL_Thing_ID);
		groups.put("t", things);
	}

	public void execDatatype1()
	{
		try {
			Connection connObjectCoref = DBConnPool.getObjectCoref();
			
			String sqlstr1 = "SELECT DISTINCT prop_id FROM inst_prop";
			PreparedStatement stmt1 = connObjectCoref.prepareStatement(sqlstr1);
			
			Connection connFalconetV05 = DBConnPool.getFalconetV05();
			String sqlstr2 = "SELECT DISTINCT range_uri_id FROM " + DatasetType.FALCONETV05_RANGE 
						   + " WHERE property_uri_id=?";
			PreparedStatement stmt2 = connFalconetV05.prepareStatement(sqlstr2);
			
			String sqlstr3 = "INSERT INTO prop_info(prop_id,range_id) VALUES(?,?)";
			PreparedStatement stmt3 = connObjectCoref.prepareStatement(sqlstr3);
			
			ResultSet rs1 = stmt1.executeQuery();
			while (rs1.next()) {
				int propID = rs1.getInt(1);
				stmt2.setInt(1, propID);
				ResultSet rs2 = stmt2.executeQuery();
				while (rs2.next()) {
					int rangeID = rs2.getInt(1);
					stmt3.setInt(1, propID);
					stmt3.setInt(2, rangeID);
					stmt3.addBatch();
				}
				stmt3.executeBatch();
				rs2.close();
			}
			rs1.close();
			stmt1.close();
			stmt2.close();
			stmt3.close();
			connObjectCoref.close();
			connFalconetV05.close();
		} catch (Throwable e) {
			logger.error(e.getMessage());
		}
	}
	
	public void execDatatype2()
	{
		try {
			Connection connObjectCoref = DBConnPool.getObjectCoref();
			
			String sqlstr1 = "SELECT id,range_id FROM prop_info";
			PreparedStatement stmt1 = connObjectCoref.prepareStatement(sqlstr1);
			String sqlstr2 = "UPDATE prop_info SET range_group=? WHERE id=?";
			PreparedStatement stmt2 = connObjectCoref.prepareStatement(sqlstr2);
			
			ResultSet rs1 = stmt1.executeQuery();
			while (rs1.next()) {
				int id = rs1.getInt(1);
				int rangeID = rs1.getInt(2);
				boolean isFound = false;
				Iterator<String> iter = groups.keySet().iterator();
				while (iter.hasNext()) {
					String key = iter.next();
					List<Integer> ranges = groups.get(key);
					if (ranges.contains(rangeID)) {
						stmt2.setString(1, key);
						stmt2.setInt(2, id);
						stmt2.executeUpdate();
						isFound = true;
						break;
					} 
				}
				if (!isFound) {
					stmt2.setString(1, "u");
					stmt2.setInt(2, id);
					stmt2.executeUpdate();
				}
			}
			rs1.close();
			stmt1.close();
			stmt2.close();
			connObjectCoref.close();
		} catch (Throwable e) {
			logger.error(e.getMessage());
		}
	}
	
	public void execDatatype3()
	{
		try {
			Connection connObjectCoref = DBConnPool.getObjectCoref();
			
			String sqlstr1 = "SELECT DISTINCT prop_id FROM prop_info";
			PreparedStatement stmt1 = connObjectCoref.prepareStatement(sqlstr1);
			
			List<Integer> list = Collections.synchronizedList(new ArrayList<Integer>());
			ResultSet rs1 = stmt1.executeQuery();
			while (rs1.next()) {
				int propID = rs1.getInt(1);
				list.add(propID);
			}
			rs1.close();
			stmt1.close();
			connObjectCoref.close();
			
			BlockingQueue<Runnable> queue = new LinkedBlockingQueue<Runnable>();  
			ThreadPoolExecutor exec = new ThreadPoolExecutor(4, 5, 1, TimeUnit.DAYS, queue);
			
			for (int i = list.size() - 1; i >= 0; --i) {
				int propID = list.get(i);
				DttpGrouperThread1 dgt1 = new DttpGrouperThread1(propID);
				exec.execute(dgt1);
			}
			exec.shutdown();
		} catch (Throwable e) {
			logger.error(e.getMessage());
		}
	}
	
	public static void main(String args[])
	{
		PropertyConfigurator.configure(DatatypeGrouper.class.getResource("/config/log4j.properties"));
		DBParam.init();
		
		//DatatypeGrouper dg = new DatatypeGrouper();
		//dg.execDatatype1();
		//dg.execDatatype2();
		//dg.execDatatype3();
	}
	
	public class DttpGrouperThread1 implements Runnable
	{
		private int propID;
		
		public DttpGrouperThread1(int id) { this.propID = id; }
		
		public void run()
		{
			try {
				Connection connObjectCoref = DBConnPool.getObjectCoref();
				
				String sqlstr1 = "UPDATE prop_info SET av=?,ac=? WHERE prop_id=?";
				PreparedStatement stmt1 = connObjectCoref.prepareStatement(sqlstr1);
				
				float [] values = calc();
				logger.debug("prop_id=" + propID + ", av=" + values[0] + ", ac=" + values[1]);
				
				stmt1.setFloat(1, values[0]);
				stmt1.setFloat(2, values[1]);
				stmt1.setInt(3, propID);
				stmt1.executeUpdate();
				connObjectCoref.close();
			} catch (Throwable e) {
				logger.error(e.getMessage());
			}
		}
		
		private float[] calc()
		{
			try {
				Connection connObjectCoref = DBConnPool.getObjectCoref();
				
				String sqlstr1 = "SELECT COUNT(DISTINCT value) FROM inst_prop WHERE prop_id=?";
				PreparedStatement stmt1 = connObjectCoref.prepareStatement(sqlstr1);
				
				int value1 = 0;
				stmt1.setInt(1, propID);
				ResultSet rs1 = stmt1.executeQuery();
				while (rs1.next())
					value1 = rs1.getInt(1);
				rs1.close();
				stmt1.close();
				
				String sqlstr2 = "SELECT DISTINCT uri_id FROM inst_prop WHERE prop_id=?";
				PreparedStatement stmt2 = connObjectCoref.prepareStatement(sqlstr2);
				String sqlstr3 = "SELECT COUNT(DISTINCT value) FROM inst_prop WHERE uri_id=? AND prop_id=?";
				PreparedStatement stmt3 = connObjectCoref.prepareStatement(sqlstr3);
				
				int value2 = 0, value3 = 0;
				stmt2.setInt(1, propID);
				ResultSet rs2 = stmt2.executeQuery();
				while (rs2.next()) {
					++value3;
					
					int uriID = rs2.getInt(1);
					stmt3.setInt(1, uriID);
					stmt3.setInt(2, propID);
					ResultSet rs3 = stmt3.executeQuery();
					while (rs3.next())
						value2 += rs3.getInt(1);
					rs3.close();
				}
				rs2.close();
				stmt2.close();
				stmt3.close();
				connObjectCoref.close();
				
				float[] values = {(float) value1 / value2, (float) value2 / value3};
				return values;
			} catch (Throwable e) {
				logger.error(e.getMessage());
				return null;
			}
		}
	}
}
