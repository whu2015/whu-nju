package cn.edu.nju.ws.ocr.train.btc2011;

import java.util.*;
import org.apache.log4j.*;
import cn.edu.nju.ws.ocr.datab.*;
import cn.edu.nju.ws.ocr.rdf.*;
import cn.edu.nju.ws.ocr.train.*;
import cn.edu.nju.ws.ocr.util.*;

public class BTC2011NameFinder implements INameFinder
{
	static Logger logger = Logger.getLogger(BTC2011NameFinder.class);
	
	private static BTC2011NameFinder instance = null;
	
	synchronized public static BTC2011NameFinder getInstance() 
	{
		if (instance == null) 
			instance = new BTC2011NameFinder();
		return instance;
	}
	
	private BTC2011NameFinder() {}
	
	public void completeInfo(Map<Integer, RDFInst> instances) throws Throwable
	{
		Map<Integer, String> uris = new HashMap<Integer, String>();
		Map<Integer, String> qnames = new HashMap<Integer, String>();

		for (Integer uriID : instances.keySet()) {
			RDFInst inst = instances.get(uriID);

			if (uris.containsKey(uriID)) {
				inst.setURI(uris.get(uriID));
				inst.setQName(qnames.get(uriID));
				
				List<RDFStmt> stmts = inst.getSnippets();
				for (int i = 0; i < stmts.size(); ++i) {
					RDFStmt stmt = stmts.get(i);
					String s = stmt.getSubject(), p = stmt.getPredicate(), o = stmt.getObject();
					if (s.startsWith("l")) {
						stmt.setSubjectName("\"" + s.substring(1) + "\"");
					} else if (s.startsWith("u")) {
						int sURIID = Integer.parseInt(s.substring(1));
						if (uris.containsKey(sURIID)) {
							stmt.setSubjectURI(uris.get(sURIID));
							stmt.setSubjectName(qnames.get(sURIID));
						} else {
							String sURI = URIHelper.uri(sURIID, DatasetType.BTC2011);
							String sQName = URIHelper.qname(sURI);
							stmt.setSubjectURI(sURI);
							stmt.setSubjectName(sQName);
							uris.put(uriID, sURI);
							qnames.put(sURIID, sQName);
						}
					}
					if (p.startsWith("u")) {
						int pURIID = Integer.parseInt(p.substring(1));
						if (uris.containsKey(pURIID)) {
							stmt.setPredicateURI(uris.get(pURIID));
							stmt.setPredicateName(qnames.get(pURIID));
						} else {
							String pURI = URIHelper.uri(pURIID, DatasetType.BTC2011);
							String pQName = URIHelper.qname(pURI);
							stmt.setPredicateURI(pURI);
							stmt.setPredicateName(pQName);
							uris.put(pURIID, pURI);
							qnames.put(pURIID, pQName);
						}
					}
					if (o.startsWith("l")) {
						stmt.setObjectName("\"" + o.substring(1) + "\"");
					} else if (o.startsWith("u")) {
						int oURIID = Integer.parseInt(o.substring(1));
						if (uris.containsKey(oURIID)) {
							stmt.setObjectURI(uris.get(oURIID));
							stmt.setObjectName(qnames.get(oURIID));
						} else {
							String oURI = URIHelper.uri(oURIID, DatasetType.BTC2011);
							String oQName = URIHelper.qname(oURI);
							stmt.setObjectURI(oURI);
							stmt.setObjectName(oQName);
							uris.put(oURIID, oURI);
							qnames.put(oURIID, oQName);
						}
					}
				}
			} else {
				String uri = URIHelper.uri(uriID, DatasetType.BTC2011);
				String qname = URIHelper.qname(uri);
				uris.put(uriID, uri);
				qnames.put(uriID, qname);
				inst.setURI(uri);
				inst.setQName(qname);

				List<RDFStmt> stmts = inst.getSnippets();
				for (int i = 0; i < stmts.size(); ++i) {
					RDFStmt stmt = stmts.get(i);
					String s = stmt.getSubject(), p = stmt.getPredicate(), o = stmt.getObject();
					if (s.startsWith("l")) {
						stmt.setSubjectName("\"" + s.substring(1) + "\"");
					} else if (s.startsWith("u")) {
						int sURIID = Integer.parseInt(s.substring(1));
						if (uris.containsKey(sURIID)) {
							stmt.setSubjectURI(uris.get(sURIID));
							stmt.setSubjectName(qnames.get(sURIID));
						} else {
							String sURI = URIHelper.uri(sURIID, DatasetType.BTC2011);
							String sQName = URIHelper.qname(sURI);
							stmt.setSubjectURI(sURI);
							stmt.setSubjectName(sQName);
							uris.put(uriID, sURI);
							qnames.put(sURIID, sQName);
						}
					}
					if (p.startsWith("u")) {
						int pURIID = Integer.parseInt(p.substring(1));
						if (uris.containsKey(pURIID)) {
							stmt.setPredicateURI(uris.get(pURIID));
							stmt.setPredicateName(qnames.get(pURIID));
						} else {
							String pURI = URIHelper.uri(pURIID, DatasetType.BTC2011);
							String pQName = URIHelper.qname(pURI);
							stmt.setPredicateURI(pURI);
							stmt.setPredicateName(pQName);
							uris.put(pURIID, pURI);
							qnames.put(pURIID, pQName);
						}
					}
					if (o.startsWith("l")) {
						stmt.setObjectName("\"" + o.substring(1) + "\"");
					} else if (o.startsWith("u")) {
						int oURIID = Integer.parseInt(o.substring(1));
						if (uris.containsKey(oURIID)) {
							stmt.setObjectURI(uris.get(oURIID));
							stmt.setObjectName(qnames.get(oURIID));
						} else {
							String oURI = URIHelper.uri(oURIID, DatasetType.BTC2011);
							String oQName = URIHelper.qname(oURI);
							stmt.setObjectURI(oURI);
							stmt.setObjectName(oQName);
							uris.put(oURIID, oURI);
							qnames.put(oURIID, oQName);
						}
					}
				}
			}
		}
	}
}

