package cn.edu.nju.ws.ocr.kernel;

import org.apache.log4j.*;
import cn.edu.nju.ws.ocr.datab.*;
import cn.edu.nju.ws.ocr.kernel.btc2011.*;
//import cn.edu.nju.ws.ocr.kernel.falconetV05.*;

public class KernelBuilderFactory 
{
	static Logger logger = Logger.getLogger(KernelBuilderFactory.class);
	
	private static KernelBuilderFactory instance;
	
	synchronized public static KernelBuilderFactory getInstance() 
	{
		if (instance == null) 
			instance = new KernelBuilderFactory();
		return instance;
	}
	
	private KernelBuilderFactory() {}
	
	public IKernelBuilder createKernelBuilder(int uriID, String source) 
	{
		if (source.equalsIgnoreCase(DatasetType.FALCONETV05)) {
			//return new FalconetV05KernelBuilder(uriID);
			return null; // due to the crash of Falcons
		} else if (source.equalsIgnoreCase(DatasetType.BTC2011)) {
			return new BTC2011KernelBuilder(uriID);
		} else return null;
	}
	
	public IKernelBuilder createKernelBuilder(String uri, String source) 
	{
		if (source.equalsIgnoreCase(DatasetType.FALCONETV05)) {
			//return new FalconetV05KernelBuilder(uri);
			return null; // due to the crash of Falcons
		} else if (source.equalsIgnoreCase(DatasetType.BTC2011)) {
			return new BTC2011KernelBuilder(uri);
		} else return null;
	}
}
