package cn.edu.nju.ws.ocr.rdf;

import org.apache.log4j.*;

public class SpecialPrefix
{
	static Logger logger = Logger.getLogger(SpecialPrefix.class);
	
	public static final String XSD = "http://www.w3.org/2001/XMLSchema#";
	public static final String XSD_prefix = "xsd";
	
	public static final String RDF = "http://www.w3.org/1999/02/22-rdf-syntax-ns#";
	public static final String RDF_prefix = "rdf";
	
	public static final String RDFS = "http://www.w3.org/2000/01/rdf-schema#";
	public static final String RDFS_prefix = "rdfs";
	
	public static final String OWL = "http://www.w3.org/2002/07/owl#";
	public static final String OWL_prefix = "owl";
	
	public static final String SKOS = "http://www.w3.org/2004/02/skos/core#";
	public static final String SKOS_prefix = "skos";
	
	public static final String DC = "http://purl.org/dc/elements/1.1/";
	public static final String DC_prefix = "dc";
	
	public static final String DCTERMS = "http://purl.org/dc/terms/";
	public static final String DCTERMS_prefix = "dcterms";
	
	public static final String FOAF = "http://xmlns.com/foaf/0.1/";
	public static final String FOAF_prefix = "foaf";
	
	public static final String GEO = "http://www.w3.org/2003/01/geo/wgs84_pos#";
	public static final String GEO_prefix = "geo";
	
	public static final String VCARD = "http://www.w3.org/2001/vcard-rdf/3.0#";
	public static final String VCARD_prefix = "vcard";
	
	public static final String OBO = "http://www.geneontology.org/formats/oboInOwl#";
	public static final String OBO_prefix = "obo";
	
	public static final String OV = "http://open.vocab.org/terms/";
	public static final String OV_prefix = "ov";
	
	public static final String COREF = "http://www.rkbexplorer.com/ontologies/coref#";
	public static final String COREF_prefix = "coref";
	
	public static final String UMBEL = "http://umbel.org/umbel/sc/";
	public static final String UMBEL_prefix = "umbel";
	
	public static final String Freebase = "http://rdf.freebase.com/ns/";
	public static final String Freebase_prefix = "freebase";
	
	public static final String DBpedia = "http://dbpedia.org/resource/";
	public static final String DBpedia_prefix = "dbpedia";
	
	public static final String DBpediaOWL = "http://dbpedia.org/ontology/"; 
	public static final String DBpediaOWL_prefix = "dbpedia-owl";
	
	public static final String DBpediaProp = "http://dbpedia.org/property/";
	public static final String DBpediaProp_prefix = "dbpprop";	
		
	public static final String YAGO = "http://dbpedia.org/class/yago/";
	public static final String YAGO_prefix = "yago";	
	
	public static final String Geonames = "http://www.geonames.org/ontology#";
	public static final String Geonames_prefix = "geonames";
	
	public static final String Factbook = "http://www4.wiwiss.fu-berlin.de/factbook/ns#";
	public static final String Factbook_prefix = "factbook";
	
	public static final String RSS = "http://purl.org/rss/1.0/";
	public static final String RSS_prefix = "rss";
	
	public static final String SIOC = "http://rdfs.org/sioc/ns#";
	public static final String SIOC_prefix = "sioc";
	
	public static final String BIBO = "http://purl.org/ontology/bibo/";
	public static final String BIBO_prefix = "bibo";
	
	public static final String Cyc = "http://sw.opencyc.org/concept/";
	public static final String Cyc_prefix = "cyc";
	
	public static final String SWRC = "http://swrc.ontoware.org/ontology#";
	public static final String SWRC_prefix = "swrc";
	
	public static final String Websoft = "http://ws.nju.edu.cn/ontology/ws.owl#";
	public static final String Websoft_prefix = "websoft";
	
	public static final String[] namespaces = { XSD, RDF, RDFS, OWL, SKOS, 
												DC, DCTERMS, FOAF, GEO, VCARD,
												OBO, OV, COREF, UMBEL, Freebase, 
												DBpedia, DBpediaOWL, DBpediaProp,
												YAGO, Geonames, Factbook, 
												RSS, SIOC, BIBO, Cyc, SWRC, Websoft };
	
	public static final String[] prefixes = { XSD_prefix, RDF_prefix, RDFS_prefix, 
											  OWL_prefix, SKOS_prefix, DC_prefix, 
											  DCTERMS_prefix, FOAF_prefix, GEO_prefix, 
											  VCARD_prefix, OBO_prefix, OV_prefix,
											  COREF_prefix, UMBEL_prefix, Freebase_prefix,
											  DBpedia_prefix, DBpediaOWL_prefix, DBpediaProp_prefix,
											  YAGO_prefix, Geonames_prefix, Factbook_prefix,
											  RSS_prefix, SIOC_prefix, BIBO_prefix, 
											  Cyc_prefix, SWRC_prefix, Websoft_prefix };
	
	public static String specialPrefix(String ns) 
	{
		if (ns == null || ns.equals(""))
			return null;
		
		for (int i = 0; i < namespaces.length; ++i) {
			if (ns.equals(namespaces[i])) 
				return prefixes[i];
		}
		return null;
	}
}
