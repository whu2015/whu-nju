package cn.edu.nju.ws.ocr.datab;

import java.sql.*;
import org.apache.commons.dbcp.*;
import org.apache.log4j.*;

public class DBConnPool 
{
	static Logger logger = Logger.getLogger(DBConnPool.class);
	
	private static BasicDataSource dsObjectCoref;
	private static BasicDataSource dsFalconetV05;
	private static BasicDataSource dsBTC2011;
	private static BasicDataSource dsNYT;
	private static BasicDataSource dsPR;
	
	private static final String validationQueryStr = "SHOW TABLES";

	synchronized private static void initObjectCoref()
	{
		dsObjectCoref = new BasicDataSource();
		
		dsObjectCoref.setDriverClassName(DBParam.DRV);
		dsObjectCoref.setUrl(DBParam.URL_ObjectCoref);
		
		dsObjectCoref.setMaxActive(20);
		dsObjectCoref.setMaxIdle(2);
		dsObjectCoref.setDefaultTransactionIsolation(Connection.TRANSACTION_READ_COMMITTED);
		
		dsObjectCoref.setTestOnBorrow(true);
		dsObjectCoref.setValidationQuery(validationQueryStr);
	}
	
	synchronized public static Connection getObjectCoref() throws Throwable
	{
		if (dsObjectCoref == null)
			initObjectCoref();
		return dsObjectCoref.getConnection();
	}
	
	synchronized public static void shutObjectCoref() throws Throwable
	{
		if (dsObjectCoref != null) 
			dsObjectCoref.close();
	}
	
	synchronized private static void initFalconetV05()
	{
		dsFalconetV05 = new BasicDataSource();
		
		dsFalconetV05.setDriverClassName(DBParam.DRV);
		dsFalconetV05.setUrl(DBParam.URL_FalconetV05);
		
		dsFalconetV05.setMaxActive(20);
		dsFalconetV05.setMaxIdle(2);
		dsFalconetV05.setDefaultTransactionIsolation(Connection.TRANSACTION_READ_COMMITTED);
		
		dsFalconetV05.setTestOnBorrow(true);
		dsFalconetV05.setValidationQuery(validationQueryStr);
	}
	
	synchronized public static Connection getFalconetV05() throws Throwable
	{
		if (dsFalconetV05 == null)
			initFalconetV05();
		return dsFalconetV05.getConnection();
	}
	
	synchronized public static void shutFalconetV05() throws Throwable
	{
		if (dsFalconetV05 != null) 
			dsFalconetV05.close();
	}
	
	synchronized private static void initBTC2011()
	{
		dsBTC2011 = new BasicDataSource();
		
		dsBTC2011.setDriverClassName(DBParam.DRV);
		dsBTC2011.setUrl(DBParam.URL_BTC2011);
		
		dsBTC2011.setMaxActive(20);
		dsBTC2011.setMaxIdle(2);
		dsBTC2011.setDefaultTransactionIsolation(Connection.TRANSACTION_READ_COMMITTED);
		
		dsBTC2011.setTestOnBorrow(true);
		dsBTC2011.setValidationQuery(validationQueryStr);
	}
	
	synchronized public static Connection getBTC2011() throws Throwable
	{
		if (dsBTC2011 == null)
			initBTC2011();
		return dsBTC2011.getConnection();
	}
	
	synchronized public static void shutBTC2011() throws Throwable
	{
		if (dsBTC2011 != null) 
			dsBTC2011.close();
	}
	
	synchronized private static void initNYT()
	{
		dsNYT = new BasicDataSource();
		
		dsNYT.setDriverClassName(DBParam.DRV);
		dsNYT.setUrl(DBParam.URL_NYT);
		
		dsNYT.setMaxActive(20);
		dsNYT.setMaxIdle(2);
		dsNYT.setDefaultTransactionIsolation(Connection.TRANSACTION_READ_COMMITTED);
		
		dsNYT.setTestOnBorrow(true);
		dsNYT.setValidationQuery(validationQueryStr);
	}
	
	synchronized public static Connection getNYT() throws Throwable
	{
		if (dsNYT == null)
			initNYT();
		return dsNYT.getConnection();
	}
	
	synchronized public static void shutNYT() throws Throwable
	{
		if (dsNYT != null) 
			dsNYT.close();
	}

	synchronized private static void initPR()
	{
		dsPR = new BasicDataSource();
		
		dsPR.setDriverClassName(DBParam.DRV);
		dsPR.setUrl(DBParam.URL_PR);
		
		dsPR.setMaxActive(20);
		dsPR.setMaxIdle(2);
		dsPR.setDefaultTransactionIsolation(Connection.TRANSACTION_READ_COMMITTED);
		
		dsPR.setTestOnBorrow(true);
		dsPR.setValidationQuery(validationQueryStr);
	}
	
	synchronized public static Connection getPR() throws Throwable
	{
		if (dsPR == null)
			initPR();
		return dsPR.getConnection();
	}
	
	synchronized public static void shutPR() throws Throwable
	{
		if (dsPR != null) 
			dsPR.close();
	}
	
	public static void main(String args[]) throws Throwable
	{
		PropertyConfigurator.configure(DBConnPool.class.getResource("/config/log4j.properties"));
		DBParam.init();
			
		getObjectCoref().close();
		getFalconetV05().close();
		getBTC2011().close();
		
		shutObjectCoref();
		shutFalconetV05();
		shutBTC2011();
	}
}
