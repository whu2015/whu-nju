package cn.edu.nju.ws.ocr.rdf;

import java.sql.*;

import org.apache.log4j.*;

import cn.edu.nju.ws.ocr.datab.*;

// update on 2014-8-4
public class BTC2011Prop extends SpecialProp 
{
	static Logger logger = Logger.getLogger(BTC2011Prop.class);
	
	// http://www.w3.org/2002/07/owl#sameAs
	public static final int OWL_sameAs_ID = 423;
	
	// http://www.w3.org/2002/07/owl#InverseFunctionalProperty
	public static final int OWL_IFP_ID = 1059;
	
	// http://www.w3.org/2002/07/owl#FunctionalProperty
	public static final int OWL_FP_ID = 1055;
	
	// http://www.w3.org/2004/02/skos/core#exactMatch
	public static final int SKOS_exactMatch_ID = 37475; 
	
	// http://www.w3.org/2004/02/skos/core#closeMatch
	public static final int SKOS_closeMatch_ID = 3484;
	
	// http://www.geneontology.org/formats/oboInOwl#hasExactSynonym
	public static final int OBO_hasExactSynonym_ID = 39952;
	
	// http://open.vocab.org/terms/similarTo
	public static final int OV_similarTo_ID = 78894;
	
	// http://www.rkbexplorer.com/ontologies/coref#coreferenceData
	// public static final int COREF_coreferenceData_ID = 0;
	
	// http://umbel.org/umbel/sc/isLike
	// public static final int UMBEL_isLike_ID = 0;
	
	// http://www.w3.org/2002/07/owl#hasKey
	public static final int OWL_hasKey_ID = 334553;
	
	// http://www.w3.org/2002/07/owl#cardinality
	public static final int OWL_cardinality_ID = 352;
	
	// http://www.w3.org/2002/07/owl#maxCardinality
	public static final int OWL_maxCardinality_ID = 190;
	
	// http://www.w3.org/2002/07/owl#qualifiedCardinality
	public static final int OWL_qualifiedCardinality_ID = 335080;
	
	// http://www.w3.org/2002/07/owl#maxQualifiedCardinality
	public static final int OWL_maxQualifiedCardinality_ID = 335073;
	
	// http://www.w3.org/2002/07/owl#onProperty
	public static final int OWL_onProperty_ID = 187; 
	
	// http://www.w3.org/2002/07/owl#Restriction
	public static final int OWL_Restriction_ID = 189;
	
	// http://www.w3.org/1999/02/22-rdf-syntax-ns#type
	public static final int RDF_type_ID = 2;

	// http://www.w3.org/2000/01/rdf-schema#subClassOf
	public static final int RDFS_subClassOf_ID = 198;
	
	// http://www.w3.org/2000/01/rdf-schema#domain
	public static final int RDFS_domain_ID = 269;
	
	// http://www.w3.org/2000/01/rdf-schema#range
	public static final int RDFS_range_ID = 248;
	
	// http://www.w3.org/2000/01/rdf-schema#label
	public static final int RDFS_label_ID = 231;
	
	// http://www.w3.org/2002/07/owl#equivalentClass
	public static final int OWL_equivalentClass_ID = 632;
	
	// http://purl.org/dc/elements/1.1/title
	public static final int DC_title_ID = 164;
	
	// http://xmlns.com/foaf/0.1/name
	public static final int FOAF_name_ID = 124;
	
	// http://xmlns.com/foaf/0.1/mbox
	public static final int FOAF_mbox_ID = 1057;

	// http://xmlns.com/foaf/0.1/mbox_sha1sum
	public static final int FOAF_mbox_sha1sum_ID = 127;
	
	// http://xmlns.com/foaf/0.1/homepage
	public static final int FOAF_homepage_ID = 130;
	
	// http://www.w3.org/2002/07/owl#Thing
	public static final int OWL_Thing_ID = 1007;
	
	// XSD datatypes ...

	void findSpecialProp()
	{
		try {
			Connection connBTC2011 = DBConnPool.getBTC2011();
			
			String sqlstr1 = "SELECT DISTINCT s,c FROM " + DatasetType.BTC2011_QUADRUPLE + " WHERE o=? AND p=?";
			PreparedStatement stmt1 = connBTC2011.prepareStatement(sqlstr1);
			
			String sqlstr2 = "INSERT INTO special_property(property,c,category,source) VALUES(?,?,?,?)";
			PreparedStatement stmt2 = connBTC2011.prepareStatement(sqlstr2);
			
			// OWL_IFP_ID
			stmt1.setString(1, "u" + OWL_IFP_ID);
			stmt1.setString(2, "u" + RDF_type_ID);
				
			ResultSet rs1 = stmt1.executeQuery();
			while (rs1.next()) {
				String s = rs1.getString(1);
				int c = rs1.getInt(2);
				
				stmt2.setString(1, s);
				stmt2.setInt(2, c);
				stmt2.setString(3, "ifp"); // "ifp"=InverseFunctionalProperty
				stmt2.setString(4, DatasetType.BTC2011);
				stmt2.executeUpdate();
			}
			rs1.close();
			
			// OWL_FP_ID
			stmt1.setString(1, "u" + OWL_FP_ID);
			stmt1.setString(2, "u" + RDF_type_ID);
							
			ResultSet rs2 = stmt1.executeQuery();
			while (rs2.next()) {
				String s = rs2.getString(1);
				int c = rs2.getInt(2);
							
				stmt2.setString(1, s);
				stmt2.setInt(2, c);
				stmt2.setString(3, "fp"); // "fp"=FunctionalProperty
				stmt2.setString(4, DatasetType.BTC2011);
				stmt2.executeUpdate();
			}
			rs2.close();
			
			stmt1.close();
			stmt2.close();
			connBTC2011.close();
		} catch (Throwable e) {
			logger.error(e.getMessage());
		}
	}
	
	void updateDerefDoc() // btc2011 doesn't have dereference information
	{
		try {
			Connection connBTC2011 = DBConnPool.getBTC2011();
			Connection connFalconetV05 = DBConnPool.getFalconetV05();
			
			String sqlstr1 = "SELECT DISTINCT property FROM special_property WHERE property LIKE 'u%' AND source=?";
			PreparedStatement stmt1 = connBTC2011.prepareStatement(sqlstr1);
			
			String sqlstr2 = "SELECT uri FROM " + DatasetType.BTC2011_URI + " WHERE uri_id=?";
			PreparedStatement stmt2 = connBTC2011.prepareStatement(sqlstr2);
			
			String sqlstr3 = "SELECT dereference_doc_uri_id FROM " + DatasetType.FALCONETV05_URI + " WHERE uri=?";
			PreparedStatement stmt3 = connFalconetV05.prepareStatement(sqlstr3);
			
			String sqlstr4 = "SELECT uri FROM " + DatasetType.FALCONETV05_URI + " WHERE id=?";
			PreparedStatement stmt4 = connFalconetV05.prepareStatement(sqlstr4);
			
			String sqlstr5 = "SELECT doc_id FROM " + DatasetType.BTC2011_DOC + " WHERE url=?";
			PreparedStatement stmt5 = connBTC2011.prepareStatement(sqlstr5);
			
			String sqlstr6 = "UPDATE special_property SET deref_doc=? WHERE property=? AND source=?";
			PreparedStatement stmt6 = connBTC2011.prepareStatement(sqlstr6);
			
			stmt1.setString(1, DatasetType.BTC2011);
			ResultSet rs1 = stmt1.executeQuery();
			while (rs1.next()) {
				String p = rs1.getString(1);
				
				stmt2.setInt(1, Integer.parseInt(p.substring(1)));
				String puri = null;
				ResultSet rs2 = stmt2.executeQuery();
				while (rs2.next())
					puri = rs2.getString(1);
				rs2.close();
				
				stmt3.setString(1, puri);
				int c = 0;
				ResultSet rs3 = stmt3.executeQuery();
				while (rs3.next())
					c = rs3.getInt(1);
				rs3.close();
				
				if (c == 0 && puri.contains("#")) { // second try
					int index = puri.lastIndexOf("#");
					stmt3.setString(1, puri.substring(0, index));
					rs3 = stmt3.executeQuery();
					while (rs3.next())
						c = rs3.getInt(1);
					rs3.close();
				}
				
				if (c != 0) {
					stmt4.setInt(1, c);
					String curi = null;
					ResultSet rs4 = stmt4.executeQuery();
					while (rs4.next())
						curi = rs4.getString(1);
					rs4.close();
					
					stmt5.setString(1, curi);
					int c2 = 0;
					ResultSet rs5 = stmt5.executeQuery();
					while (rs5.next()) 
						c2 = rs5.getInt(1);
					rs5.close();
					
					if (c2 != 0) {
						stmt6.setInt(1, c2);
						stmt6.setString(2, p);
						stmt6.setString(3, DatasetType.BTC2011);
						stmt6.executeUpdate();
					}
				}
			}
			rs1.close();
			
			stmt1.close();
			stmt2.close();
			stmt3.close();
			stmt4.close();
			stmt5.close();
			stmt6.close();
			connBTC2011.close();
			connFalconetV05.close();
		} catch (Throwable e) {
			logger.error(e.getMessage());
		}
	}
	
	void decideTrustworthy()
	{
		// UPDATE special_property SET trustworthy=1 WHERE c=deref_doc AND source='btc2011';
	}

	public static void main(String args[])
	{
		PropertyConfigurator.configure(BTC2011Prop.class.getResource("/config/log4j.properties"));
		DBParam.init();
	
		//new BTC2011Prop().findSpecialProp();
		//new BTC2011Prop().updateDerefDoc();
		// DELETE FROM special_property WHERE trustworthy<>1 AND source='btc2011';
		// SELECT property FROM special_property WHERE category='ifp' AND trustworthy=1 AND source='btc2011';
	}
}
