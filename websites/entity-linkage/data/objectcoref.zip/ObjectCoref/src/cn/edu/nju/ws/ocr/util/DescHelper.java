package cn.edu.nju.ws.ocr.util;

import java.sql.*;
import java.util.*;
import org.apache.log4j.*;
import cn.edu.nju.ws.ocr.datab.*;
import cn.edu.nju.ws.ocr.rdf.*;

public class DescHelper
{
	static Logger logger = Logger.getLogger(DescHelper.class);
	
	public static List<String> desc(String uri, String source)
	{
		if (uri == null || uri.equals(""))
			return null;
		
		int uriID = URIHelper.uriID(uri, source);
		return desc(uriID, source);
	}
	
	public static List<String> desc(int uriID, String source)
	{
		if (uriID <= 0)
			return null;
		
		// priority: rdfs:label > dc:title > foaf:name > localname
		/* List<String> descriptions = rdfs_label(uriID, source);
		if (descriptions == null || descriptions.size() == 0) {
			descriptions = dc_title(uriID, source);
			
			if (descriptions == null || descriptions.size() == 0) {
				descriptions = foaf_name(uriID, source);
				
				if (descriptions == null || descriptions.size() == 0) {
					descriptions = new ArrayList<String>();
					descriptions.add(URIHelper.localname(uriID, source));
				}
			}
		} */
		
		// now shorten to: rdfs:label > localname
		List<String> descriptions = rdfs_label(uriID, source);
		if (descriptions == null || descriptions.size() == 0) {
			descriptions = new ArrayList<String>();
			descriptions.add(URIHelper.localname(uriID, source)); // default
		}
		
		return descriptions;
	}
	
	// source={ DatasetType.FALCONETV05, DatasetType.BTC2011 }
	public static List<String> rdfs_label(int uriID, String source)
	{
		try {
			Connection conn = null;
			PreparedStatement stmt1 = null;
			
			// only English or unspecified
			if (source.equalsIgnoreCase(DatasetType.FALCONETV05)) {
				conn = DBConnPool.getFalconetV05();
				String sqlstr1 = "SELECT DISTINCT o FROM " + DatasetType.FALCONETV05_QUADRUPLE 
							   + " WHERE s=? AND p=? AND (lang='en' OR lang IS NULL)";
				stmt1 = conn.prepareStatement(sqlstr1);
				stmt1.setString(1, "u" + uriID);
				stmt1.setString(2, "u" + FalconetV05Prop.RDFS_label_ID);
			} else if (source.equalsIgnoreCase(DatasetType.BTC2011)) {
				conn = DBConnPool.getBTC2011();
				String sqlstr1 = "SELECT DISTINCT o FROM " + DatasetType.BTC2011_QUADRUPLE 
							   + " WHERE s=? AND p=? AND (lang='en' OR lang IS NULL)";
				stmt1 = conn.prepareStatement(sqlstr1);
				stmt1.setString(1, "u" + uriID);
				stmt1.setString(2, "u" + BTC2011Prop.RDFS_label_ID);
			} else return null;
				
			List<String> labels = new ArrayList<String>();
			ResultSet rs1 = stmt1.executeQuery();
			while (rs1.next()) {
				String o = rs1.getString(1);
				labels.add(o.substring(1));
			}
			rs1.close();
			stmt1.close();
			conn.close();
			
			return labels;	
		} catch (Throwable e) {
			logger.error(e.getMessage());
			return null;
		}
	}
	
	public static List<String> dc_title(int uriID, String source)
	{
		try {
			Connection conn = null;
			PreparedStatement stmt1 = null;
			
			if (source.equalsIgnoreCase(DatasetType.FALCONETV05)) {
				conn = DBConnPool.getFalconetV05();
				String sqlstr1 = "SELECT DISTINCT o FROM " + DatasetType.FALCONETV05_QUADRUPLE 
							   + " WHERE s=? AND p=?";
				stmt1 = conn.prepareStatement(sqlstr1);
				stmt1.setString(1, "u" + uriID);
				stmt1.setString(2, "u" + FalconetV05Prop.DC_title_ID);
			} else if (source.equalsIgnoreCase(DatasetType.BTC2011)) {
				conn = DBConnPool.getBTC2011();
				String sqlstr1 = "SELECT DISTINCT o FROM " + DatasetType.BTC2011_QUADRUPLE 
							   + " WHERE s=? AND p=?";
				stmt1 = conn.prepareStatement(sqlstr1);
				stmt1.setString(1, "u" + uriID);
				stmt1.setString(2, "u" + BTC2011Prop.DC_title_ID);
			} else return null;
				
			List<String> titles = new ArrayList<String>();
			
			ResultSet rs1 = stmt1.executeQuery();
			while (rs1.next()) {
				String o = rs1.getString(1);
				titles.add(o.substring(1));
			}
			rs1.close();
			stmt1.close();
			conn.close();
			
			return titles;	
		} catch (Throwable e) {
			logger.error(e.getMessage());
			return null;
		}
	}
	
	public static List<String> foaf_name(int uriID, String source)
	{
		try {
			Connection conn = null;
			PreparedStatement stmt1 = null;
			
			if (source.equalsIgnoreCase(DatasetType.FALCONETV05)) {
				conn = DBConnPool.getFalconetV05();
				String sqlstr1 = "SELECT DISTINCT o FROM " + DatasetType.FALCONETV05_QUADRUPLE 
							   + " WHERE s=? AND p=?";
				stmt1 = conn.prepareStatement(sqlstr1);
				stmt1.setString(1, "u" + uriID);
				stmt1.setString(2, "u" + FalconetV05Prop.FOAF_name_ID);
			} else if (source.equalsIgnoreCase(DatasetType.BTC2011)) {
				conn = DBConnPool.getBTC2011();
				String sqlstr1 = "SELECT DISTINCT o FROM " + DatasetType.BTC2011_QUADRUPLE 
							   + " WHERE s=? AND p=?";
				stmt1 = conn.prepareStatement(sqlstr1);
				stmt1.setString(1, "u" + uriID);
				stmt1.setString(2, "u" + BTC2011Prop.FOAF_name_ID);
			} else return null;
				
			List<String> names = new ArrayList<String>();
			
			ResultSet rs1 = stmt1.executeQuery();
			while (rs1.next()) {
				String o = rs1.getString(1);
				names.add(o.substring(1));
			}
			rs1.close();
			stmt1.close();
			conn.close();
			
			return names;	
		} catch (Throwable e) {
			logger.error(e.getMessage());
			return null;
		}
	}
	
	public static void main(String args[]) throws Throwable
	{
		PropertyConfigurator.configure(DescHelper.class.getResource("/config/log4j.properties"));
		DBParam.init();
		
		String uri = "http://www.w3.org/People/Berners-Lee/card#i";
		System.out.println(desc(uri, DatasetType.BTC2011));
	} 
}
