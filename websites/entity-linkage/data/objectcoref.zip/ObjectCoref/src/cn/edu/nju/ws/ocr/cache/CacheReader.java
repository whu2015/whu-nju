package cn.edu.nju.ws.ocr.cache;

import java.sql.*;
import java.util.*;
import org.apache.log4j.*;
import cn.edu.nju.ws.ocr.datab.*;
import cn.edu.nju.ws.ocr.rdf.*;
import cn.edu.nju.ws.ocr.util.*;

public class CacheReader 
{
	static Logger logger = Logger.getLogger(CacheReader.class);
	
	// source={ DatasetType.FALCONETV05, DatasetType.BTC2011 }
	synchronized public static Map<Integer, RDFInst> read(String uri, String source)
	{
		if (uri == null || uri.equals(""))
			return null;
		
		int uriID = URIHelper.uriID(uri, source);
		return read(uriID, source);
	}

	synchronized public static Map<Integer, RDFInst> read(int uriID, String source) 
	{
		// at least reflexive
		if (uriID <= 0)
			return null;
		
		try {	
			Connection connObjectCoref = DBConnPool.getObjectCoref();
			
			// rank_id=0 indicates the input URI
			String sqlstr1 = "SELECT MAX(group_id) FROM cache "
						   + "WHERE uri_id=? AND source=? AND rank_id=0";
			PreparedStatement stmt1 = connObjectCoref.prepareStatement(sqlstr1);
			
			stmt1.setInt(1, uriID);
			stmt1.setString(2, source);
			
			int groupID = 0;
			ResultSet rs1 = stmt1.executeQuery();
			while (rs1.next()) 
				groupID = rs1.getInt(1);
			rs1.close();
			stmt1.close();
			
			if (groupID == 0) { // not found
				connObjectCoref.close();
				return null;
			}
			
			String sqlstr2 = "SELECT uri_id,discr,rank_id FROM cache "
						   + "WHERE group_id=? ORDER BY rank_id ASC";
			PreparedStatement stmt2 = connObjectCoref.prepareStatement(sqlstr2);
			
			String sqlstr3 = "SELECT s,p,o FROM cache_stmt WHERE group_id=? AND uri_id=?";
			PreparedStatement stmt3 = connObjectCoref.prepareStatement(sqlstr3);
			
			stmt2.setInt(1, groupID);
			
			Map<Integer, RDFInst> instances = new LinkedHashMap<Integer, RDFInst>();
			ResultSet rs2 = stmt2.executeQuery();
			while (rs2.next()) {
				int id = rs2.getInt(1);
				double discr = rs2.getFloat(2);
				int rankID = rs2.getInt(3);
				
				RDFInst inst = RDFFactory.getInstance().createRDFInst(id, discr);
				inst.setCacheRankID(rankID);
				
				stmt3.setInt(1, groupID);
				stmt3.setInt(2, id);
				ResultSet rs3 = stmt3.executeQuery();
				while (rs3.next()) {
					String s = rs3.getString(1);
					String p = rs3.getString(2); 
					String o = rs3.getString(3);
					
					RDFStmt stmt = RDFFactory.getInstance().createRDFStmt(s, p, o);
					inst.addSnippet(stmt);
				}
				rs3.close();
				
				instances.put(id, inst);
			}
			rs2.close();
			stmt2.close();
			stmt3.close();
			connObjectCoref.close();
			
			return instances;
		} catch (Throwable e) {
			logger.error(e.getMessage());
			return null;
		}
	}
}
