package cn.edu.nju.ws.ocr.eval;

import java.util.*;
import org.apache.log4j.*;

// an alignment is a set of mappings
public class Alignment 
{
	static Logger logger = Logger.getLogger(Alignment.class);
	
    private List<Mapping> collection;

    public Alignment() { collection = new ArrayList<Mapping>(); }

    public void addMapping(Mapping mapping) { collection.add(mapping); }

    public double measure(String left, String right)
    {
        Mapping mapping = contains(left, right);
        if (mapping != null) 
            return mapping.measure();
        return 0;
    }

    public void setMeasure(String left, String right, double sim)
    {
        Mapping mapping = contains(left, right);
        if (mapping != null) 
        	mapping.setMeasure(sim);
    }
    
    public Mapping mapping(int index)
    {
        if (index >= 0 && index < size()) 
            return collection.get(index);
        return null;
    }

    public Mapping removeMapping(int index)
    {
        if (index >= 0 && index < size()) {
            Mapping map = collection.remove(index);
            return map;
        } 
        return null;
    }

    public Mapping removeMapping(String left, String right)
    {
        for (int i = 0, n = size(); i < n; i++) {
            Mapping mapping = collection.get(i);
            if (mapping.entity1().equals(left) 
            		&& mapping.entity2().equals(right)) {
                Mapping map = collection.remove(i);
                return map;
            }
        }
        return null;
    }

    public Mapping contains(String left, String right)
    {
        for (int i = 0, n = size(); i < n; i++) {
            Mapping mapping = collection.get(i);
            if (mapping.entity1().equals(left) 
            		&& mapping.entity2().equals(right))
                return mapping;
        }
        return null;
    }

    public Alignment cut(double threshold)
    {
        for (int i = 0; i < size(); i++) {
            Mapping mapping = collection.get(i);
            if (mapping.measure() <= threshold) { // less than or equal
                removeMapping(i);
                i--;
            }
        }
        return this;
    }
    
    public Alignment combine(Alignment align)
    {
    	for (int i = 0; i < align.size(); ++i) {
    		Mapping map = align.mapping(i);
    		String uri1 = map.entity1(), uri2 = map.entity2();
    		Mapping exist = contains(uri1, uri2);
    		if (exist == null) {
    			collection.add(map);
    		} else if (exist.measure() < map.measure()) {
    			exist.setMeasure(map.measure());
    		}
    	}
    	return this;
    }

    public int size() { return collection.size(); }

    public int size(double threshold)
    {
        int count = 0;
        for (int i = 0, n = size(); i < n; i++) {
            Mapping mapping = collection.get(i);
            if (mapping.measure() > threshold) 
                count++;
        }
        return count;
    }

    public void show()
    {
        for (int i = 0, n = size(); i < n; i++) {
            Mapping mapping = collection.get(i);
            System.out.println("entity1=" + mapping.entity1().toString());
            System.out.println("entity2=" + mapping.entity2().toString());
            System.out.println("relation=" + mapping.relation());
            System.out.println("similarity=" + mapping.measure() + "\n");
        }
    }
}
