package cn.edu.nju.ws.ocr.nlp;

import java.util.*;
import org.apache.log4j.*;

public class TF_IDF 
{
	static Logger logger = Logger.getLogger(TF_IDF.class);
	
	// should be trimmed before calling the calculation
	// TF & IDF are not globally calculated
	public static double getSimilarity(String s1, String s2)
	{
		if (s1 == null || s2 == null || s1.length() == 0 || s2.length() == 0)
			return 0;
		
		String[] ss1 = s1.split(" "), ss2 = s2.split(" ");
		
		Set<String> words = new HashSet<String>();
		for (int i = 0; i < ss1.length; ++i)
			words.add(ss1[i]);
		for (int j = 0; j < ss2.length; ++j)
			words.add(ss2[j]);
		List<String> wordList = new ArrayList<String>(words);
		
		int[][] matrix = new int[wordList.size()][2];
		for (int i = 0; i < ss1.length; ++i) {
			int row = wordList.indexOf(ss1[i]);
			matrix[row][0] = matrix[row][0] + 1;
		}
		for (int j = 0; j < ss2.length; ++j) {
			int row = wordList.indexOf(ss2[j]);
			matrix[row][1] = matrix[row][1] + 1;
		}
		
		double[][] matrix2 = new double[wordList.size()][2];
		int maxDoc = 2;
		for (int i = 0; i < wordList.size(); ++i) {
			double docTimes = 0;
            if (matrix[i][0] != 0)
            	docTimes++;
            if (matrix[i][1] != 0)
            	docTimes++;         
            double maxTerm1 = ss1.length, maxTerm2 = ss2.length;
            double weight1 = getTermWeight(matrix[i][0], docTimes, maxTerm1, maxDoc);
            if (weight1 != 0) 
            	matrix2[i][0] = weight1;
            double weight2 = getTermWeight(matrix[i][1], docTimes, maxTerm2, maxDoc);
            if (weight2 != 0)
            	matrix2[i][1] = weight2;
        }

		double sum[] = new double[3];
	    for (int j = 0; j < 2; ++j) {
	    	for (int i = 0; i < wordList.size(); ++i) {
	    		sum[0] += matrix2[i][0] * matrix2[i][0];
	    		sum[1] += matrix2[i][1] * matrix2[i][1];
	    		sum[2] += matrix2[i][0] * matrix2[i][1];
	    	}
	    }
	    return sum[2] / Math.sqrt(sum[0] * sum[1]);
	}
	
	private static double getTermWeight(double tTimes, double dTimes, double maxTerm, double maxDoc)
	{
		if (tTimes == 0) 
			return 0;
	    
	    double tf = tTimes / maxTerm;
	    double idf = (1 + Math.log(maxDoc / dTimes) / Math.log(2)) / 2;
	    return tf * idf;
	}
}
