package cn.edu.nju.ws.ocr.rdf;

import java.util.*;
import org.apache.log4j.*;
import cn.edu.nju.ws.ocr.util.*;

public class PLDList implements Cloneable 
{
	static Logger logger = Logger.getLogger(PLDList.class);
	
	private List<PLD> pldList = new ArrayList<PLD>();

	public PLDList() {}

	public void addRDFInst(RDFInst inst) 
	{
		String pld = PLDHelper.pldName(inst.getURI());
		for (PLD tmpPLD : pldList) {
			if (tmpPLD.getPLDName().equals(pld)) { // already exist
				tmpPLD.add(inst);
				return;
			}
		}
		PLD newPLD = new PLD();
		newPLD.setPLDName(pld);
		newPLD.add(inst);
		
		pldList.add(newPLD);
	}

	public List<PLD> getPLDs() { return pldList; }

	public void rankPLDs() 
	{
		for (PLD tmpPLD : pldList) 
			tmpPLD.calculateClusterDegree();
		
		Collections.sort(pldList);
	}
	
	public void clear() { pldList.clear(); }
	
	public PLDList clone() 
	{
		PLDList newPLDs = new PLDList();
		for (PLD oldPLD : pldList) 
			newPLDs.pldList.add(oldPLD.clone());
		
		return newPLDs;
	}
}
