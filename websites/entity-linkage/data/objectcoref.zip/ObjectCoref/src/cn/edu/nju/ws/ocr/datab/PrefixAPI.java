package cn.edu.nju.ws.ocr.datab;

import java.io.*;
import java.net.*;
import org.apache.log4j.*;

public class PrefixAPI 
{
	static Logger logger = Logger.getLogger(PrefixAPI.class);
	
	// prefix.cc is developed by Richard Cyganiak
	public static final String PrefixAPI_URL = "http://prefix.cc/reverse?";
	
	public static String prefix(String namespace)
	{
		if (namespace == null || namespace.equals(""))
			return null;
		
		HttpURLConnection conn = null;
		try {
			String qstr = String.format("uri=%s&format=txt", URLEncoder.encode(namespace, "UTF-8"));
			conn = (HttpURLConnection) new URL(PrefixAPI_URL + qstr).openConnection();
			
			if (conn.getResponseCode() != 200)
				return null;
			
			BufferedReader reader = new BufferedReader(new InputStreamReader(conn.getInputStream()));
			
			String s = null, prefix = null;
			while ((s = reader.readLine()) != null) 
				prefix = s.split("\t")[0];
			reader.close();
			
			return prefix;
		} catch (Throwable e) {
			logger.error(e.getMessage());
			return null;
		} finally {
			conn.disconnect();
		}
	}
	
	public static String qname(String uri)
	{
		if (uri == null || uri.equals(""))
			return null;
		
		HttpURLConnection conn = null;
		try {
			String qstr = String.format("uri=%s", URLEncoder.encode(uri, "UTF-8"));
			conn = (HttpURLConnection) new URL(PrefixAPI_URL + qstr).openConnection();
			
			if (conn.getResponseCode() != 200)
				return null;
			
			BufferedReader reader = new BufferedReader(new InputStreamReader(conn.getInputStream()));

			String s = null, qname = null;

			// e.g., <body about="http://prefix.cc/foaf:name">
			// but not an elegant implementation
			final int length = "http://prefix.cc/".length();
			while ((s = reader.readLine()) != null) {	
				if (s.startsWith("<body")) {
					int beginIndex = s.indexOf("\""), endIndex = s.lastIndexOf("\"");
					qname = s.substring(beginIndex + length + 1, endIndex);
					break;
				}
			}
			reader.close();
			
			return qname;
		} catch (Throwable e) {
			logger.error(e.getMessage());
			return null;
		} finally {
			conn.disconnect();
		}
	}
	
	public static void main(String args[])
	{
		PropertyConfigurator.configure(PrefixAPI.class.getResource("/config/log4j.properties"));
		
		String namespace = "http://xmlns.com/foaf/0.1/";
		String prefix = PrefixAPI.prefix(namespace);
		System.out.println(prefix);
		
		String uri = "http://xmlns.com/foaf/0.1/mbox_sha2sum";
		String qname = PrefixAPI.qname(uri);
		System.out.println(qname);
	} 
}
