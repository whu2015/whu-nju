package cn.edu.nju.ws.ocr.fpc;

import java.sql.*;
import java.util.*;
import java.util.concurrent.*;
import org.apache.log4j.*;
import cn.edu.nju.ws.ocr.datab.*;
import cn.edu.nju.ws.ocr.rdf.*;
import cn.edu.nju.ws.ocr.util.*;

public class InstSampler 
{
	static Logger logger = Logger.getLogger(InstSampler.class);
	
	public void execInst1()
	{
		/* SELECT uri_id,type_uri_id INTO OUTFILE '/tmp/type.txt' 
		 * FIELDS TERMINATED BY ',' OPTIONALLY ENCLOSED BY '"' LINES TERMINATED BY '\r\n' 
		 * FROM type WHERE is_explicitly_stated=1;
		 * 
		 * LOAD DATA INFILE '/tmp/type.txt' INTO TABLE inst_class 
		 * FIELDS TERMINATED BY ',' OPTIONALLY ENCLOSED BY '"' LINES TERMINATED BY '\r\n';
		 */
		
		BlockingQueue<Runnable> queue = new LinkedBlockingQueue<Runnable>();  
		ThreadPoolExecutor exec = new ThreadPoolExecutor(4, 5, 7, TimeUnit.DAYS, queue);   
			
		int begin = 1, end = 299455785; // max(type_uri_id)=299,444,702 max(uri_id)=299,455,785
		while (begin <= end) {
			InstSamplerThread1 ist1 = new InstSamplerThread1(begin);
			exec.execute(ist1);
			++begin;
		}
		exec.shutdown();
	}
	
	public void execInst2()
	{
		try {
			Connection connObjectCoref = DBConnPool.getObjectCoref();
			
			String sqlstr1 = "SELECT DISTINCT class_id FROM inst_class";
			PreparedStatement stmt1 = connObjectCoref.prepareStatement(sqlstr1);
			
			List<Integer> list = Collections.synchronizedList(new ArrayList<Integer>());
			ResultSet rs1 = stmt1.executeQuery();
			while (rs1.next()) {
				int classID = rs1.getInt(1);
				list.add(classID);
			}
			rs1.close();
			stmt1.close();
			connObjectCoref.close();
			
			logger.debug("distinct_classes=" + list.size());
			
			BlockingQueue<Runnable> queue = new LinkedBlockingQueue<Runnable>();  
			ThreadPoolExecutor exec = new ThreadPoolExecutor(4, 5, 1, TimeUnit.DAYS, queue);
			
			for (int i = 0; i < list.size(); ++i) {
				int classID = list.get(i);
				InstSamplerThread2 ist2 = new InstSamplerThread2(classID);
				exec.execute(ist2);
			}
			exec.shutdown();
		} catch (Throwable e) {
			logger.error(e.getMessage());
		}
	}
	
	public void execInst3()
	{
		try {
			Connection connObjectCoref = DBConnPool.getObjectCoref();
			
			String sqlstr1 = "SELECT class_id FROM class_instnum WHERE instnum>=300";
			PreparedStatement stmt1 = connObjectCoref.prepareStatement(sqlstr1);
			
			List<Integer> list = Collections.synchronizedList(new ArrayList<Integer>());
			ResultSet rs1 = stmt1.executeQuery();
			while (rs1.next()) {
				int classID = rs1.getInt(1);
				list.add(classID);
			}
			rs1.close();
			stmt1.close();
			connObjectCoref.close();
			
			logger.debug("sample_classes=" + list.size());
			
			BlockingQueue<Runnable> queue = new LinkedBlockingQueue<Runnable>();  
			ThreadPoolExecutor exec = new ThreadPoolExecutor(4, 5, 1, TimeUnit.DAYS, queue);
			
			for (int i = 0; i < list.size(); ++i) {
				int classID = list.get(i);
				InstSamplerThread3 ist3 = new InstSamplerThread3(classID);
				exec.execute(ist3);
			}
			exec.shutdown();
		} catch (Throwable e) {
			logger.error(e.getMessage());
		}
	}
	
	public void execInst4()
	{
		try {
			Connection connObjectCoref = DBConnPool.getObjectCoref();
			
			String sqlstr1 = "SELECT DISTINCT class_id FROM inst_class WHERE is_sample=1 GROUP BY class_id";
			PreparedStatement stmt1 = connObjectCoref.prepareStatement(sqlstr1);
			
			String sqlstr2 = "SELECT uri_id FROM inst_class WHERE is_sample=1 AND class_id=?";
			PreparedStatement stmt2 = connObjectCoref.prepareStatement(sqlstr2);			
			
			List<Integer> list = Collections.synchronizedList(new ArrayList<Integer>());
			ResultSet rs1 = stmt1.executeQuery();
			while (rs1.next()) {
				int classID = rs1.getInt(1);
				list.add(classID);
			}
			rs1.close();
			stmt1.close();
			
			Map<Integer, List<Integer>> map = new HashMap<Integer, List<Integer>>();
			for ( int i = 0; i < list.size(); ++i) {
				int classID = list.get(i);
				List<Integer> list2 = new ArrayList<Integer>();
				stmt2.setInt(1, classID);
				ResultSet rs2 = stmt2.executeQuery();
				while (rs2.next())
					list2.add(rs2.getInt(1));
				rs2.close();
				map.put(classID, list2);
			}
			stmt2.close();
			connObjectCoref.close();
			
			logger.debug("sample_inst=" + list.size());
			
			BlockingQueue<Runnable> queue = new LinkedBlockingQueue<Runnable>();  
			ThreadPoolExecutor exec = new ThreadPoolExecutor(4, 5, 1, TimeUnit.DAYS, queue);
			
			Iterator<Integer> iter = map.keySet().iterator();
			while (iter.hasNext()) {
				int classID = iter.next();
				List<Integer> uris = map.get(classID);
				InstSamplerThread4 ist4 = new InstSamplerThread4(uris);
				exec.execute(ist4);
			}
			exec.shutdown();
		} catch (Throwable e) {
			logger.error(e.getMessage());
		}
	}
	
	public static void main(String args[])
	{
		PropertyConfigurator.configure(InstSampler.class.getResource("/config/log4j.properties"));
		DBParam.init();
		
		//InstSampler is = new InstSampler();
		//is.execInst1();
		//is.execInst2();
		//is.execInst3();
		//is.execInst4();
	}
	
	public class InstSamplerThread1 implements Runnable
	{
		private int uriID;
		
		public InstSamplerThread1(int uid) { this.uriID = uid; }
		
		public void run()
		{
			try {
				logger.debug("uri_id=" + uriID);

				Connection connFalconetV05 = DBConnPool.getFalconetV05();
				
				String sqlstr1 = "SELECT type_uri_id FROM " + DatasetType.FALCONETV05_TYPE 
							   + " WHERE uri_id=? AND is_explicitly_stated=1";
				PreparedStatement stmt1 = connFalconetV05.prepareStatement(sqlstr1);
				
				Connection connObjectCoref = DBConnPool.getObjectCoref();
				String sqlstr2 = "INSERT INTO inst_class(uri_id,class_id,is_sample) VALUES(?,?,?)";
				PreparedStatement stmt2 = connObjectCoref.prepareStatement(sqlstr2);
					
				stmt1.setInt(1, uriID);
				ResultSet rs1 = stmt1.executeQuery();
				while (rs1.next()) {
					int classID = rs1.getInt(1);	
					stmt2.setInt(1, uriID);
					stmt2.setInt(2, classID);
					stmt2.setInt(3, 0);
					stmt2.addBatch();
				}
				stmt2.executeBatch();
				rs1.close();
				
				stmt1.close();
				stmt2.close();
				connFalconetV05.close();
				connObjectCoref.close();
			} catch (Throwable e) {
				logger.error(e.getMessage());
			}
		}
	}
	
	public class InstSamplerThread2 implements Runnable
	{
		private int classID;
		
		public InstSamplerThread2(int cid) { this.classID = cid; }
		
		public void run()
		{
			try {
				logger.debug("class_id=" + classID);
				
				Connection connObjectCoref = DBConnPool.getObjectCoref();
				
				String sqlstr1 = "SELECT COUNT(uri_id) FROM inst_class WHERE class_id=?";
				PreparedStatement stmt1 = connObjectCoref.prepareStatement(sqlstr1);
				
				String sqlstr2 = "INSERT INTO class_instnum(class_id,instnum) VALUES(?,?)";
				PreparedStatement stmt2 = connObjectCoref.prepareStatement(sqlstr2);
				
				stmt1.setInt(1, classID);
				ResultSet rs1 = stmt1.executeQuery();
				while (rs1.next()) {
					int count = rs1.getInt(1);
					stmt2.setInt(1, classID);
					stmt2.setInt(2, count);
					stmt2.executeUpdate();
				}
				rs1.close();
				stmt1.close();
				stmt2.close();
				connObjectCoref.close();
			} catch (Throwable e) {
				logger.error(e.getMessage());
			}
		}
	}
	
	public class InstSamplerThread3 implements Runnable
	{
		private int classID;
		
		public InstSamplerThread3(int cid) { this.classID = cid; }
		
		public void run()
		{
			try {
				logger.debug("class_id=" + classID);
				
				String classURI = URIHelper.uri(classID, DatasetType.FALCONETV05);
				if (classURI.startsWith(SpecialPrefix.RDF) 
						|| classURI.startsWith(SpecialPrefix.RDFS) 
						|| classURI.startsWith(SpecialPrefix.OWL) 
						|| classURI.startsWith(SpecialPrefix.SKOS)
						|| classURI.startsWith(SpecialPrefix.XSD))
					return; 
				
				Connection connObjectCoref = DBConnPool.getObjectCoref();
				
				String sqlstr1 = "SELECT id FROM inst_class WHERE class_id=?";
				PreparedStatement stmt1 = connObjectCoref.prepareStatement(sqlstr1);
				
				String sqlstr2 = "UPDATE inst_class SET is_sample=1 WHERE id=?";
				PreparedStatement stmt2 = connObjectCoref.prepareStatement(sqlstr2);
				
				List<Integer> ids = new ArrayList<Integer>(1000);
				List<Integer> samples = new ArrayList<Integer>(1000);
				
				stmt1.setInt(1, classID);
				ResultSet rs1 = stmt1.executeQuery();
				while (rs1.next()) {
					int id = rs1.getInt(1);
					ids.add(id);
				}
				rs1.close();
				
				if (ids.size() <= 1000) {
					samples.addAll(ids);
				} else {
					Random random = new Random(ids.size());
					while (samples.size() < 1000) {
						int index = Math.abs(random.nextInt() + 1) % ids.size();
						int id = ids.remove(index);
						samples.add(id);
					}
				}
				
				for (int i = 0; i < samples.size(); ++i) {
					int id = samples.get(i);
					stmt2.setInt(1, id);
					stmt2.addBatch();
				}
				stmt2.executeBatch();
				
				stmt1.close();
				stmt2.close();
				connObjectCoref.close();
			} catch (Throwable e) {
				logger.error(e.getMessage());
			}
		}
	}
	
	public class InstSamplerThread4 implements Runnable
	{
		private List<Integer> uris;
		
		public InstSamplerThread4(List<Integer> uris) { this.uris = uris; }
		
		public void run()
		{
			try {
				logger.debug("sample_inst_per_class=" + uris.size());
				
				Connection connFalconetV05 = DBConnPool.getFalconetV05();
				
				String sqlstr1 = "SELECT DISTINCT p,o FROM " + DatasetType.FALCONETV05_QUADRUPLE + " WHERE s=?";
				PreparedStatement stmt1 = connFalconetV05.prepareStatement(sqlstr1);
				
				Connection connObjectCoref = DBConnPool.getObjectCoref();
				
				String sqlstr2 = "INSERT INTO inst_prop(uri_id,prop_id,value) VALUES(?,?,?)";
				PreparedStatement stmt2 = connObjectCoref.prepareStatement(sqlstr2);
				
				for (int i = 0; i < uris.size(); ++i) {
					int uriID = uris.get(i);
					stmt1.setString(1, "u" + uriID);
					ResultSet rs1 = stmt1.executeQuery();
					while (rs1.next()) {
						String p = rs1.getString(1);
						if (!p.equals("u" + FalconetV05Prop.RDF_type_ID)) {
							String o = rs1.getString(2);
							stmt2.setInt(1, uriID);
							stmt2.setInt(2, Integer.parseInt(p.substring(1)));
							stmt2.setString(3, o);
							stmt2.addBatch();
						}
					}
					stmt2.executeBatch();
					rs1.close();
				}
				stmt1.close();
				stmt2.close();
				connFalconetV05.close();
				connObjectCoref.close();
			} catch (Throwable e) {
				logger.error(e.getMessage());
			}
		}
	}
}
