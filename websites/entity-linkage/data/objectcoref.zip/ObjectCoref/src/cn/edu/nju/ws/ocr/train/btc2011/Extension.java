package cn.edu.nju.ws.ocr.train.btc2011;

import java.io.*;
import java.sql.*;
import java.util.*;

import org.apache.log4j.*;

import cn.edu.nju.ws.ocr.datab.*;
import cn.edu.nju.ws.ocr.kernel.btc2011.*;
import cn.edu.nju.ws.ocr.rdf.*;
import cn.edu.nju.ws.ocr.util.*;

public class Extension 
{
	static Logger logger = Logger.getLogger(Extension.class);
	
	public final static int TOP_K = 1;
	
	private String inputURI;
	private String[] properties;
	
	public Extension(String uri, String[] properties) 
	{ 
		this.inputURI = uri; 
		this.properties = properties;
	}
	
	public List<String> coreferencing()
	{
		List<String> corefed = new ArrayList<String> ();
		try {
			long start = System.currentTimeMillis();
			
			BTC2011KernelBuilder kb = new BTC2011KernelBuilder(inputURI);
			kb.query();
			
			Map<Integer, RDFInst> instances = kb.getKernel();
			
			logger.debug("kernel_size=" +instances.size());
			
			int uriID = URIHelper.uriID(inputURI, DatasetType.BTC2011);
			
			Connection connBTC2011 = DBConnPool.getBTC2011();
			String sqlstr1 = "SELECT DISTINCT o FROM " + DatasetType.BTC2011_QUADRUPLE + " WHERE s=? AND p=? AND o NOT LIKE 'b%'";
			PreparedStatement stmt1 = connBTC2011.prepareStatement(sqlstr1);
			String sqlstr2 = "SELECT DISTINCT s FROM " + DatasetType.BTC2011_QUADRUPLE + " WHERE p=? AND o=? AND s NOT LIKE 'b%'";
			PreparedStatement stmt2 = connBTC2011.prepareStatement(sqlstr2);
			
			for (int i = 0; i < TOP_K; ++i) {
				int propID = URIHelper.uriID(properties[i], DatasetType.BTC2011);
				
				stmt1.setString(1, "u" + uriID);
				stmt1.setString(2, "u" + propID);
				ResultSet rs1 = stmt1.executeQuery();
				while (rs1.next()) {
					String o = rs1.getString(1);
					if (o != null && !o.trim().equals("l")) {
						stmt2.setString(1, "u" + propID);
						stmt2.setString(2, o);
						ResultSet rs2 = stmt2.executeQuery();
						while (rs2.next()) {
							int uriID2 = Integer.parseInt(rs2.getString(1).substring(1));
							if (!instances.containsKey(uriID2)) {
								RDFInst inst = new RDFInst(uriID2);
								instances.put(uriID2, inst);
							}
						}
						rs2.close();
					}
				}
				rs1.close();
			}
			stmt1.close();
			stmt2.close();
			connBTC2011.close();
			
			long end = System.currentTimeMillis();
			System.out.println("run_time=" + ((end - start) / (double) 1000));
			corefed.add(0, "time:" + (end - start) / 1000.0);
			int index = 1;
			for (RDFInst inst : instances.values()) {
				String uri = URIHelper.uri(inst.getURIID(), DatasetType.BTC2011);
				String coref = String.format("%s %s", index, uri);
				System.out.println(coref);
				corefed.add(coref);
				index++;
			}
		} catch (Throwable e) {
			logger.error(e.getMessage());
		}
		return corefed;
	}
	
	public static List<String> readURIsFromFile()
	{
		List<String> uris = new ArrayList<String> ();
		Scanner input = null;
		File file = null;
		try {
			file = new File("btc2011_top50_query_uris.txt");
			input = new Scanner(file);
			while(input.hasNext()) {
				String line = input.nextLine().trim();
				if(line.startsWith("http://")) {
					uris.add(line);
				}
			}
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			if(input != null) 
				input.close();
		}
		return uris;
	}
	
	public static void printResult(String fileName, List<String> results) 
	{
		PrintWriter output = null;
		try {
			output = new PrintWriter(new File(fileName));
			for(String result : results) {
				output.println(result);
				output.flush();
			}
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			if (output != null) 
				output.close();
		}
	}
	
	public static void main(String args[])
	{
		PropertyConfigurator.configure(Extension.class.getResource("/config/log4j.properties"));
		DBParam.init();
		
//		String uri = "http://dbpedia.org/resource/Tim_Berners-Lee";
		String[] prop = { "http://www.w3.org/2000/01/rdf-schema#label" };
		List<String> uris = readURIsFromFile();
		for(int i = 0; i < uris.size(); i++) {
			Extension e = new Extension(uris.get(i), prop);
			List<String> corefed = e.coreferencing();
			printResult("2014/extension_new/" + i, corefed);
		}			
	}
}
