package cn.edu.nju.ws.ocr.cache;

import java.sql.*;
import org.apache.log4j.*;
import cn.edu.nju.ws.ocr.datab.*;
import cn.edu.nju.ws.ocr.util.*;

public class QueryLogger 
{
	static Logger logger = Logger.getLogger(QueryLogger.class);
	
	synchronized public static void write(int uriID, String source)
	{
		if (uriID <= 0)
			return;
		
		String uri = URIHelper.uri(uriID, source);
		write(uri, source);
	}
	
	synchronized public static void write(String uri, String source)
	{
		if (uri == null || uri.equals(""))
			return;
		
		try {
			Connection connObjectCoref = DBConnPool.getObjectCoref();
			String sqlstr1 = "INSERT INTO querylog(uri,source) VALUES(?,?)";
			PreparedStatement stmt1 = connObjectCoref.prepareStatement(sqlstr1);
			
			stmt1.setString(1, uri);
			stmt1.setString(2, source);
			stmt1.executeUpdate();
		
			stmt1.close();
			connObjectCoref.close();
		} catch (Throwable e) {
			logger.error(e.getMessage());
		}
	}
}
