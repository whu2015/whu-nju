package cn.edu.nju.ws.ocr.kernel;

import java.util.*;
import org.apache.log4j.*;
import cn.edu.nju.ws.ocr.rdf.*;

public interface IKernelBuilder 
{
	static Logger logger = Logger.getLogger(IKernelBuilder.class);
	
	public Map<Integer, RDFInst> getKernel();
	
	public void query();
}
