package cn.edu.nju.ws.ocr.train;

import java.util.*;
import org.apache.log4j.*;
import cn.edu.nju.ws.ocr.kernel.*;
import cn.edu.nju.ws.ocr.rdf.*;

public abstract class SelfTrainerThread extends Thread 
{
	static Logger logger = Logger.getLogger(SelfTrainerThread.class);
	
	private int inputURIID = 0;
	private List<RDFInst> outputInstances;
	private Map<Integer, RDFInst> instances;
	
	private IKernelBuilder kb;
	
	private PLDList pldList;
	protected INameFinder nameFinder;
	
	public SelfTrainerThread() {}
	
	public SelfTrainerThread(int inputURIID, IKernelBuilder kb, List<RDFInst> outputInstances, 
							 INameFinder nameFinder, Map<Integer, RDFInst> instances)
	{
		super();
		
		this.inputURIID = inputURIID;
		this.kb = kb;
		this.outputInstances = outputInstances;
		this.nameFinder = nameFinder;
	}
	
	synchronized public void setPLDList(PLDList pldList) { this.pldList = pldList; }

	public void setNameFinder(INameFinder nameFinder) { this.nameFinder = nameFinder; }

	public void setInputURIID(int inputURIID) { this.inputURIID = inputURIID; }

	public void setKB(IKernelBuilder kb) { this.kb = kb; }
	
	public void setInstances(Map<Integer, RDFInst> instances) { this.instances = instances; }

	public List<RDFInst> getOutputInstances() { return outputInstances; }

	public void generateOutputNoPLD(int iteration) 
	{
		try {
			nameFinder.completeInfo(instances);
		} catch (Throwable e) {
			logger.error(e.getMessage());
		}
		
		Sorter sorter = new Sorter(this.inputURIID);
		outputInstances = sorter.sort(this.instances, this.kb.getKernel());
		
		synchronized (pldList) {
			pldList.clear();
			PLD pld = new PLD();
			Iterator<RDFInst> iter = outputInstances.iterator();
			while (iter.hasNext()) {
				RDFInst inst = iter.next();
				pld.add(inst);
			}
		}
	}
}
