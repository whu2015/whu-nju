package cn.edu.nju.ws.ocr.util;

import java.sql.*;
import java.util.*;
import org.apache.log4j.*;
import cn.edu.nju.ws.ocr.datab.*;
import cn.edu.nju.ws.ocr.rdf.*;

public class TypeHelper
{
	static Logger logger = Logger.getLogger(TypeHelper.class);
	
	public static Set<Integer> typeIDs(int uriID, String source)
	{
		if (uriID <= 0)
			return null;
		
		try {
			Set<Integer> typeIDs = null;
			
			Connection conn = null;
			PreparedStatement stmt1 = null;
			
			if (source.equalsIgnoreCase(DatasetType.FALCONETV05)) {
				conn = DBConnPool.getFalconetV05();
				typeIDs = new HashSet<Integer>();
				
				String sqlstr1 = "SELECT DISTINCT type_uri_id FROM " + DatasetType.FALCONETV05_TYPE + " WHERE uri_id=?";
				stmt1 = conn.prepareStatement(sqlstr1);
				
				stmt1.setInt(1, uriID);
				ResultSet rs1 = stmt1.executeQuery();
				while (rs1.next()) {
					int typeID = rs1.getInt(1);
					if (typeID == FalconetV05Prop.OWL_Thing_ID)
						continue;
					typeIDs.add(typeID);
				}
				rs1.close();
			} else if (source.equalsIgnoreCase(DatasetType.BTC2011)) {
				conn = DBConnPool.getBTC2011();
				typeIDs = new HashSet<Integer>();
				
				String sqlstr1 = "SELECT DISTINCT o FROM " + DatasetType.BTC2011_QUADRUPLE 
							   + " WHERE s=? AND p=? AND o LIKE 'u%'";
				stmt1 = conn.prepareStatement(sqlstr1);
				
				stmt1.setString(1, "u" + uriID);
				stmt1.setString(2, "u" + BTC2011Prop.RDF_type_ID);
				ResultSet rs1 = stmt1.executeQuery();
				while (rs1.next()) {
					int typeID = Integer.parseInt(rs1.getString(1).substring(1));
					if (typeID == BTC2011Prop.OWL_Thing_ID)
						continue;
					typeIDs.add(typeID);
				}
				rs1.close();
			} else return null;

			stmt1.close();
			conn.close();
			
			return typeIDs;
		} catch (Throwable e) {
			logger.error(e.getMessage());
			return null;
		}
	}
	
	public static Set<Integer> typeIDs(String uri, String source)
	{
		if (uri == null || uri.equals(""))
			return null;
		
		return typeIDs(URIHelper.uriID(uri, source), source);
	}
	
	public static void main(String args[])
	{
		PropertyConfigurator.configure(URIHelper.class.getResource("/config/log4j.properties"));
		DBParam.init();
		
		String uri = "http://www.w3.org/People/Berners-Lee/card#i";
		System.out.println(typeIDs(uri, DatasetType.FALCONETV05));
	}
}
