package cn.edu.nju.ws.ocr.train.btc2011;

import java.util.*;
import org.apache.log4j.*;

public class PropPair implements Comparable<PropPair>
{
	static Logger logger = Logger.getLogger(PropPair.class);
	
	public int propID1, propID2;
	public int times;
	public double infoGain;
	public Map<String, Map<Integer, Integer>> terms;
	
	PropPair(int propID1, int propID2, int times) 
	{
		this.propID1 = propID1;
		this.propID2 = propID2;
		this.times = times;
		this.terms = Collections.synchronizedMap(new LinkedHashMap<String, Map<Integer, Integer>>());
	}
	
	synchronized public void addTerm(int uriID, List<String> list)
	{
		for (int i = 0; i < list.size(); ++i) {
			String term = list.get(i);
			if (!terms.containsKey(term)) {
				Map<Integer, Integer> map = new LinkedHashMap<Integer, Integer>();
				map.put(uriID, 1);
				terms.put(term, map);
			} else {
				Map<Integer, Integer> map = terms.get(term);
				if (!map.containsKey(uriID))
					map.put(uriID, 1);
			}
		}
	}
	
//	public String toString() { return propID1 + " " + propID2 + " " + times; }
	
	public String toString() {
		String prop1 = (propID1 == 0)? "localname" : BTC2011Negatives.getURIByID(String.valueOf(propID1));
		String prop2 = (propID2 == 0)? "localname" : BTC2011Negatives.getURIByID(String.valueOf(propID2));
		return String.format("%s\t%s: %s", prop1, prop2, infoGain);
	}

	public int compareTo(PropPair pp) 
	{
		if (this.infoGain < pp.infoGain) {
			return 1;
		} else if (this.infoGain > pp.infoGain) {
			return -1;
		} else return 0;
	}
}
