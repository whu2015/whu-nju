package cn.edu.nju.ws.ocr.datab;

import java.util.*;
import org.apache.log4j.*;

public class DBParam 
{
	static Logger logger = Logger.getLogger(DBParam.class);
	
	public static final String DBConnFile = "/config/dbconn.properties";
	
	public static final String DRV = "com.mysql.jdbc.Driver";

	public static String URL_ObjectCoref;
	public static String URL_FalconetV05;
	public static String URL_BTC2011;
	public static String URL_NYT;
	public static String URL_PR;

	private static Properties getProperties()
	{
		try {
			Properties properties = new Properties();
			properties.load(DBParam.class.getResourceAsStream(DBConnFile));
			
			return properties;
		} catch (Throwable e) {
			logger.error(e.getMessage());
			return null;
		} 
	}
	
	public static void init()
	{
		Properties properties = getProperties();
		
		String r = properties.getProperty("URL_ObjectCoref");
        if (r != null) 
        	URL_ObjectCoref = r.trim();
        
        String s = properties.getProperty("URL_FalconetV05");
        if (s != null)
        	URL_FalconetV05 = s.trim();
        
        String t = properties.getProperty("URL_BTC2011");
        if (t != null)
        	URL_BTC2011 = t.trim();
        
        String u = properties.getProperty("URL_NYT");
        if (u != null)
        	URL_NYT = u.trim();

        String v = properties.getProperty("URL_PR");
        if (v != null)
        	URL_PR = v.trim();

        logger.info(URL_ObjectCoref);
        logger.info(URL_FalconetV05);
        logger.info(URL_BTC2011);
        logger.info(URL_NYT);
        logger.info(URL_PR);
	}
	
	public static void main(String args[])
	{
		PropertyConfigurator.configure(DBParam.class.getResource("/config/log4j.properties"));
		DBParam.init();
	}
}
