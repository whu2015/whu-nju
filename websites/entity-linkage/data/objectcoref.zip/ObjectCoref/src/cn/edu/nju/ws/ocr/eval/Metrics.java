package cn.edu.nju.ws.ocr.eval;

import org.apache.log4j.*;

public class Metrics 
{
	static Logger logger = Logger.getLogger(Metrics.class);
	
	private int found, exist, correct;
    
    private double precision, recall, fmeasure;
    
    private Alignment errors, corrects, losts;

    public Alignment correctAlignment() { return corrects; }

    public void setCorrectAlignment(Alignment ca) { corrects = ca; }

    public Alignment lostAlignment() { return losts; }

    public void setLostAlignment(Alignment la) { losts = la; }

    public Alignment errorAlignment() { return errors; }

    public void setErrorAlignment(Alignment ea) { errors = ea; }

    public int correct() { return correct; }

    public void setCorrect(int c) { correct = c; }

    public int found() { return found; }

    public void setFound(int f) { found = f; }

    public int exist() { return exist; }

    public void setExist(int e) { exist = e; }

    public double fmeasure() { return fmeasure; }

    public void setFMeasure(double fm) { fmeasure = fm; }

    public double precision() { return precision; }

    public void setPrecision(double prec) { precision = prec; }

    public double recall() { return recall; }

    public void setRecall(double rec) { recall = rec; }
}
