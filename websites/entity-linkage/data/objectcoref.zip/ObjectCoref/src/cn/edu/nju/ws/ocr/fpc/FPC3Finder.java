package cn.edu.nju.ws.ocr.fpc;

import java.sql.*;
import java.util.*;
import org.apache.log4j.*;
import cn.edu.nju.ws.ocr.datab.*;

public class FPC3Finder 
{
	static Logger logger = Logger.getLogger(FPC3Finder.class);
	
	private List<Itemset3> fpc3;
	
	public FPC3Finder() { this.fpc3 = new ArrayList<Itemset3>(5); }
	
	public List<Itemset3> falconetV05_fpc3()
	{
		try {
			Connection connObjectCoref = DBConnPool.getObjectCoref();
			
			String sqlstr1 = "SELECT prop_id1,prop_id2,prop_id3 FROM fpc3 WHERE confirmed=1";
			PreparedStatement stmt1 = connObjectCoref.prepareStatement(sqlstr1);
			
			ResultSet rs1 = stmt1.executeQuery();
			while (rs1.next()) {
				int prop1 = rs1.getInt(1), prop2 = rs1.getInt(2), prop3 = rs1.getInt(3);
				Itemset3 is = new Itemset3(prop1, prop2, prop3);
				fpc3.add(is);
			}
			rs1.close();
			stmt1.close();
			connObjectCoref.close();
			
			return fpc3;
		} catch (Throwable e) {
			logger.error(e.getMessage());
			return null;
		}
	}
	
	public List<Itemset3> btc2011_fpc3()
	{	
		try {
			Connection connBTC2011 = DBConnPool.getBTC2011();
			
			String sqlstr1 = "SELECT prop_id1,prop_id2,prop_id3 FROM fpc3 WHERE confirmed=1";
			PreparedStatement stmt1 = connBTC2011.prepareStatement(sqlstr1);
			
			ResultSet rs1 = stmt1.executeQuery();
			while (rs1.next()) {
				int prop1 = rs1.getInt(1), prop2 = rs1.getInt(2), prop3 = rs1.getInt(3);
				Itemset3 is = new Itemset3(prop1, prop2, prop3);
				fpc3.add(is);
			}
			rs1.close();
			stmt1.close();
			connBTC2011.close();
			
			return fpc3;
		} catch (Throwable e) {
			logger.error(e.getMessage());
			return null;
		}
	}
}
