package cn.edu.nju.ws.ocr.util;

import org.apache.log4j.*;
import org.apache.nutch.util.*;

public class PLDHelper 
{
	static Logger logger = Logger.getLogger(PLDHelper.class);
	
	// call domain.jar, but no clue about where this JAR comes from
	public static String pldName(String uri) 
	{
		if (uri == null || uri.equals(""))
			return null;
		
		// only effective for HTTP URIs
		if (uri.startsWith("http://")) 
			uri = uri.substring(7);
		
		uri = uri.replaceAll(":", "/");
		uri = "http://" + uri;
		
		try {
			return URLUtil.getDomainName(uri);
		} catch (Throwable e) {
			logger.error(e.getMessage());
			return null;
		}
	}
	
	public static void main(String args[]) throws Throwable
	{
		PropertyConfigurator.configure(PLDHelper.class.getResource("/config/log4j.properties"));
		
		String uri = "http://ws.nju.edu.cn/courses/db";
		String uri2 = "ftp://114.212.190.144";
		String uri3 = "mailto:whu@nju.edu.cn";
		String uri4 = "urn:uuid:9fcac449-28b7-45d2-bb2c-0da941659e2d";
		
		System.out.println(PLDHelper.pldName(uri));
		System.out.println(PLDHelper.pldName(uri2));
		System.out.println(PLDHelper.pldName(uri3));
		System.out.println(PLDHelper.pldName(uri4));
	} 
}
