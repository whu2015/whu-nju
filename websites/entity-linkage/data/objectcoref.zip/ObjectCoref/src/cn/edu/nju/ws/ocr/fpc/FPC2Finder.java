package cn.edu.nju.ws.ocr.fpc;

import java.io.*;
import java.sql.*;
import java.util.*;
import org.apache.log4j.*;
import cn.edu.nju.ws.ocr.datab.*;

public class FPC2Finder 
{
	static Logger logger = Logger.getLogger(FPC2Finder.class);
	
	private List<Itemset2> fpc2;
	
	public FPC2Finder() { this.fpc2 = new ArrayList<Itemset2>(100); }
	
	public void falconetV05_fpc2_input(String filepath)
	{
		try {
			BufferedReader reader = new BufferedReader(
					new InputStreamReader(new FileInputStream(filepath)));
			
			Connection connObjectCoref = DBConnPool.getObjectCoref();
			
			String sqlstr1 = "INSERT INTO fpc2 VALUES(?,?,0,0,0,0,1)";
			PreparedStatement stmt1 = connObjectCoref.prepareStatement(sqlstr1);
			
			String s = reader.readLine();
			while (s != null) {
				String[] fpc = s.split("\t");
				
				stmt1.setInt(1, Integer.parseInt(fpc[0].trim()));
				stmt1.setInt(2, Integer.parseInt(fpc[2].trim()));
				stmt1.executeUpdate();
				
				s = reader.readLine();
			}
			stmt1.close();
			connObjectCoref.close();
			
			reader.close();
		} catch (Throwable e) {
			logger.error(e.getMessage());
		} 
	}
	
	public List<Itemset2> falconetV05_fpc2()
	{
		try {
			Connection connObjectCoref = DBConnPool.getObjectCoref();
			
			String sqlstr1 = "SELECT prop_id1,prop_id2 FROM fpc2 WHERE confirmed=1";
			PreparedStatement stmt1 = connObjectCoref.prepareStatement(sqlstr1);
			
			ResultSet rs1 = stmt1.executeQuery();
			while (rs1.next()) {
				int prop1 = rs1.getInt(1), prop2 = rs1.getInt(2);
				Itemset2 is = new Itemset2(prop1, prop2);
				fpc2.add(is);
			}
			rs1.close();
			stmt1.close();
			connObjectCoref.close();
			
			return fpc2;
		} catch (Throwable e) {
			logger.error(e.getMessage());
			return null;
		}
	}
	
	public void btc2011_fpc2_input(String filepath)
	{
		try {
			BufferedReader reader = new BufferedReader(
					new InputStreamReader(new FileInputStream(filepath)));
			
			Connection connBTC2011 = DBConnPool.getBTC2011();
			
			String sqlstr1 = "INSERT INTO fpc2 VALUES(?,?,1)";
			PreparedStatement stmt1 = connBTC2011.prepareStatement(sqlstr1);
			
			String s = reader.readLine();
			while (s != null) {
				String[] fpc = s.split("\t");
				
				stmt1.setInt(1, Integer.parseInt(fpc[0].trim()));
				stmt1.setInt(2, Integer.parseInt(fpc[2].trim()));
				stmt1.executeUpdate();
				
				s = reader.readLine();
			}
			stmt1.close();
			connBTC2011.close();
			
			reader.close();
		} catch (Throwable e) {
			logger.error(e.getMessage());
		} 
	}
	
	public List<Itemset2> btc2011_fpc2()
	{	
		try {
			Connection connBTC2011 = DBConnPool.getBTC2011();
			
			String sqlstr1 = "SELECT prop_id1,prop_id2 FROM fpc2 WHERE confirmed=1";
			PreparedStatement stmt1 = connBTC2011.prepareStatement(sqlstr1);
			
			ResultSet rs1 = stmt1.executeQuery();
			while (rs1.next()) {
				int prop1 = rs1.getInt(1), prop2 = rs1.getInt(2);
				Itemset2 is = new Itemset2(prop1, prop2);
				fpc2.add(is);
			}
			rs1.close();
			stmt1.close();
			connBTC2011.close();
			
			return fpc2;
		} catch (Throwable e) {
			logger.error(e.getMessage());
			return null;
		}
	}
	
	public static void main(String args[]) 
	{
		PropertyConfigurator.configure(FPC2Finder.class.getResource("/config/log4j.properties"));
		DBParam.init();
		
		//FPC2Finder fpc2 = new FPC2Finder();
		//fpc2.falconetV05_fpc2_input(FPC2Finder.class.getResource("/config/fpc2_falconetV05.txt").getPath());
	}
}
