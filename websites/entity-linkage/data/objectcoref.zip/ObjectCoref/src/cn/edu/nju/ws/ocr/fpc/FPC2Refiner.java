package cn.edu.nju.ws.ocr.fpc;

import java.io.*;
import java.sql.*;
import java.util.*;
import org.apache.log4j.*;
import cn.edu.nju.ws.ocr.datab.*;
import cn.edu.nju.ws.ocr.nlp.*;
import cn.edu.nju.ws.ocr.rdf.*;
import cn.edu.nju.ws.ocr.util.*;

public class FPC2Refiner
{
	static Logger logger = Logger.getLogger(FPC2Refiner.class);
	
	public void execFPC1()
	{
		try {
			Connection connObjectCoref = DBConnPool.getObjectCoref();
			
			String sqlstr1 = "SELECT itemset FROM prop_comb WHERE support>=0.98 AND level=2";
			PreparedStatement stmt1 = connObjectCoref.prepareStatement(sqlstr1);
			
			String sqlstr2 = "INSERT IGNORE INTO fpc2(prop_id1,prop_id2) VALUES(?,?)";
			PreparedStatement stmt2 = connObjectCoref.prepareStatement(sqlstr2);
			
			Map<String,Itemset2> itemsets = new HashMap<String, Itemset2>();
			ResultSet rs1 = stmt1.executeQuery();
			while (rs1.next()) {
				String[] properties = rs1.getString(1).split(" ");
				int p1 = Integer.parseInt(properties[0]);
				int p2 = Integer.parseInt(properties[1]);
				if (p1 < p2) {
					String key = p1 + " " + p2;
					Itemset2 is = new Itemset2(p1, p2);
					itemsets.put(key, is);
				} else if (p1 > p2) {
					String key = p2 + " " + p1;
					Itemset2 is = new Itemset2(p2, p1);
					itemsets.put(key, is);
				} // skip p1=p2
			}
			rs1.close();
			stmt1.close();
			
			Iterator<String> keys = itemsets.keySet().iterator();
			while (keys.hasNext()) {
				String key = keys.next();
				Itemset2 is = itemsets.get(key);
				stmt2.setInt(1, is.getProp1());
				stmt2.setInt(2, is.getProp2());
				stmt2.executeUpdate();
			}
			stmt2.close();
			connObjectCoref.close();
		} catch (Throwable e) {
			logger.error(e.getMessage());
		}
	}
	
	public void execFPC2()
	{
		try {
			Connection connObjectCoref = DBConnPool.getObjectCoref();
			
			String sqlstr1 = "SELECT prop_id1,prop_id2 FROM fpc2";
			PreparedStatement stmt1 = connObjectCoref.prepareStatement(sqlstr1);
			
			Connection connFalconetV05 = DBConnPool.getFalconetV05();
			String sqlstr2 = "SELECT uri FROM " + DatasetType.FALCONETV05_URI + " WHERE id=?";
			PreparedStatement stmt2 = connFalconetV05.prepareStatement(sqlstr2);
			
			String sqlstr3 = "UPDATE fpc2 SET not_builtin=1 WHERE prop_id1=? AND prop_id2=?";
			PreparedStatement stmt3 = connObjectCoref.prepareStatement(sqlstr3);
			
			ResultSet rs1 = stmt1.executeQuery();
			while (rs1.next()) {
				int prop1 = rs1.getInt(1), prop2 = rs1.getInt(2);
				String uri1 = null, uri2 = null;
				stmt2.setInt(1, prop1);
				ResultSet rs2 = stmt2.executeQuery();
				while (rs2.next()) {
					uri1 = rs2.getString(1);
				}
				rs2.close();
				if (uri1.startsWith(SpecialPrefix.RDF) 
						|| uri1.startsWith(SpecialPrefix.RDFS) 
						|| uri1.startsWith(SpecialPrefix.OWL) 
						|| uri1.startsWith(SpecialPrefix.SKOS)
						|| uri1.startsWith(SpecialPrefix.XSD)
						|| uri1.startsWith(SpecialPrefix.DC)) {				
					continue;
				} else {
					stmt2.setInt(1, prop2);
					rs2 = stmt2.executeQuery();
					while (rs2.next()) {
						uri2 = rs2.getString(1);
					}
					rs2.close();
					if (uri2.startsWith(SpecialPrefix.RDF) 
							|| uri2.startsWith(SpecialPrefix.RDFS) 
							|| uri2.startsWith(SpecialPrefix.OWL) 
							|| uri2.startsWith(SpecialPrefix.SKOS)
							|| uri2.startsWith(SpecialPrefix.XSD)
							|| uri2.startsWith(SpecialPrefix.DC)) {				
						continue;
					} else {
						stmt3.setInt(1, prop1);
						stmt3.setInt(2, prop2);
						stmt3.executeUpdate();
					}
				}
			}
			rs1.close();
			stmt1.close();
			stmt2.close();
			stmt3.close();
			connObjectCoref.close();
			connFalconetV05.close();
		} catch (Throwable e) {
			logger.error(e.getMessage());
		}
	}
	
	public void execFPC3()
	{
		try {
			Connection connObjectCoref = DBConnPool.getObjectCoref();
			
			String sqlstr1 = "SELECT prop_id1,prop_id2 FROM fpc2";
			PreparedStatement stmt1 = connObjectCoref.prepareStatement(sqlstr1);
			
			String sqlstr2 = "SELECT range_group,av,ac FROM prop_info WHERE prop_id=?";
			PreparedStatement stmt2 = connObjectCoref.prepareStatement(sqlstr2);
			
			String sqlstr3 = "UPDATE fpc2 SET range_compatible=?,av_compatible=?,ac_compatible=? "
						   + "WHERE prop_id1=? AND prop_id2=?";
			PreparedStatement stmt3 = connObjectCoref.prepareStatement(sqlstr3);
			
			ResultSet rs1 = stmt1.executeQuery();
			while (rs1.next()) {
				int prop1 = rs1.getInt(1), prop2 = rs1.getInt(2);	
				logger.debug(prop1 + ", " + prop2);
				
				String range1 = null, range2 = null;
				double av1 = 0, ac1= 0, av2 = 0, ac2 = 0;
				
				stmt2.setInt(1, prop1);
				ResultSet rs2 = stmt2.executeQuery();
				while (rs2.next()) {
					range1 = rs2.getString(1);
					av1 = rs2.getDouble(2);
					ac1 = rs2.getDouble(3);
				}
				rs2.close();
				
				stmt2.setInt(1, prop2);
				rs2 = stmt2.executeQuery();
				while (rs2.next()) {
					range2 = rs2.getString(1);
					av2 = rs2.getDouble(2);
					ac2 = rs2.getDouble(3);
				}
				rs2.close();
				
				if (range1 == null || range2 == null 
						|| range1.equals("t") || range2.equals("t") 
						|| range1.equals(range2)) {
					stmt3.setInt(1, 1);
				} else stmt3.setInt(1, 0);
				
				if (Math.abs(av1 - av2) <= 0.1) {
					stmt3.setInt(2, 1);
				} else stmt3.setInt(2, 0);
				
				if (Math.abs(ac1 - ac2) <= 0.1) {
					stmt3.setInt(3, 1);
				} else stmt3.setInt(3, 0);
				
				stmt3.setInt(4, prop1);
				stmt3.setInt(5, prop2);
				stmt3.executeUpdate();
			}
			rs1.close();
			stmt1.close();
			stmt2.close();
			stmt3.close();
			connObjectCoref.close();
		} catch (Throwable e) {
			logger.error(e.getMessage());
		}
	}
	
	public void execFPC4()
	{
		try {
			Connection connObjectCoref = DBConnPool.getObjectCoref();
			
			String sqlstr1 = "SELECT prop_id1,prop_id2 FROM fpc2 "
						   + "WHERE range_compatible=1 AND av_compatible=1 AND ac_compatible=1 AND not_builtin=1 "
						   + "ORDER BY prop_id1,prop_id2";
			PreparedStatement stmt1 = connObjectCoref.prepareStatement(sqlstr1);
			
			String sqlstr2 = "SELECT property FROM special_property WHERE source=? AND property LIKE 'u%'";
			PreparedStatement stmt2 = connObjectCoref.prepareStatement(sqlstr2);
			
			stmt2.setString(1, DatasetType.FALCONETV05);
			Set<Integer> specialProperties = new HashSet<Integer>();
			ResultSet rs2 = stmt2.executeQuery();
			while (rs2.next()) {
				String prop = rs2.getString(1);
				specialProperties.add(Integer.parseInt(prop.substring(1)));
			}
			rs2.close();
			stmt2.close();
			
			Connection connFalconetV05 = DBConnPool.getFalconetV05();
			
			String sqlstr3 = "SELECT uri FROM " + DatasetType.FALCONETV05_URI + " WHERE id=?";
			PreparedStatement stmt3 = connFalconetV05.prepareStatement(sqlstr3);
			
			int count = 0;
			BufferedWriter bw = new BufferedWriter(new FileWriter("fpc2_original.txt"));
			ResultSet rs1 = stmt1.executeQuery();
			while (rs1.next()) {
				int prop1 = rs1.getInt(1), prop2 = rs1.getInt(2);
				
				if (!specialProperties.contains(prop1) && !specialProperties.contains(prop2)) {
					String uri1 = null, uri2 = null;
					stmt3.setInt(1, prop1);
					ResultSet rs3 = stmt3.executeQuery();
					while (rs3.next()) 
						uri1 = rs3.getString(1);
					rs3.close();
					
					stmt3.setInt(1, prop2);
					rs3 = stmt3.executeQuery();
					while (rs3.next()) 
						uri2 = rs3.getString(1);
					rs3.close();
					
					String[] qname1 = URIHelper.namespace_localname(uri1);
					String[] qname2 = URIHelper.namespace_localname(uri2);
					if (qname1[0].equals(qname2[0])) {
						StringSplitter ss = StringSplitter.getStringSplitter();
						String ln1 = ss.splitByDelimit(qname1[1]);
						String ln2 = ss.splitByDelimit(qname2[1]);
						// at least have a few common words
						if (Jaccard.getSimilarity(ln1, ln2) > 0.3) 
							bw.write((++count) + " " + prop1 + " " + uri1 + " , " + prop2 + " " + uri2 + "\r\n");
					}
				}
			}
			rs1.close();
			bw.close();
			stmt1.close();
			stmt3.close();
			connObjectCoref.close();
			connFalconetV05.close();
		} catch (Throwable e) {
			logger.error(e.getMessage());
		}
	}
	
	public static void main(String args[])
	{
		PropertyConfigurator.configure(FPC2Refiner.class.getResource("/config/log4j.properties"));
		DBParam.init();
		
		//FPC2Refiner fpcr = new FPC2Refiner();
		//fpcr.execFPC1();
		//fpcr.execFPC2();
		//fpcr.execFPC3();
		//fpcr.execFPC4();
	}
}
