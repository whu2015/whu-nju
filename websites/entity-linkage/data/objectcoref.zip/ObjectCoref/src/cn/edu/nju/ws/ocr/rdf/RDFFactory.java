package cn.edu.nju.ws.ocr.rdf;

import java.util.*;
import org.apache.log4j.*;

public class RDFFactory 
{
	static Logger logger = Logger.getLogger(RDFFactory.class);
	
	private static RDFFactory factory;

	private RDFFactory() {}

	public static RDFFactory getInstance() 
	{
		if (factory == null) 
			factory = new RDFFactory();
		return factory;
	}

	public RDFInst createRDFInst(int uriID) { return new RDFInst(uriID); }
	
	public RDFInst createRDFInst(String uri) { return new RDFInst(uri); }
	
	public RDFInst createRDFInst(int uriID, Set<String> names) { return new RDFInst(uriID, names); }

	public RDFInst createRDFInst(int uriID, String uri) { return new RDFInst(uriID, uri); }
	
	public RDFInst createRDFInst(int uriID, double sim) { return new RDFInst(uriID, sim); }

	public RDFInst createRDFInst(int uriID, String uri, int dc) { return new RDFInst(uriID, uri, dc); }
	
	public RDFInst createRDFInst(int uriID, String uri, double sim) { return new RDFInst(uriID, uri, sim); }
	
	public RDFInst createRDFInst(int uriID, String uri, int dc, double sim) { return new RDFInst(uriID, uri, dc, sim); }

	public RDFStmt createRDFStmt(String s, String p, String o) { return new RDFStmt(s, p, o); }
}
