package cn.edu.nju.ws.ocr.train;

import java.util.*;
import org.apache.log4j.*;
import cn.edu.nju.ws.ocr.rdf.*;

public interface INameFinder
{	
	static Logger logger = Logger.getLogger(INameFinder.class);
	
	public void completeInfo(Map<Integer, RDFInst> instances) throws Throwable;
}
