package cn.edu.nju.ws.ocr.cache;

import java.sql.*;
import org.apache.log4j.*;
import cn.edu.nju.ws.ocr.datab.*;

public class PrefixLogger 
{
	static Logger logger = Logger.getLogger(PrefixLogger.class);
	
	synchronized public static String write(String namespace)
	{
		if (namespace == null || namespace.equals(""))
			return null;
		
		try {
			Connection connObjectCoref = DBConnPool.getObjectCoref();
			
			// count(*) avoids unknown prefix that has been queried
			String sqlstr1 = "SELECT prefix,COUNT(*) FROM prefix WHERE namespace=?";
			PreparedStatement stmt1 = connObjectCoref.prepareStatement(sqlstr1);
			
			stmt1.setString(1, namespace);
			
			String prefix = null;
			int count = 0;
			ResultSet rs1 = stmt1.executeQuery();
			while (rs1.next()) {
				prefix = rs1.getString(1);
				count = rs1.getInt(2);
			}
			rs1.close();
			stmt1.close();
			
			if (count > 0) {
				connObjectCoref.close();
				return prefix;
			}
			
			prefix = PrefixAPI.prefix(namespace);
			
			String sqlstr2 = "INSERT INTO prefix(namespace,prefix) VALUES(?,?)";
			PreparedStatement stmt2 = connObjectCoref.prepareStatement(sqlstr2);
			
			stmt2.setString(1, namespace);
			stmt2.setString(2, prefix);
			stmt2.executeUpdate();

			stmt2.close();
			connObjectCoref.close();
			
			return prefix;
		} catch (Throwable e) {
			logger.error(e.getMessage());
			return null;
		}
	}
	
	synchronized public static String read(String namespace)
	{
		if (namespace == null || namespace.equals(""))
			return null;
		
		try {
			Connection connObjectCoref = DBConnPool.getObjectCoref();
			
			String sqlstr1 = "SELECT prefix FROM prefix WHERE namespace=?";
			PreparedStatement stmt1 = connObjectCoref.prepareStatement(sqlstr1);
			
			stmt1.setString(1, namespace);
			
			String prefix = null;
			ResultSet rs1 = stmt1.executeQuery();
			while (rs1.next())
				prefix = rs1.getString(1);
			rs1.close();
			stmt1.close();
			connObjectCoref.close();
			
			return prefix;
		} catch (Throwable e) {
			logger.error(e.getMessage());
			return null;
		}
	}
}
