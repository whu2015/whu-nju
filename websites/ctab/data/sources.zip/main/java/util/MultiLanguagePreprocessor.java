package util;
import java.io.BufferedReader;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.HashSet;
import java.util.Set;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class MultiLanguagePreprocessor {
	private Set<String> language;
	private static MultiLanguagePreprocessor instance = null;
	
	public static MultiLanguagePreprocessor getInstance() {
		if(instance == null) {
			instance = new MultiLanguagePreprocessor();
		}
		return instance;
	}
	
	private MultiLanguagePreprocessor() {
		language = new HashSet<String>();
		readLanguage();
	}
	
	private void readLanguage() {
		try {
			BufferedReader bufR = new BufferedReader(new InputStreamReader(
					new FileInputStream("Language"), "utf-8"));
			
			String lang;
			while((lang = bufR.readLine()) != null) {
				language.add(lang);
			}

			bufR.close();
		} catch(IOException e) {
			e.printStackTrace();
		}
	}

	public String decodeStr(String s) {
		Pattern pattern = Pattern.compile("%[0-9a-fA-F]{2}");
		Matcher matcher = pattern.matcher(s);
		while(matcher.find()) {
			String unicode = matcher.group().substring(1);
			int hex = Integer.parseInt(unicode, 16);
			s = matcher.replaceFirst((char)hex+"");
			matcher = pattern.matcher(s);
		}
		
		pattern = Pattern.compile("\\$[0-9a-fA-F]{4}");
		matcher = pattern.matcher(s);
		while(matcher.find()) {
			String unicode = matcher.group().substring(1);
			int hex = Integer.parseInt(unicode, 16);
			s = matcher.replaceFirst((char)hex+"");
			matcher = pattern.matcher(s);
		}
		
		pattern = Pattern.compile("\\\\u[0-9a-fA-F]{4}");
		matcher = pattern.matcher(s);
		while(matcher.find()) {
			String unicode = matcher.group().substring(2);
			int hex = Integer.parseInt(unicode, 16);
			s = matcher.replaceFirst((char)hex+"");
			matcher = pattern.matcher(s);
		}

		return s;
	}
	
	public boolean isMultiLanguageUri(String uri) {
		for(String lang : language) {
			if(uri.contains("http://"+lang+".wikipedia.org"))
				return true;
			if(uri.endsWith("wikipedia."+lang)) {
				return true;
			}
			if(uri.contains("wikipedia."+lang+".")) {
				return true;
			}
			if(uri.contains("wikipedia."+lang+"_")) {
				return true;
			}
			if(uri.contains(lang+".dbpedia.org")) {
				return true;
			}
		}
		return false;
	}
	
	public boolean isMultiLanguageValue(String value) {
		for(String lang : language) {
			if(value.endsWith("@"+lang)) return true;
		}
		return false;
	}
}