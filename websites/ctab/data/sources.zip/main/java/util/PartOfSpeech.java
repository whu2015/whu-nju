package util;

import edu.stanford.nlp.tagger.maxent.MaxentTagger;
/*
 * Get the core concept.
 * Core concept is either the first verb in the label or,
 * if there is no verb, the first noun is the label,
 * together with any adjectives that modify that noun.
 */

public class PartOfSpeech {
	
	public static MaxentTagger tagger = new MaxentTagger("edu/stanford/nlp/models/pos-tagger/english-left3words/english-left3words-distsim.tagger");
	
	public static String getCoreConcept(String phrase) {
		
		String core = null;
		String aNoun = "";
        String tagged = tagger.tagString(phrase);
        
//        System.out.println(phrase + " -> " + tagged);
        
        boolean stopNoun = false;

        String[] tokens = tagged.split("\\s+");
        for (String token: tokens) {
        	if (token.contains("V") && token.length() > 7) {
        		token = token.substring(0, token.lastIndexOf("_"));
        		core = token;
        		aNoun = "";
        		break;
        	}
        	
           	if ((token.contains("N") || token.contains("J")) && !stopNoun) {
           		if (token.contains("IN")) {
           			stopNoun = true;
           		} else {
           			token = token.substring(0, token.lastIndexOf("_"));
           			aNoun += " " + token;
           		}
        	}
        }
        
        if (core == null) {
        	core = aNoun.trim();
        }
        
//        System.out.println("\t" + core);
        if (core.equals("")) {
        	return phrase;
        }
        
        return core;
	}
	
	
	public static void main(String[] args) {
		String str = "was located in";
		str = StringUtil.propProcess(str);
		System.out.println(str + " || " + getCoreConcept(str));
	}
}
