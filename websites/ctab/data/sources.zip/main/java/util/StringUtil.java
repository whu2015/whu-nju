package util;

import java.util.ArrayList;
import java.util.HashMap;

import anonymous.dataprovider.service.EndpointService;
import anonymous.mapping.UriMapping;

public class StringUtil {
	static EndpointService endpointService = new EndpointService();

	static HashMap<String, String> cacheMap = new HashMap<>();

	public static String getLabel(String uri) {
		String label = uri;

		if(uri.contains("http://rdf.freebase.com/ns/")) {
			label = UriMapping.getInstace().getFreebaseMap(uri);
		} else if(uri.contains("http://sw.opencyc.org/concept/")) {
			label = UriMapping.getInstace().getOpenCycMap(uri);
		} else if(uri.contains("http://sw.cyc.com/concept/")) {
			label = UriMapping.getInstace().getOpenCycMap(uri);
		} else if(uri.contains("http://data.linkedmdb.org/resource/")) {
			label = UriMapping.getInstace().getMdbMap(uri);
		}

		if (uri.contains("http://dbpedia.org/class/yago")) {
			label = label.replaceAll("\\d", "");
		}

		//just for Property Merge!!
//		if(label.startsWith("/m/")) {
//			return "";
//		}
		
		if(label.startsWith("/m/")) {
			return label.substring(3);
		}
		
		label = label.replaceAll("\"", "");

		if (label.contains("#")) {
			label = label.substring(label.indexOf('#')+1);
			return label;
		}

		if(label.equals("")) System.out.println("?????"+uri);
		if (label.lastIndexOf('/') == label.length() - 1) {
			label = label.substring(0, label.length()-1);
		}
		if (label.contains("/")) {
			label = label.substring(label.lastIndexOf('/')+1);
			return label;
		}
		
    	return label;	
	}
	
	public static String propProcess(String uri) {
		String s = getLabel(uri);
		
		s = s.substring(s.lastIndexOf('.')+1);
		if(s.equals("")) s = getLabel(uri);
		s = stringTokenize(s, true);
		if(s.equals("")) s = getLabel(uri);
		return s;
	}
	
	public static ArrayList<String> tokenize(String s, boolean lowercase) {
		if (s == null) {
			return null;
		}

		ArrayList<String> strings = new ArrayList<String>();

		String current = "";
		Character prevC = 'x';

		for (Character c: s.toCharArray()) {

			if ((Character.isLowerCase(prevC) && Character.isUpperCase(c)) || 
					c == '_' || c == '-' || c == ' ' || c == '/' || c == '\\' || c == '>' || c == '.') {

				current = current.trim();

				if (current.length() > 0) {
					if (lowercase) 
						strings.add(current.toLowerCase());
					else
						strings.add(current);
				}

				current = "";
			}

			if (c != '_' && c != '-' && c != '/' && c != '\\' && c != '>' && c != '.') {
				current += c;
				prevC = c;
			}
		}

		current = current.trim();

		if (current.length() > 0) {
			// this check is to handle the id numbers in YAGO
			if (!(current.length() > 4 && Character.isDigit(current.charAt(0)) && 
					Character.isDigit(current.charAt(current.length()-1)))) {
				strings.add(current.toLowerCase());
			}
		}

		return strings;
	}

	private static String stringTokenize(String s, boolean lowercase) {
		String result = "";

		ArrayList<String> tokens = tokenize(s, lowercase);
		for (String token: tokens) {
			result += token + " ";
		}

		return result.trim();
	}
	
	public static void main(String[] args) {
		System.out.println(propProcess("http://yago-knowledge.org/resource/infobox/en/role"));
		System.out.println(propProcess("http://dbpedia.org/ontology/part"));
		System.out.println(propProcess("http://www.chicagoreader.com/obama/951208/"));
	}
}