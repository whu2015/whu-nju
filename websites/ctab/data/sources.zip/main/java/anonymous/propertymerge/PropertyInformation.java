package anonymous.propertymerge;

import anonymous.dataprovider.Dataset;
import anonymous.dataprovider.LocalName;
import anonymous.similarity.SimilarityMetricFactory;
import org.apache.jena.rdf.model.Property;
import org.apache.jena.rdf.model.Statement;
import org.apache.jena.rdf.model.StmtIterator;
import util.PartOfSpeech;
import util.StringUtil;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by skim on 17-3-24.
 */
public class PropertyInformation implements Comparable<PropertyInformation> {
    private Property property;
    public String label;
    private String coreConcept;
    private List<String> values;
    private String exampleValue;
    private SimilarityMetricFactory.PropertySummary summary;

    public PropertyInformation(Property property, Dataset dataset, SimilarityMetricFactory factory) {
        this.property = property;
        label = StringUtil.propProcess(property.getURI());
        coreConcept = PartOfSpeech.getCoreConcept(label);
        values = new ArrayList<String>();

        for (StmtIterator ia = dataset.listObjectsOfProperty(property); ia != null && ia.hasNext(); ) {
            Statement stmt = ia.nextStatement();
            values.add(stmt.getObject().toString());
        }

        summary = factory.createPropertySummary(values);
    }

    public Property getProperty() {
        return property;
    }

    public String getLabel() {
        return label;
    }

    public String getLocalName() {
        String uri = property.getURI();
        uri = uri.substring(uri.lastIndexOf("/") + 1);
        uri = uri.substring(uri.lastIndexOf(".") + 1);
        return uri;
    }

    public String getCoreConcept() {
        return coreConcept;
    }

    public List<String> getValues() {
        return values;
    }

    public String getExampleValue() {
        return exampleValue;
    }

    public SimilarityMetricFactory.PropertySummary getSummary() {
        return summary;
    }

    public int compareTo(PropertyInformation o) {
        if (property.getNameSpace() == null) {
            System.out.println(property);
        }
        if (o.getProperty().getNameSpace() == null) {
            System.out.println(o.getProperty());
        }
        return property.getNameSpace().compareTo(o.getProperty().getNameSpace());
    }
}
