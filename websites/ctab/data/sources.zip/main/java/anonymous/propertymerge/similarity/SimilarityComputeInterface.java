package anonymous.propertymerge.similarity;

import anonymous.dataprovider.PropertyNode;

import java.util.List;

/**
 * Created by skim on 17-7-17.
 */
public interface SimilarityComputeInterface {
    double[][] compute(List<PropertyNode> properties);
}
