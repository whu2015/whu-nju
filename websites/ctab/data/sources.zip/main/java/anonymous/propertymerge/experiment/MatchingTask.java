package anonymous.propertymerge.experiment;

import anonymous.dataprovider.service.EndpointService;
import anonymous.dataprovider.service.EndpointService;
import anonymous.propertymerge.PropertyMetadata;
import org.apache.jena.rdf.model.*;

import java.io.File;
import java.io.FileNotFoundException;
import java.util.*;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * Created by skim on 17-7-12.
 */
public class MatchingTask {
    private List<Group> dataset;
    private EndpointService endpointService;

    class Group {
        public Model model;
        public Set<String> properties;
    }

    MatchingTask() {
        dataset = new ArrayList<>();
        endpointService = new EndpointService();
        PropertyMetadata meta = new PropertyMetadata();


        File baseDir = new File("/home/skim/workspace/disambiguation/instances/");
        for (File category : baseDir.listFiles()) {
            for (File group : category.listFiles()) {
//                loadResolvedEntities(group.listFiles(new PatternFilenameFilter("0-.*")));
//                loadResolvedEntities(group.listFiles(new PatternFilenameFilter("1-.*")));
//                loadResolvedEntities(group.listFiles(new PatternFilenameFilter("2-.*")));
                loadResolvedEntities(group.listFiles());
            }
        }

//        File f = new File("/home/skim/workspace/disambiguation/instances/WrittenWork/017");
//        loadResolvedEntities(f.listFiles());

        Scanner scanner = null;
        try {
            scanner = new Scanner(new File("./data/property_merge/pairs.txt"));
            while(scanner.hasNext()) {
                String[] pair = scanner.nextLine().split(";", 2);
                String x = pair[0], y = pair[1];
                String valuePairs = pickValuePairs(x, y);
                if (x.contains("yago-knowledge") && valuePairs.length() < 10) {
                    continue;
                }
                if (x.contains("www.wikidata.org")) {
                    x = x.substring(0, x.length() - 1);
                }

                if (x.contains("http://dbpedia.org")) {
                    String t = y;
                    y = x;
                    x = t;
                }

                System.out.printf("url\t%s\t%s\n", x, y);
                System.out.printf("label\t%s\t%s\n", meta.getLabel(x), meta.getLabel(y));
                System.out.printf("domain\t%s\t%s\n", meta.getDomain(x), meta.getDomain(y));
                System.out.printf("range\t%s\t%s\n", meta.getRange(x), meta.getRange(y));
                System.out.printf("comment\t%s\t%s\n", meta.getComment(x), meta.getComment(y));
                System.out.print(valuePairs);
                System.out.println("same\t\t");
                System.out.println();
            }

        } catch (FileNotFoundException e) {
            e.printStackTrace();
        } finally {
            if(scanner != null) {
                scanner.close();
            }
        }
    }

    private Pattern pattern = Pattern.compile("\\d-(\\w+)\\.nt");

    private String pickValuePairs(String x, String y) {
        List<String> pairs = new ArrayList<>();
        for (int i = 0; i < dataset.size() && pairs.size() < 30; i++) {
            String pair = pickValuePair(i, x, y);
            if (pair != null) {
                pairs.add(pair);
            }
        }

        Collections.sort(pairs);
        Collections.reverse(pairs);

        StringBuilder result = new StringBuilder();

        for (int i = 0; i < pairs.size(); i++) {
            result.append(pairs.get(i)).append("\n");
        }

        return result.toString();
    }

    private String pickValuePair(int index, String x, String y)
    {
        Group group = dataset.get(index);
        if (group.properties.contains(x) && group.properties.contains(y)) {
            String vy = getEnglishLiteral(group.model, y);
            String vx = getEnglishLiteral(group.model, x);
            return String.format("Value Pair\t%s\t%s", vx, vy);
        }

        return null;
    }

    private String getEnglishLiteral(Model model, String property) {
        NodeIterator iterator = model.listObjectsOfProperty(model.createProperty(property));
        if (iterator.hasNext()) {
            RDFNode node = iterator.next();
            if (node.isLiteral() && (node.asLiteral().getLanguage() == null || node.asLiteral().getLanguage().equals("") ||
                    node.asLiteral().getLanguage().equals("en"))) {
                return node.asLiteral().getString();
            }
            String comment = node.toString();
            if (node.isResource()) {
//                comment = "<" + node.asResource().getURI() + ">";
                comment = endpointService.getLabel(node.asResource().getURI());
                if (comment == null) {
                    comment = node.asResource().getLocalName();
                }
            }
            while (iterator.hasNext()) {
                node = iterator.next();
                if (node.isLiteral() && (node.asLiteral().getLanguage() == null || node.asLiteral().getLanguage().equals("") ||
                        node.asLiteral().getLanguage().equals("en"))) {
                    return node.asLiteral().getString();
                }
            }
            return comment;
        }

        return null;
    }

    private void loadResolvedEntities(File[] files) {
        if (files != null && files.length > 0) {
            Group group = new Group();
            group.model = ModelFactory.createDefaultModel();
            group.properties = new HashSet<>();
            for (File file : files) {
                Matcher matcher = pattern.matcher(file.getName());
                if (matcher.matches()) {
                    Model model = ModelFactory.createDefaultModel();
                    model.read(file.getAbsolutePath());
                    StmtIterator iterator = model.listStatements();
                    while (iterator.hasNext()) {
                        Statement stmt = iterator.nextStatement();
                        group.properties.add(stmt.getPredicate().getURI());
                        group.model.add(stmt);
                    }
                }
            }
            if (group.properties.size() > 0) {
                dataset.add(group);
            }
        }
    }


    public static void main(String[] args) {
        new MatchingTask();
    }
}
