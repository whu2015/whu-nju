package anonymous.propertymerge;

import anonymous.dataprovider.service.EndpointService;
import anonymous.dataprovider.service.EndpointService;
import anonymous.dataprovider.service.LiteralService;
import org.apache.jena.rdf.model.*;
import org.apache.jena.vocabulary.RDFS;

import java.net.URL;
import java.time.LocalDate;

/**
 * Created by skim on 17-7-12.
 */
public class PropertyMetadata {
    private EndpointService endpointService;

    public PropertyMetadata() {
        endpointService = new EndpointService();
    }

    public String getLocalName(String uri) {
        return uri.substring(uri.lastIndexOf("/") + 1);
    }

    public String getLabel(String uri) {
        String label = endpointService.getLabel(uri);
        return label != null ? label : "NA";
    }

    public String getComment(String uri) {
        String label = endpointService.getLiteral(uri, RDFS.comment.getURI());
        if (label != null) return label;
        label = endpointService.getLiteral(uri, "http://schema.org/description");
        if (label != null) return label;
        return "NA";
    }

    public String getDomain(String uri) {
        for (RDFNode node : endpointService.getResources(uri, RDFS.domain.getURI())) {
            if (node.isLiteral()) {
                return node.asLiteral().toString();
            } else {
                return LiteralService.getLocalName(node.asResource());
            }
        }
        return "NA";
    }

    public String getRange(String uri) {
        for (RDFNode node : endpointService.getResources(uri, RDFS.range.getURI())) {
            if (node.isLiteral()) {
                return node.asLiteral().toString();
            } else {
                return LiteralService.getLocalName(node.asResource());
            }
        }
        return "NA";
    }

    public static void main(String[] args) {
        PropertyMetadata meta = new PropertyMetadata();
        System.out.println(meta.getLabel("http://www.wikidata.org/entity/P1040"));
    }
}
