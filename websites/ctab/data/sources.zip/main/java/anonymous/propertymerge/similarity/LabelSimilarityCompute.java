package anonymous.propertymerge.similarity;

import anonymous.dataprovider.PropertyNode;
import anonymous.similarity.PlainValueSimilarityMetric;
import com.wcohen.ss.JaroWinkler;

/**
 * Created by skim on 17-7-17.
 */
public class LabelSimilarityCompute extends AbstractSimilarityCompute {
    private boolean[][] conflict;
//    private CoreSimilarityMetric metric = new CoreSimilarityMetric();
    private PlainValueSimilarityMetric metric = new PlainValueSimilarityMetric();
    public LabelSimilarityCompute(boolean[][] conflict) {
        this.conflict = conflict;
    }

    @Override
    protected double computeSimilarity(PropertyNode x, PropertyNode y, int i, int j) {
        if (conflict[i][j]) {
            return 0;
        }

        return metric.compute(x.getLabel(), y.getLabel());
    }

    static public void main(String args[]) {
        JaroWinkler measure = new JaroWinkler();
        System.out.println(measure.score("date of birth", "birth date"));
    }
}
