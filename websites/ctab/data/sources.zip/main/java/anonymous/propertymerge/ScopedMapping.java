package anonymous.propertymerge;

import anonymous.propertymerge.grouping.GreedyCliqueGrouping;
import anonymous.dataprovider.InstanceGroup;
import anonymous.dataprovider.PropertyNode;
import anonymous.generation.table.CTableGenerator;
import anonymous.generation.table.PropertyClique;
import anonymous.mapping.PropertyMappingInterface;
import anonymous.propertymerge.grouping.GreedyCliqueGrouping;
import org.apache.jena.rdf.model.Property;

import java.io.*;
import java.util.*;

public class ScopedMapping implements PropertyMappingInterface {
    private static Map<String, Double> pairScores = null;
    private GreedyCliqueGrouping greedyCliqueGrouping;

    private void bootstrap() {
        if (pairScores != null) return;
        pairScores = new HashMap<>();
        try {
            Scanner scanner = new Scanner(new FileInputStream("./data/property_merge/all_pair_detail.csv"));
            scanner.nextLine();
            while (scanner.hasNextLine()) {
                String parts[] = scanner.nextLine().split(",");
                if (parts.length > 7) {
                    String line = parts[0] + parts[1];
                    if (line.contains("http://www.w3.org/2003/01/geo/wgs84_pos#long")
                            || line.contains("http://yago-knowledge.org/resource/hasCitationTitle")
                            || line.contains("http://rdf.freebase.com/ns/type.object.type")
                            || line.contains("http://rdf.freebase.com/key/wikipedia.en_title")) {
                        continue;
                    }
                    pairScores.put(parts[0] + " " + parts[1], Double.parseDouble(parts[6]));
                    pairScores.put(parts[1] + " " + parts[0], Double.parseDouble(parts[6]));
                }
            }
        } catch (FileNotFoundException e) {
            e.printStackTrace();
        }
    }

    public ScopedMapping(List<PropertyNode> properties) {
        bootstrap();

        double[][] score = new double[properties.size()][properties.size()];
        boolean[][] conflict = new boolean[properties.size()][properties.size()];
        String[] propertyURIs = new String[properties.size()];
        for (int i = 0; i < properties.size(); i++) {
            propertyURIs[i] = properties.get(i).getProperty().getURI();
            for (int j = 0; j < properties.size(); j++) {
                String bond = properties.get(i).getProperty().getURI() + " " + properties.get(j).getProperty().getURI();

                score[i][j] = pairScores.getOrDefault(bond, 0.0);

                conflict[i][j] = (i != j) && getNamespace(properties.get(i).getProperty().getURI()).equals(getNamespace(properties.get(j).getProperty().getURI()));
            }
        }

        greedyCliqueGrouping = new GreedyCliqueGrouping(score, conflict, propertyURIs);
        greedyCliqueGrouping.run(0.5);
    }

    private String getNamespace(String property) {
        return property.substring(0, property.indexOf('/', "http://".length() + 1));
    }

    @Override
    public boolean connected(String a, String b) {
        return greedyCliqueGrouping.connected(a, b);
    }

}
