package anonymous.propertymerge.experiment;

import org.javatuples.Pair;

import java.io.File;
import java.io.FileNotFoundException;
import java.util.HashMap;
import java.util.Map;
import java.util.Scanner;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * Created by skim on 17-7-13.
 */
public class MatchingTaskReader {
    private Map<Pair<String, String>, Pair<Integer, Integer>> vote;

    public MatchingTaskReader() {
        vote = new HashMap<>();
    }

    public void loadData(File filename) {
        try {
            Scanner scanner = new Scanner(filename);
            Pattern pairPattern = Pattern.compile("url,([^,]+),([^,]+)");
            Pattern resultPattern = Pattern.compile(".*Yes\\[] No\\[] Not Sure\\[], ?(\\d|y|n|u)");
            while (scanner.hasNext()) {
                String line = scanner.nextLine();
                Matcher matcher = pairPattern.matcher(line);
                if (matcher.matches()) {
                    boolean found = false;
                    Pair<String, String> pair = new Pair<>(matcher.group(1), matcher.group(2));
                    if ((pair.getValue0() + pair.getValue1()).equals("http://rdf.freebase.com/ns/film.actor.filmhttp://dbpedia.org/ontology/field")) {
                        pair = pair;
                    }
                    if (!vote.containsKey(pair)) {
                        vote.put(pair, new Pair<>(0, 0));
                    }
                    while (!found && scanner.hasNext()) {
                        line = scanner.nextLine();
                        Matcher resultMatcher = resultPattern.matcher(line);
                        if (resultMatcher.matches()) {
                            found = true;
                            Pair<Integer, Integer> v = vote.get(pair);
                            if (resultMatcher.group(1).equals("y") || resultMatcher.group(1).equals("1")) {
                                vote.put(pair, new Pair<>(v.getValue0() + 1, v.getValue1()));
                                vote.get(pair).setAt0(vote.get(pair).getValue0() + 1);
                            } else if (resultMatcher.group(1).equals("n") || resultMatcher.group(1).equals("2")) {
                                vote.put(pair, new Pair<>(v.getValue0(), v.getValue1() + 1));
                            }
                        }
                    }
                }
            }
        } catch (FileNotFoundException e) {
            e.printStackTrace();
        }
    }

    public static void main(String[] args) {
        MatchingTaskReader task = new MatchingTaskReader();
        task.loadData(new File("/home/skim/workspace/disambiguation/experiments/hjc.csv"));
        task.loadData(new File("/home/skim/workspace/disambiguation/experiments/hjc_.csv"));
        task.loadData(new File("/home/skim/workspace/disambiguation/experiments/lhx.csv"));
        task.loadData(new File("/home/skim/workspace/disambiguation/experiments/zqh.csv"));
        task.loadData(new File("/home/skim/workspace/disambiguation/experiments/cem.csv"));
        task.loadData(new File("/home/skim/workspace/disambiguation/experiments/hw.csv"));
        task.loadData(new File("/home/skim/workspace/disambiguation/experiments/lxz.csv"));
        task.loadData(new File("/home/skim/workspace/disambiguation/experiments/szq.csv"));
        task.loadData(new File("/home/skim/workspace/disambiguation/experiments/glb.csv"));
        task.loadData(new File("/home/skim/workspace/disambiguation/experiments/sf.csv"));
        System.out.println("prop1,prop2,rater1,rater2,rater3");
        int count = 0;
        for (Pair<String, String> pair : task.vote.keySet()) {
//            System.out.println(pair);
//            System.out.println(task.vote.get(pair));
            int y = task.vote.get(pair).getValue0(), n = task.vote.get(pair).getValue1();
            String pp = pair.getValue0() + "," + pair.getValue1() + ",";
            if (pp.contains("http://rdf.freebase.com/ns/film.actor.film")) {
                pp = pp;
            }
//            for (int i = 0; i < y; i++) {
//                System.out.print("\'1\',");
//            }
//            for (int i = 0; i < n; i++) {
//                System.out.print("\'2\',");
//            }
//            for (int i = 0; i < 3 - y - n; i++) {
//                System.out.print("\'3\',");
//            }
            if (y == 3 || y - n == 2) {
                System.out.printf("%s,%s,1", pair.getValue0(), pair.getValue1());
                System.out.println();
            } else if (n == 3 || n - y == 2) {
                System.out.printf("%s,%s,0", pair.getValue0(), pair.getValue1());
                System.out.println();
            } else if (y == 2 && n == 1) {
                System.out.printf("%s,%s,%f", pair.getValue0(), pair.getValue1(), 2.0 / 3);
                System.out.println();
            } else if (y == 1 && n == 2) {
                System.out.printf("%s,%s,%f", pair.getValue0(), pair.getValue1(), 1.0 / 3);
                System.out.println();
            } else if (y == 1 && n == 0) {
                System.out.printf("%s,%s,%f", pair.getValue0(), pair.getValue1(), 2.0 / 3);
                System.out.println();
            } else if (y == 0 && n == 1) {
                System.out.printf("%s,%s,%f", pair.getValue0(), pair.getValue1(), 1.0 / 3);
                System.out.println();
            } else if (y == 1 && n == 1){
                System.out.printf("%s,%s,%f", pair.getValue0(), pair.getValue1(), 1.0 / 2);
                System.out.println();
            } else {
                System.out.printf("%s,%s,%f", pair.getValue0(), pair.getValue1(), 1.0 / 2);
                System.out.println();
            }
//            if (y > n) {
//                System.out.printf("%s,%s,1", pair.getValue0(), pair.getValue1());
//                System.out.println();
//            } else if (n > y) {
//                System.out.printf("%s,%s,0", pair.getValue0(), pair.getValue1());
//                System.out.println();
//            } else {
//                count += 1;
//                System.out.println(pair);
//                System.out.println(y);
//                System.out.println(n);
//        }
        }
//        System.out.println(count);
    }
}
