package anonymous.propertymerge.similarity;

import anonymous.dataprovider.PropertyNode;

import java.util.List;

/**
 * Created by skim on 17-7-17.
 */
public abstract class AbstractSimilarityCompute implements SimilarityComputeInterface {
    @Override
    public double[][] compute(List<PropertyNode> properties) {
        int l = properties.size();
        double[][] sim = new double[properties.size()][];
        for (int i = 0; i < l; i++) sim[i] = new double[l];
        for (int i = 0; i < l; i++) {
            sim[i][i] = 1;
            for (int j = i + 1; j < l; j++) {
                sim[i][j] = computeSimilarity(properties.get(i), properties.get(j), i, j);
                sim[j][i] = sim[i][j];
            }
        }

        return sim;
    }

    protected abstract double computeSimilarity(PropertyNode x, PropertyNode y, int i, int j);
}
