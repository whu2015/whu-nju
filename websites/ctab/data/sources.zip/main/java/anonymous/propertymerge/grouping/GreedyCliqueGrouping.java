package anonymous.propertymerge.grouping;

import anonymous.mapping.PropertyMappingInterface;

import java.util.*;

/**
 * Created by skim on 17-7-11.
 */
public class GreedyCliqueGrouping implements PropertyMappingInterface {

    private double[][] similarity;
    private boolean[][] conflict;
    private String[] properties;
    private Map<String, Set<String>> uriMappings;

    public GreedyCliqueGrouping(double[][] sim, boolean[][] conflict, String[] properties) {
        this.similarity = sim;
        this.conflict = conflict;
        this.properties = properties;
    }

    public double[][] getMatchingMatrix() {
        double[][] matching = new double[properties.length][];
        for (int i = 0, l = properties.length; i < l; i++) {
            matching[i] = new double[l];
            Set<String> clique = getClique(properties[i]);
            for (int j = 0; j < l; j++) {
                if (clique.contains(properties[j])) {
                    matching[i][j] = 1;
                } else {
                    matching[i][j] = 0;
                }
            }
        }
        return matching;
    }

    public Set<String> getClique(String uri) {
        return uriMappings.get(uri);
    }

    public void run(double threshold) {
        List<Set<Integer>> mappings;
        int l = properties.length;

        mappings = new ArrayList<>(properties.length);
        for (int i = 0; i < properties.length; i++) {
            mappings.add(new HashSet<>());
            mappings.get(i).add(i);
        }

        PriorityQueue<SimilarityTriple> queue = new PriorityQueue<>();
        for (int i = 0; i < l; i++) {
            for (int j = i + 1; j < l; j++) {
                queue.add(new SimilarityTriple(i, j, similarity[i][j]));
            }
        }

        while (!queue.isEmpty()) {
            SimilarityTriple triple = queue.poll();
            Set<Integer> c1 = mappings.get(triple.i), c2 = mappings.get(triple.j);
            if (Math.abs(triple.sim) < threshold) break;
            boolean confl = false;
            for (Integer p : c1) {
                if (conflict[p][triple.j]) {
                    confl = true;
                    break;
                }
            }

            if (confl) {
                continue;
            }
            for (Integer p : c2) {
                if (conflict[p][triple.i]) {
                    confl = true;
                    break;
                }
            }

            if (confl) {
                continue;
            }

            c1.addAll(c2);
            mappings.set(triple.j, c1);
        }

        uriMappings = new HashMap<>();
        for (Set<Integer> intClique : mappings) {
            Iterator<Integer> iterator = intClique.iterator();
            if (iterator.hasNext()) {
                if (!uriMappings.containsKey(properties[iterator.next()])) {
                    Set<String> clique = new HashSet<>();
                    for (Integer index : intClique) {
                        clique.add(properties[index]);
                        uriMappings.put(properties[index], clique);
                    }
                }
            }
        }
    }

    @Override
    public boolean connected(String a, String b) {
        return uriMappings.containsKey(a) && uriMappings.get(a).contains(b);
    }

    private class SimilarityTriple implements Comparable<SimilarityTriple> {
        public int i, j;
        private double sim;

        SimilarityTriple(int i, int j, double sim) {
            this.i = i;
            this.j = j;
            this.sim = sim;
        }

        @Override
        public int compareTo(SimilarityTriple o) {
            if (Math.abs(sim - o.sim) < 0.000001) {
                return 0;
            } else if (sim > o.sim) {
                return -1;
            } else {
                return 1;
            }
        }
    }
}
