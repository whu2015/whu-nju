package anonymous.propertymerge;

import anonymous.mapping.PropertyMappingInterface;

import java.io.File;
import java.io.IOException;
import java.util.*;

/**
 * Created by skim on 17-8-11.
 */
public class PropertyMappingGroundTruth implements PropertyMappingInterface {
    static private Map<String, Set<String>> mappings = null;

    public PropertyMappingGroundTruth() {
        if (mappings != null) return ;
        mappings = new HashMap<>();
        try {
            Scanner scanner = new Scanner(new File("./data/property_merge/gold_match.csv"));
            while (scanner.hasNextLine()) {
                String parts[] = scanner.nextLine().split("\t", 2);
                addMapping(parts[0], parts[1]);
            }
            scanner = new Scanner(new File("./data/property_merge/gold_match_extra.csv"));
            while (scanner.hasNextLine()) {
                String parts[] = scanner.nextLine().split("\t", 2);
                addMapping(parts[0], parts[1]);
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    private void addMapping(String x, String y) {
        Set<String> merged;
        merged = mappings.getOrDefault(x, new HashSet<>());
        merged.addAll(mappings.getOrDefault(y, new HashSet<>()));
        merged.add(x);
        merged.add(y);
        for (String p : merged) {
            mappings.put(p, merged);
        }
    }

    public Set<String> getMapping(String a) {
        return mappings.get(a);
    }

    @Override
    public boolean connected(String a, String b) {
        return mappings.containsKey(a) && mappings.get(a).contains(b);
    }
}
