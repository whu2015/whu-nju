package anonymous.propertymerge;

import anonymous.mapping.PropertyMappingInterface;

import java.io.FileInputStream;
import java.util.HashMap;
import java.util.Map;
import java.util.Objects;
import java.util.Scanner;

public class PredefinedPropertyMerge implements PropertyMappingInterface {
    private Map<String, Integer> labels;

    public PredefinedPropertyMerge(String name) {
        int i = 0;
        try {
            Scanner scanner = new Scanner(new FileInputStream("./data/property_merge/task_id_map.tsv"));
            while (scanner.hasNextLine()) {
                String part[] = scanner.nextLine().split("\t", 2);
                if (part[0].equals(name)) {
                    i = Integer.parseInt(part[1]);
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
        }


        labels = new HashMap<>();
        try {
            Scanner scanner = new Scanner(new FileInputStream("./data/property_merge/all_pairs_clique_label.csv"));
            scanner.nextLine();
            while (scanner.hasNextLine()) {
                String part[] = scanner.nextLine().split(",", 251);
                if (part[i].length() > 0) {
                    if (part[0].equals("http://www.w3.org/1999/02/22-rdf-syntax-ns#type")) continue;
                    labels.put(part[0], (int)Math.floor(Double.parseDouble(part[i])));
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    @Override
    public boolean connected(String a, String b) {
        return Objects.equals(labels.getOrDefault(a, -1), labels.getOrDefault(b, -2));
    }
}
