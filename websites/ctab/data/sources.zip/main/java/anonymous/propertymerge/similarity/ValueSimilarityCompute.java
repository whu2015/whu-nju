package anonymous.propertymerge.similarity;

import anonymous.dataprovider.cache.EntityLabelCache;
import anonymous.dataprovider.PropertyNode;
import anonymous.dataprovider.cache.EntityLabelCache;
import com.hp.hpl.jena.datatypes.xsd.impl.XSDFloat;
import info.debatty.java.stringsimilarity.JaroWinkler;
import org.apache.jena.datatypes.RDFDatatype;
import org.apache.jena.datatypes.xsd.impl.XSDBaseNumericType;
import org.apache.jena.datatypes.xsd.impl.XSDDouble;
import org.apache.jena.rdf.model.RDFNode;
import org.apache.jena.rdf.model.Resource;
import org.apache.jena.rdf.model.Statement;
import org.apache.jena.vocabulary.RDFS;

import java.util.List;

/**
 * Created by skim on 17-7-18.
 */
public class ValueSimilarityCompute implements SimilarityComputeInterface {
    private boolean[][] conflict;
    private JaroWinkler winkler;

    public ValueSimilarityCompute(boolean[][] conflict, EntityLabelCache cache) {
        this.conflict = conflict;
        winkler = new JaroWinkler();
    }

    @Override
    public double[][] compute(List<PropertyNode> properties) {
        int l = properties.size();
        double[][] sim = new double[properties.size()][];
        for (int i = 0; i < l; i++) sim[i] = new double[l];
        for (int i = 0; i < l; i++) {
            sim[i][i] = 1;
            for (int j = i + 1; j < l; j++) {
                if (!conflict[i][j]) {
                    double maxSim = 0;
                    for (RDFNode ni : properties.get(i).getValues()) {
                        for (RDFNode nj : properties.get(j).getValues()) {
                            maxSim = Math.max(maxSim, getSimilarity(ni, nj));
                        }
                    }
                    sim[i][j] = maxSim;
                } else {
                    sim[i][j] = 0;
                }
                sim[j][i] = sim[i][j];
            }
        }

        return sim;
    }

    public double getSimilarity(RDFNode x, RDFNode y) {
        if (x.isLiteral() && y.isLiteral()) {
            if (x.asLiteral().getDatatype().equals(y.asLiteral().getDatatype())) {
                RDFDatatype type = x.asLiteral().getDatatype();
                if (type instanceof XSDBaseNumericType || type instanceof XSDDouble || type instanceof XSDFloat) {
                    double xd = x.asLiteral().getDouble(), yd = y.asLiteral().getDouble();
                    if (xd * yd <= 0) {
                        return 0;
                    }

//                    return Math.abs(yd - xd) / Math.max(Math.abs(xd), Math.abs(yd));
                    return 0;
                } else {
                    return winkler.similarity(x.asLiteral().getString(), y.asLiteral().getString());
                }
            } else {
                return 0;
            }
        } else if (x.isResource() && y.isResource()) {
            if (x.asResource().getURI() == null || y.asResource().getURI() == null) return 0;
            String xl = getLabel(x.asResource()), yl = getLabel(y.asResource());
            if (xl == null || yl == null) return 0;
            return winkler.similarity(xl, yl);
        } else {
            return 0;
        }
    }

    private String getLabel(Resource r) {
        Statement stmt = r.asResource().getProperty(RDFS.label);
        if (stmt != null) {
            return stmt.getObject().asLiteral().getString();
        } else {
            return null;
        }
    }
}
