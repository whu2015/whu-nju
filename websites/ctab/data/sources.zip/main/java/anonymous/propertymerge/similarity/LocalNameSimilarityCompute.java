package anonymous.propertymerge.similarity;

import anonymous.dataprovider.PropertyNode;
import info.debatty.java.stringsimilarity.JaroWinkler;

/**
 * Created by skim on 17-7-17.
 */
public class LocalNameSimilarityCompute extends AbstractSimilarityCompute {
    private boolean[][] conflict;
    private JaroWinkler winkler;

    public LocalNameSimilarityCompute(boolean[][] conflict) {
        this.conflict = conflict;
        winkler = new JaroWinkler();
    }

    @Override
    protected double computeSimilarity(PropertyNode x, PropertyNode y, int i, int j) {
        if (conflict[i][j]) {
            return 0;
        }
        return winkler.similarity(x.getLocalName(), y.getLocalName());
    }
}
