package anonymous.evaluation.partialorder;

import java.util.*;

/**
 * Created by skim on 17-8-10.
 * Ref: Fagin, Ronald, et al. "Comparing partial rankings." SIAM Journal on Discrete Mathematics 20.3 (2006): 628-648.
 *      Theorem 5
 */
public class KendallHausdorffDistance {
    public static <T> double compute(List<Set<T>> a, List<Set<T>> b) {
        // refine
//        List<T> refine = new ArrayList<T>();
//        for (Set<T> bucket : a.subList(0, a.size() - 1)) refine.addAll(bucket);
//        for (Set<T> bucket : b.subList(0, b.size() - 1)) refine.addAll(bucket);
//        a.get(a.size() - 1).retainAll(refine);
//        b.get(b.size() - 1).retainAll(refine);
//        a = a.subList(0, a.size() - 1);
//        b = b.subList(0, b.size() - 1);

        double distance;
        List<T> totalOrder = new ArrayList<T>(), orderLeft, orderRight;
        for (Set<T> bucket : a) totalOrder.addAll(bucket);
//        for (Set<T> bucket : b) totalOrder.addAll(bucket);

        Collections.reverse(b);
        orderLeft = refinement(refinement(totalOrder, b), a);
        Collections.reverse(b);
        orderRight = refinement(refinement(totalOrder,a), b);
        distance = KendallDistance.compute(orderLeft, orderRight);

        orderLeft = refinement(refinement(totalOrder, b), a);
        Collections.reverse(a);
        orderRight = refinement(refinement(totalOrder,a), b);
        Collections.reverse(a);
        return Math.max(distance, KendallDistance.compute(orderLeft, orderRight));
    }

    static <T> List<T> refinement(List<T> totalOrder, List<Set<T>> bucketOrder) {
        List<T> refinement = new ArrayList<>();
        for (Set<T> bucket : bucketOrder) {
            for (T item : totalOrder) {
                if (bucket.contains(item)) refinement.add(item);
            }
        }
        return refinement;
    }

    static public void main(String args[]) {
        ArrayList<Set<String>> x = new ArrayList<>(), y= new ArrayList<>();

        x.add(new HashSet<>());x.get(0).addAll(Arrays.asList("genre", "type"));
        x.add(new HashSet<>());x.get(1).addAll(Arrays.asList("givenName", "label", "alias"));
        x.add(new HashSet<>());x.get(2).addAll(Arrays.asList("birthPlace", "place_of_birth"));
        x.add(new HashSet<>());x.get(3).addAll(Arrays.asList("gender"));
        x.add(new HashSet<>());x.get(4).addAll(Arrays.asList("birthDate"));
        
        y.add(new HashSet<>());y.get(y.size() - 1).addAll(Arrays.asList("birthDate"));
        y.add(new HashSet<>());y.get(y.size() - 1).addAll(Arrays.asList("birthPlace", "place_of_birth"));
        y.add(new HashSet<>());y.get(y.size() - 1).addAll(Arrays.asList("givenName", "label", "alias"));
        y.add(new HashSet<>());y.get(y.size() - 1).addAll(Arrays.asList("genre", "type"));
        y.add(new HashSet<>());y.get(y.size() - 1).addAll(Arrays.asList("birthDate"));
        
        System.out.println(KendallHausdorffDistance.compute(x, y));

        ArrayList<Set<Integer>> ix = new ArrayList<>(), iy = new ArrayList<>();
        ix.add(new HashSet<>());ix.get(ix.size() - 1).addAll(Arrays.asList(1, 2, 3));
        ix.add(new HashSet<>());ix.get(ix.size() - 1).addAll(Arrays.asList(4, 5));

        iy.add(new HashSet<>());iy.get(iy.size() - 1).addAll(Arrays.asList(1, 3));
        iy.add(new HashSet<>());iy.get(iy.size() - 1).addAll(Arrays.asList(2, 4, 5));
        System.out.println(KendallHausdorffDistance.compute(ix, iy));
    }
}
