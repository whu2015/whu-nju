package anonymous.evaluation.cluster;

import java.util.List;

public class ClusteringEvaluation {
    static private class Intra {
        public double a = 0, b = 0, c = 0, d = 0, m = 0;
    }

    static private <T> Intra computeIntraClassData(List<T> a, List<T> b) {
        Intra intra = new Intra();
        intra.m = a.size();
        for (int i = 0; i < a.size() - 1; i++) {
            for (int j = i + 1; j < a.size(); j++) {
                if (a.get(i).equals(a.get(j))) {
                    if (b.get(i).equals(b.get(j))) {
                        intra.a++;
                    } else {
                        intra.b++;
                    }
                } else {
                    if (b.get(i).equals(b.get(j))) {
                        intra.c++;
                    } else {
                        intra.d++;
                    }
                }
            }
        }
        return intra;
    }

    static <T> double computeFMI(List<T> a, List<T> b) {
        Intra i = computeIntraClassData(a, b);
        return Math.sqrt(i.a * i.a / (i.a + i.b) / (i.a + i.c));
    }

    static <T> double computeJaccard(List<T> a, List<T> b) {
        Intra i = computeIntraClassData(a, b);
        return i.a / (i.a + i.b + i.c);
    }

    static <T> double computeRI(List<T> a, List<T> b) {
        Intra i = computeIntraClassData(a, b);
        return (i.a + i.d) / (i.m * (i.m - 1) / 2.0);
    }
}
