package anonymous.evaluation.partialorder;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by skim on 17-8-10.
 */
public class KendallDistance {
    static <T> double compute(List<T> a, List<T> b) {
        int reverse = 0, total = a.size() * (a.size() - 1) / 2;
        for (int i = 0; i < b.size(); i++) {
            for (int j = i + 1; j < b.size(); j++) {
                if (a.indexOf(b.get(i)) > a.indexOf(b.get(j))) reverse++;
            }
        }
        return 1.0 * reverse / total;
    }

    static public void main(String args[]) {
        ArrayList<Integer> x = new ArrayList<>(), y= new ArrayList<>();
        for (int vx : new int[]{0, 3, 1, 6, 2, 5, 99}) x.add(vx);
        for (int vy : new int[]{1, 0, 3, 6, 99, 2, 5}) y.add(vy);
        System.out.println(KendallDistance.compute(x, y));
    }
}
