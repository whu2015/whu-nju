package anonymous.mapping;

/**
 * Created by skim on 17-3-27.
 */
public interface PropertyMappingInterface {
    boolean connected(String a, String b);
}
