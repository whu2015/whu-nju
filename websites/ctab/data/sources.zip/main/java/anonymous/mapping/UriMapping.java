package anonymous.mapping;

import java.io.InputStream;
import java.util.HashMap;
import java.util.Map;
import java.util.Scanner;

public class UriMapping {
	private static UriMapping instance;
	
	private Map<String, String> freebaseMapping;
	private Map<String, String> opencycMapping;
	private Map<String, String> mdbMapping;

	public static synchronized UriMapping getInstace() {
		if(instance == null) {
			instance = new UriMapping();
		}
		
		return instance;
	}
	
	private UriMapping() {
		freebaseMapping = new HashMap<String, String>();
		opencycMapping = new HashMap<String, String>();
		mdbMapping = new HashMap<String, String>();
		
		readFreebaseMapping();
		readCycMapping();
		readMdbMapping();
	}
	
	private void readFreebaseMapping() {
		System.out.println(getClass().getClassLoader().getResource("table/map/freebasemap.txt"));
		InputStream input = getClass().getClassLoader().getResourceAsStream("table/map/freebasemap.txt");
		Scanner scanner = null;
		try {
			scanner = new Scanner(input);
			while(scanner.hasNext()) {
				String line = scanner.nextLine();
				String key = line.substring(0, line.indexOf(';'));
				String value = line.substring(line.indexOf(';')+1, line.length());
				freebaseMapping.put(key, value);
			}
			
		} finally {
			if(scanner != null) {
				scanner.close();
			}
		}	
	}
	
	private void readCycMapping() {
		InputStream input = getClass().getClassLoader().getResourceAsStream("table/map/opencycmap.txt");
		Scanner scanner = null;
		try {
			scanner = new Scanner(input);
			while(scanner.hasNext()) {
				String line = scanner.nextLine();
				String key = line.substring(0, line.indexOf(';'));
				String value = line.substring(line.indexOf(';')+1, line.length());
				opencycMapping.put(key, value);
			}
			
		} finally {
			if(scanner != null) {
				scanner.close();
			}
		}		
	}
	
	private void readMdbMapping() {
		InputStream input = getClass().getClassLoader().getResourceAsStream("table/map/mdbmap.txt");
		Scanner scanner = null;
		try {
			scanner = new Scanner(input);
			while(scanner.hasNext()) {
				String line = scanner.nextLine();
				String key = line.substring(0, line.indexOf(';'));
				String value = line.substring(line.indexOf(';')+1, line.length());
				mdbMapping.put(key, value);
			}
			
		} finally {
			if(scanner != null) {
				scanner.close();
			}
		}		
	}

	public String getFreebaseMap(String uri) {
		if(freebaseMapping.containsKey(uri)) {
			return freebaseMapping.get(uri);
		} else return uri;
	}
	
	public String getOpenCycMap(String uri) {
		if(opencycMapping.containsKey(uri)) {
			return opencycMapping.get(uri);
		} else return uri;
	}
	
	public String getMdbMap(String uri) {
		if(mdbMapping.containsKey(uri)) {
			return mdbMapping.get(uri);
		} else return uri;
	}
}