package anonymous.mapping;

import anonymous.dataprovider.cache.AbstractCache;
import org.apache.jena.rdf.model.Property;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.*;

/**
 * Created by skim on 17-7-18.
 */
public class OfflinePropertyMapping extends AbstractCache implements PropertyMappingInterface {
    private Map<String, Set<String>> uriMappings;

    public OfflinePropertyMapping() {
        uriMappings = new HashMap<>();
        load();
    }

    public void addMatching(Property x, Property y) {
        addMatching(x.getURI(), y.getURI());
    }

    public void addMatching(String x, String y) {
        Set<String> setX = uriMappings.get(x), setY = uriMappings.get(y);
        if (setX == null) {
            setX = new HashSet<>();
            setX.add(x);
        }

        if (setY == null) {
            setY = new HashSet<>();
            setY.add(y);
        }

        if (setX.size() > 4 && setY.size() > 4) {
//            System.out.println("danger!");
//            System.out.println(setX);
//            System.out.println(setY);
        }

        setX.addAll(setY);

        for (String p : setX) {
            uriMappings.put(p, setX);
        }
    }

    @Override
    public boolean connected(String a, String b) {
        return uriMappings.containsKey(a) && uriMappings.get(a).contains(b);
    }

    @Override
    public String getCacheName() {
        return "mapping.property.bin";
    }

    @Override
    public void save() {
        try {
            saveCache(uriMappings);
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    @Override
    @SuppressWarnings("unchecked")
    public void load() {
        try {
            uriMappings = (Map<String, Set<String>>)loadCache();
            uriMappings = new HashMap<>();
            try {
                Scanner scanner = new Scanner(new File("./data/property_merge/localpm.csv"));
                while (scanner.hasNext()) {
                    String line = scanner.next();
                    String parts[] = line.split(",");
//                    if (parts[5].equals("1")) {
                        addMatching(parts[0], parts[1]);
//                    }
                }
            } catch (FileNotFoundException e) {
                e.printStackTrace();
            }
        } catch (IOException | ClassNotFoundException e) {
            e.printStackTrace();
        }
    }

    public static void main(String[] args) {
        OfflinePropertyMapping pm = new OfflinePropertyMapping();
        pm.uriMappings = new HashMap<>();
        try {
            Scanner scanner = new Scanner(new File("./data/property_merge/pm.csv"));
            while (scanner.hasNext()) {
                String line = scanner.next();
                String parts[] = line.split(",");
                if (parts[5].equals("1")) {
                    pm.addMatching(parts[0], parts[1]);
                }
            }
        } catch (FileNotFoundException e) {
            e.printStackTrace();
        }
        pm.save();
    }
}
