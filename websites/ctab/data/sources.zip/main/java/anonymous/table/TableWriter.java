package anonymous.table;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.IOException;

/**
 * Created by skim on 17-5-16.
 */
public interface TableWriter {
    void write(File file) throws IOException;
}
