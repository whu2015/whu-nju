package anonymous.generation.ranking;

import anonymous.generation.table.CTableGenerator;
import anonymous.util.TopK;
import anonymous.dataprovider.InstanceGroup;
import anonymous.generation.table.CTableGenerator;
import anonymous.generation.table.PropertyClique;
import anonymous.util.TopK;
import org.apache.jena.rdf.model.Property;

import java.io.File;
import java.util.*;

public class EntropyRanking {
    private CTableGenerator generator = null;
    private List<Map<PropertyClique, Set<String>>> featureGroup;

    private int entityCount; // N
    private Map<PropertyClique, Map<String, Double>> featureCount;
    private Map<String, Double> valueCount;

    public EntropyRanking(CTableGenerator generator) {
        this.generator = generator;
        featureGroup = generator.getFeatures();
        entityCount = featureGroup.size();
    }

    public Map<PropertyClique, Double> ranking() {
        Map<PropertyClique, Map<String, Integer>> counts = new HashMap<>();
        Map<PropertyClique, Double> rankings = new HashMap<>();

        for (Map<PropertyClique, Set<String>> featureMap : featureGroup) {
            for (PropertyClique c : featureMap.keySet()) {
                Set<String> values = featureMap.get(c);
                if (!counts.containsKey(c)) {
                    counts.put(c, new HashMap<>());
                }
                Map<String, Integer> cnt = counts.get(c);
                for (String value : values) {
                    if (!cnt.containsKey(value)) cnt.put(value, 0);
                    cnt.put(value, cnt.get(value) + 1);
                }
            }
        }

        for (Map.Entry<PropertyClique, Map<String, Integer>> entry : counts.entrySet()) {
            double entropy = 0;
            int total = 0;
            for (int x : entry.getValue().values()) {
                total += x;
            }

            for (int x : entry.getValue().values()) {
                double p = x * 1.0 / total;
                entropy += p * Math.log(p);
            }

            rankings.put(entry.getKey(), -entropy);
        }

        return rankings;
    }

    static public void main(String args[]) {
        InstanceGroup instanceGroup = new InstanceGroup();
        instanceGroup.loadDirectory(new File("./data/dataset/old/00-Barack_Obama"));
        CTableGenerator generator = new CTableGenerator(instanceGroup);
        EntropyRanking ranking = new EntropyRanking(generator);
//        System.out.println(ranking.ranking().values());
        System.out.println(TopK.getTopK(ranking.ranking(), 10));
    }
}
