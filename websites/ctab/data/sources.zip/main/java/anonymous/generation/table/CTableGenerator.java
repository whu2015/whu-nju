package anonymous.generation.table;

import anonymous.util.DateFormat;
import anonymous.util.LargestCommonSequence;
import anonymous.dataprovider.Instance;
import anonymous.dataprovider.InstanceGroup;
import anonymous.dataprovider.PropertyNode;
import anonymous.mapping.PropertyMappingInterface;
import anonymous.propertymerge.PredefinedPropertyMerge;
import anonymous.propertymerge.PropertyMappingGroundTruth;
import anonymous.propertymerge.ScopedMapping;
import anonymous.propertymerge.similarity.ValueSimilarityCompute;
import anonymous.util.DateFormat;
import anonymous.util.LargestCommonSequence;
import org.apache.jena.rdf.model.*;
import org.apache.jena.vocabulary.RDFS;
import util.JaroWinklerDistance;

import java.io.*;
import java.util.*;

/**
 * Created by skim on 17-6-20.
 */
public class CTableGenerator {
    public double DISCR_R = 0.3, DISCR_ALPHA = 1.5;
    public double COMPARABILITY_BETA_1 = 0.70, COMPARABILITY_BETA_2 = 0.25, COMPARABILITY_BETA_3 = 0.05;
    public double COMPARABILITY_REFINEMENT = 1.0;
    final double VALUE_SCORE_DELTA = 0.5, VALUE_SCORE_L = 5;
    final int VALUE_MAX_LENGTH = 100;
    protected InstanceGroup instanceGroup;
    protected Map<PropertyClique, Map<PropertyClique, Double>> diversityCache;
    protected ValueSimilarityCompute compute;

    public Instance instances[];
    public PropertyClique properties[];

    public CTableGenerator(InstanceGroup instanceGroup, String name) {
        compute = new ValueSimilarityCompute(null, null);
        this.instanceGroup = instanceGroup;
        diversityCache = new HashMap<>();
        // load instances
        instances = new Instance[instanceGroup.getInstances().size()];
        instanceGroup.getInstances().toArray(instances);
        // property merge
        PropertyMappingInterface pm;
//        pm = new ScopedMapping(instanceGroup.getProperties());
        pm = new PredefinedPropertyMerge(name.split("-")[1]);
        // load property groups
        List<PropertyClique> groups = new ArrayList<>();

        for (PropertyNode property : instanceGroup.getProperties()) {
            boolean connected = false;
            int count = 0;
            for (Instance instance : instances) {
                if (property.getValue(instance.getEntity()) != null) {
                    count += 1;
                    break;
                }
            }
            if (count == 0) continue;
//            property.refreshPropertyType(instanceGroup.getEndpointService());
            for (PropertyClique group : groups) {
                for (Property prop : group.getProperties()) {
                    if (pm.connected(prop.getURI(), property.getProperty().getURI())) {
                        group.addProperty(property.getProperty());
                        connected = true;
                        break;
                    }
                }
            }

            if (!connected) {
                PropertyClique group = new PropertyClique();
                group.addProperty(property.getProperty());
                groups.add(group);
            }
        }

        groups.sort((x, y) -> {
           return getValueCount(x) - getValueCount(y);
        });

        properties = new PropertyClique[groups.size()];
        groups.toArray(properties);
    }

    public CTableGenerator(InstanceGroup instanceGroup) {
        compute = new ValueSimilarityCompute(null, null);
        this.instanceGroup = instanceGroup;
        diversityCache = new HashMap<>();
        // load instances
        instances = new Instance[instanceGroup.getInstances().size()];
        instanceGroup.getInstances().toArray(instances);
        // property merge
        PropertyMappingInterface pm;
        pm = new ScopedMapping(instanceGroup.getProperties());
        // load property groups
        List<PropertyClique> groups = new ArrayList<>();

        for (PropertyNode property : instanceGroup.getProperties()) {
            boolean connected = false;
            int count = 0;
            for (Instance instance : instances) {
                if (property.getValue(instance.getEntity()) != null) {
                    count += 1;
                    break;
                }
            }
            if (count == 0) continue;
            property.refreshPropertyType(instanceGroup.getEndpointService());
            for (PropertyClique group : groups) {
                for (Property prop : group.getProperties()) {
                    if (pm.connected(prop.getURI(), property.getProperty().getURI())) {
                        group.addProperty(property.getProperty());
                        connected = true;
                        break;
                    }
                }
            }

            if (!connected) {
                PropertyClique group = new PropertyClique();
                group.addProperty(property.getProperty());
                groups.add(group);
            }
        }

        properties = new PropertyClique[groups.size()];
        groups.toArray(properties);
    }

    public CTableGenerator(InstanceGroup instanceGroup, Class<? extends PropertyMappingInterface> interfaceClass) {
        compute = new ValueSimilarityCompute(null, null);

        this.instanceGroup = instanceGroup;
        diversityCache = new HashMap<>();

        // load instances
        instances = new Instance[instanceGroup.getInstances().size()];
        instanceGroup.getInstances().toArray(instances);
        // property merge
//        PropertyMappingInterface pm = PropertyMapping.getInstance();
//        PropertyMappingInterface pm = new PropertyMappingGroundTruth();
        PropertyMappingInterface pm = null;
        if (interfaceClass != null) {
            try {
                pm = interfaceClass.newInstance();
            } catch (InstantiationException|IllegalAccessException e) {
                e.printStackTrace();
            }
        }
        if (pm == null) {
            pm = new ScopedMapping(instanceGroup.getProperties());
        }
        // load property groups
        List<PropertyClique> groups = new ArrayList<>();

        for (PropertyNode property : instanceGroup.getProperties()) {
            boolean connected = false;
            int count = 0;
            for (Instance instance : instances) {
                if (property.getValue(instance.getEntity()) != null) {
                    count += 1;
                    break;
                }
            }
            if (count == 0) continue;
//            property.refreshPropertyType(endpointService);
            for (PropertyClique group : groups) {
                for (Property prop : group.getProperties()) {
                    if (pm.connected(prop.getURI(), property.getProperty().getURI())) {
                        group.addProperty(property.getProperty());
                        connected = true;
                        break;
                    }
                }
            }

            if (!connected) {
                PropertyClique group = new PropertyClique();
                group.addProperty(property.getProperty());
                groups.add(group);
            }
        }


        groups.sort((x, y) -> {
            return getValueCount(x) - getValueCount(y);
        });
        properties = new PropertyClique[groups.size()];
        groups.toArray(properties);
    }

    public List<Map<PropertyClique, Set<String>>> getFeatures() {
        List<Map<PropertyClique, Set<String>>> featureGroup = new ArrayList<>();
        for (Instance instance : instances) {
            Map<PropertyClique, Set<String>> featureMap = new HashMap<>();
            for (PropertyClique c : properties) {
                Set<String> values = new HashSet<>();
                for (RDFNode node : getValues(instance, c)) {
                    String value = node.toString();
                    if (node.isLiteral()) {
                        value = node.asLiteral().getString();
                    } else {
                        Resource r = node.asResource();
                        if (r != null) {
                            Statement labelStmt = r.getProperty(RDFS.label);
                            if (labelStmt != null) {
                                value = labelStmt.getObject().asLiteral().getString();
                            }
                        }
                    }
                    values.add(value);
                }
                featureMap.put(c, values);
            }
            featureGroup.add(featureMap);
        }
        return featureGroup;
    }

    protected void showScore(List<PropertyClique> cliques) {
        for (PropertyClique clique : cliques) {
            System.out.printf("%s(%s)\t", clique.getShortString(), clique.getProperties().get(0).getURI());
            System.out.printf("%f\t%f\t%f\n", getDiscriminability(clique), getAbundance(clique), getSemantics(clique));
//            System.out.printf("%f\n", comp);
        }
    }

    public void showTable(List<PropertyClique> cliques, PrintStream out) {
        HashSet<String> uselessProperties = new HashSet<>();
        try {
            Scanner scanner = new Scanner(new FileInputStream("./data/useless.txt"));
            while (scanner.hasNextLine()) uselessProperties.add(scanner.nextLine());
        } catch (FileNotFoundException e) {
            e.printStackTrace();
        }


        Map<Integer, String> labels = new HashMap<>();
        for (Instance instance : instances) {
            if (instance.getSource().contains("dbpedia")) {
                String uuu = instance.getEntity().getURI();
                labels.put(instance.getLabel(), uuu.substring(uuu.lastIndexOf("/") + 1));
            }
        }

        out.printf("score\tdataset");
        for (Instance instance : instances) {
            out.printf("\t%s", instance.getNs().substring("http://".length()).replaceAll("\\.com|\\.org|www\\.|rdf\\.", ""));
        }
        out.println();

        out.printf("\tentity");
        for (Instance instance : instances) {
            out.printf("\t%s", instance.getEntity().getURI());
        }
        out.println();


        for (PropertyClique clique : cliques) {
            if (clique.getProperties().get(0).getURI().contains("http://yago-knowledge.org/resource/infobox")) continue;
//            if (clique.toString().contains("dbpedia.org/property")) continue;
//            if (clique.toString().startsWith("http://yago-knowledge.org/infobox/en")) continue;
//            if (clique.toString().startsWith("http://rdf.freebase.com/key/")) continue;
//            if (clique.toString().startsWith("http://rdf.freebase.com/ns/common.topic")) continue;
//            if (clique.toString().contains("rdf.freebase.com/") && clique.toString().endsWith(".type")) continue;
//            if (uselessProperties.contains(clique.toString())) continue;

            List<String> selectedValues = selectValues(clique);
            int count = 0;
            Set<String> sources = new HashSet<>();
            for (int i = 0; i < selectedValues.size(); i++) {
                String selectedValue = selectedValues.get(i);
                if (selectedValue != null) {
                    count++;
                    sources.add(instances[i].getNs());
                }
            }
//            if (count <= 2) continue;
            if (uselessProperties.contains(clique.toString())) {
                out.printf("0\t");
            } else if (sources.size() == 1) {
                if (count >= 3) {
                    if (clique.toString().contains("rdf.freebase.com/key/")) {
                        out.printf("1\t");
                    } else {
                        out.printf("\t");
                    }
                } else {
                    out.printf("0\t");
                }
            } else {
                if (clique.toString().contains("rdf.freebase.com/key/") || clique.toString().contains("http://dbpedia.org/ontology/wikiPageID")) {
                    if (count >= 7) {
                        out.printf("3\t");
                    } else if (count >= 4) {
                        out.printf("2\t");
                    } else {
                        out.printf("1\t");
                    }
                } else {
                    if (getDiscriminability(clique) < 0.2 && getAbundance(clique) < 0.2) {
                        out.printf("3\t");
                    } else {
                        out.printf("\t");
                    }
                }
            }

            out.printf("%s\t", clique.toString());

            for (String value : selectedValues) {
                out.printf("%s\t", value == null ? " " : value);
            }

            out.printf("%d\t%f\t%f\t%f", count, getDiscriminability(clique), getAbundance(clique), getSemantics(clique));
            out.println();
        }
    }

    public List<String> selectValues(PropertyClique clique) {
        List<List<String>> valueLists = new ArrayList<>(instances.length);
        List<String> allValues = new ArrayList<>(), values = new ArrayList<>(instances.length);
        for (Instance instance : instances) {
            List<String> valueList = selectValue(instance, clique);
            valueLists.add(valueList);
            allValues.addAll(valueList);
        }

        for (List<String> valueList : valueLists) {
            valueList = selectValueByKnapsack(valueList, allValues);
            StringBuilder builder = new StringBuilder();
            for (String value : valueList) {
                builder.append(value);
                builder.append("; ");
            }
            values.add(valueList.size() > 0 ? builder.substring(0, Math.min(100, builder.length() - 2)) : null);
        }
        return values;
    }

    protected List<String> selectValueByKnapsack(List<String> values, List<String> domain) {
        JaroWinklerDistance measure = new JaroWinklerDistance();
        //JaroWinklerMeasure measure = new JaroWinklerMeasure();
        List<String> picked = new ArrayList<>();
        int weight[] = new int[values.size()];
        double cost[] = new double[values.size()];
        for (int i = 0; i < values.size(); i++) {
            weight[i] = values.get(i).length();
            cost[i] = 0;
            for (String v : domain) {
                if (measure.getDistance(v, values.get(i)) <= 0.1) {
                    cost[i]++;
                }
            }
            cost[i] = 1 / cost[i];
        }

        Set<Integer> pickedIndex = new HashSet<>();
        int totalWeight = 0;
        while (totalWeight < VALUE_MAX_LENGTH && pickedIndex.size() < values.size()) {
            int maxI = 0;
            double maxPrice = 0;
            for (int i = 0; i < values.size(); i++) {
                if (pickedIndex.contains(i)) continue;
                if (cost[i] / weight[i] > maxPrice && totalWeight + weight[i] < VALUE_MAX_LENGTH) {
                    maxPrice = cost[i] / weight[i];
                    maxI = i;
                }
            }
            pickedIndex.add(maxI);
            totalWeight += weight[maxI];
        }

        for (Integer i : pickedIndex) {
            picked.add(values.get(i));
        }

        if (picked.size() == 0 && values.size() > 0) {
            picked.add(values.get(0));
        }

        if (picked.size() >= 3) picked = picked.subList(0, 2);

        return picked;
    }

    protected List<String> selectValue(Instance instance, PropertyClique clique) {
        TreeSet<String> displayValues = new TreeSet<>();
        for (RDFNode node : getValues(instance, clique)) {
            String displayValue = "";
            displayValue = toLiteral(node);
            Set<String> toRemoves = new HashSet<>();
            for (String pickedValue : displayValues) {
                String existed = pickedValue.toLowerCase();
                int size = LargestCommonSequence.compute(existed, displayValue.toLowerCase()).length();
                if (size + 5 >= displayValue.length()) {
                    displayValue = null;
                    break;
                }
                if (size + 5 >= pickedValue.length()) {
                    toRemoves.add(pickedValue);
                }
//                if (pickedValue.contains(displayValue)) {
//                    displayValue = null;
//                    break;
//                }
            }
            if (displayValue != null) displayValues.add(displayValue);
            for (String toRemove : toRemoves) displayValues.remove(toRemove);
        }

        return new ArrayList<>(displayValues);
    }

    public static void main(String[] args) {
        InstanceGroup instanceGroup;
        File[] files = (new File("./data/prepare/all/")).listFiles();
        Arrays.sort(files);
        int i = 0;
        PrintStream out;
        try {
            out = new PrintStream(new FileOutputStream(
                    String.format("./data/property_select/experiment/all.tsv", i)));

            for (File file : files) {
                System.out.println(file.getPath());
                try {
//                PrintStream out = new PrintStream(new FileOutputStream(
//                        String.format("./data/property_select/experiment/all/%03d.tsv", i)));
                    i++;

                    instanceGroup = new InstanceGroup();
                    instanceGroup.loadTsvDirectory(file);
//                    CTableGenerator generator = new CTableGenerator(instanceGroup, PropertyMappingGroundTruth.class);
                    CTableGenerator generator = new CTableGenerator(instanceGroup, file.getName());
                    generator.showTable(Arrays.asList(generator.properties), out);
                    out.println();
                    out.println();
                    out.println();
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }
        } catch (FileNotFoundException e) {
            e.printStackTrace();
        }
    }

    public List<PropertyClique> pickCliqueCC(int T /* min cover */) {
        List<PropertyClique> D = new ArrayList<>();
        Set<PropertyClique> C = new HashSet<>();
        for (PropertyClique c : properties) C.add(c);
        Map<Instance, Integer> x = new HashMap<>();
        for (Instance instance : instances) x.put(instance, T);
        Set<Instance> E = new HashSet<>();
        for (Instance instance : instances) E.add(instance);
        while (E.size() > 0) {
            double minWeight = Double.MAX_VALUE;
            PropertyClique minClique = null;
            for (PropertyClique Cj : C) {
                Set<Instance> sj = getInstantiatedEntities(Cj);
                sj.retainAll(E);
                double weight = getRefinedComparability(Cj, D) / sj.size();
                if (weight < minWeight) {
                    minWeight = weight;
                    minClique = Cj;
                }
            }
            if (minClique == null) break;
            D.add(minClique);
            C.remove(minClique);

            Set<Instance> sj = getInstantiatedEntities(minClique);
            sj.retainAll(E);

            for (Instance instance : sj) {
                x.put(instance, x.get(instance) - 1);
                if (x.get(instance) == 0) {
                    E.remove(instance);
                }
            }
        }
        return D;
    }

    protected HashMap<Instance, List<RDFNode>> values = new HashMap<>();

    protected double getValueScore(RDFNode vi, Instance instance) {
        if (!values.containsKey(instance)) {
            List<RDFNode> vs = new ArrayList<>();
            for (PropertyClique node : properties) {
                vs.addAll(getValues(instance, node));
            }
            values.put(instance, vs);
        }

        return getValueScore(vi, values.get(instance));
    }

    protected double getValueScore(RDFNode vi, List<RDFNode> W) {
        double maxSim = 0;

        for (RDFNode vj : W) {
            maxSim = Math.max(maxSim, compute.getSimilarity(vi, vj));
        }

        return vi.toString().length() / VALUE_SCORE_L - VALUE_SCORE_DELTA * maxSim;
    }


    public List<PropertyClique> pickCliqueGreedy(int maxCount) {
        TreeMap<Double, PropertyClique> scores = new TreeMap<>();
        for (PropertyClique c : properties) {
            double weight = getRefinedComparability(c, Arrays.asList(properties));
            scores.put(weight, c);
        }

        List<PropertyClique> D = new ArrayList<>();
        while (!scores.isEmpty() && D.size() < maxCount) {
            D.add(scores.get(scores.firstKey()));
            scores.remove(scores.firstKey());
        }
        return D;
    }

    public List<PropertyClique> pickCliqueBC(double B /* max budget */) {
        Set<Instance> E = new HashSet<>();
        for (Instance instance : instances) E.add(instance);

        List<PropertyClique> D = new ArrayList<>();
        double b = 0;
        Set<PropertyClique> C = new HashSet<>();
        for (PropertyClique c : properties) C.add(c);

        while (!C.isEmpty()) {
            double maxWeight = 0;
            PropertyClique maxClique = null;

            double gd = getSubModularFunctionValue(instances, D);
            List<PropertyClique> gDUCj = new ArrayList<>(D);

            for (PropertyClique Cj : C) {
                gDUCj.add(Cj);
                double delta =  (getSubModularFunctionValue(instances, gDUCj) - gd);
                double weight = delta / getRefinedComparability(Cj, D);
                if (weight > maxWeight) {
                    maxWeight = weight;
                    maxClique = Cj;
                }
                gDUCj.remove(Cj);
            }

            if (maxClique == null) {
                maxClique = C.iterator().next();
                double minWeight = getRefinedComparability(maxClique, D);
                for (PropertyClique Cj : C) {
                    if (getRefinedComparability(Cj, D) < minWeight) {
                        minWeight = getRefinedComparability(Cj, D);
                        maxClique = Cj;
                    }
                }
            }

            if (b + getRefinedComparability(maxClique, D) <= B) {
                b += getRefinedComparability(maxClique, D);
                D.add(maxClique);
            }

            C.remove(maxClique);
        }
        return D;
    }

    protected double getRefinedComparability(PropertyClique clique, List<PropertyClique> d) {
        if (clique.getShortString().equals("hasGender")) {
            clique = clique;
        }
        return COMPARABILITY_REFINEMENT * getComparability(clique)
//                + (1 - COMPARABILITY_REFINEMENT) * getDiversity(clique, d);
        + (1 - COMPARABILITY_REFINEMENT) * getDiversity(clique);
    }

    protected double getComparability(PropertyClique clique) {
        return COMPARABILITY_BETA_1 * getDiscriminability(clique) + COMPARABILITY_BETA_2 * getAbundance(clique)
                + COMPARABILITY_BETA_3 * getSemantics(clique);
    }

    HashMap<Instance, HashMap<PropertyClique, Double>> valueScores = null;

    protected double getValueScore(Instance instance, PropertyClique clique) {
        if (valueScores == null) {
            valueScores = new HashMap<>();
            for (Instance inst : instances) {
                valueScores.put(inst, new HashMap<>());
                List<RDFNode> values = new ArrayList<>();
                for (PropertyClique cliq : properties) {
                    values.addAll(getValues(inst, cliq));
                }


                for (PropertyClique cliq : properties) {
                    double maxScore = 0;
                    for (RDFNode vi : getValues(instance, cliq)) {
                        double maxSim = 0;
                        for (RDFNode vj : values) {
                            if (!vi.equals(vj)) maxSim = Math.max(maxSim, compute.getSimilarity(vi, vj));
                        }
                        maxScore = Math.max(vi.toString().length() / VALUE_SCORE_L - VALUE_SCORE_DELTA * maxSim, maxScore);
                    }
                    valueScores.get(inst).put(cliq, maxScore);
                }
            }
        }

        return valueScores.get(instance).get(clique);
    }

    protected double getSubModularFunctionValue(Instance instances[], List<PropertyClique> cliques) {
        return getTotalRelatedness(instances, cliques);
    }

    protected double getTotalRelatedness(Instance instances[], List<PropertyClique> cliques) {
        double g = 0;
        for (Instance instance : instances) {
            PriorityQueue<Double> f = new PriorityQueue<>();
            double maxF = 0;
            for (PropertyClique clique : cliques) {
                maxF = Math.max(maxF, getRelatedness(instance, clique));
//                maxF += getRelatedness(instance, clique);
//                maxF = Math.max(maxF, getValueScore(instance, clique));
                f.add(getRelatedness(instance, clique));
            }
//            maxF = Math.min(maxF, 10);

//            if (!f.isEmpty()) maxF += f.poll();
//            if (!f.isEmpty()) maxF += f.poll();
//            if (!f.isEmpty()) maxF += f.poll();
//            maxF = Math.min(maxF, 30);

            g += maxF;
        }

        return g;
    }

    protected Map<Instance, Map<PropertyClique, Double>> relatedness = new HashMap();

    protected double getRelatedness(Instance e, PropertyClique c) {
        if (!relatedness.containsKey(e)) relatedness.put(e, new HashMap<>());
        if (relatedness.get(e).containsKey(c)) return relatedness.get(e).get(c);

        double totalNum = 0, diffNum, setNum = 0;
        HashSet<String> literals = new HashSet<>();
        for (Instance instance : instances) {
            List<RDFNode> values = getValues(instance, c);
            totalNum += values.size();
            if (values.size() >= 1) {
                setNum += 1;
            }

            for (RDFNode node : values) {
                if (node.isLiteral()) {
                    literals.add(node.asLiteral().getString());
                } else {
                    literals.add(node.asResource().getURI());
                }
            }
        }

        diffNum = literals.size();

        int size = getValues(e, c).size();
        double r = size > 0 ? Math.log(1 + 1.0 * diffNum / size) : 0;
//        r = Math.min(r, instances.length);
        relatedness.get(e).put(c, r);
        return r;
//        return Math.min(Math.log(getValues(e, c).size()) / Math.log(instanceGroup.getInstances().size()), 1);
//        return 1 - getAbundance(c);
    }

    public double getDiversity(PropertyClique c) {
        List<PropertyClique> cliques = Arrays.asList(properties);
        return getDiversity(c, cliques.subList(0, cliques.indexOf(c)));
    }

    public double getDiversity(PropertyClique c, List<PropertyClique> d) {
        double maxDiversity = 0;
        for (PropertyClique di : d) {
            double diversity = getDiversity(c, di);
            if (diversity > maxDiversity) maxDiversity = diversity;
        }
        return maxDiversity;
    }

    protected double getDiversity(PropertyClique ci, PropertyClique cj) {
        if (!diversityCache.containsKey(ci) || !diversityCache.get(ci).containsKey(cj)) {
            if (!diversityCache.containsKey(ci)) diversityCache.put(ci, new HashMap<>());
            if (!diversityCache.containsKey(cj)) diversityCache.put(cj, new HashMap<>());
            Set<Instance> union, interscetion;
            union = getInstantiatedEntities(ci);
            union.addAll(getInstantiatedEntities(cj));
            int unionSize = union.size();
            interscetion = getInstantiatedEntities(ci);
            interscetion.retainAll(getInstantiatedEntities(cj));
            double simSum = 0;
            for (Instance instance : interscetion) {
                double simMax = 0;
                for (RDFNode vx : getValues(instance, ci)) {
                    for (RDFNode vy : getValues(instance, cj)) {
                        simMax = Math.max(simMax, getSimilarity(vx, vy));
                    }
                }
                simSum += simMax;
            }
            double diversity = simSum / unionSize;
            diversityCache.get(ci).put(cj, diversity);
            diversityCache.get(cj).put(ci, diversity);
        }
        return diversityCache.get(ci).get(cj);
    }

    protected double getSimilarity(RDFNode vx, RDFNode vy) {
        if (vx == null || vy == null) return 0.0;
        return compute.getSimilarity(vx, vy);
    }

    protected int getValueCount(PropertyClique clique) {
        HashSet<String> literals = new HashSet<>();
        for (Instance instance : instances) {
            for (RDFNode node : getValues(instance, clique)) {
                literals.add(toLiteral(node));
            }
        }
        return literals.size();
    }

    public Set<Instance> getInstantiatedEntities(PropertyClique clique) {
        Set<Instance> s = new HashSet<>();
        for (Instance instance : instances) {
            if (getValues(instance, clique).size() > 0) {
                s.add(instance);
            }
        }

        return s;
    }

    public double getSemantics(PropertyClique clique) {
        int semantic = 0;
        for (Property property : clique.getProperties()) {
            semantic += isSemantic(property) ? 0 : 1;
        }
        return semantic * 1.0 / clique.getProperties().size();
    }

    protected boolean isSemantic(Property property) {
        if (property.getURI().equals("http://www.w3.org/2002/07/owl#sameAs")) return true;
        if (instanceGroup.getPropertyNode(property).isFunctionalProperty()) return true;
        if (instanceGroup.getPropertyNode(property).isInverseFunctionalProperty()) return true;
        return false;
    }

    public double getAbundance(PropertyClique clique) {
        double totalNum = 0, setNum = 0;
        for (Instance instance : instances) {
            List<RDFNode> values = getValues(instance, clique);
            totalNum += 1;
            if (values.size() >= 1) {
                setNum += 1;
            }
        }

        return 1.0 - Math.log(setNum) / Math.log(totalNum);
//        return 1.0 - Math.log(setNum) / Math.log(totalNum);
    }

    protected String toLiteral(RDFNode node) {
        if (node.isLiteral()) {
            String text = node.asLiteral().getString();
            if (node.asLiteral().getDatatypeURI().equals("http://www.w3.org/2001/XMLSchema#date")) {
                text = DateFormat.formatDate(node);
                if (text == null) {
                    text = node.asLiteral().getString();
                }
            }

            try {
                if (text.contains(".")) {
                    double v = Double.parseDouble(text);
                    text = String.format("%.3f", v);
                }
            } catch (NumberFormatException ignored) {
            }

            return (text.substring(0, Math.min(text.length(), 100)).replaceAll("\n", " "));
        } else {
            Resource r = node.asResource();
            if (r.getURI().equals("http://rdf.freebase.com/ns/m.05zppz")) return "male";
            if (r.getURI().equals("http://rdf.freebase.com/ns/m.02zsn")) return "female";
            if (r.getURI().contains("http://yago-knowledge.org/resource/")) {
                String label = r.getURI();
                return label.substring("http://yago-knowledge.org/resource/".length()).replaceAll("_", " ");
            } else if (r.getProperty(RDFS.label) != null) {
                return r.getProperty(RDFS.label).getString();
            } else {
                return (r.getURI());
            }
        }
    }

    public double getDiscriminability(PropertyClique clique) {
        double totalNum = 0, diffNum, setNum = 0;
        HashSet<String> literals = new HashSet<>();
        for (Instance instance : instances) {
            List<RDFNode> values = getValues(instance, clique);
            totalNum += values.size();
            if (values.size() >= 1) {
                setNum += 1;
            }

            for (RDFNode node : values) {
                literals.add(toLiteral(node));
            }
        }

        diffNum = literals.size();
//        return diffNum / totalNum;
//        if (diffNum == 1) diffNum = 0;
        return Math.pow(Math.abs(diffNum / totalNum - DISCR_R), DISCR_ALPHA);
    }

    protected double getPrice(PropertyClique group) {
        double price = 0;
        HashSet<String> allValues = new HashSet<>();
        for (Instance instance : instances) {
            List<RDFNode> values = getValues(instance, group);
            if (values.size() > 0) {
                price += 1;
            }
        }

        return price;
    }

    public List<RDFNode> getValues(Instance instance, PropertyClique group) {
        List<RDFNode> values = new ArrayList<>();
        for (Property property : group.getProperties()) {
            List<RDFNode> nodes = instanceGroup.getPropertyNode(property).getValue(instance.getEntity());
            if (nodes != null) values.addAll(nodes);
        }
        return values;
    }

    protected List<RDFNode> getValues(Instance instance, Property c) {
        return instanceGroup.getPropertyNode(c).getValue(instance.getEntity());
    }

    protected List<Set<String>> convertToBucket(List<PropertyClique> cliques) {
        List<Set<String>> buckets = new ArrayList<>();
        Set<String> domain = new HashSet<>();
        for (PropertyClique c : properties) for (Property p : c.getProperties()) domain.add(p.getURI());
        for (PropertyClique clique : cliques) {
            Set<String> bucket = new HashSet<>();
            for (Property p : clique.getProperties()) bucket.add(p.getURI());
            buckets.add(bucket);
            domain.removeAll(bucket);
        }
        if (domain.size() > 0) buckets.add(domain);
        return buckets;
    }

    public List<Set<String>> convertToBucket(String shortNames[]) {
        List<PropertyClique> cliques = new ArrayList<>();
        for (String shortName : shortNames) {
            if (shortName.equals("prefLabel")) shortName = "label";
            PropertyClique bestMatch = new PropertyClique();
            for (PropertyClique c : properties) {
                if (c.getFullString().toLowerCase().contains(shortName.toLowerCase())) {
                    if (bestMatch.getProperties().size() < c.getProperties().size()) {
                        bestMatch = c;
                    }
                }
            }

            if (bestMatch.getProperties().size() == 0 )System.out.println("error clique:" + shortName);
            cliques.add(bestMatch);
        }

        return convertToBucket(cliques);
    }

    public List<Set<String>> findBuckets(String shortNames[]) {
        List<PropertyClique> cliques = new ArrayList<>();
        for (String shortName : shortNames) {
            boolean found = false;
            for (PropertyClique c : properties) {
                for (Property p : c.getProperties()) {
                    if (p.getURI().equals(shortName)) {
                        found = true;
                        cliques.add(c);
                        break;
                    }
                }
                if (found) break;
            }
        }

        return convertToBucket(cliques);
    }

    protected List<PropertyClique> convertToCliques(String shortNames[]) {
        List<PropertyClique> cliques = new ArrayList<>();
        for (String shortName : shortNames) {
            for (PropertyClique c : properties) {
                if (c.getShortString().equals(shortName)) {
                    cliques.add(c);
                    break;
                }
            }
        }

        return cliques;
    }
}

