package anonymous.generation.ranking;

import anonymous.dataprovider.InstanceGroup;
import anonymous.generation.table.CTableGenerator;
import anonymous.util.TopK;
import anonymous.dataprovider.InstanceGroup;
import anonymous.generation.table.CTableGenerator;
import anonymous.generation.table.PropertyClique;
import anonymous.util.TopK;
import org.apache.jena.rdf.model.Property;

import java.io.File;
import java.util.*;

public class FacesRanking {
    private CTableGenerator generator = null;
    private List<Map<PropertyClique, Set<String>>> featureGroup;

    private int entityCount; // N
    private Map<PropertyClique, Map<String, Double>> featureCount;
    private Map<String, Double> valueCount;

    public FacesRanking(CTableGenerator generator) {
        this.generator = generator;
        featureGroup = generator.getFeatures();
        entityCount = featureGroup.size();
    }

    public Map<PropertyClique, Double> ranking() {
        prepareInformativeness();
        preparePopularity();
        Map<PropertyClique, Double> rankings = new HashMap<>();

        for (Map<PropertyClique, Set<String>> featureMap : featureGroup) {
            for (PropertyClique c : featureMap.keySet()) {
                if (!rankings.containsKey(c)) rankings.put(c, 0.0);
                int cnt = 0;
                for (String value : featureMap.get(c)) {
                    cnt += 1;
                    if (cnt > 10) break;
                    double count = featureCount.get(c).get(value);
                    double inf = Math.log(entityCount / count);
                    double po = Math.log(valueCount.get(value));
                    rankings.put(c, rankings.get(c) + inf * po);
                }
            }
        }

        return rankings;
    }

    public List<String> pickValues(List<String> description) {
        Map<String, List<String>> descriptionMap = new HashMap<>();
        String label = null;
        for (String line : description) {
            String parts[] = line.split(";", 3);
            if (parts.length < 3) continue;
            label = parts[0];
            if (!descriptionMap.containsKey(parts[1])) descriptionMap.put(parts[1], new ArrayList<>());
            descriptionMap.get(parts[1]).add(parts[2]);
        }

        List<String> shrinked = new ArrayList<>();

        for (Map.Entry<String, List<String>> entry : descriptionMap.entrySet()) {
            PropertyClique c = null;
            for (PropertyClique clique : generator.properties) {
                for (Property property : clique.getProperties()) {
                    if (property.getURI().contains(entry.getKey())) {
                        c = clique;
                        break;
                    }

                }
                if (c != null) break;
            }

            String maxValue = entry.getValue().get(0);

            if (c != null) {
                double max = 0;
                for (String value : entry.getValue()) {
                    try {
                        value = value.substring(1);
                        double count = featureCount.get(c).get(value);
                        double inf = Math.log(entityCount / count);
                        double po = Math.log(valueCount.get(value));
                        if (po * inf > max) {
                            max = po * inf;
                            maxValue = value;
                        }
                    } catch (Exception e) {
                        System.out.println("error:" + c.getShortString() + ";" +value);
                    }
                }
            }
            shrinked.add(label + ";" + entry.getKey() + ";" + maxValue);
        }

        return shrinked;
    }

    private void prepareInformativeness() {
        featureCount = new HashMap<>();
        for (Map<PropertyClique, Set<String>> featureMap : featureGroup) {
            for (PropertyClique c : featureMap.keySet()) {
                if (!featureCount.containsKey(c)) featureCount.put(c, new HashMap<>());
                for (String value : featureMap.get(c)) {
                    if (!featureCount.get(c).containsKey(value)) {
                        featureCount.get(c).put(value, 1.0);
                    } else {
                        featureCount.get(c).put(value, featureCount.get(c).get(value) + 1);
                    }
                }
            }
        }
    }

    private void preparePopularity() {
        valueCount = new HashMap<>();
        for (Map<PropertyClique, Set<String>> featureMap : featureGroup) {
            for (Set<String> values : featureMap.values()) {
                for (String value : values) {
                    if (!valueCount.containsKey(value)) valueCount.put(value, 0.0);
                    valueCount.put(value, valueCount.get(value) + 1);
                }
            }
        }
    }

    static public void main(String args[]) {
        InstanceGroup instanceGroup = new InstanceGroup();
        instanceGroup.loadDirectory(new File("./data/dataset/old/00-Barack_Obama"));
        CTableGenerator generator = new CTableGenerator(instanceGroup);
        FacesRanking ranking = new FacesRanking(generator);
//        System.out.println(ranking.ranking().values());
        System.out.println(TopK.getTopK(ranking.ranking(), 10));
    }
}
