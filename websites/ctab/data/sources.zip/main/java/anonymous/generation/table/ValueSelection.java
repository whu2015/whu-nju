package anonymous.generation.table;

import anonymous.dataprovider.InstanceGroup;
import anonymous.dataprovider.PropertyNode;
import anonymous.dataprovider.cache.PropertyLabelCache;
import anonymous.dataprovider.service.EndpointService;
import anonymous.dataprovider.InstanceGroup;
import anonymous.dataprovider.PropertyNode;
import anonymous.dataprovider.service.EndpointService;
import anonymous.dataprovider.cache.PropertyLabelCache;
import org.apache.jena.rdf.model.RDFNode;
import org.apache.jena.rdf.model.Resource;

import java.io.File;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

/**
 * Created by skim on 17-8-5.
 */
public class ValueSelection {
    static public void main(String[] args) {
        EndpointService endpointService = new EndpointService();
        PropertyLabelCache propertyLabelCache = new PropertyLabelCache(endpointService);
//        File old = new File("dataset");
        File old = new File("./data/dataset/old");

        Set<String> found = new HashSet<>();
        for (File inst : old.listFiles()) {
//        File inst = new File("./dataset/00-Barack_Obama");
            InstanceGroup group = new InstanceGroup(propertyLabelCache);
            group.loadDirectory(inst);

            for (PropertyNode pn : group.getProperties()) {
                if (found.contains(pn.getProperty().getURI())) continue;
                found.add(pn.getProperty().getURI());

//                if (pn.getProperty().getURI().endsWith("s")) continue;
//                if (pn.getProperty().getURI().contains("s_")) continue;

                for (Resource ent : pn.getEntities()) {
                    List<RDFNode> nodes = pn.getValue(ent);
                    if (nodes.size() > 10) {
                        System.out.printf("%s, %s, %d(%s, %s)\n",
                                endpointService.getLabel(ent.getURI()),
                                pn.getLabel(), nodes.size(), ent.getURI(), pn.getProperty().getURI());
                        for (RDFNode node : nodes.subList(0, 5)) {
                            if (node.isLiteral()) {
                                System.out.println(node.asLiteral());
                            } else {
                                System.out.printf("%s(%s)\n", node.toString(), endpointService.getLabel(node.asResource().getURI()));
                            }
                        }

                        System.out.println();
//                        break;
                    }
                }
            }

//            break;
        }
    }
}
