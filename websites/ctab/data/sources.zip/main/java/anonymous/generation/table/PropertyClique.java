package anonymous.generation.table;

import org.apache.jena.rdf.model.*;
import org.apache.jena.rdf.model.impl.PropertyImpl;

import java.util.*;

/**
 * Created by skim on 17-6-20.
 */
public class PropertyClique extends PropertyImpl {
    public PropertyClique() {
        super("http://ws.nju.edu.cn/ctable/property/" + UUID.randomUUID().toString());
        properties = new ArrayList<>();
    }


    public PropertyClique(String props) {
        super("http://ws.nju.edu.cn/ctable/property/" + UUID.randomUUID().toString());
        properties = new ArrayList<>();
        Model model = ModelFactory.createDefaultModel();
        for (String prop : props.split(";")) {
            properties.add(model.createProperty(prop));
        }
    }

    public String toString() {
        StringBuilder builder = new StringBuilder();
        if (properties.size() > 0) {
            builder.append(properties.get(0).getURI());
            for (int i = 1; i < properties.size(); i++) {
                builder.append(";");
                builder.append(properties.get(i).getURI());
            }
        }

        return builder.toString();
    }

    public String getShortString() {
        if (properties.size() > 0) {
            String label = properties.get(0).getLocalName();
            if (label.equals("Mx4rwLSVCpwpEbGdrcN5Y29ycA")) {
                label = label;
            }
            for (Property p : properties) {
                if (p.getNameSpace().startsWith("http://dbpedia.org") || p.getNameSpace().contains("w3.org")) label = p.getLocalName();
            }
            return label;
        }

        return "EMPTY_GROUP";
    }

    public String getFullString() {
        String fullString = "";
        boolean first = true;
        for (Property property : properties) {
            if (!first) fullString += ";";
            fullString += property.getLocalName();
            first = false;
        }

        return fullString;
    }

    public boolean isProperty() {
        return false;
    }

    void addProperty(Property property) {
        properties.add(property);
    }

    public List<Property> getProperties() {
        return properties;
    }

//    @SuppressWarnings("unchecked")
//    public void storeValues(InstanceGroup instanceGroup) {
//        values = new HashMap<>();
//        valueTexts = new HashMap<>();
//        valueIDs = new HashMap<>();
//        valueCounts = new HashMap<>();
//        allValueTexts = new HashSet<>();
//        emptyCount = 0;
//
//        for (Instance instance : instanceGroup.getInstances()) {
//            List<RDFNode> instanceValues = new ArrayList<>();
//            for (Property property : getProperties()) {
//                List<RDFNode> nodes = instanceGroup.getPropertyNode(property).getValue(instance.getEntity());
//                if (nodes == null) continue;
//                instanceValues.addAll(nodes);
//                for (RDFNode node : nodes) {
//                    String valueText;
//                    if (node.isLiteral()) {
//                        valueText = node.asLiteral().toString();
//                    } else {
//                        valueText = instanceGroup.getLabel(node.asResource());
//                        if (valueText == null) {
//                            valueText = node.asResource().getURI();
//                        }
//                    }
//
//                    valueText = valueText.toLowerCase();
//
//                    valueTexts.put(node, valueText);
//
//                    if (!valueIDs.containsKey(valueText)) {
//                        valueIDs.put(valueText, valueIDs.size());
//                    }
//
//                    if (!valueCounts.containsKey(valueText)) {
//                        valueCounts.put(valueText, 1);
//                    } else {
//                        valueCounts.put(valueText, valueCounts.get(valueText) + 1);
//                    }
//
//                    allValueTexts.add(valueText);
//                }
//            }
//
//            values.put(instance, instanceValues);
//            if (instanceValues.size() == 0) emptyCount += 1;
//        }
//    }
//
//    public String getText(RDFNode node) {
//        return valueTexts.get(node);
//    }
//
//    public double getProbability(RDFNode node) {
//        return 1.0 * valueCounts.get(getText(node)) / (emptyCount + allValueTexts.size());
//    }
//
//    public double getEmptyProbability() {
//        return 1.0 * emptyCount / (emptyCount + allValueTexts.size());
//    }
//
//    public String getId(RDFNode node) {
//        return valueIDs.get(getText(node)).toString();
//    }

//    public List<RDFNode> getValues(Instance instance) {
//        return values.get(instance);
//    }

    private List<Property> properties;

//    private Map<Instance, List<RDFNode>> values;
    private Map<RDFNode, String> valueTexts;
    private Map<String, Integer> valueIDs;
    private Map<String, Integer> valueCounts;
    private Set<String> allValueTexts;
    private int emptyCount;
}
