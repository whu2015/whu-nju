package anonymous.similarity;

/**
 * Created by skim on 17-3-12.
 */
public interface SimilarityMetric {
    double compute(String a, String b);
}
