package anonymous.similarity;

/**
 * Created by skim on 17-3-22.
 */
public class GeographicDistanceMetric implements SimilarityMetric {
    static public double computeLatitudeDifference(double x, double y)
    {
        return Math.abs(x - y) / 180.0f;
    }

    static public double computeLongitudeDifference(double x, double y)
    {
        double diff = Math.abs(x - y) / 360.0f;
        return diff - Math.ceil(diff);
    }

    public double compute(String a, String b) {
        GeoPoint ga = getCoordinates(a);
        GeoPoint gb = getCoordinates(b);
        if (ga == null || gb == null) {
            return 0;
        }

        double dy = computeLatitudeDifference(ga.latitude, gb.latitude);
        double dx = computeLongitudeDifference(ga.longitude, gb.longitude);
        return Math.sqrt(dx * dx + dy * dy);
    }

    private class GeoPoint {
        double latitude;
        double longitude;
    }


    /**
     * Extracts the latitude and longitude from a string and takes their order from the parameter "longitudeFirst".
     *
     * @param s The WGS84 coordinate string. Examples from DBpedia are:
     *          - POINT(-0.124722 51.5081) // first longitude then latitude, used by <http://www.w3.org/2003/01/geo/wgs84_pos#geometry>
     *          - 51.50805555555556 -0.12472222222222222 // first latitude then longitude, used by <http://www.georss.org/georss/point>
     * @return The coordinate if it could be extracted, null otherwise.
     */
    private GeoPoint getCoordinates(String s) {
        String numbers = s.replaceAll("[^\\d]", "");
        String[] parts = numbers.split(" ", 2);
        try {
            GeoPoint point = new GeoPoint();
            if (s.startsWith("POINT")) {
                point.longitude = Double.parseDouble(parts[0]);
                point.latitude = Double.parseDouble(parts[1]);
            } else {
                point.latitude = Double.parseDouble(parts[0]);
                point.longitude = Double.parseDouble(parts[1]);
            }
            return point;
        } catch (NumberFormatException ignored) {
            return null;
        }
    }
}
