package anonymous.similarity;

import com.wcohen.ss.JaroWinkler;
import synonymousdict.Synonymous;
import util.PartOfSpeech;

/**
 * Created by skim on 17-3-24.
 */
public class CoreSimilarityMetric implements SimilarityMetric {
    public double compute(String a, String b) {
        if (a == null || b == null) return 0;
        double sim = winkler.score(a, b);

        String[] strAs = a.split("\\s");
        String[] strBs = b.split("\\s");

        for (String strA : strAs) {
            for (String strB : strBs) {
                if (syn.isSynWords(strA, strB)) {
                    double newScore = winkler.score(a.replace(strA, strB), b);
                    if (newScore > sim) {
                        a = a.replace(strA, strB);
                        sim = newScore;
                    }
                }
            }
        }
        return sim;
    }

    static private JaroWinkler winkler = new JaroWinkler();
    static private Synonymous syn = Synonymous.getInstance();
}
