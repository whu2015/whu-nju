package anonymous.similarity;

import java.util.*;

/**
 * Created by skim on 17-3-12.
 */
public class SimilarityMetricFactory {
    public class PropertySummary {
        PropertySummary() {
            numericValueExists = false;
            dateValueExists = false;
            plainValueExists = false;
            numericValueMin = Double.MAX_VALUE;
            numericValueMax = -Double.MAX_VALUE;
            dateValueMin = null;
            dateValueMax = null;
            stringValues = new ArrayList<String>();
            numericValues = new ArrayList<Double>();
            dateValues = new ArrayList<Date>();
        }

        public boolean numericValueExists, dateValueExists, plainValueExists;
        private double numericValueMin, numericValueMax;
        private Date dateValueMin, dateValueMax;
        private List<String> stringValues;
        private List<Double> numericValues;
        private List<Date> dateValues;
    }

    public double getMaximumNumericValueSimilarity(PropertySummary a, PropertySummary b, double sim) {
        if (a.numericValueExists && b.numericValueExists) {
            List<Double> x = a.numericValues, y = b.numericValues;
            int i = 0, j = 0, flag = -1, pflag = -1; // prev: -1 mean no previous, 0 means previous value is from x, otherwise y
            double value = 0, pvalue = 0;
            while (i < x.size() && j < y.size()) {
                if (x.get(i) > y.get(j)) {
                    flag = 1;
                    value = y.get(j);
                    j++;
                } else if (x.get(i) < y.get(j)) {
                    flag = 0;
                    value = x.get(i);
                    i++;
                } else if (x.get(i) != 0){
                    return 1;
                } else {
                    i++;
                    j++;
                    pflag = -1;
                    continue;
                }

                if (flag + pflag == 1) {
                    if (value > 0 && pvalue <= 0) {
                        while (i < x.size() && x.get(i) <= 0) i++;
                        while (j < y.size() && y.get(j) <= 0) j++;
                        pflag = -1;
                        continue;
                    } else {
                        sim = Math.max(sim, Math.abs(value - pvalue) / Math.max(Math.abs(value), Math.abs(pvalue)));
                    }
                }

                pvalue = value;
                pflag = flag;
            }
        }

        if (a.dateValueExists && b.dateValueExists) {
            DateSimilarityMetric plainValueSimilarityMetric = new DateSimilarityMetric(
                    a.dateValueMin.before(b.dateValueMin) ? a.dateValueMin : b.dateValueMin,
                    a.dateValueMax.before(b.dateValueMax) ? a.dateValueMax : b.dateValueMax);
            for (Date sa : a.dateValues) {
                for (Date sb : b.dateValues) {
                    sim = Math.max(sim, plainValueSimilarityMetric.compute(sa, sb));
                }
            }
        }

        return sim;
    }

    public double getMaximumValueSimilarity(PropertySummary a, PropertySummary b, double sim) {
        if (sim < 0.1 && a.plainValueExists && b.plainValueExists) {
            SimilarityMetric plainValueSimilarityMetric = new PlainValueSimilarityMetric();
            for (String sa : a.stringValues) {
                for (String sb : b.stringValues) {
                    sim = Math.max(sim, plainValueSimilarityMetric.compute(sa, sb));
                }
            }
        }

        sim = Math.max(sim, getMaximumNumericValueSimilarity(a, b, 0));

        return sim;
    }

    public SimilarityMetric createSimilarityMetric(PropertySummary a, PropertySummary b) {
        SimilarityMetric numericSimilarityMetric = null;
        SimilarityMetric dateSimilarityMetric = null;
        SimilarityMetric plainValueSimilarityMetric = null;

        int metricCount = 0;

        if (a.plainValueExists && b.plainValueExists) {
            plainValueSimilarityMetric = new PlainValueSimilarityMetric();
            metricCount += 1;
        }

        if (a.numericValueExists && b.numericValueExists) {
            numericSimilarityMetric = new PercentageNumericSimilarityMetric();
            metricCount += 1;
        }

        if (a.dateValueExists && b.dateValueExists) {
            dateSimilarityMetric = new DateSimilarityMetric(
                    a.dateValueMin.before(b.dateValueMin) ? a.dateValueMin : b.dateValueMin,
                    a.dateValueMax.before(b.dateValueMax) ? a.dateValueMax : b.dateValueMax);
            metricCount += 1;
        }

        if (metricCount == 0) {
            return new ZeroSimilarityMetric();
        } else if (metricCount == 1) {
            if (numericSimilarityMetric != null) {
                return numericSimilarityMetric;
            } else if (dateSimilarityMetric != null) {
                return dateSimilarityMetric;
            } else {
                return plainValueSimilarityMetric;
            }
        } else {
            CompositeSimilarityMetric metric = new CompositeSimilarityMetric();
            if (numericSimilarityMetric != null) {
                metric.addSimilarityMetric(numericSimilarityMetric);
            }
            if (dateSimilarityMetric != null) {
                metric.addSimilarityMetric(dateSimilarityMetric);
            }
            if (plainValueSimilarityMetric != null) {
                metric.addSimilarityMetric(plainValueSimilarityMetric);
            }

            return metric;
        }
    }

    public PropertySummary createPropertySummary(List<String> values)
    {
        PropertySummary summary = new PropertySummary();

        for (String text : values) {
            if (PercentageNumericSimilarityMetric.isNumeric(text)) {
                summary.numericValueExists = true;
                double value = Double.valueOf(text);
                summary.numericValues.add(value);
                if (value > summary.numericValueMax) {
                    summary.numericValueMax = value;
                }
                if (value < summary.numericValueMin) {
                    summary.numericValueMin = value;
                }
            } else {
                Date date = DateSimilarityMetric.parseObject(text);
                if (date != null) {
                    summary.dateValues.add(date);
                    summary.dateValueExists = true;
                    if (summary.dateValueMax == null) {
                        summary.dateValueMax = date;
                        summary.dateValueMin = date;
                    } else if (date.after(summary.dateValueMax)) {
                        summary.dateValueMax = date;
                    } else if (date.before(summary.dateValueMin)) {
                        summary.dateValueMin = date;
                    }
                } else {
                    summary.plainValueExists = true;
                    summary.stringValues.add(text);
                }
            }
        }

        Collections.sort(summary.numericValues);
        Collections.sort(summary.dateValues);
        Collections.sort(summary.stringValues);

        return summary;
    }
}
