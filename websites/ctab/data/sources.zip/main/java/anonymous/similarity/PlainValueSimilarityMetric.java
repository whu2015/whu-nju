package anonymous.similarity;

import info.debatty.java.stringsimilarity.JaroWinkler;

/**
 * Created by skim on 17-3-13.
 */
public class PlainValueSimilarityMetric implements SimilarityMetric {
    public PlainValueSimilarityMetric() {
    }

    static private JaroWinkler winkler = new JaroWinkler();

    public double compute(String a, String b) {
        return winkler.similarity(a, b);
    }

    public static void main(String[] args) {
        PlainValueSimilarityMetric metric = new PlainValueSimilarityMetric();
        System.out.println(metric.compute("abstract", "P50c"));
    }
}
