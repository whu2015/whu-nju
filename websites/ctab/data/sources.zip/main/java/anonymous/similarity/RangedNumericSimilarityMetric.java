package anonymous.similarity;

/**
 * Created by skim on 17-3-12.
 */
public class RangedNumericSimilarityMetric implements SimilarityMetric {
    public RangedNumericSimilarityMetric(double min, double max) {
        range = Math.abs(max - min);
    }

    public double compute(String a, String b) {
        if (!PercentageNumericSimilarityMetric.isNumeric(a) || !PercentageNumericSimilarityMetric.isNumeric(b)) {
            return 0;
        }
        double difference = Math.abs(Double.valueOf(a) - Double.valueOf(b));
        return Math.min(1.0 - difference / range, 1);
    }

    public double getRange()
    {
        return range;
    }

    private double range;
}
