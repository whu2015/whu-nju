package anonymous.similarity;

import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;

/**
 * Created by skim on 17-3-12.
 */
public class DateSimilarityMetric implements SimilarityMetric {
    public DateSimilarityMetric(Date min, Date max) {
        range = Math.abs(max.getTime() - min.getTime());
    }

    public double compute(String a, String b) {
        Date dateA = parseObject(a), dateB = parseObject(b);
        if (dateA == null || dateB == null) {
            return 0;
        }
        double difference = Math.abs(dateA.getTime() - dateB.getTime());
        double large = Math.max(dateA.getTime(), dateB.getTime());
        return 1 - difference / large;
    }

    public double compute(Date dateA, Date dateB) {
        double difference = Math.abs(dateA.getTime() - dateB.getTime());
        double large = Math.max(dateA.getTime(), dateB.getTime());
        return 1 - difference / large;
    }

    public long getRange()
    {
        return range;
    }

    static public boolean isDate(String data) {
        return parseObject(data) != null;
    }

    static public Date parseObject(String text) {
        Date date = null;
        for (int i = 0; i < dateFormats.length; i++) {
            try {
                date = dateFormats[i].parse(text);
                break;
            } catch (ParseException ignored) {
            }
        }

        return date;
    }

    public static void main(String[] args) {
        Date date = parseObject("100-2-##");
        System.out.println(date.toString());
    }

    static private DateFormat[] dateFormats = {
            new SimpleDateFormat("yyyy-##-##"), // year
            new SimpleDateFormat("yyyy-MM-##"), // month
            new SimpleDateFormat("yyyy-MM-dd"), // date
            new SimpleDateFormat("yyyy-MM-dd HH:mm:ss") // datetime
    };
    private long range;
}
