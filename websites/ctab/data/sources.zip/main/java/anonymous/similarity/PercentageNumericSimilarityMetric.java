package anonymous.similarity;

/**
 * Created by skim on 17-3-13.
 */
public class PercentageNumericSimilarityMetric implements SimilarityMetric {
    private float percentageMax = 1.0f;

    public PercentageNumericSimilarityMetric() {
        percentageMax = 1.0f;
    }

    public PercentageNumericSimilarityMetric(float percentageMax) {
        this.percentageMax = percentageMax;
    }

    public double compute(String a, String b) {
        try {
            double valueA = Double.valueOf(a);
            double valueB = Double.valueOf(b);
            if (valueA < 0 ^ valueB < 0) {
                return 0;
            }

            valueA = Math.abs(valueA);
            valueB = Math.abs(valueB);
            return 1 - Math.abs(valueA - valueB) / Math.max(valueA, valueB) / percentageMax;
        } catch (NumberFormatException ignored) {
            return 0;
        } catch (NullPointerException e) {
            return 0;
        }
    }

    static public boolean isNumeric(String data) {
        try {
            Double.parseDouble(data);
            return true;
        } catch (NumberFormatException ignored) {
            return false;
        }
    }
}
