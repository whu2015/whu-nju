package anonymous.similarity;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by skim on 17-3-12.
 */
public class CompositeSimilarityMetric implements SimilarityMetric {
    private List<SimilarityMetric> similarityList;

    public CompositeSimilarityMetric()
    {
        this.similarityList = new ArrayList<SimilarityMetric>();
    }

    public CompositeSimilarityMetric(List<SimilarityMetric> similarityList)
    {
        this.similarityList = similarityList;
    }

    public void addSimilarityMetric(SimilarityMetric similarity)
    {
        similarityList.add(similarity);
    }

    public double compute(String a, String b) {
        double similarity = 0;

        for (SimilarityMetric similarityMetric : similarityList) {
            double newSimilarity = similarityMetric.compute(a, b);
            if (newSimilarity > similarity) {
                similarity = newSimilarity;
            }
        }

        return similarity;
    }
}
