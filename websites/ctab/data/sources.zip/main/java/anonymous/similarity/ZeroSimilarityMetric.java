package anonymous.similarity;

/**
 * Created by skim on 17-3-14.
 */
public class ZeroSimilarityMetric implements SimilarityMetric {
    public ZeroSimilarityMetric() {
    }

    public double compute(String a, String b) {
        return 0;
    }
}
