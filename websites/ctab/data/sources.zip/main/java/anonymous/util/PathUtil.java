package anonymous.util;

import java.io.File;
import java.util.Arrays;

public class PathUtil {
    static public File[] listdir(File directory) {
        if (!directory.isDirectory()) {
            System.out.printf("Warning: %s is not directory\n", directory.getAbsolutePath());
            return new File[0];
        }
        File[] files = directory.listFiles();
        if (files == null) return new File[0];
        Arrays.sort(files);
        return files;
    }
}
