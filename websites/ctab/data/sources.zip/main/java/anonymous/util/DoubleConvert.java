package anonymous.util;

public class DoubleConvert {
    public static byte[] getByteArray(long l) {
        byte b[] = new byte[8];
        b[0] = (byte)  (0xff & (l >> 56));
        b[1] = (byte)  (0xff & (l >> 48));
        b[2] = (byte)  (0xff & (l >> 40));
        b[3] = (byte)  (0xff & (l >> 32));
        b[4] = (byte)  (0xff & (l >> 24));
        b[5] = (byte)  (0xff & (l >> 16));
        b[6] = (byte)  (0xff & (l >> 8));
        b[7] = (byte)  (0xff & l);
        return b;
    }

    static public void main(String args[]) {
        String text = "0dec27ade8a40192";
        double v = 37.622222;
        for (byte x : getByteArray(Double.doubleToLongBits(v))) {
            System.out.println(x);
            //http://www.wikidata.org/entity/VCc01ea297e4c8190a64eac6e43959d900
        }
    }
}
