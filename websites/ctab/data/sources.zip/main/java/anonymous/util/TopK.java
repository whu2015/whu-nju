package anonymous.util;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.TreeSet;

public class TopK {
    static public <K, V> List<K> getTopK(Map<K, V> scores, int k) {
        List<K> topK = new ArrayList<>(k);
        TreeSet<V> values = new TreeSet<>(scores.values());
        while (!values.isEmpty() && topK.size() < k) {
            V threshold = values.pollLast();
            for (K key : scores.keySet()) {
                if (scores.get(key).equals(threshold)) {
                    topK.add(key);
                    if (topK.size() >= k) break;
                }
            }
        }

        return topK;
    }
}
