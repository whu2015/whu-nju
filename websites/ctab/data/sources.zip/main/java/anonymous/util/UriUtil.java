package anonymous.util;

public class UriUtil {
    private static final String HTTP = "http://";

    static public String getSource(String uri) {
        return uri.substring(HTTP.length(), uri.indexOf("/", HTTP.length()));
    }

    public static void main(String args[]) {
        System.out.println(getSource("http://dbpedia.org/resource/Richard_Johnson_"));
    }
}
