package anonymous.util;

import org.apache.jena.rdf.model.RDFNode;

public class DateFormat {
    static public String formatDate(RDFNode node) {
        String objectValue = node.asLiteral().getString();
        String dateParts[] = objectValue.replaceAll("##", "1").replaceAll("#", "1").split("-");
        if (dateParts.length == 1) {
            objectValue = String.format("%s-%02d-%02d", dateParts[0], 1, 1);
        } else if (dateParts.length == 2) {
            objectValue = String.format("%s-%02d-%02d", dateParts[0], Integer.parseInt(dateParts[1]), 1);
        } else if (dateParts.length == 3) {
            objectValue = String.format("%s-%02d-%02d", dateParts[0], Integer.parseInt(dateParts[1]), Integer.parseInt(dateParts[2]));
        } else {
            return null;
        }

        return objectValue;
    }
}
