package anonymous.dataprovider;

import anonymous.dataprovider.cache.EntityLabelCache;
import anonymous.dataprovider.cache.PropertyLabelCache;
import anonymous.dataprovider.service.EndpointService;
import anonymous.dataprovider.service.EndpointService;
import anonymous.dataprovider.cache.EntityLabelCache;
import anonymous.dataprovider.cache.PropertyLabelCache;
import anonymous.mapping.UriMapping;
import com.alibaba.fastjson.JSON;
import org.apache.jena.rdf.model.*;
import org.apache.jena.vocabulary.OWL;
import org.apache.jena.vocabulary.RDFS;
import util.StringUtil;

import java.io.*;
import java.net.URLDecoder;
import java.util.*;
import java.util.function.Predicate;

/**
 * Created by skim on 17-7-6.
 */
public class InstanceGroup {
    private Map<Property, PropertyNode> propertyMap;
    private List<PropertyNode> properties;
    private List<Instance> instances = null;
    private Map<String, Instance> instanceMap;
    private PropertyLabelCache cache = null;
    private EndpointService endpointService;

    private int label;

    public EndpointService getEndpointService() {
        return endpointService;
    }

    public InstanceGroup(PropertyLabelCache cache) {
        instances = new ArrayList<>();
        properties = new ArrayList<>();
        instanceMap = new HashMap<>();
        propertyMap = new HashMap<>();
        endpointService = cache.getEndpointService();
        this.cache = cache;
        label = 0;
    }

    public InstanceGroup() {
        instances = new ArrayList<>();
        properties = new ArrayList<>();
        instanceMap = new HashMap<>();
        propertyMap = new HashMap<>();
        endpointService = new EndpointService();
        cache = new PropertyLabelCache(endpointService);
    }

    public String getLabel(Resource resource) {
        Statement stmt = resource.getProperty(RDFS.label);
        if (stmt != null) {
            return stmt.getObject().asLiteral().getString();
        }
        return endpointService.getLabel(resource.toString());
    }

    public List<Instance> getInstances() {
        return instances;
    }

    public List<PropertyNode> getProperties() {
        return properties;
    }

    public PropertyNode getPropertyNode(Property property) {
        return propertyMap.get(property);
    }

    public PropertyNode getPropertyNode(String property) {
        return propertyMap.get(ModelFactory.createDefaultModel().createProperty(property));
    }

    public void loadFullDirectory(File directory) {
        if (directory != null && directory.isDirectory()) {
            File[] files = directory.listFiles();
            if (files != null) {
                for (File file : files) {
                    loadDirectory(file);
                }
            }
        }
    }

    public void loadTsvDirectory(File directory) {
        if (directory != null && directory.isDirectory()) {
            String lastLabel = "";
            int lastIndex = 0;
            File[] files = directory.listFiles(pathname -> pathname.getName().endsWith(".tsv"));
            if (files != null) {
                Arrays.sort(files);
                for (File file : files) {
                    String[] parts = file.getName().split("-", 3);
                    if (!lastLabel.equals(parts[0])) {
                        lastIndex = getNextLabel();
                        lastLabel = parts[0];
                    }

                    try {
                        parseTsv(file, lastIndex,  file.getName().replaceAll(".tsv", ""));
                    } catch (Exception e) {
                        e.printStackTrace();
                    }
                }

                HashSet<String> entityURIs = new HashSet<>();
                for (Instance instance : instances) entityURIs.add(instance.getEntity().getURI());
                List<RDFNode> values = propertyMap.get(OWL.sameAs) != null ? propertyMap.get(OWL.sameAs).getValues() : null;
                if (values != null) {
                    values.removeIf(rdfNode -> rdfNode.isURIResource() && entityURIs.contains(rdfNode.asResource().getURI()));
                }

                for (Instance instance : instances) {
                    if (propertyMap.get(OWL.sameAs) == null) continue;
                    values = propertyMap.get(OWL.sameAs).getValue(instance.getEntity());
                    if (values != null) {
                        values.removeIf(rdfNode -> rdfNode.isURIResource() && entityURIs.contains(rdfNode.asResource().getURI()));
                    }
                }
            }
        }
    }

    public void loadDirectory(File directory) {
        if (directory != null && directory.isDirectory()) {
            String lastLabel = "";
            int lastIndex = 0;
            File[] files = directory.listFiles(new FileFilter() {
                @Override
                public boolean accept(File pathname) {
                    return pathname.getName().endsWith(".nt");
                }
            });
            if (files != null) {
                Arrays.sort(files);
                int i = 0;
                for (File file : files) {
                    String[] parts = file.getName().split("-", 3);
                    if (!lastLabel.equals(parts[0])) {
                        lastIndex = getNextLabel();
                        lastLabel = parts[0];
                    }

                    try {
                        parseNTriples(file, lastIndex,  file.getName().replaceAll(".nt", ""));
                    } catch (Exception e) {
                        continue;
                    }
                    i += 1;
//                    if (instances.size() >= 10) break;
                }
            }
        }
    }

    public void loadPlainDirectory(File directory) {
        if (directory != null && directory.isDirectory()) {
            String lastLabel = "";
            int lastIndex = 0;
            File[] files = directory.listFiles();
            if (files != null) {
                for (File file : files) {
                    String[] parts = file.getName().split("-", 3);
                    if (!lastLabel.equals(parts[0])) {
                        lastIndex = getNextLabel();
                        lastLabel = parts[0];
                    }

                    parsePlainText(file, lastIndex, file.getName().replaceAll(".nt", ""));
                }
            }
        }
    }

    public void parsePlainText(File file, int label, String name) {
        Model model = ModelFactory.createDefaultModel();
        Resource resource = null;

        // get entity uri
        Set<Property> propertySet = new HashSet<>();
        try {
            Scanner scanner = new Scanner(file);
            boolean firstLine = true;
            while (scanner.hasNext()) {
                String line = scanner.next();
                if (line.contains("http://xmlns.com/foaf/0.1/primaryTopic")) {
                    line = line;
                }
                String part[] = line.split(";", 3);
                if (part.length == 3 && part[2].length() > 1) {
                    if (firstLine) {
                        resource = model.createResource(part[0]);
                        firstLine = false;
                    }

                    Property property = model.createProperty(part[1]);
                    propertySet.add(property);
                    if (!propertyMap.containsKey(property)) {
                        PropertyNode pn = new PropertyNode(property, cache.getLabel(property));
                        properties.add(pn);
                        propertyMap.put(property, pn);
                    }

                    Statement stmt = null;

                    if (part[2].startsWith("u")) {
                        stmt = model.createStatement(resource, property, model.createResource(part[2].substring(1)));
                    } else {
                        try {
                            stmt = model.createStatement(resource, property, part[2].substring(1));
                        } catch (Exception e) {
//                            System.out.println(e);
                        }
                    }

                    propertyMap.get(property).addStatement(stmt);
                }
            }
        } catch (FileNotFoundException e) {
            e.printStackTrace();
        }

        Instance instance = new Instance(resource.getNameSpace(), resource, label, name);
        instances.add(instance);
        instanceMap.put(resource.getURI(), instance);

        for (Property property : propertySet) {
            propertyMap.get(property).addConflicts(propertySet);
        }
    }

    public void parseTsv(File file, int label, String name) {
        Model model = ModelFactory.createDefaultModel();
        Set<Property> propertySet = new HashSet<>();
        Resource subject = null;
        boolean firstLine = true;
        try {
            Scanner scanner = new Scanner(file);
            scanner.nextLine();
            while (scanner.hasNext()) {
                String part[] = scanner.nextLine().split("\t", 7);
                if (firstLine) {
                    subject = model.createResource(part[0]);
                    model.add(subject, RDFS.label, part[1]);
                    firstLine = false;
                }

                Property property = model.createProperty(part[2]);
//                    String object = URLDecoder.decode(part[4], "utf8");
                String object = part[4];
                Statement stmt;
                if (part[5].equals("entity")) {
                    Resource obj = model.createResource(object);
                    model.add(obj, RDFS.label, part[6]);
                    stmt = model.createStatement(subject, property, obj);
                } else {
                    stmt = model.createStatement(subject, property, object);
                }
                propertySet.add(property);
                if (!propertyMap.containsKey(property)) {
                    PropertyNode pn = new PropertyNode(property, property.getLocalName());
                    properties.add(pn);
                    propertyMap.put(property, pn);
                }

                propertyMap.get(property).addStatement(stmt);
            }
        } catch (FileNotFoundException e) {
            e.printStackTrace();
        }


        if (subject == null) {
            System.out.println("Error: empty file: " + file.getAbsolutePath());
            return;
        }
        Instance instance = new Instance(subject.getNameSpace(), subject, label, name);
        instances.add(instance);
        instanceMap.put(subject.getURI(), instance);

        for (Property property : propertySet) {
            propertyMap.get(property).addConflicts(propertySet);
        }
    }

    public void parseNTriples(File file, int label, String name) {
        Model model = ModelFactory.createDefaultModel();
        try {
            model.read(file.toString());
        } catch (org.apache.jena.riot.RiotException e) {
//            e.printStackTrace();
            return ;
        }
        boolean firstLine = true;


        Resource resource = null;

        // get entity uri
        NodeIterator nodeIterator = model.listObjectsOfProperty(model.createResource("http://ws.nju.edu.cn/ctable/dataset"), RDFS.member);
        if (nodeIterator.hasNext()) {
            resource = nodeIterator.next().asResource();
        }

        if (resource == null) {
            try {
                Scanner scanner = new Scanner(file);
                if (scanner.hasNext()) {
                    String part[] = scanner.next().split(" ");
                    resource = model.createResource(part[0].substring(1, part[0].length() - 1));
                }
            } catch (FileNotFoundException e) {
                e.printStackTrace();
            }
        }

        // load values
        Set<Property> propertySet = new HashSet<>();
        for (StmtIterator stmtIterator = model.listStatements(); stmtIterator.hasNext(); ) {
            Statement stmt = stmtIterator.nextStatement();
            if (!stmt.getSubject().equals(resource)) continue;
            if (stmt.getObject().isURIResource() && stmt.getObject().asResource().getURI().equals("http://www.wikidata.org/ontology#Item")) continue;
            Property property = stmt.getPredicate();
            propertySet.add(property);
            if (!propertyMap.containsKey(property)) {
                PropertyNode pn = new PropertyNode(property, property.getLocalName());
                properties.add(pn);
                propertyMap.put(property, pn);
            }

            propertyMap.get(property).addStatement(stmt);
        }

        if (resource == null) {
            System.out.println("Error: empty file: " + file.getAbsolutePath());
            return;
        }

        Instance instance = new Instance(resource.getNameSpace(), resource, label, name);
        instances.add(instance);
        instanceMap.put(resource.getURI(), instance);

        for (Property property : propertySet) {
            propertyMap.get(property).addConflicts(propertySet);
        }
    }

    public int getNextLabel() {
        label += 1;
        return label;
    }

    public static OBJECT convertToObject(RDFNode node, EntityLabelCache entityLabelCache) {
        String uri = node.asResource().getURI();
        String label = null;
        if(uri.contains("http://rdf.freebase.com/ns/")) {
            label = UriMapping.getInstace().getFreebaseMap(uri);
        } else if(uri.contains("http://sw.opencyc.org/concept/")) {
            label = UriMapping.getInstace().getOpenCycMap(uri);
        } else if(uri.contains("http://sw.cyc.com/concept/")) {
            label = UriMapping.getInstace().getOpenCycMap(uri);
        } else if(uri.contains("http://data.linkedmdb.org/resource/")) {
            label = UriMapping.getInstace().getMdbMap(uri);
        }

        if (label == null || label.startsWith("http://")) {
            if (uri.startsWith("http://rdf.freebase.com/ns/wikipedia.en.")) label = uri.substring("http://rdf.freebase.com/ns/wikipedia.en.".length());

            if (label == null) {
                label = entityLabelCache.getLabel(node.asResource().getURI());
            }
        }

        OBJECT object = new OBJECT();
        object.uri = uri;
        if (label != null && !label.startsWith("http://")) {
            object.label = label;
        } else {
            object.altLabel = StringUtil.getLabel(uri);
        }

        return object;
    }

    public void refreshPropertyType(EndpointService endpointService) {
        for (PropertyNode node : getProperties()) {
            node.refreshPropertyType(endpointService);
        }
    }

    public static void main(String[] args) {
        Map<String, Double> scores = new HashMap<>();
        try {
            Scanner scanner = new Scanner(new File("old.csv"));
            while (scanner.hasNext()) {
                String[] part = scanner.nextLine().split(",");
                if (part.length == 3) scores.put(part[0] + ":" + part[1], Double.parseDouble(part[2]));
                if (part.length == 3) scores.put(part[0] + "c:" + part[1], Double.parseDouble(part[2]));
                if (part.length == 3) scores.put(part[0] + ":" + part[1] + "c", Double.parseDouble(part[2]));
            }
        } catch (IOException e) {
        }

        EndpointService endpointService = new EndpointService();
        PropertyLabelCache propertyLabelCache = new PropertyLabelCache(endpointService);
        EntityLabelCache entityLabelCache = new EntityLabelCache(endpointService);

        InstanceGroup completeGroup = new InstanceGroup(propertyLabelCache);
        List<InstanceGroup> groups = new ArrayList<>();
        File f = new File("../disambiguation/instances");
        for (File cate : f.listFiles()) {
            for (File inst : cate.listFiles()) {
                if (inst.list().length > 0) {
                    InstanceGroup group = new InstanceGroup(propertyLabelCache);
                    group.loadDirectory(inst);
                    groups.add(group);

                    completeGroup.loadDirectory(inst);
                }
            }
//            break;
        }
        f = new File("./Processed-Instances/");
        for (File plain : f.listFiles()) {
            InstanceGroup group = new InstanceGroup(propertyLabelCache);
            group.loadPlainDirectory(plain);
            groups.add(group);

            completeGroup.loadPlainDirectory(plain);
//            break;
        }

//        for (InstanceGroup group : groups) {
//            for (PropertyNode pn : group.getProperties()) {
//                pn.refreshPropertyType(endpointService);
//            }
//        }

        for (PropertyNode pn : completeGroup.getProperties()) {
            pn.refreshPropertyType(endpointService);
        }



        try {
            Scanner scanner = new Scanner(new File("old.csv"));
            FileWriter writer = new FileWriter("final.njson");
            int count = 0;
            int fail = 0;
            while (scanner.hasNext()) {
                String[] part = scanner.next().split(",");
                if (part[0].contains("http://dbpedia.org/property") || part[1].contains("http://dbpedia.org/property")) {
                    continue;
                }

                if (part[0].contains("http://www.wikidata.org/entity/P") && !part[0].endsWith("c")) {
                    part[0] = part[0] + "c";
                }

                if (part[1].contains("http://www.wikidata.org/entity/P") && !part[1].endsWith("c")) {
                    part[1] = part[1] + "c";
                }


                PropertyNode x = completeGroup.getPropertyNode(part[0]), y = completeGroup.getPropertyNode(part[1]);

                if (y == null || x == null) {
                    System.out.println("ignore empty:" + part[0] + "," + part[1]);
                    continue;
                }

                PropertyPair pair = new PropertyPair();
                pair.prop1.URI = x.getProperty().getURI();
                pair.prop1.label = x.getLabel();
                pair.prop1.localName = x.getLocalName();

                pair.prop2.URI = y.getProperty().getURI();
                pair.prop2.label = y.getLabel();
                pair.prop2.localName = y.getLocalName();

                if (scores.containsKey(pair.prop1.URI + ":" + pair.prop2.URI)) {
                    pair.score = scores.get(pair.prop1.URI + ":"  + pair.prop2.URI);
                } else if (scores.containsKey(pair.prop2.URI + ":" + pair.prop1.URI)) {
                    pair.score = scores.get(pair.prop2.URI + ":"  + pair.prop1.URI);
                } else {
                    pair.score = -1.0;
                }

                if (x.isDatatypeProperty() && y.isDatatypeProperty()) {
                    pair.prop1.data = new ArrayList<>();
                    pair.prop2.data = new ArrayList<>();
                    for (InstanceGroup group : groups) {
                        List<Data> xData = new ArrayList<>(), yData = new ArrayList<>();

                        if (group.getPropertyNode(x.getProperty()) != null) {
                            for (RDFNode node : group.getPropertyNode(x.getProperty()).getValues()) {
                                if (node.isLiteral()) {
                                    if (node.asLiteral().getLanguage() != null) {
                                        if (!node.asLiteral().getLanguage().equals("en") && !node.asLiteral().getLanguage().equals("eng") && !node.asLiteral().getLanguage().equals("")) {
                                            continue;
                                        }
                                    }
                                    xData.add(new Data(node.asLiteral().toString(), node.asLiteral().getDatatypeURI()));
                                }
                            }
                        }

                        if (group.getPropertyNode(y.getProperty()) != null) {
                            for (RDFNode node : group.getPropertyNode(y.getProperty()).getValues()) {
                                if (node.isLiteral()) {
                                    if (node.asLiteral().getLanguage() != null) {
                                        if (!node.asLiteral().getLanguage().equals("en") && !node.asLiteral().getLanguage().equals("eng") && !node.asLiteral().getLanguage().equals("")) {
                                            continue;
                                        }
                                    }
                                    yData.add(new Data(node.asLiteral().toString(), node.asLiteral().getDatatypeURI()));
                                }
                            }
                        }

                        pair.prop1.data.add(xData);
                        pair.prop2.data.add(yData);
                    }
                } else if (x.isObjectProperty() && y.isObjectProperty()) {
                    pair.prop1.objects = new ArrayList<>();
                    pair.prop2.objects = new ArrayList<>();
                    for (InstanceGroup group : groups) {
                        List<OBJECT> xData = new ArrayList<>(), yData = new ArrayList<>();
                        if (group.getPropertyNode(x.getProperty()) != null) {
                            for (RDFNode node : group.getPropertyNode(x.getProperty()).getValues()) {
                                if (node.isResource()) {
                                    OBJECT obj = convertToObject(node, entityLabelCache);
                                    xData.add(obj);
                                }
                            }
                        }
                        if (group.getPropertyNode(y.getProperty()) != null) {
                            for (RDFNode node : group.getPropertyNode(y.getProperty()).getValues()) {
                                if (node.isResource()) {
                                    OBJECT obj = convertToObject(node, entityLabelCache);
                                    yData.add(obj);
                                }
                            }
                        }

                        pair.prop1.objects.add(xData);
                        pair.prop2.objects.add(yData);
                    }
                } else {
                    if (pair.score > 0) {
                        System.out.println("ignore:" + part[0] + "," + part[1]);
                    }
                    continue;
                }

                writer.write(JSON.toJSONString(pair));
                writer.write("\n");

                count += 1;
                if (count % 100 == 0) System.out.printf("processed: %d\n", count);
            }

            writer.close();
            entityLabelCache.save();
        } catch (IOException e) {
            e.printStackTrace();
        }


//        for (Instance instance : group.instances) {
//            for (StmtIterator iterator = instance.getEntity().listProperties(); iterator.hasNext(); ) {
//                Statement stmt = iterator.nextStatement();
//                if (stmt.getObject().isLiteral()) {
//                    if (stmt.getObject().asLiteral().getLanguage() == null ||
//                            stmt.getObject().asLiteral().getLanguage().equals("en") ||
//                            stmt.getObject().asLiteral().getLanguage().equals("eng") ||
//                            stmt.getObject().asLiteral().getLanguage().equals("")
//                            ) {
//                        System.out.printf("%s;%s;l%s\n", stmt.getSubject().getURI(), stmt.getPredicate().getURI(), stmt.getObject().asLiteral().getString());
//                    }
//                } else {
//                    System.out.printf("%s;%s;u%s\n", stmt.getSubject().getURI(), stmt.getPredicate().getURI(), stmt.getObject().asResource().getURI());
//                }
//            }
//            System.out.println();
//        }
    }

    static class OBJECT {
        public OBJECT() {}
        public String uri;
        public String label;
        public String altLabel;
    }

    static class Data {
        public Data() {}
        public Data(String value, String type) { this.value = value; this.type = type; }
        public String value;
        public String type;
    }

    static class PropertyObject {
        public PropertyObject() {
            objects = null;
            data = null;
        }
        public String URI;
        public String localName;
        public String label;
        public String altLabel;
        public List<List<OBJECT>> objects;
        public List<List<Data>> data;
    }

    static class PropertyPair {
        public PropertyPair() { prop1 = new PropertyObject(); prop2 = new PropertyObject(); }
        public PropertyObject prop1, prop2;
        public double score;
    }
}