package anonymous.dataprovider;

import anonymous.dataprovider.service.EndpointService;
import anonymous.dataprovider.service.EndpointService;
import com.hp.hpl.jena.vocabulary.RDF;
import org.apache.jena.rdf.model.Property;
import org.apache.jena.rdf.model.RDFNode;
import org.apache.jena.rdf.model.Resource;
import org.apache.jena.rdf.model.Statement;
import org.apache.jena.vocabulary.OWL;

import java.util.*;

/**
 * Created by skim on 17-7-17.
 */
public class PropertyNode {
    private Property property;
    private String label;
    private String localName;
    private List<RDFNode> values;
    private List<Statement> statements;
    private Map<Resource, List<RDFNode>> entityValues;
    private Set<Property> conflictProperties;
    private boolean isObjectProperty;
    private boolean isDatatypeProperty;
    private boolean isFunctionalProperty;
    private boolean isInverseFunctionalProperty;

    public PropertyNode(Property property, String label) {
        this.property = property;
        this.label = label;
        localName = property.getLocalName();
        values = new ArrayList<>();
        statements = new ArrayList<>();
        entityValues = new HashMap<>();
        conflictProperties = new HashSet<>();
    }

    public void refreshPropertyType(EndpointService endpointService) {
        isObjectProperty = true;
        isDatatypeProperty = true;

        for (RDFNode value : values) {
            if (value.isLiteral()) isObjectProperty = false;
            if (value.isResource()) isDatatypeProperty = false;
            if (!isObjectProperty && !isDatatypeProperty) break;
        }

        isFunctionalProperty = false;
        isInverseFunctionalProperty = false;
        if (endpointService != null) {
            for (Resource resource : endpointService.getResources(property.getURI(), RDF.type.getURI())) {
                if (resource.equals(OWL.DatatypeProperty)) {
                    isDatatypeProperty = true;
                } else if (resource.equals(OWL.ObjectProperty)) {
                    isObjectProperty = true;
                } else if (resource.equals(OWL.FunctionalProperty)) {
                    isFunctionalProperty = true;
                } else if (resource.equals(OWL.InverseFunctionalProperty)) {
                    isInverseFunctionalProperty = true;
                }
            }
        }
    }

    public void addConflicts(Set<Property> conflicts) {
        conflictProperties.addAll(conflicts);
    }

    public void addStatement(Statement stmt) {
        statements.add(stmt);
        values.add(stmt.getObject());
        if (!entityValues.containsKey(stmt.getSubject())) {
            entityValues.put(stmt.getSubject(), new ArrayList<>());
        }
        entityValues.get(stmt.getSubject()).add(stmt.getObject());
    }

    public Property getProperty() {
        return property;
    }

    public String getLabel() {
        return label;
    }

    public String getLocalName() {
        return localName;
    }

    public List<Statement> getStatements() {
        return statements;
    }

    public List<RDFNode> getValues() {
        return values;
    }

    public List<RDFNode> getValue(Resource entity) {
        return entityValues.get(entity);
    }

    public Set<Resource> getEntities() {
        return entityValues.keySet();
    }

    public Set<Property> getConflictProperties() {
        return conflictProperties;
    }

    public boolean isObjectProperty() {
        return isObjectProperty;
    }

    public boolean isDatatypeProperty() {
        return isDatatypeProperty;
    }

    public boolean isFunctionalProperty() {
        return isFunctionalProperty;
    }

    public boolean isInverseFunctionalProperty() {
        return isInverseFunctionalProperty;
    }

    static void refreshPropertyNode(List<PropertyNode> properties, EndpointService endpointService) {
        for (PropertyNode propertyNode : properties) {
            propertyNode.refreshPropertyType(endpointService);
        }
    }
}
