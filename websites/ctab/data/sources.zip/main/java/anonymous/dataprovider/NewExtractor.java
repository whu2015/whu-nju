package anonymous.dataprovider;

import anonymous.dataprovider.cache.EntityLabelCache;
import anonymous.dataprovider.cache.PropertyLabelCache;
import anonymous.dataprovider.service.EndpointService;
import anonymous.mapping.UriMapping;
import com.alibaba.fastjson.JSON;
import org.apache.jena.rdf.model.RDFNode;
import org.apache.jena.rdf.model.Statement;
import org.apache.jena.vocabulary.RDFS;
import util.StringUtil;

import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.util.*;

public class NewExtractor {
    static public void main(String args[]) {
        EndpointService endpointService = new EndpointService();
        PropertyLabelCache propertyLabelCache = new PropertyLabelCache(endpointService);
        EntityLabelCache entityLabelCache = new EntityLabelCache(endpointService);

        InstanceGroup completeGroup = new InstanceGroup(propertyLabelCache);
        List<InstanceGroup> groups = new ArrayList<>();
        File f = new File("./data/dataset/new");
        int i = 0;
        for (File cate : f.listFiles()) {
//            for (File inst : cate.listFiles()) {
                if (cate.list().length > 0) {
                    i += 1;
                    System.out.printf("%s\t%d\n", cate.getName().split("-")[1], i);
                    InstanceGroup group = new InstanceGroup(propertyLabelCache);
                    group.loadDirectory(cate);
                    groups.add(group);

                    completeGroup.loadDirectory(cate);
                }
//            }
        }
        f = new File("./data/dataset/old");
        for (File plain : f.listFiles()) {
            InstanceGroup group = new InstanceGroup(propertyLabelCache);
            i += 1;
            System.out.printf("%s\t%d\n", plain.getName().split("-")[1], i);
            group.loadDirectory(plain);
            groups.add(group);

            completeGroup.loadDirectory(plain);
        }


        for (PropertyNode pn : completeGroup.getProperties()) {
            pn.refreshPropertyType(endpointService);
        }



        try {
            FileWriter writer = new FileWriter("properties.njson");

            for (PropertyNode x : completeGroup.getProperties()) {
                PropertyObject prop1 = new PropertyObject();
                if (x.getProperty().getURI().length() > 0) {
                    String realUri = x.getProperty().getURI();
                    if (realUri.contains("wikidata") && realUri.endsWith("c")) {
                        realUri = realUri.substring(0, realUri.length() - 1);
                    }
                    String label = endpointService.getLabel(realUri);
                    if (label != null) {
                        prop1.label = label;
                    } else {
                        prop1.label = x.getLabel();
                    }
                }
                prop1.localName = x.getLocalName();
                prop1.URI = x.getProperty().getURI();

                if (x.isDatatypeProperty()) {
                    prop1.data = new ArrayList<>();
                    for (InstanceGroup group : groups) {
                        List<Data> xData = new ArrayList<>();

                        if (group.getPropertyNode(x.getProperty()) != null) {
                            for (RDFNode node : group.getPropertyNode(x.getProperty()).getValues()) {
                                if (node.isLiteral()) {
                                    if (node.asLiteral().getLanguage() != null) {
                                        if (!node.asLiteral().getLanguage().equals("en") && !node.asLiteral().getLanguage().equals("eng") && !node.asLiteral().getLanguage().equals("")) {
                                            continue;
                                        }
                                    }
                                    xData.add(new Data(node.asLiteral().getString(), node.asLiteral().getDatatypeURI()));
                                }
                            }
                        }

                        prop1.data.add(xData);
                    }
                } else if (x.isObjectProperty()) {
                    prop1.objects = new ArrayList<>();
                    for (InstanceGroup group : groups) {
                        List<OBJECT> xData = new ArrayList<>();
                        if (group.getPropertyNode(x.getProperty()) != null) {
                            for (RDFNode node : group.getPropertyNode(x.getProperty()).getValues()) {
                                if (node.isResource()) {
                                    OBJECT obj = convertToObject(node, entityLabelCache);
                                    xData.add(obj);
                                }
                            }
                        }

                        prop1.objects.add(xData);
                    }
                } else {
                    System.out.println(prop1.URI);
                }

                writer.write(JSON.toJSONString(prop1));
                writer.write("\n");
            }

            writer.close();
            entityLabelCache.save();
        } catch (IOException e) {
            e.printStackTrace();
        }

    }

    public static OBJECT convertToObject(RDFNode node, EntityLabelCache entityLabelCache) {
        String uri = node.asResource().getURI();
        String label = null;
        if(uri.contains("http://rdf.freebase.com/ns/")) {
            label = UriMapping.getInstace().getFreebaseMap(uri);
        } else if(uri.contains("http://sw.opencyc.org/concept/")) {
            label = UriMapping.getInstace().getOpenCycMap(uri);
        } else if(uri.contains("http://sw.cyc.com/concept/")) {
            label = UriMapping.getInstace().getOpenCycMap(uri);
        } else if(uri.contains("http://data.linkedmdb.org/resource/")) {
            label = UriMapping.getInstace().getMdbMap(uri);
        }

        if (label == null || label.startsWith("http://")) {
            if (uri.startsWith("http://rdf.freebase.com/ns/wikipedia.en.")) label = uri.substring("http://rdf.freebase.com/ns/wikipedia.en.".length());

            if (label == null || label.startsWith("http://")) {
                Statement stmt = node.asResource().getProperty(RDFS.label);
                if (stmt != null && stmt.getObject().isLiteral()) {
                    label = stmt.getObject().asLiteral().getString();
                } else {
                    if (node.asResource().getURI().contains("freebase")) {
                        System.out.println(node.asResource().getURI());
                    }
                    label = entityLabelCache.getLabel(node.asResource().getURI());
                }
            }
        }

        OBJECT object = new OBJECT();
        object.uri = uri;
        if (label != null && !label.startsWith("http://")) {
            object.label = label;
        } else {
            object.altLabel = StringUtil.getLabel(uri);
        }

        return object;
    }

    static class PropertyObject {
        public PropertyObject() {
            objects = null;
            data = null;
        }
        public String URI;
        public String localName;
        public String label;
        public String altLabel;
        public List<List<OBJECT>> objects;
        public List<List<Data>> data;
    }

    static class OBJECT {
        public OBJECT() {}
        public String uri;
        public String label;
        public String altLabel;
    }

    static class Data {
        public Data() {}
        public Data(String value, String type) { this.value = value; this.type = type; }
        public String value;
        public String type;
    }
}
