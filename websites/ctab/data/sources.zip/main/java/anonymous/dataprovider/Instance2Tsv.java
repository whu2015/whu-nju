package anonymous.dataprovider;

import anonymous.dataprovider.service.EndpointService;
import anonymous.propertymerge.PropertyMappingGroundTruth;
import anonymous.util.DateFormat;
import anonymous.dataprovider.cache.PropertyLabelCache;
import anonymous.dataprovider.service.EndpointService;
import anonymous.propertymerge.PropertyMappingGroundTruth;
import anonymous.util.DateFormat;
import org.apache.jena.rdf.model.RDFNode;
import org.apache.jena.rdf.model.Statement;
import org.apache.jena.rdf.model.StmtIterator;
import org.apache.jena.vocabulary.RDFS;

import java.io.*;
import java.net.URLEncoder;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import java.util.Set;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class Instance2Tsv {
    final Pattern dbpediaURIPattern = Pattern.compile("http://([a-zA-Z]+)\\.dbpedia\\.org/resource/.*");
    PropertyMappingGroundTruth pm = new PropertyMappingGroundTruth();

    private String getLabelByMapping(String propUri, EndpointService service) {
        if (propUri.contains("yago-knowledge.org")) {
            Set<String> matching = pm.getMapping(propUri);
            if (matching != null) {
                for (String match : matching) {
                    String label = service.getLabel(match);
                    if (label != null) return label;
                }
            }
        }

        return null;
    }

    public Instance2Tsv(File in, File out) {

        File groups[] = in.listFiles();

        EndpointService service = new EndpointService();
        PropertyLabelCache cache = new PropertyLabelCache(service);
        assert groups != null;
        for (File groupDir : groups) {
            System.out.printf("Process Group: %s\n", groupDir.getName());
            if (Integer.parseInt(groupDir.getName().split("-")[0]) < 40) continue;
            File outGroup = Paths.get(out.getPath(), groupDir.getName()).toAbsolutePath().toFile();
            outGroup.mkdirs();
            InstanceGroup group = new InstanceGroup(cache);
            group.loadDirectory(groupDir);
            for (Instance instance : group.getInstances()) {
                List<String> lines = new ArrayList<>();
                String subject = instance.getEntity().getURI();
                String subjectLabel = service.getLabel(subject);
                if (subjectLabel == null) {
                    subjectLabel = service.getLabel(instance.getEntity());
                }
                for (StmtIterator iterator = instance.getEntity().listProperties(); iterator.hasNext(); ) {
                    Statement stmt = iterator.nextStatement();
                    String property = stmt.getPredicate().getURI();
                    String propertyLabel = service.getLabel(property);

                    if (property.contains("dbpedia.org/property")) continue;
                    if (property.contains("http://yago-knowledge.org/resource/infobox/en/")) continue;

                    if (propertyLabel == null) propertyLabel = getLabelByMapping(property, service);

                    RDFNode node = stmt.getObject();
                    String type = "none";
                    String objectValue = node.toString();
                    String objectLabel = "";
                    if (node.isURIResource()) {
                        String label = service.getLabel(node.asResource().getURI());
                        objectValue = node.asResource().getURI();
                        if (label != null) {
                            type = "entity";
                            objectLabel = label;
                        } else {
                            objectLabel = service.getLabel(node.asResource());
                            if (objectLabel != null) {
                                type = "entity";
                            } else {
                                type = "uri";
                            }
                        }
                    } else if (node.isLiteral()) {
                        type = node.asLiteral().getDatatypeURI();
                        if (type.equals("http://www.w3.org/2001/XMLSchema#date")) {
                            objectValue = DateFormat.formatDate(node);
                            if (objectValue == null) {
                                objectValue = node.asLiteral().getString();
                                System.out.printf("Invalid Date Format: %s", node.asLiteral().getString());
                            }
                        } else {
                            if (type.equals("http://www.w3.org/1999/02/22-rdf-syntax-ns#langString")) {
                                if (!node.asLiteral().getLanguage().contains("en") && node.asLiteral().getLanguage().length() > 0) {
//                                    System.out.println(node.asLiteral().getLanguage());
                                    continue;
                                }
                            }
                            objectValue = node.asLiteral().getString().replaceAll("\n", " ").replaceAll("\t", " ");
                        }
                        objectLabel = "";
                    }

                    if (property.equals("http://www.w3.org/2002/07/owl#sameAs")) {
                        Matcher matcher = dbpediaURIPattern.matcher(objectValue);
                        if (matcher.matches() && !matcher.group(1).equals("en")) {
                            continue;
                        }
                    } else if (property.equals("http://rdf.freebase.com/ns/location.location.geolocation")) {
                        String latitude = service.getLiteral(objectValue, "http://rdf.freebase.com/ns/location.geocode.latitude");
                        String longitude = service.getLiteral(objectValue, "http://rdf.freebase.com/ns/location.geocode.longitude");


                        lines.add(String.format("%s\t%s\t%s\t%s\t%s\t%s\t%s", subject, subjectLabel, "http://www.w3.org/2003/01/geo/wgs84_pos#lat", "latitude",
                                latitude, "http://www.w3.org/2001/XMLSchema#float", ""));
                        lines.add(String.format("%s\t%s\t%s\t%s\t%s\t%s\t%s", subject, subjectLabel, "http://www.w3.org/2003/01/geo/wgs84_pos#long", "longitude",
                                longitude, "http://www.w3.org/2001/XMLSchema#float", ""));
                        continue;
                    } else if (objectValue.startsWith("http://www.wikidata.org/entity/VC")) {
                        String latitude = service.getLiteral(objectValue, "http://www.wikidata.org/ontology#latitude");
                        String longitude = service.getLiteral(objectValue, "http://www.wikidata.org/ontology#longitude");


                        lines.add(String.format("%s\t%s\t%s\t%s\t%s\t%s\t%s", subject, subjectLabel, "http://www.w3.org/2003/01/geo/wgs84_pos#lat", "latitude",
                                latitude, "http://www.w3.org/2001/XMLSchema#float", ""));
                        lines.add(String.format("%s\t%s\t%s\t%s\t%s\t%s\t%s", subject, subjectLabel, "http://www.w3.org/2003/01/geo/wgs84_pos#long", "longitude",
                                longitude, "http://www.w3.org/2001/XMLSchema#float", ""));
                        continue;
                    }

                    lines.add(String.format("%s\t%s\t%s\t%s\t%s\t%s\t%s", subject, subjectLabel, property, propertyLabel,
                            objectValue, type, objectLabel));
                }
                lines.sort(Comparator.naturalOrder());

                try {
                    System.out.println(instance.getName());
                    PrintStream writer = new PrintStream(new FileOutputStream(Paths.get(outGroup.getPath(), instance.getName() + ".tsv").toFile()));
                    writer.println("sub\tsubl\tprop\tpropl\tobj\tobj_t\tobj_l");
                    for (String line : lines) writer.println(line);
                    writer.close();
                } catch (FileNotFoundException e) {
                    e.printStackTrace();
                }
            }
        }
    }

    static public void main(String args[]) {
//        new Instance2Tsv(new File("./data/dataset/human"), new File("./data/preprocessed/human"));
//        new Instance2Tsv(new File("./data/prepare/old_final"), new File("./data/prepare/old_tsv"));
//        new Instance2Tsv(new File("./data/prepare/new"), new File("./data/prepare/new_tsv"));
        new Instance2Tsv(new File("./data/prepare/old__"), new File("./data/prepare/old__tsv"));
    }
}
