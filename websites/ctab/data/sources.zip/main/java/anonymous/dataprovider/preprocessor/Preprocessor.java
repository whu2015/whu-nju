package anonymous.dataprovider.preprocessor;

public class Preprocessor {
    public Preprocessor(String baseDir, String targetDir) {

    }

    static public void main(String args[]) {
        //
    }
}
