package anonymous.dataprovider.service;

import java.io.*;

/**
 * Created by skim on 17-8-7.
 */
public class CacheService {
    static private final String CACHE_DIR = "./cache/";

    static public <T> void saveJSON(T obj, String path) {
        ObjectOutputStream os = null;
        try {
            os = new ObjectOutputStream(new FileOutputStream(CACHE_DIR + path));
            os.writeObject(obj);
            os.close();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    static public <T> void save(T obj, String path) {
        ObjectOutputStream os = null;
        try {
            os = new ObjectOutputStream(new FileOutputStream(CACHE_DIR + path));
            os.writeObject(obj);
            os.close();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    static public <T> T loadCache(String path) {
        ObjectInputStream is = null;
        try {
            is = new ObjectInputStream(new FileInputStream(CACHE_DIR + path));
            @SuppressWarnings("unchecked")
            T obj = (T)is.readObject();
            is.close();
            return obj;
        } catch (IOException|ClassNotFoundException e) {
            e.printStackTrace();
        }

        return null;
    }

    static public void main(String[] args) {
        double[][] data = CacheService.loadCache("sim.label.bin");
        System.out.println(data.length);
    }
}
