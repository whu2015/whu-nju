package anonymous.dataprovider;

import anonymous.dataprovider.service.EndpointService;
import anonymous.dataprovider.service.EndpointService;
import com.alibaba.fastjson.JSON;
import edu.stanford.nlp.fsm.FastExactAutomatonMinimizer;
import org.apache.jena.rdf.model.*;
import org.apache.jena.riot.RDFDataMgr;
import org.apache.jena.riot.RDFFormat;
import org.apache.jena.riot.RiotException;
import org.apache.jena.vocabulary.RDFS;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.*;
import java.util.ArrayList;
import java.util.List;
import java.util.regex.Pattern;

/**
 * Created by skim on 17-8-10.
 */
public class EntityDownloader {
    static class Dataset {
        List<Group> groups;
    }

    static class Group {
        public List<Instance> instances;
        public String label;
    }

    static class Instance {
        public String group;
        public String source;
        public String name;
        public String uri;
    }

    static private Model downloadGeonames(String uri) {
        Model model = ModelFactory.createDefaultModel(), processed = ModelFactory.createDefaultModel();
        model.read(uri + "about.rdf");

        for (StmtIterator iterator = model.listStatements(); iterator.hasNext(); ) {
            Statement stmt = iterator.nextStatement();
            if (!stmt.getSubject().getURI().equals(uri)) continue;
            if (stmt.getObject().isResource() && stmt.getObject().asResource().getURI().equals(uri + "about.rdf")) continue;
            processed.add(stmt);
            if (stmt.getObject().isResource()) {
                Resource resource = stmt.getObject().asResource();
                if (Pattern.compile("http://sws.geonames.org/\\d+/").matcher(resource.getURI()).matches()) {
                    Model resourceModel = ModelFactory.createDefaultModel();
                    resourceModel.read(resource.getURI() + "about.rdf");
                    try {
                        String label = resourceModel
                                .getResource(resource.getURI())
                                .getProperty(resourceModel.createProperty("http://www.geonames.org/ontology#name"))
                                .getLiteral().getString();
                        processed.add(resource,
                                processed.createProperty("http://www.geonames.org/ontology#name"),
                                label);
                    } catch (Exception ignored) {
                    }
                }
            }
        }

        return processed;
    }

    static public void main(String args[]) {
        Logger logger = LoggerFactory.getLogger(EntityDownloader.class);

        List<Group> groups;
        try {
            File file = new File("data/seeds/single.json");
            FileReader reader = new FileReader(file);
            int fileLen = (int)file.length();
            char[] chars = new char[fileLen];
            reader.read(chars);
            String txt = String.valueOf(chars);
            groups = JSON.parseArray(txt, Group.class);

            EndpointService service = new EndpointService();
//            String basedir = "data/dataset/old";
            String basedir = file.getParentFile().getParent() + "/dataset/" + file.getName().replace(".json", "");
            for (Group group : groups) {
//            Group group = groups.get(1);
                String groupDir = String.format("%s/%02d-%s", basedir, groups.indexOf(group), group.label);
                if (!(new File(groupDir)).exists()) {
                    (new File(groupDir)).mkdirs();
                }
                for (Instance instance : group.instances) {
                    try {
                        System.out.println(instance.uri);
                        Model model = null;
                        if (instance.uri.contains("freebase")) {
                            model = service.fetchEntityBySelect(instance.uri);
                            model = service.processModel(instance.uri, model);
//                            continue;
                        } else if (instance.uri.startsWith("http://sws.geonames.org")) {
                            model = downloadGeonames(instance.uri);
//                            continue;
                        } else {
                            try {
//                                model = service.fetchEntityBySelect(instance.uri);
                                model = service.fetchEntityByCascadingSelect(instance.uri);
                            } catch (Exception ignored) {
                                model = service.fetchEntityBySelect(instance.uri);
                            }
//                            model = service.processModel(instance.uri, model);
//                            continue;
                        }

                        if (model == null) {
                            logger.warn("unable to fetch entity: {}", instance.uri);
                            continue;
                        }
                        model.add(
                                model.createResource("http://ws.nju.edu.cn/ctable/dataset"),
                                RDFS.member,
                                model.createResource(instance.uri));
                        RDFDataMgr.write(new FileOutputStream(String.format("%s/%s-%s-%s.nt", groupDir, instance.group, instance.source, instance.name)), model, RDFFormat.NTRIPLES);
                    } catch (Exception e) {
                        e.printStackTrace();
                    }

                }
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}
