package anonymous.dataprovider.cache;
import java.io.Serializable;

/**
 * Created by skim on 17-7-16.
 */
public interface CacheInterface extends Serializable {
    String getCacheName();
    void save();
    void load();
}
