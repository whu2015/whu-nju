package anonymous.dataprovider;

import org.apache.jena.rdf.model.Model;
import org.apache.jena.rdf.model.ModelFactory;
import org.apache.jena.rdf.model.Statement;
import org.apache.jena.rdf.model.StmtIterator;

import java.io.File;
import java.util.ArrayList;
import java.util.List;

/**
 * Created by skim on 17-7-6.
 */
public class InstanceLoader {
    public static Model loadNTriple(String file) {
        Model model = ModelFactory.createDefaultModel();
        model.read(file, "NT");
        // remove multi-language literal
        List<Statement> toRemove = new ArrayList<>();

        for (StmtIterator iterator = model.listStatements(); iterator.hasNext(); ) {
            Statement stmt = iterator.next();
            if (stmt.getObject().isLiteral()) {
                if (stmt.getObject().asLiteral().getLanguage() != null
                        && !stmt.getObject().asLiteral().getLanguage().equals("en")) {
                    toRemove.add(stmt);
                }
            }
        }

        for (Statement stmt : toRemove) {
            model.remove(stmt);
        }

        return model;
    }


    public static void main(String[] args) {

        LocalName localName = new LocalName();
        File baseDir = new File("/home/skim/workspace/disambiguation/instances/");
        for (File category : baseDir.listFiles()) {
            for (File group : category.listFiles()) {
                for (File inst : group.listFiles()) {
                    Model model = loadNTriple(inst.getAbsolutePath());
                    for (StmtIterator iterator = model.listStatements(); iterator.hasNext(); ) {
                        Statement stmt = iterator.next();
                        localName.getName(stmt.getPredicate().getURI());
                    }
                }
            }
        }
    }
}
