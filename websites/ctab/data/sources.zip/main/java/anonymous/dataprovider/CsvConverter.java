package anonymous.dataprovider;

import org.apache.jena.rdf.model.*;
import org.apache.jena.riot.RDFFormat;
import org.apache.jena.vocabulary.RDFS;

import java.io.File;
import java.io.PrintStream;
import java.util.List;

public class CsvConverter {
    static public void main(String args[]) {
        File basedir = new File("./data/dataset/old");
        File tasks[] = basedir.listFiles();
        assert tasks != null;
        for (File task : tasks) {
            File instances[] = task.listFiles();
            assert instances != null;
            for (File instanace : instances) {
                PrintStream out = System.out;
                Model model = ModelFactory.createDefaultModel();
                model.read(instanace.getAbsolutePath(), String.valueOf(RDFFormat.NTRIPLES));
                System.out.println(model);
                NodeIterator nodeIterator = model.listObjectsOfProperty(model.createResource("http://ws.nju.edu.cn/ctable/dataset"), RDFS.member);

                assert nodeIterator.hasNext();
                RDFNode node = nodeIterator.nextNode();
                assert node.isResource();
                Resource entity = node.asResource();

                for (StmtIterator iterator = entity.listProperties(); iterator.hasNext(); ) {
                    Statement stmt = iterator.nextStatement();
                    out.printf("%s,%s,%s,%s\n", entity.getURI(), stmt.getPredicate().getURI(), stmt.getObject().toString(), stmt.getObject().toString());
                }
                assert false;
            }
        }
    }
}
