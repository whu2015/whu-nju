package anonymous.dataprovider;

import org.apache.jena.rdf.model.*;
import org.apache.jena.vocabulary.RDFS;

import java.io.*;
import java.util.Arrays;
import java.util.Scanner;

public class Extractor {
    static public void main(String args[]) throws IOException {
        File baseDir = new File("./data/prepare/all");
        File[] groups = baseDir.listFiles();
        assert groups != null; // make the IDE happy
        for (File group : groups) {
            File[] files = group.listFiles(pathname -> pathname.getName().endsWith(".tsv"));
            File dir = new File("./dataset/" + group.getName());
            dir.mkdir();
            if (files != null) {
                Arrays.sort(files);
                for (File file : files) {
                    String fname = file.getName();

                    fname = fname.substring(0, fname.length() - ".tsv".length());
                    PrintStream ps = new PrintStream(new FileOutputStream("./dataset/" + group.getName() + "/" + fname));

                    String subject = null;
                    Scanner scanner = new Scanner(new FileInputStream(file));
                    scanner.nextLine();
                    while (scanner.hasNextLine()) {
                        String parts[] = scanner.nextLine().split("\t");
                        if (subject == null) {
                            subject = parts[0];
                        }
                        String prop = parts[2];

                        if (parts[5].equals("entity")) {
                            ps.printf("%s;%s;l%s\n", subject, prop, parts[6]);
                        } else {
                            ps.printf("%s;%s;l%s\n", subject, prop, parts[4]);
                        }
                    }

                    ps.close();
                }
            }
        }
    }
}
