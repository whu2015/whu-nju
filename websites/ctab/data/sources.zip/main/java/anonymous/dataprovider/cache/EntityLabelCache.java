package anonymous.dataprovider.cache;

import anonymous.dataprovider.service.EndpointService;
import anonymous.dataprovider.InstanceGroup;
import anonymous.dataprovider.PropertyNode;
import anonymous.dataprovider.service.EndpointService;
import org.apache.jena.rdf.model.RDFNode;

import java.io.File;
import java.io.IOException;
import java.util.HashSet;
import java.util.Set;

/**
 * Created by skim on 17-7-16.
 */
public class EntityLabelCache extends AbstractLabelCache {
    private Set<String> invalidURI = new HashSet<>();

    public EntityLabelCache() {
        super();
    }

    public EntityLabelCache(EndpointService local) {
        super(local);
        load();
    }

    public String getLabel(String property) {
        if (invalidURI.contains(property)) return null;
        String label = property;
        try {
             label = getLabel(model.createResource(property));
        } catch (Exception e){
            System.out.println("error:" + property);
            if (property.contains("dbpedia.org")) {
                label = getLabel(model.createResource(property));
            }
            invalidURI.add(property);
        }
        return label;
    }

    @Override
    public String getCacheName() {
        return "label.entity.bin";
    }

    public static void main(String[] args) throws InterruptedException {
        EndpointService endpointService = new EndpointService();
        PropertyLabelCache cache = new PropertyLabelCache(endpointService);
        InstanceGroup dataset = new InstanceGroup();
//        File base = new File("./dataset");
//        for (File f : base.listFiles()) {
//            dataset.loadDirectory(f);
//        }
        File base = new File("../disambiguation/instances");
        for (File cate : base.listFiles()) {
            for (File group : cate.listFiles()) {
                dataset.loadDirectory(group);
            }
        }

        for (PropertyNode property : dataset.getProperties()) {
            for (RDFNode node : property.getValues()) {
                if (!node.isResource()) continue;
                try {
                    String label = cache.getLabel(node.asResource().toString());
                    if (label == null
                            && !node.asResource().toString().contains("http://schema.org")
                            && !node.asResource().toString().contains("http://dbpedia.org/class/yago/")
                            && !node.asResource().toString().contains("http://purl.org/ontology")
                            && !node.asResource().toString().contains("http://umbel.org/umbel")
                            && !node.asResource().toString().contains("/ontology/")
                            && !node.asResource().toString().contains("/ontology#")
                            && !node.asResource().toString().contains("http://www.ontologydesignpatterns.org/ont/dul/DUL.owl")
                            && !node.asResource().toString().contains(".dbpedia.org/")) {
                        label = node.asResource().getLocalName();
                    }
                } catch (Exception e) {
                    System.out.println("error:" + node.asResource().getURI());
                }
            }
        }

        cache.save();
    }
}
