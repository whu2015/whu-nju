package anonymous.dataprovider.service;

import anonymous.dataprovider.cache.AbstractLabelCache;
import anonymous.dataprovider.preprocessor.freebase.FreebaseIntermediateNode;
import org.aksw.jena_sparql_api.http.QueryExecutionFactoryHttp;
import org.apache.jena.query.*;
import org.apache.jena.rdf.model.*;
import org.apache.jena.riot.RDFDataMgr;
import org.apache.jena.riot.RDFFormat;
import org.apache.jena.sparql.vocabulary.FOAF;
import org.apache.jena.vocabulary.RDF;
import org.apache.jena.vocabulary.RDFS;
import org.apache.jena.vocabulary.SKOS;
import org.javatuples.Pair;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.*;
import java.util.*;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * Created by skim on 17-7-14.
 */
public class EndpointService {
    final Logger logger = LoggerFactory.getLogger(AbstractLabelCache.class);
    private Map<String, Set<Model>> models;
    private List<Pair<String, String>> endpoints;
    private FreebaseIntermediateNode freebaseIntermediateNode = new FreebaseIntermediateNode();
    private Map<String, String> extraLabels;

    public EndpointService() {
        models = new HashMap<>();
        loadModel("ontology/geonames.rdf");
        loadModel("ontology/owl.ttl");
        loadModel("ontology/schema.nt");
        loadModel("ontology/foaf.rdf");
        loadModel("ontology/rdf-schema.ttl");
        loadModel("ontology/22-rdf-syntax-ns.ttl");
        loadModel("ontology/creativecommons.rdf");
        loadModel("ontology/skos.rdf");
        loadModel("ontology/dcterms.rdf");
        loadModel("ontology/prov-o.owl");
        loadModel("ontology/DUL.owl");
//        loadModel("ontology/dbpedia.owl");
//        loadModel("ontology/geonames.rdf");

        extraLabels = new HashMap<>();
        Scanner mapScanner = new Scanner(EndpointService.class.getClassLoader().getResourceAsStream("table/map/extra_labels.tsv"));
        while (mapScanner.hasNextLine()) {
            String parts[] = mapScanner.nextLine().split("\t", 2);
            extraLabels.put(parts[0], parts[1]);
        }

        endpoints = new ArrayList<>();

        Scanner scanner = new Scanner(EndpointService.class.getClassLoader().getResourceAsStream("config.endpoints"));
        while (scanner.hasNext()) {
            String parts[] = scanner.nextLine().split("=", 2);
            if (parts.length >= 2) {
                endpoints.add(new Pair<>(parts[0], parts[1]));
            }
        }
        scanner.close();
    }

    private void loadModel(String resource) {
        Model model = ModelFactory.createDefaultModel();
        try {
            model.read(getClass().getClassLoader().getResource(resource).toString());
        } catch (Exception e) {
            System.out.printf("Warning: failed to load model: %s", resource);
        }
        for (ResIterator iterator = model.listSubjects(); iterator.hasNext(); ) {
            String uri = iterator.nextResource().getURI();
            if (!models.containsKey(uri)) {
                models.put(uri, new HashSet());
            }
            models.get(uri).add(model);
        }
    }

    public String findEndpoint(String uri) {
        for (Pair<String, String> endpoint : endpoints) {
            if (uri.contains(endpoint.getValue0())) {
                return endpoint.getValue1();
            }
        }
        return null;
    }

    private Set<Model> findModel(String uri) {
        return models.getOrDefault(uri, new HashSet<>());
    }

    private String getDefaultLanguage(String uri) {
        if (uri.contains("http://yago-knowledge.org")) {
            return "eng";
        }
        return "en";
    }

    public String getLabel(String uri) {

        if (uri.startsWith("http://www.wikidata.org/entity/P")) {
            uri = uri.substring("http://www.wikidata.org/entity/P".length());
            uri = "http://www.wikidata.org/entity/P" + uri.replaceAll("c|s|-freebase|-freebas", "");
        } else if (uri.startsWith("http://rdf.freebase.com/key")) {
            return uri.substring(uri.lastIndexOf(".") + 1);
        }

        if (extraLabels.containsKey(uri)) return extraLabels.get(uri);

        String label = null;
        if (uri.contains("yago-knowledge.org/resource")) {
            label = getLiteral(uri, SKOS.prefLabel.getURI());
            if (label == null) {
                label = getLiteral(uri, RDFS.label.getURI());
            }
        } else {
            label = getLiteral(uri, RDFS.label.getURI());
        }

        if (label == null) {
            if (uri.startsWith("http://www.wikidata.org/ontology#")) {
                return uri.substring(uri.lastIndexOf("#") + 1);
            }
//            if (uri.startsWith("http://rdf.freebase.com/ns")) {
//                label = uri.substring(uri.lastIndexOf(".") + 1);
//            } else
            if (uri.startsWith("http://yago-knowledge.org/resource/wikicat_")) {
                return uri.substring("http://yago-knowledge.org/resource/wikicat_".length()).replaceAll("_", " ");
            }
        }

        return label;
    }

    public String getLabel(Resource entity) {
        String label = null;
        Property labelProperty = RDFS.label;
        if (entity.getURI().contains("geonames")) {
            labelProperty = entity.getModel().createProperty("http://www.geonames.org/ontology#name");
        }
        for (StmtIterator iterator = entity.listProperties(labelProperty); iterator.hasNext(); ) {
            Literal node = iterator.nextStatement().getObject().asLiteral();
            if (node.getLanguage() == null || node.getLanguage().length() == 0 || node.getLanguage().equals("en")) {
                label = node.getString();
            }
        }

        if (label == null && Pattern.compile("http://sws.geonames.org/\\d+/").matcher(entity.getURI()).matches()) {
            Model resourceModel = ModelFactory.createDefaultModel();
            resourceModel.read(entity.getURI() + "about.rdf");
            try {
                label = resourceModel
                        .getResource(entity.getURI())
                        .getProperty(resourceModel.createProperty("http://www.geonames.org/ontology#name"))
                        .getLiteral().getString();
            } catch (Exception ignored) {
            }
        }

        return label;
    }

    public String getLabelSafe(String uri) {
        String label = getLabel(uri);
        if (label == null) {
            if (label.startsWith("http://yago-knowledge.org/resource/infobox")) return label;
            if (label.startsWith("http://yago-knowledge.org/resource/")) return null;
            System.out.printf("Warning: no label for %s\n", uri);
        }
        return label;
    }

    public List<Resource> getResources(String subject, String predicate) {
        for (Model model : findModel(subject)) {
            List<Resource> resources = getResources(subject, predicate, model);
            if (resources.size() > 0) return resources;
        }
        return getResources(subject, predicate, findEndpoint(subject));
    }

    public List<Resource> getResources(String subject, String predicate, Model model) {
        List<Resource> resources = new ArrayList<>();
        if (model == null) return resources;
        String query = String.format("SELECT DISTINCT ?o WHERE {<%s> <%s> ?o . FILTER( ISIRI(?o) ) }", subject, predicate);
        QueryExecution qe = QueryExecutionFactory.create(query, model);
        ResultSet rs = qe.execSelect();
        while (rs.hasNext()) {
            resources.add(rs.next().getResource("o"));
        }
        return resources;
    }

    public List<Resource> getResources(String subject, String predicate, String endpoint) {
        List<Resource> resources = new ArrayList<>();
        if (endpoint == null) return resources;
        if (subject.contains("\"")) subject = subject.replace("\"", "%22");
        if (subject.contains(",")) subject = subject.replace("\"", "%2C");
        String query = String.format("SELECT DISTINCT ?o WHERE {<%s> <%s> ?o . FILTER( ISIRI(?o) ) }", subject, predicate);
        QueryExecutionFactoryHttp qef = new QueryExecutionFactoryHttp(endpoint);
        QueryExecution qe = qef.createQueryExecution(query);
        qe.setTimeout(3000);
        ResultSet rs = qe.execSelect();
        while (rs.hasNext()) {
            resources.add(rs.next().getResource("o"));
        }
        return resources;
    }

    public List<Resource> getSubjects(String object, String predicate, String endpoint) {
        List<Resource> resources = new ArrayList<>();
        if (endpoint == null) return resources;
        if (object.contains("\"")) object = object.replace("\"", "%22");
        if (object.contains(",")) object = object.replace("\"", "%2C");
        String query = String.format("SELECT DISTINCT ?o WHERE { ?o <%s> <%s> . FILTER( ISIRI(?o) ) }", predicate, object);
        QueryExecutionFactoryHttp qef = new QueryExecutionFactoryHttp(endpoint);
        QueryExecution qe = qef.createQueryExecution(query);
        qe.setTimeout(3000);
        ResultSet rs = qe.execSelect();
        while (rs.hasNext()) {
            resources.add(rs.next().getResource("o"));
        }
        return resources;
    }

    public List<RDFNode> getObject(String subject, String predicate) {
        return getObject(subject, predicate, findEndpoint(subject));
    }

    public List<RDFNode> getObject(String subject, String predicate, String endpoint) {
        List<RDFNode> resources = new ArrayList<>();
        if (endpoint == null) return resources;
        if (subject.contains("\"")) subject = subject.replace("\"", "%22");
        if (subject.contains(",")) subject = subject.replace("\"", "%2C");
        String query = String.format("SELECT DISTINCT ?o WHERE {<%s> <%s> ?o }", subject, predicate);
        QueryExecutionFactoryHttp qef = new QueryExecutionFactoryHttp(endpoint);
        QueryExecution qe = qef.createQueryExecution(query);
        qe.setTimeout(3000);
        ResultSet rs = qe.execSelect();
        while (rs.hasNext()) {
            resources.add(rs.next().get("o"));
        }
        return resources;
    }

    public String getLiteral(String uri, String property) {
        return getLiteral(uri, property, getDefaultLanguage(uri));
    }

    public String getLiteral(String uri, String property, String lang) {
        for (Model model : findModel(uri)) {
            String label = getLiteral(uri, property, lang, model);
            if (label != null) return label;
        }
        return getLiteral(uri, property, lang, findEndpoint(uri));
    }

    public String getLiteral(String uri, String property, String lang, Model model) {
        if (model == null) return null;
        String query = String.format("SELECT ?l WHERE {<%s> <%s> ?l . FILTER( lang(?l) = '%s')}", uri, property, lang);
        QueryExecution qe = QueryExecutionFactory.create(query, model);
        ResultSet rs = qe.execSelect();
        String label = getLongestString(rs, "l", uri);
        if (label != null) return label;

        query = String.format("SELECT ?l WHERE {<%s> <%s> ?l}", uri, property);
        qe = QueryExecutionFactory.create(query, model);
        rs = qe.execSelect();
        label = getLongestString(rs, "l", uri);
//        if (label != null) return label;

        return label;
    }

    public String getLiteral(String uri, String property, String lang, String endpoint) {
        if (endpoint == null) return null;
        if (uri.startsWith("http://data.linkedmdb.org/sparql?query=DESCRIBE+")) return null;
        uri = uri.replaceAll("\"", "%22");//.replaceAll(",", "%2C")
        String query = String.format("SELECT ?l WHERE {<%s> <%s> ?l . FILTER( lang(?l) = '%s' || lang(?l) = '' )}", uri, property, lang);
        QueryExecutionFactoryHttp qef = new QueryExecutionFactoryHttp(endpoint);
        QueryExecution qe = qef.createQueryExecution(query);
        ResultSet rs = null;
        try {
            rs = qe.execSelect();
        } catch (Exception e) {
            e.printStackTrace();
            System.out.println(e);
            System.out.println(endpoint);
            System.out.println(uri);
            System.out.println(property);
            System.out.println(lang);
        }

        return rs != null ? getLongestString(rs, "l", uri) : null;
    }

    private String getLongestString(ResultSet rs, String varName, String uri) {
        String value = "";
        if (uri.startsWith("http://yago-knowledge.org")) {
            uri = uri.substring(uri.lastIndexOf("/") + 1).replace("_", " ");
            while (rs.hasNext()) {
                QuerySolution sol = rs.next();
                String v = sol.getLiteral(varName).getString();
                if (v.length() > value.length() && !value.equals(uri)) {
                    value = v;
                }
            }
        } else {
            while (rs.hasNext()) {
                QuerySolution sol = rs.next();
                String v = sol.getLiteral(varName).getString();
                if (v.length() > value.length()) {
                    value = v;
                }
            }
        }
        return value.length() > 0 ? value : null;
    }

    static public void saveCache(Object obj, String filename) throws IOException {
        ObjectOutputStream os = new ObjectOutputStream(new FileOutputStream(filename));
        os.writeObject(obj);
        os.close();
    }

    static public Object loadCache(String filename) throws IOException, ClassNotFoundException {
        ObjectInputStream is = new ObjectInputStream(new FileInputStream(filename));
        Object obj = is.readObject();
        is.close();
        return obj;
    }

    public Model fetchEntity(String uri) {
        String endpoint = findEndpoint(uri);
        if (endpoint == null) throw new RuntimeException("unable to find endpoint");
        QueryExecutionFactoryHttp qef = new QueryExecutionFactoryHttp(endpoint);
        QueryExecution qe = qef.createQueryExecution(String.format("DESCRIBE <%s>", uri));
        return qe.execDescribe();
    }

    public Model fetchEntityBySelect(String uri) {
        String endpoint = findEndpoint(uri);
        if (endpoint == null) {
            throw new RuntimeException("unable to find endpoint: " + uri);
        }
        Model model = ModelFactory.createDefaultModel();
        QueryExecutionFactoryHttp qef = new QueryExecutionFactoryHttp(endpoint);
        QueryExecution qe = qef.createQueryExecution(String.format("SELECT ?p ?o WHERE { <%s> ?p ?o }", uri));
        ResultSet rs = qe.execSelect();
        Resource resource = model.createResource(uri);
        while (rs.hasNext()) {
            QuerySolution qs = rs.next();
            model.add(resource, model.createProperty(qs.getResource("p").getURI()), qs.get("o"));
        }
        return model;
    }

    public Model fetchEntityByCascadingSelect(String uri) {
        final String sparql = "select ?s ?pl ?ol ?p ?o where {\n" +
                "    VALUES ?s {<%s>}\n" +
                "    {{\n" +
                "        ?s ?p ?o .\n" +
                "        OPTIONAL {?o rdfs:label ?ol}\n" +
                "        FILTER(ISIRI(?o))\n" +
                "    }\n" +
                "    UNION\n" +
                "    {\n" +
                "        ?s ?p ?ol .\n" +
                "    }}.\n" +
                "    OPTIONAL {?p rdfs:label ?pl}\n" +
                "    FILTER(lang(?ol) = 'en' OR lang(?ol) = '' OR lang(?ol) = 'eng')\n" +
//                "    FILTER(lang(?pl) = 'en' OR lang(?pl) = '' OR lang(?pl) = 'eng')\n" +
                "}";
        String endpoint = findEndpoint(uri);
        if (endpoint == null) {
            throw new RuntimeException("unable to find endpoint: " + uri);
        }
        Model model = ModelFactory.createDefaultModel();
        QueryExecutionFactoryHttp qef = new QueryExecutionFactoryHttp(endpoint);
        QueryExecution qe = qef.createQueryExecution(String.format(sparql, uri));
        ResultSet rs = qe.execSelect();
        Resource resource = model.createResource(uri);
        while (rs.hasNext()) {
            QuerySolution qs = rs.next();
            Property property = model.createProperty(qs.getResource("p").getURI());
            if (qs.get("o") != null) {
                Resource obj = qs.get("o").asResource();
                if (obj.getURI().contains("\"")) {
                    obj = model.createResource(obj.getURI().replace("\"", "%22"));
                } else {
                    model.add(qs.getResource("s"), property, obj);
                }
                if (qs.get("ol") != null) {
                    model.add(obj, RDFS.label, qs.get("ol"));
                }
            } else {
                model.add(qs.getResource("s"), property, qs.get("ol"));
            }

        }
        return model;
    }

    public Model processModel(String uri, Model model) {
        Model processedModel = ModelFactory.createDefaultModel();
        Resource entity = processedModel.createResource(uri);
        processedModel.add(processedModel.createResource("http://ws.nju.edu.cn/ctable/dataset"), RDFS.member, entity);

        Set<Property> properties = new HashSet<>();

        for (StmtIterator iterator = model.listStatements(); iterator.hasNext(); ) {
            Statement stmt = iterator.nextStatement();
            if (!stmt.getSubject().getURI().equals(uri)) continue;
            if (stmt.getPredicate().getURI().equals("http://yago-knowledge.org/resource/hasGender")) {
                properties.add(FOAF.gender);
                processedModel.add(stmt.getSubject(), stmt.getPredicate(), stmt.getObject().asResource().getLocalName().toLowerCase());
                continue;
            }
            if (stmt.getPredicate().getURI().contains("http://dbpedia.org/property")) continue;
            if (stmt.getPredicate().getURI().contains("http://rdf.freebase.com/key/wikipedia.") &&
                    !stmt.getPredicate().getURI().contains("http://rdf.freebase.com/key/wikipedia.en")) continue;

            if (stmt.getSubject().getURI().contains("http://yago-knowledge.org") && stmt.getPredicate().equals(RDFS.label)) {
                String localName = stmt.getSubject().getURI();
                localName = localName.substring(localName.lastIndexOf("/") + 1).replaceAll("_", " ");
                if (!(stmt.getObject().isLiteral() && stmt.getObject().asLiteral().getString().equals(localName))) {
                    continue;
                }
            }

            properties.add(stmt.getPredicate());

            // Object is literal
            if (stmt.getObject().isLiteral()) {
                Literal literal = stmt.getObject().asLiteral();
                if (literal.getLanguage() != null && literal.getLanguage().length() > 0
                        && !(literal.getLanguage().equals("en") || literal.getLanguage().equals("eng"))) {
                    logger.warn("non english literal: {}", literal.getString());
                    continue;
                }
                if (stmt.getSubject().getURI().contains("freebase")) {
                    String text = stmt.getLiteral().getString();
                    if (text.contains("$")) {
                        Pattern pattern = Pattern.compile("\\$([0-9a-fA-F]{4})");
                        Matcher matcher = pattern.matcher(text);
                        StringBuffer sb = new StringBuffer();
                        while(matcher.find()) {
                            try {
                                matcher.appendReplacement(sb, "" + (char)(Integer.parseInt(matcher.group(1), 16)));
                            } catch (Exception e) {
                                System.out.println(text);
                            }
                        }
                        matcher.appendTail(sb);
                        processedModel.add(stmt.getSubject(), stmt.getPredicate(), sb.toString());
                        continue;
                    }
                }
                processedModel.add(stmt);
                continue;
            }

            // Object is resource, so we have to retrieve label for them
            if (stmt.getObject().isURIResource()) {
                Resource resource = stmt.getObject().asResource();
                Statement labelStmt = resource.getProperty(RDFS.label);
                if (resource.getURI().startsWith("http://yago-knowledge.org")) labelStmt = null;
                String label;
                if (labelStmt == null) {
                    if (resource.getURI().contains("dbpedia.org") && !resource.getURI().contains("http://dbpedia.org")) continue;

                    if (resource.getURI().startsWith("http://rdf.freebase.com/ns/")) {
                        if (stmt.getPredicate().getURI().equals("http://rdf.freebase.com/ns/government.polled_entity.poll_scores")) {
                            resource = resource;
                        }
                        List<RDFNode> targets = freebaseIntermediateNode.getTarget(stmt.getSubject().getURI(), stmt.getPredicate(), stmt.getObject().asResource(), this);
                        if (targets.size() > 0) {
                            if (targets.get(0).isLiteral()) {
                                for (RDFNode target : targets) {
                                    processedModel.add(stmt.getSubject(), stmt.getPredicate(), target.asLiteral());
                                }
                                continue;
                            } else {
                                for (RDFNode target : targets) {
                                    label = getLabel(target.asResource().getURI());
                                    if (label != null) {
                                        processedModel.add(resource, RDFS.label, label);
                                    }
                                }
                                processedModel.add(stmt);
                                continue;
                            }
                        } else {
                            Model m = fetchEntityBySelect(resource.getURI());
                            if (!m.listStatements().hasNext()) continue; // empty node
                        }

                        logger.warn("Unable to handle empty node for {}", stmt);
                        processedModel.add(stmt);
                        continue;
                    }

                    label = getLabel(resource.getURI());
//                    if (label != null) {
//                        logger.warn("label is not loaded: {}", resource.getURI());
//                    }
                } else {
                    label = labelStmt.getObject().asLiteral().getString();
                }
                // found label for object
                if (label != null) {
                    processedModel.add(resource, RDFS.label, label);
                    processedModel.add(stmt);
                    continue;
                }

                // the resource isn't supposed to be a URL in web
                if (uri.startsWith(resource.getNameSpace())) {
                    logger.warn("Unable to retrieve label for {}", resource.getURI());
                    processedModel.add(stmt);
                    continue;
                }

                processedModel.add(stmt);
                logger.debug("Unable to retrieve label for {}", resource.getURI());
                continue;
            }
        }

        for (Property property : properties) {
            String label = getLabel(property.getURI());
            if (label != null) {
                processedModel.add(property, RDFS.label, label);
            } else {
                logger.warn("Unable to retrieve label for {}", property.getURI());
            }

            for (RDFNode node : getResources(property.getURI(), RDFS.domain.getURI())) {
                processedModel.add(property, RDFS.domain, node);
            }

            for (RDFNode node : getResources(property.getURI(), RDFS.range.getURI())) {
                processedModel.add(property, RDFS.range, node);
            }

            String comment = getLiteral(property.getURI(), RDFS.comment.getURI());
            if (comment == null) {
                comment = getLiteral(property.getURI(), "http://schema.org/description");
            }
            if (comment != null) processedModel.add(property, RDFS.comment, comment);


            for (Resource resource : getResources(property.getURI(), RDF.type.getURI())) {
                processedModel.add(property, RDF.type, resource);
            }
        }

        return processedModel;
    }

    public void showEntity(String uri, Model model) {
        showEntity(uri, model, System.out);
    }

    public void showEntity(String uri, Model model, PrintStream out) {
        for (StmtIterator iterator = model.listStatements(); iterator.hasNext(); ) {
            Statement stmt = iterator.nextStatement();
            if (!stmt.getSubject().getURI().equals(uri)) continue;
            if (stmt.getObject().isLiteral()) {
                if (stmt.getObject().asLiteral().getLanguage() != null
                        && stmt.getObject().asLiteral().getLanguage().length() > 0
                        && !stmt.getObject().asLiteral().getLanguage().equals(getDefaultLanguage(uri))) {
                    continue;
                }
            }

            if (stmt.getObject().isLiteral()) {
                out.printf("%s(%s), %s, %s\n",
//                        getLabelSafe(stmt.getPredicate().getURI()),
                        stmt.getPredicate().getPropertyResourceValue(RDFS.label),
                        stmt.getPredicate().getURI(),
                        stmt.getObject().asLiteral().getString(),
                        stmt.getObject().asLiteral().getDatatypeURI());
            } else if (stmt.getObject().isURIResource()) {
                out.printf("%s(%s), %s(%s),resource\n",
//                        getLabelSafe(stmt.getPredicate().getURI()),
                        stmt.getPredicate().getPropertyResourceValue(RDFS.label),
                        stmt.getPredicate().getURI(),
//                        getLabel(stmt.getObject().asResource().getURI()),
                        stmt.getObject().asResource().getPropertyResourceValue(RDFS.label),
                        stmt.getObject().asResource().getURI());
            }
        }
    }

    public static void main(String[] args) throws InterruptedException {

        EndpointService ld = new EndpointService();
//        System.out.println(ld.getLabel("http://dbpedia.org/resource/London,_England"));
//        assert false;
        System.out.println(ld.getLabel("http://yago-knowledge.org/resource/Saint_Petersburg"));
//        ld.fetchEntityBySelect("http://yago-knowledge.org/resource/Madame_Curie_(film)");
//        System.out.println(ld.getLabel("http://rdf.freebase.com/ns/m.05zppz"));
//        assert false;
//        System.out.println(ld.getLabel("http://dbpedia.org/resource/Capitalization_of_\"Internet\""));
//        System.out.println(ld.getLabel("http://www.w3.org/1999/02/22-rdf-syntax-ns#langString"));
//        ld.getLabel("http://www.wikidata.org/entity/P646-freebase");
//        System.out.println(ld.getResources("http://dbpedia.org/ontology/campus", RDF.type.getURI()));
//        String uri = "http://rdf.freebase.com/ns/m.01wf_p_";
//        uri = "http://www.wikidata.org/entity/Q36804";
//        uri = "http://www.wikidata.org/entity/P570";
//        uri = "http://rdf.freebase.com/ns/m.01205kx7";
//        uri = "http://rdf.freebase.com/ns/film.personal_film_appearance";
//        ld.showEntity(uri);
//        String entities[] = {"http://rdf.freebase.com/ns/m.02mjmr"};
//        for (String entity : entities) {
//            Model model = ld.processModel(entity, ld.fetchEntity(entity));
//            try {
//                RDFDataMgr.write(new FileOutputStream("obama.nt"), model, RDFFormat.NTRIPLES);
//            } catch (FileNotFoundException e) {
//                e.printStackTrace();
//            }
//            ld.showEntity(entity, model);
//            System.out.println();
//        }
    }
}
