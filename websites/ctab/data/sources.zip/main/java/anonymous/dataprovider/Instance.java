package anonymous.dataprovider;

import org.apache.jena.rdf.model.Resource;
import org.apache.jena.rdf.model.Statement;
import org.apache.jena.vocabulary.RDFS;

import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;

/**
 * Created by skim on 17-3-23.
 */
public class Instance {
    private Resource entity;
    private String source;
    private int label;
    private String name;

    public Instance(String source, Resource entity, int label, String name) {
        this.entity = entity;
        this.source = getSource(source);
        this.label = label;
        this.name = name;
    }

    public boolean sameAs(Instance inst) {
        return inst.label == this.label;
    }

    public String getName() {
//        Statement stmt = entity.getProperty(RDFS.label);
//        return String.format("%s-%s-%s", label, source, stmt != null ? stmt.getObject().asLiteral().getString() : entity.getLocalName());
        return name;
    }

    public Resource getEntity() {
        return entity;
    }

    public String getNs() {
        return this.entity.getURI().substring(0, this.entity.getURI().indexOf("/", "http://".length() + 1));
    }

    public String getSource() {
        return source;
    }

    public int getLabel() {
        return label;
    }

    private String getSource(String source) {
        if (source.contains("dbpedia.org")) return "dbp";
        if (source.contains("freebase.com")) return "fb";
        if (source.contains("opencyc")) return "cyc";
        if (source.contains("nytimes")) return "nyt";
        if (source.contains("yago-knowledge")) return "yg";
        if (source.contains("wikidata.org")) return "wd";
        if (source.contains("geonames")) return "gn";
        return source;
    }
}
