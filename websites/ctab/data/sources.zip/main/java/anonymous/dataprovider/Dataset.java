package anonymous.dataprovider;

import anonymous.similarity.SimilarityMetricFactory;
import org.apache.jena.rdf.model.*;
import util.StringUtil;

import java.io.*;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

/**
 * Created by skim on 17-3-23.
 */
public class Dataset {
    private Model model = null;
    private List<Instance> entities = null;
    private Set<Property> properties = null;
    private int fileCount = 0;

    public List<Instance> getEntities() {
        return entities;
    }

    public int getEntityIndex(Resource entity) {
        for (int i = 0; i < entities.size(); i++) {
            Instance instance = entities.get(i);
            if (instance.getEntity().equals(entity)) {
                return i;
            }
        }

        return -1;
    }

    public Dataset() {
        model = ModelFactory.createDefaultModel();
        entities = new ArrayList<>();
        properties = new HashSet<Property>();
    }

    public Set<Property> getProperties()
    {
        return properties;
    }

    public StmtIterator listObjectsOfProperty(Property property) {
        Selector selector = new SimpleSelector(null, property, (RDFNode)null);
        return model.listStatements(selector);
    }

    public void loadDirectory(File directory) {
        if (directory != null && directory.isDirectory()) {
            File[] files = directory.listFiles();
            if (files != null) {
                for (File f : files) {
                    String[] parts = f.getName().split("-", 3);
                    if (parts.length < 3) {
                        parts = new String[] {"0", "dbpedia", f.getName()};
                    }
                    parseSimpleFile(f, parts[1], Integer.parseInt(parts[0]), f.getName().replaceAll(".nt", ""));
                    fileCount++;
                }
            }
        }
    }

    public static BufferedReader preProcessNTriple(File file) throws IOException {
        Model model = ModelFactory.createDefaultModel();
        model.read(file.getAbsolutePath(), "TURTLE");

        BufferedWriter bufW = new BufferedWriter(new OutputStreamWriter(
                new FileOutputStream("./tmp.bin")));
        for (StmtIterator iter = model.listStatements(); iter.hasNext(); ) {
            Statement stmt = iter.next();
            String sub = stmt.getSubject().getURI();
            String prop = stmt.getPredicate().getURI();
            String o = "";
            RDFNode obj = stmt.getObject();
            if (obj.isLiteral()) {
                if (obj.asLiteral().getLanguage() == null || obj.asLiteral().getLanguage().compareTo("en") == 0) {
                    o = "l" + obj.asLiteral().toString();
                } else {
                    continue;
                }
            } else {
                o = "u" + obj.asResource().getURI();
            }
            bufW.write(sub+";"+prop+";"+o+"\n");
        }

        bufW.close();

        return new BufferedReader(new InputStreamReader(new FileInputStream("./tmp.bin"), "utf-8"));
    }

    private void parseSimpleFile(File file, String source, int label, String name) {
        BufferedReader reader = null;
        try {
            if (file.getName().endsWith(".ttl") | file.getName().endsWith(".nt")) {
                reader = preProcessNTriple(file);
            } else {
                reader = new BufferedReader(new InputStreamReader(new FileInputStream(file.getAbsolutePath()), "utf-8"));
            }
            String line = reader.readLine();
            if (line != null) {
                Resource entity = model.createResource(line.split(";", 2)[0]);
                entities.add(new Instance(source, entity, label, name));
                for (; line != null; line = reader.readLine()) {
                    String[] parts = line.split(";", 3);
                    Property p = model.createProperty(parts[1]);
                    properties.add(p);

                    String obj = parts[2];
                    if(obj.startsWith("u")) {
                        if (p.getURI().contains("http://www.w3.org/1999/02/22-rdf-syntax-ns#type")) {
                            p = p;
                        }
                        if(obj.endsWith(".html") || obj.endsWith(".rdf")) {
                            obj = obj.substring(1);
                            entity.addProperty(p, model.createResource(obj));
                        } else {
                            obj = StringUtil.propProcess(obj.substring(1));
                            entity.addProperty(p, model.createLiteral(obj));
                        }
                    } else {
                        obj = obj.substring(1);
                        entity.addProperty(p, model.createLiteral(obj));
                    }
                }
            }
            reader.close();
        } catch (Exception ignored) {
            ignored.printStackTrace();
            file.delete();
        } finally {
            if (reader != null) {
                try {
                    reader.close();
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }
        }
    }

    public int getInstanceCount() {
        return fileCount;
    }
}
