package anonymous.dataprovider;

import org.apache.jena.vocabulary.RDFS;
import org.apache.jena.rdf.model.*;

import java.io.InputStream;
import java.net.URL;
import java.util.HashMap;
import java.util.Map;
import java.util.Scanner;

/**
 * Created by skim on 17-7-7.
 */
public class LocalName {
    public LocalName() {
        mappings = new HashMap<>();
        loadMappings();
        loadAllOntology();
        // extra mappings
        mappings.put("http://rdvocab.info/RDARelationshipsWEMI/manifestationOfWork", "manifestation of work");
        mappings.put("http://www.geonames.org/ontology#alternateName", "alternate name");
        mappings.put("http://dbpedia.org/ontology/soundRecording", "sound recording");
        mappings.put("http://umbel.org/umbel#isLike", "is like");
        mappings.put("http://rdf.freebase.com/ns/kg.object_profile.prominent_type", "prominent type");
        mappings.put("http://rdf.freebase.com/ns/topic_server.webref_cluster_members_type", "webrdf cluster members type");
    }

    public String getName(String uri) {
        if (mappings.containsKey(uri)) {
            return mappings.get(uri);
        }

        if (uri.startsWith("http://wikiba.se/ontology-beta")) {
            String uriShorten = uri.replace("ontology-beta", "ontology");

            if (mappings.containsKey(uriShorten)) {
                mappings.put(uri, mappings.get(uriShorten));
                return mappings.get(uriShorten);
            }

            uriShorten = uri.substring(uri.indexOf("#") + 1);
            uriShorten = uriShorten.substring(0, 1).toUpperCase() + uriShorten.substring(1);
            uriShorten = "http://wikiba.se/ontology#" + uriShorten;

            if (mappings.containsKey(uriShorten)) {
                mappings.put(uri, mappings.get(uriShorten));
                return mappings.get(uriShorten);
            }
        }

        if (uri.startsWith("http://creativecommons.org/ns")) {
            String uriShorten = uri.substring(uri.indexOf("#") + 1);
            uriShorten = uriShorten.substring(0, 1).toUpperCase() + uriShorten.substring(1);
            uriShorten = "http://creativecommons.org/ns#" + uriShorten;

            if (mappings.containsKey(uriShorten)) {
                mappings.put(uri, mappings.get(uriShorten));
                return mappings.get(uriShorten);
            }

            uriShorten = camel2SpaceSplit(uri.substring(uri.indexOf("#") + 1));
            mappings.put(uri, uriShorten);
            return mappings.get(uriShorten);
        }

        if (uri.startsWith("http://dbpedia.org/property/")) {
            String localName = camel2SpaceSplit(uri.substring(uri.lastIndexOf("/") + 1));
            mappings.put(uri, localName);
            return localName;
        }

        if (uri.startsWith("http://www.w3.org")) {
            if (uri.contains("#")) {
                String localName = uri.substring(uri.indexOf('#')+1);
                mappings.put(uri, localName);
                return localName;
            }
        }

        if (uri.startsWith("http://purl.org/dc/") || uri.startsWith("http://xmlns.com/foaf/0.1/")
                || uri.startsWith("http://schema.org/")) {
            String localName = camel2SpaceSplit(uri.substring(uri.lastIndexOf("/") + 1));
            mappings.put(uri, localName);
            return localName;
        }

        if (uri.startsWith("http://rdf.freebase.com/ns")) {
            System.out.printf("label not found: %s\n", uri);
            mappings.put(uri, uri.substring(uri.lastIndexOf(".") + 1).replace("_", " "));
            return mappings.get(uri);
        }

        if (uri.startsWith("http://yago-knowledge.org/resource/")) {
            if (!uri.contains("infobox")) {
                String localName = camel2SpaceSplit(uri.substring(uri.lastIndexOf("/") + 1));
                mappings.put(uri, localName);
                return localName;
            } else {
                String localName = camel2SpaceSplit(uri.substring(uri.lastIndexOf("/") + 1));
                mappings.put(uri, localName);
                return localName;
            }
        }

        if (uri.startsWith("http://www.wikidata.org")) {
            String localName = uri.substring(uri.lastIndexOf("/") + 1);
            char c = localName.charAt(localName.length() - 1);
            if (c < '0' || c > '9') {
                localName = localName.substring(0, localName.length() - 1);
            }
            String label = mappings.get("http://www.wikidata.org/entity/" + localName);
            if (label != null) {
                mappings.put(uri, label);
                return mappings.get(uri);
            }
        }

        return uri;
    }

    private String camel2SpaceSplit(String str) {
        StringBuilder builder = new StringBuilder();
        for (char s : str.toCharArray()) {
            if (Character.isUpperCase(s)) {
                if (builder.length() > 0) {
                    builder.append(" ");
                }
                builder.append(Character.toLowerCase(s));
            } else {
                builder.append(s);
            }
        }

        return builder.toString();
    }

    private void loadMappings() {
        ClassLoader loader = getClass().getClassLoader();
        loadMapping(loader.getResourceAsStream("table/map/freebase_prop.txt"));
        loadMapping(loader.getResourceAsStream("table/map/freebasemap.txt"));
        loadMapping(loader.getResourceAsStream("table/map/opencycmap.txt"));
        loadMapping(loader.getResourceAsStream("table/map/mdbmap.txt"));
    }

    private void loadMapping(InputStream input) {
        Scanner scanner = null;
        try {
            scanner = new Scanner(input);
            while(scanner.hasNext()) {
                String[] kv = scanner.nextLine().split(";", 2);
                mappings.put(kv[0], kv[1].toLowerCase());
            }

        } finally {
            if(scanner != null) {
                scanner.close();
            }
        }
    }

    private void loadAllOntology() {
        ClassLoader loader = getClass().getClassLoader();
        loadOntology(loader.getResource("ontology/dbpedia.owl"));
        loadOntology(loader.getResource("ontology/22-rdf-syntax-ns.ttl"));
        loadOntology(loader.getResource("ontology/owl.ttl"));
        loadOntology(loader.getResource("ontology/ontology-1.0.owl.rdf"));
        loadOntology(loader.getResource("ontology/creativecommons.rdf"));
        loadOntology(loader.getResource("ontology/geonames.rdf"));
    }

    private void loadOntology(URL filename) {
        Model model = ModelFactory.createDefaultModel();
        model.read(filename.toString());


        Selector selector = new SimpleSelector(null, RDFS.label, (RDFNode)null);
        for (StmtIterator iterator = model.listStatements(selector); iterator.hasNext(); ) {
            Statement stmt = iterator.next();
            if (stmt.getObject().isLiteral() && (stmt.getObject().asLiteral().getLanguage() == null || stmt.getObject().asLiteral().getLanguage().equals("") || stmt.getObject().asLiteral().getLanguage().startsWith("en"))) {
                mappings.put(stmt.getSubject().getURI(), stmt.getObject().asLiteral().getString().toLowerCase());
            }
        }
    }

    private Map<String, String> mappings;


}
