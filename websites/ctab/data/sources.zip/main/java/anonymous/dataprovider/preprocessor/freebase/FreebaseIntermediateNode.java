package anonymous.dataprovider.preprocessor.freebase;

import anonymous.dataprovider.service.EndpointService;
import anonymous.dataprovider.InstanceGroup;
import anonymous.dataprovider.PropertyNode;
import anonymous.dataprovider.cache.PropertyLabelCache;
import anonymous.dataprovider.service.EndpointService;
import org.apache.jena.rdf.model.*;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.*;
import java.util.*;

public class FreebaseIntermediateNode {
    private static Map<String, String> routes;
    private Logger logger = LoggerFactory.getLogger(FreebaseIntermediateNode.class);

    public FreebaseIntermediateNode() {
        if (routes == null) {
            routes = new HashMap<>();
            loadRoutes();
        }
    }

    private void loadRoutes() {
        try {
            Scanner scanner = new Scanner(new File("./data/preprocess/intermediate_node/route.csv"));
            while (scanner.hasNextLine()) {
                String line = scanner.nextLine();
                String parts[] = line.split(",");
                if (parts.length != 2) {
                    logger.warn("invalid line in route: {}", line);
                    continue;
                }
                routes.put(parts[0], parts[1]);
            }
        } catch (FileNotFoundException e) {
            e.printStackTrace();
        }
    }

    public List<RDFNode> getTarget(String subject, Property property, Resource object, EndpointService endpointService) {
        String nextProperty = routes.get(property.getURI());
        ArrayList<RDFNode> nodes = new ArrayList<>();
        if (nextProperty == null) return nodes;
        if (nextProperty.equals("localname")) {
            if (object.getLocalName().contains(".")) {
                logger.warn("suspecting intermediate node route: {}, {}", property.getURI(), object.getURI());
            }
            nodes.add(property.getModel().createLiteral(object.getLocalName()));
            return nodes;
        }

        String hint = null;
        if (!nextProperty.startsWith("http://")) {
            hint = nextProperty.substring(0, 1);
            nextProperty = nextProperty.substring(1);
        }

        if (hint == null) {
            for (RDFNode node : endpointService.getObject(object.getURI(), nextProperty)) {
                if (node.isLiteral() && node.asLiteral().getLanguage() != null && node.asLiteral().getLanguage().length() > 0 &&!node.asLiteral().getLanguage().equals("en")) continue;
                nodes.add(node);
            }
            return nodes;
        } else if (hint.equals("!")) {
            for (Resource resource : endpointService.getResources(object.getURI(), nextProperty)) {
                if (resource.getURI().equals(subject)) continue;
                nodes.add(resource);
            }
            return nodes;
        } else if (hint.equals("$")) {
            try {
                nodes.add(property.getModel().createLiteral(endpointService.getLiteral(object.getURI(), nextProperty)));
            } catch (Exception e) {
                System.out.println(endpointService.getLiteral(object.getURI(), nextProperty));
                e.printStackTrace();
            }
            return nodes;
        }
        logger.warn("unsupported hint: {}", hint);
        return nodes;
    }

    static public void main(String[] args) throws FileNotFoundException {
        EndpointService endpointService = new EndpointService();
        PropertyLabelCache propertyLabelCache = new PropertyLabelCache(endpointService);
        FreebaseIntermediateNode intermediateNode = new FreebaseIntermediateNode();
        File old = new File("./dataset");

        PrintStream out = new PrintStream(new FileOutputStream("./data/preprocess/intermediate_node/properties.txt"));
//        PrintStream out = System.out;

        Set<String> found = new HashSet<>();
        File files[] = old.listFiles();
        Arrays.sort(files);
        for (File inst : files) {
//        File inst = new File("./dataset/00-Barack_Obama");
            InstanceGroup group = new InstanceGroup(propertyLabelCache);
            group.loadPlainDirectory(inst);

            for (PropertyNode pn : group.getProperties()) {
                if (found.contains(pn.getProperty().getURI())) continue;
                found.add(pn.getProperty().getURI());
                if (!pn.getProperty().getURI().contains("http://rdf.freebase.com")) continue;

                if (pn.getProperty().getURI().equals("http://rdf.freebase.com/ns/base.billionaires.billionaire.net_worth")) {
                    pn = pn;
                }
                for (Resource ent : pn.getEntities()) {
                    List<RDFNode> nodes = pn.getValue(ent);
                    if (nodes.size() > 0) {
                        RDFNode node = nodes.get(0);
                        if (node.isURIResource() && node.asResource().getURI() != null && node.asResource().getURI().contains("rdf.freebase.com")) {
                            String nodeURI = node.asResource().getURI();
                            String label = endpointService.getLabel(nodeURI);
                            if (label == null || node.asResource().getURI().contains(label)) {
                                if (pn.getProperty().getURI().equals("http://rdf.freebase.com/ns/base.billionaires.billionaire.net_worth")) {
                                    pn = pn;
                                }
                                List<RDFNode> targets = intermediateNode.getTarget(nodeURI, pn.getProperty(), node.asResource(), endpointService);
                                if (targets.size() > 0 && targets.get(0) != node.asResource()) continue;
                                out.printf("%s(%s), %s, %s\n",
                                        endpointService.getLabel(ent.getURI()), ent.getURI(),
                                        pn.getProperty().getURI(), nodeURI);
                                Model m = endpointService.fetchEntityBySelect(nodeURI);

                                int count = 0;
                                String route = "";

                                for (StmtIterator iterator = m.listStatements(); iterator.hasNext(); ) {
                                    Statement stmt = iterator.nextStatement();
                                    if (!stmt.getSubject().getURI().equals(nodeURI)) continue;
                                    if (stmt.getObject().isResource() && nodeURI.equals(stmt.getObject().asResource().getURI())) continue;
                                    if (stmt.getPredicate().getURI().contains("type.object.type") || stmt.getPredicate().getURI().contains("#type")) continue;
                                    if (stmt.getObject().isLiteral()) {
                                        out.printf("%s, ", stmt.getPredicate().getURI());
                                        out.println(stmt.getObject().asLiteral().getString());
                                    } else {
                                        if (stmt.getObject().asResource().getURI().equals(nodeURI)) continue;
                                        out.printf("%s, ", stmt.getPredicate().getURI());
                                        out.printf("%s (%s)\n", endpointService.getLabel(stmt.getObject().asResource().getURI()), stmt.getObject().asResource().getURI());
                                        route = stmt.getPredicate().getURI();
                                    }
                                    count += 1;
                                }
//                                endpointService.showEntity(nodeURI, endpointService.processModel(nodeURI, m), out);
                                if (count == 0) {
                                    if (!pn.getProperty().getLocalName().contains(".")) {
                                        out.printf("====%s,localname\n\n\n", pn.getProperty().getURI());
                                    } else {
                                        found.remove(pn.getProperty().getURI());
                                    }
                                } else if (count == 1) {
                                    out.printf("====%s,%s\n\n\n", pn.getProperty().getURI(), route);
                                } else {
                                    out.printf("====%s,\n\n\n", pn.getProperty().getURI());
                                }

                            }
                        }
                        break;
                    }
                }
            }

//            break;
        }
    }
}
