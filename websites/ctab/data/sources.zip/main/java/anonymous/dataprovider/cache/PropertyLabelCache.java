package anonymous.dataprovider.cache;

import anonymous.dataprovider.service.EndpointService;
import anonymous.dataprovider.Dataset;
import anonymous.dataprovider.service.EndpointService;
import org.apache.jena.rdf.model.Property;
import org.apache.jena.rdf.model.Resource;

import java.io.File;

/**
 * Created by skim on 17-7-16.
 */
public class PropertyLabelCache extends AbstractLabelCache {

    public EndpointService getEndpointService() {
        return local;
    }

    public PropertyLabelCache() {
        super();
    }

    public PropertyLabelCache(EndpointService local) {
        super(local);
        load();
    }

    @Override
    public String getCacheName() {
        return "label.property.bin";
    }

    public String getLabel(String property) {
        return getLabel(model.createProperty(property));
    }

    @Override
    public String getLabel(Resource property) {
        if (property.getURI().equals("http://creativecommons.org/ns#attributionURL")) return "attribution URL";
        if (property.getURI().equals("http://www.w3.org/ns/prov#wasDerivedFrom")) return "was derived from";
        if (property.getURI().equals("http://purl.org/dc/terms/subject")) return "subject";
        if (property.getURI().equals("http://purl.org/dc/terms/date")) return "date";
        if (property.getURI().equals("http://purl.org/dc/terms/term")) return "term";
        if (property.getURI().equals("http://purl.org/dc/terms/title")) return "title";
        if (property.getURI().equals("http://www.georss.org/georss/point")) return "point";

        if (property.getURI().equals("http://sw.cyc.com/CycAnnotations_v1#label")) return "label";
        if (property.getURI().equals("http://sw.opencyc.org/concept/Mx4rBVVEokNxEdaAAACgydogAg")) return "Quoted Isa";
        if (property.getURI().equals("http://sw.opencyc.org/concept/Mx4rTv-jk9SPTXa991kk5mAvHg")) return "Wikipedia Article Name Canonical";
        if (property.getURI().equals("http://sw.opencyc.org/concept/Mx4rNv0nbm4TTjOp7yhmnzOyqg")) return "Wikipedia Article URL";
        if (property.getURI().equals("http://sw.opencyc.org/concept/Mx4rwLSVCpwpEbGdrcN5Y29ycA")) return "Pretty String";
        if (property.getURI().equals("http://sw.opencyc.org/concept/Mx4rZOAVeiYGEdqAAAACs2IMmw")) return "BT";
        if (property.getURI().equals("http://sw.opencyc.org/concept/Mx4riWVFR6HJSpaEaHrcWS3MSA")) return "See Also URI";

        if (property.getURI().equals("http://purl.org/dc/elements/1.1/description")) return "description";
        if (property.getURI().equals("http://www.wikidata.org/entity/P646-freebase")) return "Freebase ID";
        if (property.getURI().equals("http://www.wikidata.org/entity/P646-freebas")) return "Freebase ID";
        if (property.getURI().equals("http://rdvocab.info/RDARelationshipsWEMI/manifestationOfWork")) return "manifestation of work";
        if (property.getURI().equals("http://www.geonames.org/ontology#alternateName")) return "alternate name";
        if (property.getURI().equals("http://dbpedia.org/ontology/soundRecording")) return "sound recording";
        if (property.getURI().equals("http://umbel.org/umbel#isLike")) return "is like";
        if (property.getURI().equals("http://rdf.freebase.com/ns/kg.object_profile.prominent_type")) return "prominent type";
        if (property.getURI().equals("http://rdf.freebase.com/ns/topic_server.webref_cluster_members_type")) return "webrdf cluster members type";

        if (property.getURI().startsWith("http://yago-knowledge.org")) {
            return property.getLocalName();
        }

        String label = null;
        if (property.getNameSpace().equals("http://www.wikidata.org/entity/")) {
            label = super.getLabel(model.createProperty(property.getURI().substring(0, property.getURI().length() - 1)));
        } else {
            label = super.getLabel(property);
        }

        if (label == null) {
            if (property.getURI().startsWith("http://rdf.freebase.com/")) {
                label = property.getLocalName().replace(".", " ");
            } else if (property.getURI().startsWith("http://data.nytimes.com") ||
                    property.getURI().startsWith("http://data.linkedmdb.org") ||
                    property.getURI().startsWith("http://dbpedia.org/property/") ||
                    property.getURI().startsWith("http://www.w3.org")) {
                label = property.getLocalName().replace("_", " ");
            }
        }
        return label;
    }

    public static void main(String[] args) throws InterruptedException {
        EndpointService endpointService = new EndpointService();
        PropertyLabelCache cache = new PropertyLabelCache(endpointService);
        Dataset dataset = new Dataset();
        File base = new File("./dataset");
        for (File f : base.listFiles()) {
            dataset.loadDirectory(f);
        }
        base = new File("../disambiguation/instances");
        for (File cate : base.listFiles()) {
            for (File group : cate.listFiles()) {
                dataset.loadDirectory(group);
            }
        }

        for (Property property : dataset.getProperties()) {
            try {
                String label = cache.getLabel(property);
                if (label == null) {
                    System.out.println(property);
                }
            } catch (Exception e) {
                System.out.println(property);
            }
        }

        cache.save();
    }
}
