package anonymous.dataprovider.cache;

import anonymous.dataprovider.service.EndpointService;
import anonymous.dataprovider.service.EndpointService;
import org.apache.jena.rdf.model.Model;
import org.apache.jena.rdf.model.ModelFactory;
import org.apache.jena.rdf.model.Resource;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.IOException;
import java.util.HashMap;
import java.util.Map;

/**
 * Created by skim on 17-7-16.
 */
public abstract class AbstractLabelCache extends AbstractCache {
    final Logger logger = LoggerFactory.getLogger(AbstractLabelCache.class);
    protected Map<String, Map<String, String>> cache;
    protected EndpointService local;
    protected Model model;

    public AbstractLabelCache() {
        this.local = null;
        this.model = ModelFactory.createDefaultModel();
        load();
    }

    public AbstractLabelCache(EndpointService local) {
        this.local = local;
        this.model = ModelFactory.createDefaultModel();
//        load();
    }

    public String getLabel(Resource property) {
        String ns = property.getNameSpace();
        String localName = property.getLocalName();

        if (cache == null) {
            cache = new HashMap<>();
        }

        if (!cache.containsKey(ns)) {
            cache.put(ns, new HashMap<>());
        }

        if (!cache.get(ns).containsKey(localName)) {
            if (local == null) {
                logger.warn("No data source for property {}", property);
                return null;
            }
            String label = local.getLabel(property.getURI());
            if (label == null) return null;
            cache.get(ns).put(localName, label);
        }

        return cache.get(ns).get(localName);
    }

    @Override
    public void save() {
        try {
            saveCache(cache);
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    @Override
    @SuppressWarnings("unchecked")
    public void load() {
        try {
            cache = (Map<String, Map<String, String>>)loadCache();
        } catch (IOException | ClassCastException | ClassNotFoundException e) {
            cache = new HashMap<>();
            e.printStackTrace();
        }
    }
}
