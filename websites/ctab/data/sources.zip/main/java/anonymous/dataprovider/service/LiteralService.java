package anonymous.dataprovider.service;

import org.apache.jena.rdf.model.*;

/**
 * Created by skim on 17-8-6.
 */
public class LiteralService {
    static public String getEnglishLiteral(Model model, Resource resource, Property property) {
        NodeIterator iterator = model.listObjectsOfProperty(resource, property);
        if (iterator.hasNext()) {
            RDFNode node = iterator.next();
            if (node.isLiteral() && (node.asLiteral().getLanguage() == null || node.asLiteral().getLanguage().equals("") ||
                    node.asLiteral().getLanguage().equals("en") || node.asLiteral().getLanguage().equals("eng"))) {
                return node.asLiteral().getString();
            }
            String comment = node.toString();
            while (iterator.hasNext()) {
                node = iterator.next();
                if (node.isLiteral() && (node.asLiteral().getLanguage() == null || node.asLiteral().getLanguage().equals("") ||
                        node.asLiteral().getLanguage().equals("en") || node.asLiteral().getLanguage().equals("eng"))) {
                    return node.asLiteral().getString();
                }
            }
            return comment;
        }

        return null;
    }

    static public String getLocalName(Resource resource) {
        if (resource.getNameSpace().equals("http://rdf.freebase.com/ns/")) {
            String localName = resource.getLocalName();
            return localName.substring(localName.lastIndexOf('.') + 1);
        }
        return resource.getLocalName();
    }
}
