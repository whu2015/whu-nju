package anonymous.dataprovider.cache;

import java.io.*;

/**
 * Created by skim on 17-7-16.
 */
abstract public class AbstractCache implements CacheInterface {
    public void saveCache(Object obj) throws IOException {
        ObjectOutputStream os = new ObjectOutputStream(new FileOutputStream(getCacheFile()));
        os.writeObject(obj);
        os.close();
    }

    public Object loadCache() throws IOException, ClassNotFoundException {
        ObjectInputStream is = new ObjectInputStream(new FileInputStream(getCacheFile()));
        Object obj = is.readObject();
        is.close();
        return obj;
    }

    private File getCacheFile() {
        return new File("cache/" + getCacheName());
    }
}
