package synonymousdict;

import java.io.IOException;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.HashMap;
import java.util.HashSet;
import java.util.regex.Pattern;

import org.jsoup.Jsoup;
import org.jsoup.nodes.Document;
import org.jsoup.nodes.Element;
import org.jsoup.select.Elements;

public class Synonymous {
	private static Synonymous instance;
	private HashMap<String, HashSet<String>> synWords;
	
	public static Synonymous getInstance() {
		if(instance == null) {
			instance = new Synonymous();
		}
		return instance;
	}

	private Synonymous() {
		synWords = new HashMap<String, HashSet<String>>();
	}
	
	public void readData(String word) {
		String urlStr = "http://www.thesaurus.com/browse/"+word;
//		String urlStr = "http://localhost:3000/http://www.thesaurus.com/browse/"+word;
		
		HashSet<String> sWords = new HashSet<String>();
		synWords.put(word, sWords);

		Document doc;
		try {
			URL url = new URL(urlStr);
			HttpURLConnection con = (HttpURLConnection) url.openConnection();
			int status = con.getResponseCode();
			if(status != 200) {
				return;
			}
		} catch(Exception e){
			return;
		}
		try {
			doc = Jsoup.connect(urlStr).get();
			
			Element synElement = doc.getElementById("synonyms-0");
			if(synElement == null) {
//				System.out.println("!!!"+word);
				return;
			}
			Element synList = synElement.getElementsByClass("relevancy-list").first();
			
			Elements wordsHTML = synList.getElementsByTag("li");
			for(int i = 0; i < wordsHTML.size(); i ++) {
				Element wordHTML = wordsHTML.get(i);

				Element textElement = wordHTML.getElementsByClass("text").first(); 
				String sWord = textElement.text();
				
				String categoryStr = wordHTML.child(0).attributes().get("data-category");
				int index = categoryStr.indexOf("relevant") + 9;
				String relevantStr = categoryStr.substring(index, index + 1);
				int relevant = Integer.parseInt(relevantStr);
				
				String complexityStr = wordHTML.child(0).attributes().get("data-complexity");
				int complexity = Integer.parseInt(complexityStr);
				
				String lengthStr = wordHTML.child(0).attributes().get("data-length");
				int length = Integer.parseInt(lengthStr);

				String isCommonStr = wordHTML.child(0).attributes().get("class");
				boolean isCommon = isCommonStr.contains("common-word");
				
				if(isCommon && relevant == 3) {
					sWords.add(sWord);
				}

//				System.out.println(word + " " + relevant + " " + complexity + " " + length + " " + isCommon);
			}
		} catch(IOException e) {
			e.printStackTrace();
		}
	}
	
	public HashSet<String> getSynWords(String word) {
		if(!synWords.containsKey(word))	{
			readData(word);
		}
		return synWords.get(word);
	}

	Pattern p = Pattern.compile("p\\d+\\w?");

	public boolean isSynWords(String wordA, String wordB) {
		if (p.matcher(wordA).matches() || p.matcher(wordB).matches()) {
			return false;
		}

		if(!synWords.containsKey(wordA)) {
			readData(wordA);
		}
		if(!synWords.containsKey(wordB)) {
			readData(wordB);
		}
		return synWords.get(wordA).contains(wordB) || synWords.get(wordB).contains(wordA);
	}
	
	public static void main(String[] args) {
		System.out.println(Synonymous.getInstance().isSynWords("name", "title"));
	}
}