package synonymousdict;

public class SynWord {
	private String word;
	private int relevant;
	private int complexity;
	private int length;
	private boolean isCommon;
	
	public SynWord(String word) {
		this.word = word;
	}
	
	public SynWord(String w, int rel, int comp, int l, boolean c) {
		word = w;
		relevant = rel;
		complexity = comp;
		length = l;
		isCommon = c;
	}
	
	public String getWord() {
		return word;
	}
	
	public int getRelevant() {
		return relevant;
	}
	
	public int getComplexity() {
		return complexity;
	}
	
	public int getLength() {
		return length;
	}
	
	public boolean getIsCommon() {
		return isCommon;
	}
}