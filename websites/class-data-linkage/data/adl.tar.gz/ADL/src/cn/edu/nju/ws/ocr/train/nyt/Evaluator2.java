package cn.edu.nju.ws.ocr.train.nyt;

import java.sql.*;
import java.text.DecimalFormat;
import java.util.Collections;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;
import java.util.concurrent.BlockingQueue;
import java.util.concurrent.LinkedBlockingQueue;
import java.util.concurrent.ThreadPoolExecutor;
import java.util.concurrent.TimeUnit;

import org.apache.log4j.Logger;
import org.apache.log4j.PropertyConfigurator;

import cn.edu.nju.ws.ocr.datab.DBConnPool;
import cn.edu.nju.ws.ocr.datab.DBParam;
import cn.edu.nju.ws.ocr.nlp.ISub;
import cn.edu.nju.ws.ocr.nlp.StringReplace;


public class Evaluator2 {
	static Logger logger = Logger.getLogger(Evaluator2.class);
	/**
	 * @param args
	 */
	
	private int nytPrefLabelID = 72;
	private int geonamesLabelID = 1811;
	private int geonamesLatID = 21;
	private int geonamesLongID = 17;
	private int dbpediaLatID = 1668856;
	private int dbpediaLongID = 1668855;
	
	static Map<Integer, Set<Integer>> instURIIDs = Collections.synchronizedMap(
			new HashMap<Integer, Set<Integer>>());
	int trainFID = 305;
	double threshold = 0.99;
	int propCount = 5;
	
	public Evaluator2(int tfid, double thd, int pcnt) {
		this.trainFID = tfid;
		this.threshold = thd;
		this.propCount = pcnt;
	}

	void evaluator2(String dbname){
		
		PropInfoGain ig = new PropInfoGain(dbname,trainFID);
		ig.GenPropPQ(threshold);

		int[] propArray = new int[propCount*2];
		for (int i=0; i<propCount&& ig.queue2.size()>0; i++){
			Point point = ig.queue2.poll();
			propArray[i*2] = point.propURIID1;
			propArray[i*2+1] = point.propURIID2;
			logger.info(propArray[i*2] + " "+propArray[i*2+1]);
		}
		
		try {
			Connection connNYT2011 = DBConnPool.getNYT2011();
			Statement stmt1 = connNYT2011.createStatement();		
			ResultSet rs1 = stmt1.executeQuery("SELECT distinct instance_uri_id1 FROM positive_nyt_"+dbname+" where fold_id<>"+trainFID+" " +
					"and fold_id<="+(trainFID+10)+" " +
					"and fold_id>="+(trainFID-10));
			Set<Integer> rawInsts = 
					Collections.synchronizedSet(new HashSet<Integer>());
			while(rs1.next()){
				
				rawInsts.add(rs1.getInt(1));
			}
			rs1.close();
			stmt1.close();
			connNYT2011.close();
			
			BlockingQueue<Runnable> queue = new LinkedBlockingQueue<Runnable>();  
			ThreadPoolExecutor exec = new ThreadPoolExecutor(4, 5, 7, TimeUnit.DAYS, queue);
			for (int instURIID1 : rawInsts) {
				Evaluator2Thread1 peppt1 = 
						new Evaluator2Thread1(instURIID1, propArray, dbname);
				exec.execute(peppt1);
			}
			exec.shutdown();
			while(true){
				if(exec.getActiveCount() == 0){
					Evaluator2Counters(dbname);
					break;
				}
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
	void Evaluator2Counters(String dbname){
		int tp = 0, fp = 0, ttp = 0;;
		Map<Integer, Set<Integer>> testInstURIIDs = Collections.synchronizedMap(
					new HashMap<Integer, Set<Integer>>());
		
		try {
			Connection connNYT2011 = DBConnPool.getNYT2011();
			Statement stmt1 = connNYT2011.createStatement();		
			ResultSet rs1 = stmt1.executeQuery("SELECT distinct instance_uri_id1,instance_uri_id2 FROM positive_nyt_"+dbname+" where fold_id<>"+trainFID+" " +
					"and fold_id<="+(trainFID+10)+" " +
					"and fold_id>="+(trainFID-10));
			while(rs1.next()){
				int instURIID = rs1.getInt(1);
				int corefURIID = rs1.getInt(2);
				if (testInstURIIDs.containsKey(instURIID)) {
					Set<Integer> corefURIIDs = testInstURIIDs.get(instURIID);
					corefURIIDs.add(corefURIID);
				} else {
					Set<Integer> corefURIIDs = Collections.synchronizedSet(new HashSet<Integer>());
					corefURIIDs.add(corefURIID);
					testInstURIIDs.put(instURIID, corefURIIDs);
				}
				ttp++;
			}
			
			
			for(int instURIID: instURIIDs.keySet()){
				
				if (testInstURIIDs.containsKey(instURIID)) {
					Set<Integer> testCorefURIIDs = testInstURIIDs.get(instURIID);
					for(int corefURIID: instURIIDs.get(instURIID)){
						if(testCorefURIIDs.contains(corefURIID))
						//if(corefURIID != -1)
							tp++;
						else{
							logger.debug(instURIID+"||"+corefURIID);
							if(corefURIID != -1)
								fp++;
						}
					}
				}
			}
			//System.out.println(dbname+" tp: "+tp+" fp: "+fp+" precision: "+(double)tp/(tp+fp)+" recall: "+(double)tp/ttp);
			System.out.println("precision: "+(double)tp/(tp+fp)+" recall: "+(double)tp/ttp);
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
	public class Evaluator2Thread1 implements Runnable
	{
		private int instURIID;
		private int[] propArray;
		private String dbname;
		
		public Evaluator2Thread1(int uid, int[] propArray, String dbname)
		{
			this.instURIID = uid;
			this.propArray = propArray;
			this.dbname = dbname;
		}
		
		public void run()
		{
			try {
				//logger.debug(instURIID);
				Connection connNYT2011 = DBConnPool.getNYT2011();
				String sqlstr1 = null, sqlstr2 = null, sqlstr3 = null;
				if(trainFID > 100 && trainFID <=110)
					sqlstr1 = "SELECT DISTINCT o FROM  nyt_locations_quadruple " 
								   + "WHERE s=? AND p=? AND o NOT LIKE 'b%';";
				else if(trainFID > 200 && trainFID <=210)
					sqlstr1 = "SELECT DISTINCT o FROM  nyt_organizations_quadruple " 
							   + "WHERE s=? AND p=? AND o NOT LIKE 'b%';";
				else if(trainFID > 300 && trainFID <=310)
					sqlstr1 = "SELECT DISTINCT o FROM  nyt_people_quadruple " 
							   + "WHERE s=? AND p=? AND o NOT LIKE 'b%';";
				
				sqlstr2 = "SELECT distinct s FROM  "+dbname+"_quadruple " 
						   	   + "WHERE p=? AND o like ?;";
				sqlstr3 = "SELECT DISTINCT uri_id FROM  "+dbname+"_uri " 
					   	   + "WHERE localname = ?;";

				PreparedStatement stmt1 = connNYT2011.prepareStatement(sqlstr1);
				PreparedStatement stmt2 = connNYT2011.prepareStatement(sqlstr2);
				PreparedStatement stmt3 = connNYT2011.prepareStatement(sqlstr3);
				
				Instance inst = new Instance(instURIID);
				for(int i=0 ; i<propCount;i++){				
					stmt1.setString(1, "u" + instURIID);
					stmt1.setString(2, "u" + propArray[2*i]);
					ResultSet rs1 = stmt1.executeQuery();
					while (rs1.next()) {
						String o = rs1.getString(1);
						if(propArray[2*i] == nytPrefLabelID && (dbname.equals("dbpedia") || dbname.equals("freebase_alternative")) && trainFID >300 && trainFID <=310){
							String obj = NameFinder.nytPeopleLabel(instURIID)[1];
							if (obj != null && !obj.trim().equals(""))
								inst.addPropValue(propArray[2*i], obj);
						}
						else if(propArray[2*i] == nytPrefLabelID){
							String obj = null;
							if(o.indexOf("(") > 0 && dbname.equals("dbpedia"))
								//obj = o.substring(1, o.indexOf("(")-1)+", "+o.substring(o.indexOf("(")+1,o.indexOf("(")+2);
								obj = o.substring(1, o.indexOf("(")-1);
							else if (o.indexOf("(") > 0 && !dbname.equals("dbpedia"))
								obj = o.substring(1, o.indexOf("(")-1);
							else
								obj = o.substring(1);
							inst.addPropValue(propArray[2*i], obj);
						}
						
						else if (o.startsWith("u")) {
							int objURIID = Integer.parseInt(o.substring(1));
							String obj = NameFinder.nytLocalname(objURIID);
							if (obj != null && !obj.trim().equals(""))
								inst.addPropValue(propArray[2*i], obj);
						} else { // o.startsWith("l")
							String obj = o.substring(1);
							if (obj != null && !obj.trim().equals(""))
								inst.addPropValue(propArray[2*i], obj);
						}
					}
					rs1.close();
				}
				
				int tempCorefURIID = -1;
				Map<Integer,Integer> tempCorefURIIDs = new HashMap<Integer,Integer>();
				for(int i=0 ; i<propCount;i++){
					
					
					if(inst.propValues.get(propArray[2*i]) != null){
						if((dbname.equals("geonames") && (propArray[2*i+1] == geonamesLatID || propArray[2*i+1] == geonamesLongID))){
							stmt2.setString(1, "u" + propArray[2*i+1]);
							for(String obj:inst.propValues.get(propArray[2*i])){
								
								DecimalFormat df2  = new DecimalFormat("###.000");  
								double fobj = Double.parseDouble(obj);
								fobj = (double) ((int)(fobj*1000)/1000.0);
								stmt2.setString(2, "l"+df2.format(fobj)+"%");
							}
							ResultSet rs2 = stmt2.executeQuery();
							while (rs2.next()) {
								tempCorefURIID = Integer.parseInt(rs2.getString(1).substring(1));
								if(tempCorefURIIDs.containsKey(tempCorefURIID)){
									int count = tempCorefURIIDs.get(tempCorefURIID);
									tempCorefURIIDs.remove(tempCorefURIID);
									tempCorefURIIDs.put(tempCorefURIID, count+5);
									
								}
								else{
									tempCorefURIIDs.put(tempCorefURIID, 5);
								}
								
							}
							rs2.close();
						}
						else if(propArray[2*i+1] != 0 && propArray[2*i+1] != geonamesLabelID){
							stmt2.setString(1, "u" + propArray[2*i+1]);
							for(String obj:inst.propValues.get(propArray[2*i])){
								if(trainFID >300 && (dbname.equals("freebase_alternative") || dbname.equals("dbpedia"))){
									obj = StringReplace.strReplace("_", " ", obj);
									String objArray[] = obj.split(" ");
									obj = "";
									for(int oindex = 0; oindex < objArray.length; oindex++){
										if(objArray[oindex].length() >= 2)
											obj = obj + objArray[oindex] + " ";
										else if(dbname.equals("dbpedia"))
											obj = obj + objArray[oindex] + ", ";
										
									}
									obj = obj.trim();
								}
								else if (dbname.equals("freebase_alternative")){
									String objArray[] = obj.split(" ");
									if(objArray.length >= 4){
										obj = "";
										for(int oindex = 0; oindex < objArray.length-1; oindex++){
											obj = obj + objArray[oindex] + " ";
										}
									}
									obj = obj.trim();
								}
								if(dbname.equals("geonames") ||dbname.equals("dbpedia") )
									stmt2.setString(2, "l"+obj);
								else
									stmt2.setString(2, "l"+obj+"%");
								//logger.debug(instURIID+"||"+obj+"||");
								ResultSet rs2 = stmt2.executeQuery();
								while (rs2.next()) {
									
									tempCorefURIID = Integer.parseInt(rs2.getString(1).substring(1));
									if(URIQualify.quandtrupleCount(tempCorefURIID, dbname) > 1){
										if(tempCorefURIIDs.containsKey(tempCorefURIID)){
											int count = tempCorefURIIDs.get(tempCorefURIID);
											tempCorefURIIDs.remove(tempCorefURIID);
											tempCorefURIIDs.put(tempCorefURIID, count+1);
											
										}
										else{
											tempCorefURIIDs.put(tempCorefURIID, 1);
										}
									}
									
								}
								rs2.close();
							}
						}
						else if (propArray[2*i+1] == 0){
							if(dbname.equals("dbpedia")){
								for(String obj:inst.propValues.get(propArray[2*i])){
									obj = StringReplace.strReplace(" ", "_", obj);
									stmt3.setString(1, obj);
									ResultSet rs3 = stmt3.executeQuery();
									
										
									while(rs3.next()){										
										tempCorefURIID = rs3.getInt(1);
										if(tempCorefURIIDs.containsKey(tempCorefURIID)){
											int count = tempCorefURIIDs.get(tempCorefURIID);
											tempCorefURIIDs.remove(tempCorefURIID);
											tempCorefURIIDs.put(tempCorefURIID, count+1);
											
										}
										else{
											tempCorefURIIDs.put(tempCorefURIID, 1);
										}
									}
									rs3.close();
								}
							}
							else if(dbname.equals("freebase_alternative")){
								
							}
						}
						else if (propArray[2*i+1] == geonamesLabelID){
							for(String obj:inst.propValues.get(propArray[2*i])){
								obj = StringReplace.strReplace(" ", "_", obj);
								stmt3.setString(1, obj);
								ResultSet rs3 = stmt3.executeQuery();
								while(rs3.next()){
									int valueID = rs3.getInt(1);
									stmt2.setString(1, "u" + propArray[2*i+1]);
									stmt2.setString(2, "u" + valueID);
									ResultSet rs2 = stmt2.executeQuery();
									while(rs2.next()){
										tempCorefURIID = Integer.parseInt(rs2.getString(1).substring(1));
										if(tempCorefURIIDs.containsKey(tempCorefURIID)){
											int count = tempCorefURIIDs.get(tempCorefURIID);
											tempCorefURIIDs.remove(tempCorefURIID);
											tempCorefURIIDs.put(tempCorefURIID, count+3);
											
										}
										else{
											tempCorefURIIDs.put(tempCorefURIID, 3);
										}
									}
									
									rs2.close();
								}
								rs3.close();
							}
						}
					}
					
				}
				
				stmt1.close();
			

				
				int maxSim = -1;
				for(int URIID: tempCorefURIIDs.keySet()){
					if(tempCorefURIIDs.get(URIID) > maxSim){
						maxSim = tempCorefURIIDs.get(URIID);
						tempCorefURIID = URIID;
					}
				}
				
				if(maxSim == -1 && (dbname.equals("freebase_alternative") || (dbname.equals("dbpedia")) && trainFID < 300)){
					for(int i=0 ; i<propCount;i++){
						if(inst.propValues.get(propArray[2*i]) != null){
							if(propArray[2*i+1] != 0){
								stmt2.setString(1, "u" + propArray[2*i+1]);
								for(String obj:inst.propValues.get(propArray[2*i])){
									String objArray[] = obj.split(" ");
									if(objArray.length >= 2){
										obj = "";
										if(dbname.equals("freebase_alternative"))
											for(int oindex = 0; oindex < objArray.length/2; oindex++){
												obj = obj + objArray[oindex] + " ";
											}
										else if((dbname.equals("dbpedia")))
											for(int oindex = 0; oindex < objArray.length-1; oindex++){
												obj = obj + objArray[oindex] + " ";
											}
									}
									obj = obj.trim();
									if(dbname.equals("freebase_alternative"))
										stmt2.setString(2, "l"+obj+"%");
									else
										stmt2.setString(2, "l"+obj);
									ResultSet rs2 = stmt2.executeQuery();
									while (rs2.next()) {
										tempCorefURIID = Integer.parseInt(rs2.getString(1).substring(1));
										if(tempCorefURIIDs.containsKey(tempCorefURIID)){
											int count = tempCorefURIIDs.get(tempCorefURIID);
											tempCorefURIIDs.remove(tempCorefURIID);
											tempCorefURIIDs.put(tempCorefURIID, count+1);
											
										}
										else{
											tempCorefURIIDs.put(tempCorefURIID, 1);
										}									
									}
									rs2.close();
								}
							}
						}
						
					}
				}
				
				if(maxSim == -1 && dbname.equals("dbpedia") && trainFID > 300){
					for(int i=0 ; i<propCount;i++){
						if(inst.propValues.get(propArray[2*i]) != null){
							if(propArray[2*i+1] != 0){
								stmt2.setString(1, "u" + propArray[2*i+1]);
								for(String obj:inst.propValues.get(propArray[2*i])){
									obj = StringReplace.strReplace("_", ". ", obj);
									stmt2.setString(2, "l"+obj+"%");
									ResultSet rs2 = stmt2.executeQuery();
									while (rs2.next()) {
										tempCorefURIID = Integer.parseInt(rs2.getString(1).substring(1));
										if(tempCorefURIIDs.containsKey(tempCorefURIID)){
											int count = tempCorefURIIDs.get(tempCorefURIID);
											tempCorefURIIDs.remove(tempCorefURIID);
											tempCorefURIIDs.put(tempCorefURIID, count+1);
											
										}
										else{
											tempCorefURIIDs.put(tempCorefURIID, 1);
										}									
									}
									rs2.close();
								}
							}
							else{
								for(String obj:inst.propValues.get(propArray[2*i])){
									obj = StringReplace.strReplace("_", " ", obj);
									String objArray[] = obj.split(" ");
									obj = "";
									for(int oindex = 0; oindex < objArray.length; oindex++){
										if(objArray[oindex].length() > 2)
											obj = obj + objArray[oindex] + "_";
										
									}
									obj = obj.substring(0,obj.length()-1);
									stmt3.setString(1, obj);
									ResultSet rs3 = stmt3.executeQuery();
									while(rs3.next()){
										tempCorefURIID = rs3.getInt(1);
										if(tempCorefURIIDs.containsKey(tempCorefURIID)){
											tempCorefURIIDs.remove(tempCorefURIID);
											tempCorefURIIDs.put(tempCorefURIID, 1);
											
										}
										else{
											tempCorefURIIDs.put(tempCorefURIID, 1);
										}
									}
									rs3.close();
								}
							}
						}
						
					}
				}
				
				for(int URIID: tempCorefURIIDs.keySet()){
					if(tempCorefURIIDs.get(URIID) > maxSim){
						maxSim = tempCorefURIIDs.get(URIID);
						tempCorefURIID = URIID;
					}
				}
				
				stmt2.close();
				stmt3.close();
				if(dbname.equals("geonames") && maxSim == 5)
					tempCorefURIID = -1;
				
				
				logger.debug(instURIID+"||"+tempCorefURIID+"||"+maxSim);
				if(URIQualify.fetchWikiPageRedirects(tempCorefURIID) != -1 && dbname.equals("dbpedia"))
					tempCorefURIID = URIQualify.fetchWikiPageRedirects(tempCorefURIID);
				if(URIQualify.quandtrupleCount(tempCorefURIID, dbname) <= 1)
					tempCorefURIID = -1;
				if (instURIIDs.containsKey(instURIID)) {
					Set<Integer> corefURIIDs = instURIIDs.get(instURIID);
					corefURIIDs.add(tempCorefURIID);
				} else {
					Set<Integer> corefURIIDs = Collections.synchronizedSet(new HashSet<Integer>());
					corefURIIDs.add(tempCorefURIID);
					instURIIDs.put(instURIID, corefURIIDs);
				}
				connNYT2011.close();
			} catch (SQLException e) {
				logger.error(e.getMessage());
			}
		}
	}
	
	public class Instance
	{
		public int uriID;
		public Map<Integer, Set<String>> propValues;
		
		public Instance(int uid)
		{
			this.uriID = uid;
			this.propValues = new HashMap<Integer, Set<String>>();
		}
		
		public void addPropValue(int pid, String v)
		{
			if (propValues.containsKey(pid)) {
				Set<String> values = propValues.get(pid);
				values.add(v);
			} else {
				Set<String> values = new HashSet<String>();
				values.add(v);
				propValues.put(pid, values);
			}
		}
	}
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		PropertyConfigurator.configure("./config/log4j.properties");
		DBParam.init();

		Evaluator2 e = new Evaluator2(101,0.8,5);
		//e.NytGeonamesEvaluator1();
		e.evaluator2("dbpedia");
		//e.Evaluator2Counters("persons2");
	}

}
