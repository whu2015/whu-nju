package cn.edu.nju.ws.ocr.train.btc;

import java.sql.*;
import java.util.*;

import org.apache.log4j.Logger;
import org.apache.log4j.PropertyConfigurator;

import cn.edu.nju.ws.ocr.datab.DBConnPool;
import cn.edu.nju.ws.ocr.datab.DBParam;
import cn.edu.nju.ws.ocr.train.btc.BTC_NameFinder;

class Point{
    int propURIID;
    double infoGain;
  
    public Point( int x,double y){
        this.propURIID = x;
        this.infoGain = y;
    }   
    
    
    public void print(){
        System.out.println("\t" + BTC_NameFinder.uri(propURIID) + "\t" + infoGain );
    }

}

public class BTC_PropInfoGain {
	
	static Logger logger = Logger.getLogger(BTC_PropInfoGain.class);
	
	double threshold = 0.9;
	String type;
	String pld;
	private double infoD = 0;
	int negNum;
    int posNum;
    int sumNum;
    
	PriorityQueue<Point> queue = new PriorityQueue<Point>( 1, new Comparator<Point>(){
		public int compare( Point a, Point b ){
			if( a.infoGain < b.infoGain ){
				return 1;
            }
            else if( a.propURIID == b.propURIID){
                return 0;
            }
            else{
                return -1;
            }
        }
    });
	
	BTC_PropInfoGain(String type,String pld){
		this.type = type;
		this.pld = pld;
		try {
			Connection connBTC2011 = DBConnPool.getBTC2011();
			String query1 = "SELECT count(distinct uri_id1,uri_id2) FROM btc.btc2011_stattest_"+type+"_pp_neg where pld = ?";
			PreparedStatement stmt1 = connBTC2011.prepareStatement(query1);
			String query2 = "SELECT count(distinct uri_id1,uri_id2) FROM btc.btc2011_stattest_"+type+"_pp where pld = ?";
			PreparedStatement stmt2 = connBTC2011.prepareStatement(query2);
			
			stmt1.setString(1, pld);
			ResultSet rs1 = stmt1.executeQuery();
			rs1.next();
			this.negNum = rs1.getInt(1);
			stmt2.setString(1, pld);
			ResultSet rs2 = stmt2.executeQuery();
			rs2.next();
			this.posNum = rs2.getInt(1);
			this.sumNum = this.negNum + this.posNum;
			rs1.close();
			rs2.close();
			stmt1.close();
			stmt2.close();
			connBTC2011.close();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}	
		info();
	}
	
	private void info(){		
		infoD =  -((double)posNum/sumNum)*Math.log((double)posNum/sumNum) - ((double)negNum/sumNum)*Math.log((double)negNum/sumNum);
	}
	
	public double info(int propURIID){
		try {
			Connection connBTC2011 = DBConnPool.getBTC2011();
			String query1 = "SELECT uri_id1, uri_id2 FROM btc.btc2011_stattest_"+type+"_pp " +
					"where prop_id1 = ? and sim >= ? and pld = ?;";
			PreparedStatement stmt1 = connBTC2011.prepareStatement(query1);
			String query2 = "SELECT uri_id1, uri_id2 FROM btc.btc2011_stattest_"+type+"_pp_neg " +
					"where prop_id1 = ? and sim >= ? and pld = ?;";
			PreparedStatement stmt2 = connBTC2011.prepareStatement(query2);
			
			
			Set<Integer> countSet = new HashSet<Integer>();
			countSet.clear();
			
			stmt1.setInt(1, propURIID);
			stmt1.setDouble(2, threshold);
			stmt1.setString(3, pld);
			ResultSet rs1 = stmt1.executeQuery(); 
			while(rs1.next()){
				countSet.add(rs1.getInt(1)+rs1.getInt(2));
			}
			int posNumP = countSet.size();
			int posNumN = posNum - posNumP;
			countSet.clear();
			
			stmt2.setInt(1, propURIID);
			stmt2.setDouble(2, threshold);
			stmt2.setString(3, pld);
			ResultSet rs2 = stmt2.executeQuery();
			while(rs2.next()){
				//int temp[] = {rs1.getInt(1),rs1.getInt(2)};
				countSet.add(rs2.getInt(1)+rs2.getInt(2));
			}
			int negNumP = countSet.size();
			int negNumN = negNum - negNumP;
			
			int sumNumP = posNumP + negNumP;
			int sumNumN = posNumN + negNumN;
			
//			logger.info(prop_uri_id+ " " + posNumP + " " + negNumP);
			rs1.close();
			rs2.close();
			stmt1.close();
			stmt2.close();
			connBTC2011.close();
			if(posNumP != 0 && negNumP != 0 && posNumN != 0 && negNumN != 0)			
				return ((double)sumNumP/sumNum)*(-((double)posNumP/sumNumP)*Math.log((double)posNumP/sumNumP) - ((double)negNumP/sumNumP)*Math.log((double)negNumP/sumNumP)) + 
					   ((double)sumNumN/sumNum)*(-((double)posNumN/sumNumN)*Math.log((double)posNumN/sumNumN) - ((double)negNumN/sumNumN)*Math.log((double)negNumN/sumNumN));
			else if(posNumP != 0 && negNumP != 0)
				return ((double)sumNumP/sumNum)*(-((double)posNumP/sumNumP)*Math.log((double)posNumP/sumNumP) - ((double)negNumP/sumNumP)*Math.log((double)negNumP/sumNumP));
			else if(posNumN != 0 && negNumN != 0)
				return ((double)sumNumN/sumNum)*(-((double)posNumN/sumNumN)*Math.log((double)posNumN/sumNumN) - ((double)negNumN/sumNumN)*Math.log((double)negNumN/sumNumN));
			else
				return 0;
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return 0;
	}
	
//	public double splitInfo(int prop_uri_id, int threshold){
//		try {
//			Connection connDC7900 = DBConnPool.getDC7900();
//			Statement stmt1 = connDC7900.createStatement();
//			
//
//			int sumNum = negNum + posNum;
//			logger.info("negNum = " + negNum + " posNum = " + posNum + " sumNum = "+sumNum);
//					
//			infoD =  -((double)posNum/sumNum)*Math.log((double)posNum/sumNum) - ((double)negNum/sumNum)*Math.log((double)negNum/sumNum);
//
//		} catch (SQLException e) {
//			// TODO Auto-generated catch block
//			e.printStackTrace();
//		}
//	}

	public void GenPropPQ(){
		try {
			Connection connBTC2011 = DBConnPool.getBTC2011();
			String query1 = "SELECT distinct prop_id1 FROM btc2011_stattest_"+type+"_pp where pld = ?";
			PreparedStatement stmt1 = connBTC2011.prepareStatement(query1);
			String query2 = "SELECT distinct prop_id1 FROM btc2011_stattest_"+type+"_pp_neg where pld = ?";
			PreparedStatement stmt2 = connBTC2011.prepareStatement(query2);
			
			stmt1.setString(1, pld);
			ResultSet rs1 = stmt1.executeQuery();
			while(rs1.next()){
//				logger.info("positive property_uri_id1 "+ rs1.getInt(1));
				Point temp = new Point(rs1.getInt(1), infoD-info(rs1.getInt(1)) );
				queue.add(temp);
			}
			stmt2.setString(1, pld);
			ResultSet rs2 = stmt2.executeQuery();
			while(rs2.next()){
				//logger.info("negative property_uri_id1 "+ rs1.getInt(1));
				if(!PQcontains(rs2.getInt(1))){
					Point temp = new Point(rs2.getInt(1), infoD-info(rs2.getInt(1)) );
					queue.add(temp);
				}
			}
			rs1.close();
			rs2.close();
			stmt1.close();
			stmt2.close();
			
			connBTC2011.close();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
	public boolean PQcontains(int x){
		Iterator<Point> it = queue.iterator();
		while(it.hasNext()){
			if(x == it.next().propURIID)
				return true;
		}
		return false;
	}
	
	public void printPQ(){
		System.out.println( type);
		while( queue.size() > 0 ){
            Point p = ( Point )queue.poll();
            p.print();
        }
	}
	
	
	public static void main(String[] args) {
		PropertyConfigurator.configure("./config/log4j.properties");
		DBParam.init();
		
		BTC_PropInfoGain ig = new BTC_PropInfoGain("person","dbpedia.org");
		ig.GenPropPQ();
		ig.printPQ();
	}

}
