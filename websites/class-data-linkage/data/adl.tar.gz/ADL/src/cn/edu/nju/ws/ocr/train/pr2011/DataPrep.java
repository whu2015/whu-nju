package cn.edu.nju.ws.ocr.train.pr2011;

import java.sql.*;

import cn.edu.nju.ws.ocr.datab.DBConnPool;

public class DataPrep {

	static void initTestPositivePair(){
		try {
			Connection connPR = DBConnPool.getPR();
			Statement stmt1 = connPR.createStatement();
			stmt1.executeUpdate("truncate pr.__test_positive_pair;");
			stmt1.close();
			connPR.close();
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
