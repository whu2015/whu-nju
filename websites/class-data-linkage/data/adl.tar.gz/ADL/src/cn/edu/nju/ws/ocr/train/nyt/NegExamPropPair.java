package cn.edu.nju.ws.ocr.train.nyt;

import java.sql.*;
import java.util.*;
import java.util.concurrent.*;
import org.apache.log4j.*;
import cn.edu.nju.ws.ocr.datab.*;
import cn.edu.nju.ws.ocr.nlp.ISub;

class NegSet{
	//int foldID;
	int classURIID2;
	int instURIID2;
	
	NegSet(int pclassURIID2,int pinstURIID2){
		//foldID = pfoldID;
		classURIID2 = pclassURIID2;
		instURIID2 = pinstURIID2;
	}
}

public class NegExamPropPair 
{
	static Logger logger = Logger.getLogger(NegExamPropPair.class);
	
	private int nytPrefLabelID = 72;
	private int nytOWLSameAsID = 29;
	private int nytRDFTypeID = 32;
	private int geonamesOWLSameAsID = 1813;
	private int geonamesRDFTypeID = 14;
	private int dbpediaOWLSameAsID = -1;
	private int dbpediaRDFTypeID = 2;
	private int freebaseAlternativeOWLSameAsID = 121;
	private int freebaseAlternativeRDFTypeID = 16;

	
	//nyt_geonames
	public void execNegExamPropPair1(String dbname, int foldID)
	{
		
		try {
			Connection connNYT2011 = DBConnPool.getNYT2011();
			String sqlstr1 = "SELECT distinct instance_uri_id1,instance_uri_id2,class_uri_id2 "
					       + "FROM negative_nyt_"+dbname+" where fold_id=?;";
			PreparedStatement stmt1 = connNYT2011.prepareStatement(sqlstr1);
			
			Map<Integer, Set<NegSet>> positiveExamples = 
					Collections.synchronizedMap(new HashMap<Integer, Set<NegSet>>());
			
			stmt1.setInt(1, foldID);
			ResultSet rs1 = stmt1.executeQuery();
			while (rs1.next()) {
				int instURIID1 = rs1.getInt(1);
				int instURIID2 = rs1.getInt(2);
				int classURIID2 = rs1.getInt(3);
				//int foldID = rs1.getInt(4);
				if (positiveExamples.containsKey(instURIID1)) {
					Set<NegSet> instances = positiveExamples.get(instURIID1);
					NegSet ps = new NegSet(classURIID2,instURIID2);
					instances.add(ps);
				} else {
					Set<NegSet> instances = new HashSet<NegSet>();
					NegSet ps = new NegSet(classURIID2,instURIID2);
					instances.add(ps);
					positiveExamples.put(instURIID1, instances);
				}
			}
			rs1.close();
			stmt1.close();
			connNYT2011.close();			
//			File[] files = new File("./data/mappings/10-fold/").listFiles();
//			for (int i = 0; i < files.length; ++i) {
//				File f = files[i];
//				if (f.getName().startsWith("nyt-geonames-mappings")) {
//					AlignmentReader ar = new AlignmentReader(f.getPath());
//					Alignment a = ar.read();
//					if((i+1)%10 == (foldID%100)%10)
//						for(int j = 0; j < a.size(); j++){
//							int instURIID1 = URIHelper.uriID(a.mapping(j).entity1(), "nyt_uri");
//							int instURIID2 = URIHelper.uriID(a.mapping(j).entity2(), "geonames_uri");
//							if (positiveExamples.containsKey(instURIID1)) {
//								Set<Integer> instances = positiveExamples.get(instURIID1);
//								instances.add(instURIID2);
//							} else {
//								Set<Integer> instances = new HashSet<Integer>();
//								instances.add(instURIID2);
//								positiveExamples.put(instURIID1, instances);
//							}
//						}
//				}
//			}

			
			BlockingQueue<Runnable> queue = new LinkedBlockingQueue<Runnable>();  
			ThreadPoolExecutor exec = new ThreadPoolExecutor(4, 5, 7, TimeUnit.DAYS, queue);
			for (int instURIID1 : positiveExamples.keySet()) {
				Set<NegSet> instances = positiveExamples.get(instURIID1);
				NegExamPropPairThread1 peppt1 = 
						new NegExamPropPairThread1(foldID, instURIID1, instances, dbname);
				exec.execute(peppt1);
			}
			exec.shutdown();
		} catch (SQLException e) {
			logger.error(e.getMessage());
		}
	}
	
	public static void main(String args[])
	{
		PropertyConfigurator.configure("./config/log4j.properties");
		DBParam.init();
		
		NegExamPropPair pepp = new NegExamPropPair();
		pepp.execNegExamPropPair1("dbpedia",310);
	}
	
	public class NegExamPropPairThread1 implements Runnable
	{
		private int foldID;
		private int instURIID;
		private Set<NegSet> corefURIIDs;
		private String dbname;
		
		public NegExamPropPairThread1(int fid,int uid, Set<NegSet> cuids, String dbname)
		{
			this.foldID = fid;
			this.instURIID = uid;
			this.corefURIIDs = cuids;
			this.dbname = dbname;
		}
		
		public void run()
		{
			try {
				//logger.debug("type_uri_id=" + typeURIID + ", inst_uri_id=" + instURIID);
				
				Connection connNYT2011 = DBConnPool.getNYT2011();
				String sqlstr1= null;
				if(foldID > 100 && foldID <=110 ){
					sqlstr1 = "SELECT DISTINCT p,o FROM nyt_locations_quadruple " 
							+ "WHERE s=? AND p<>? AND p<>? AND o NOT LIKE 'b%';";
				}
				else if(foldID > 200 && foldID <=210){
					sqlstr1 = "SELECT DISTINCT p,o FROM nyt_organizations_quadruple " 
							+ "WHERE s=? AND p<>? AND p<>? AND o NOT LIKE 'b%';";
				}
				else{
					sqlstr1 = "SELECT DISTINCT p,o FROM nyt_people_quadruple " 
							+ "WHERE s=? AND p<>? AND p<>? AND o NOT LIKE 'b%';";
				}
				PreparedStatement stmt1 = connNYT2011.prepareStatement(sqlstr1);
				String sqlstr2 = "SELECT DISTINCT p,o FROM "+dbname+"_quadruple " 
						   + "WHERE s=? AND p<>? AND p<>? AND o NOT LIKE 'b%';";
				PreparedStatement stmt2 = connNYT2011.prepareStatement(sqlstr2);
				
				Instance inst = new Instance(instURIID);
				stmt1.setString(1, "u" + instURIID);
				stmt1.setString(2, "u" + nytOWLSameAsID);
				stmt1.setString(3, "u" + nytRDFTypeID);
				ResultSet rs1 = stmt1.executeQuery();
				while (rs1.next()) {
					String p = rs1.getString(1);
					String o = rs1.getString(2);
					int propURIID = Integer.parseInt(p.substring(1));
					if(propURIID == nytPrefLabelID && (dbname.equals("dbpedia") || dbname.equals("freebase_alternative")) && foldID >300 && foldID <=310){
						String obj = NameFinder.nytPeopleLabel(instURIID)[1];
						if (obj != null && !obj.trim().equals(""))
							inst.addPropValue(propURIID, obj);
					}
					else if(propURIID == nytPrefLabelID){
						String obj = null;
						if(o.indexOf("(") > 0)
							obj = o.substring(1, o.indexOf("(")-1);
						else
							obj = o.substring(1);
						inst.addPropValue(propURIID, obj);
					}
					
					else if (o.startsWith("u")) {
						int objURIID = Integer.parseInt(o.substring(1));
						String obj = NameFinder.nytLocalname(objURIID);
						if (obj != null && !obj.trim().equals(""))
							inst.addPropValue(propURIID, obj);
					} else { // o.startsWith("l")
						String obj = o.substring(1);
						if (obj != null && !obj.trim().equals(""))
							inst.addPropValue(propURIID, obj);
					}
				}
				rs1.close();
				
				Map<Instance,NegSet> corefs = new HashMap<Instance,NegSet>();
				for (NegSet corefURIID : corefURIIDs) {
					Instance coref = new Instance(corefURIID.instURIID2);
					stmt2.setString(1, "u" + corefURIID.instURIID2);
					if(dbname.equals("geonames")){
						stmt2.setString(2, "u" + geonamesOWLSameAsID);
						stmt2.setString(3, "u" + geonamesRDFTypeID);
					}
					else if(dbname.equals("dbpedia")){
						stmt2.setString(2, "u" + dbpediaOWLSameAsID);
						stmt2.setString(3, "u" + dbpediaRDFTypeID);
					}
					else if(dbname.equals("freebase_alternative")){
						stmt2.setString(2, "u" + freebaseAlternativeOWLSameAsID);
						stmt2.setString(3, "u" + freebaseAlternativeRDFTypeID);
					}
					ResultSet rs2 = stmt2.executeQuery();
					while (rs2.next()) {
						String p = rs2.getString(1);
						String o = rs2.getString(2);
						int propURIID = Integer.parseInt(p.substring(1));
						if(dbname.equals("geonames")){
							if (o.startsWith("u")) {
								int objURIID = Integer.parseInt(o.substring(1));
								String obj = NameFinder.geonamesLocalname(objURIID);
								if (obj != null && !obj.trim().equals(""))
									coref.addPropValue(propURIID, obj);
							} else {
								String obj = o.substring(1);
								if (obj != null && !obj.equals(""))
									coref.addPropValue(propURIID, obj);
							}
						}
						else if(dbname.equals("dbpedia")){
							if (o.startsWith("u")) {
								int objURIID = Integer.parseInt(o.substring(1));
								String obj = NameFinder.dbpediaQname(objURIID)[1];
								if (obj != null && !obj.trim().equals(""))
									coref.addPropValue(propURIID, obj);
							} else {
								String obj = o.substring(1);
								if (obj != null && !obj.equals(""))
									coref.addPropValue(propURIID, obj);
							}
						}
						else if(dbname.equals("freebase_alternative")){
							if (o.startsWith("u")) {
								int objURIID = Integer.parseInt(o.substring(1));
								String obj = NameFinder.freebaseAlternativeQname(objURIID)[1];
								if (obj != null && !obj.trim().equals(""))
									coref.addPropValue(propURIID, obj);
							} else {
								String obj = o.substring(1);
								if (obj != null && !obj.equals(""))
									coref.addPropValue(propURIID, obj);
							}
						}
					}
					if(dbname.equals("dbpedia")){
						String obj =  NameFinder.dbpediaQname(corefURIID.instURIID2)[1];
						if(obj.lastIndexOf(",")>0)
							coref.addPropValue(0, obj.substring(0,obj.lastIndexOf(",")));
						else
							coref.addPropValue(0, obj);
					}
					else if(dbname.equals("freebase_alternative")){
						String o[] =  NameFinder.freebaseAlternativeQname(corefURIID.instURIID2)[1].split(".");
						if(o != null){
							if(o.length >= 2){
								coref.addPropValue(0, o[1]);
							}
							else if(o.length == 1)
								coref.addPropValue(0, o[0]);
						}
					}
					rs2.close();
					corefs.put(coref,corefURIID);
				}
				
				
				
				stmt1.close();
				stmt2.close();
				
				
				String sqlstr3 = "INSERT IGNORE INTO negative_nyt_"+dbname+"_property_pair VALUES(?,?,?,?,?,?,?,?,?,?)";
				PreparedStatement stmt3 = connNYT2011.prepareStatement(sqlstr3);
				
				Map<Integer, Set<String>> instPropValues = inst.propValues;
				for (Instance coref : corefs.keySet()) {
					Map<Integer, Set<String>> corefPropValues = coref.propValues;
					NegSet ps = corefs.get(coref);
					//int foldID = ps.foldID;
					int typeURIID2 = ps.classURIID2;
					
					for (int instPropURIID : instPropValues.keySet()) {
						Set<String> instValues = instPropValues.get(instPropURIID);
						for (int corefPropURIID : corefPropValues.keySet()) {
							Set<String> corefValues = corefPropValues.get(corefPropURIID);
							for (String instValue : instValues) {
								for (String corefValue : corefValues) {
									double sim = ISub.getSimilarity(instValue, corefValue);
									if (sim >= 0.7) {
										logger.debug("foldID: "+foldID + " || "+instValue+" || " + corefValue);
										stmt3.setInt(1, foldID);
										stmt3.setInt(2, 64);
										stmt3.setInt(3, typeURIID2);
										stmt3.setInt(4, instURIID);
										stmt3.setInt(5, coref.uriID);
										stmt3.setInt(6, instPropURIID);
										stmt3.setInt(7, corefPropURIID);
										stmt3.setString(8, instValue);
										stmt3.setString(9, corefValue);
										stmt3.setFloat(10, (float) sim);
										stmt3.addBatch();
									}
								}
							}
						}
					}
					stmt3.executeBatch();
				}
				stmt3.close();
				connNYT2011.close();
			} catch (SQLException e) {
				logger.error(e.getMessage());
			}
		}
	}
	
	public class Instance
	{
		public int uriID;
		public Map<Integer, Set<String>> propValues;
		
		public Instance(int uid)
		{
			this.uriID = uid;
			this.propValues = new HashMap<Integer, Set<String>>();
		}
		
		public void addPropValue(int pid, String v)
		{
			if (propValues.containsKey(pid)) {
				Set<String> values = propValues.get(pid);
				values.add(v);
			} else {
				Set<String> values = new HashSet<String>();
				values.add(v);
				propValues.put(pid, values);
			}
		}
	}
}
