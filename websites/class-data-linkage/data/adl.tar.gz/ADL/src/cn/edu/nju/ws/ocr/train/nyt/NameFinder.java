package cn.edu.nju.ws.ocr.train.nyt;

import java.sql.*;

import org.apache.log4j.*;
import cn.edu.nju.ws.ocr.datab.*;

public class NameFinder 
{
	static Logger logger = Logger.getLogger(NameFinder.class);
	
	public static String dbpediaURI(int uriID)
	{
		try {
			Connection connNYT2011 = DBConnPool.getNYT2011();
			String sqlstr1 = "SELECT uri FROM dbpedia_uri WHERE uri_id=?";
			PreparedStatement stmt1 = connNYT2011.prepareStatement(sqlstr1);
			
			String uri = null;
			stmt1.setInt(1, uriID);
			ResultSet rs1 = stmt1.executeQuery();
			while (rs1.next()) 
				uri = rs1.getString(1);
			rs1.close();
			stmt1.close();
			connNYT2011.close();
			return uri;
		} catch (SQLException e) {
			logger.error(e.getMessage());
			return null;
		}
	}
	
	public static String[] dbpediaQname(int uriID)
	{
		String uri = dbpediaURI(uriID);
		
		if (uri == null || uri.trim().equals("")) {
			return null;
		} else {
			String namespace = null, localname = null;
			int index = uri.lastIndexOf("#");
			if (index != -1) {
				namespace = uri.substring(0, index + 1);
				localname = uri.substring(index + 1);
			} else {
				index = uri.lastIndexOf("/");
				if (index != -1) {
					namespace = uri.substring(0, index + 1);
					localname = uri.substring(index + 1);
				} else {
					index = uri.lastIndexOf(":");
					if (index != -1) {
						namespace = uri.substring(0, index + 1);
						localname = uri.substring(index + 1);
					}
				}
			}
			String[] qname = {namespace, localname};
			return qname;
		}
	}
	
	public static String freebaseAlternativeURI(int uriID)
	{
		try {
			Connection connNYT2011 = DBConnPool.getNYT2011();
			String sqlstr1 = "SELECT uri FROM freebase_alternative_uri WHERE uri_id=?";
			PreparedStatement stmt1 = connNYT2011.prepareStatement(sqlstr1);
			
			String uri = null;
			stmt1.setInt(1, uriID);
			ResultSet rs1 = stmt1.executeQuery();
			while (rs1.next()) 
				uri = rs1.getString(1);
			rs1.close();
			stmt1.close();
			connNYT2011.close();
			return uri;
		} catch (SQLException e) {
			logger.error(e.getMessage());
			return null;
		}
	}
	
	public static String[] freebaseAlternativeQname(int uriID)
	{
		String uri = dbpediaURI(uriID);
		
		if (uri == null || uri.trim().equals("")) {
			return null;
		} else {
			String namespace = null, localname = null;
			int index = uri.lastIndexOf("#");
			if (index != -1) {
				namespace = uri.substring(0, index + 1);
				localname = uri.substring(index + 1);
			} else {
				index = uri.lastIndexOf("/");
				if (index != -1) {
					namespace = uri.substring(0, index + 1);
					localname = uri.substring(index + 1);
				} else {
					index = uri.lastIndexOf(":");
					if (index != -1) {
						namespace = uri.substring(0, index + 1);
						localname = uri.substring(index + 1);
					}
				}
			}
			String[] qname = {namespace, localname};
			return qname;
		}
	}
	
	public static String nytURI(int uriID)
	{
		try {
			Connection connNYT2011 = DBConnPool.getNYT2011();
			String sqlstr1 = "SELECT uri FROM nyt_uri WHERE uri_id=?";
			PreparedStatement stmt1 = connNYT2011.prepareStatement(sqlstr1);
			
			String uri = null;
			stmt1.setInt(1, uriID);
			ResultSet rs1 = stmt1.executeQuery();
			while (rs1.next()) 
				uri = rs1.getString(1);
			rs1.close();
			stmt1.close();
			connNYT2011.close();
			return uri;
		} catch (SQLException e) {
			logger.error(e.getMessage());
			return null;
		}
	}

	public static String nytLocalname(int uriID)
	{
		String uri = nytURI(uriID);
		
		if (uri == null || uri.trim().equals("")) {
			return null;
		} else {
			String localname = null;
			int index = uri.lastIndexOf("#");
			if (index != -1) {
				localname = uri.substring(index + 1);
			} else {
				index = uri.lastIndexOf("/");
				if (index != -1) {
					localname = uri.substring(index + 1);
				} else {
					index = uri.lastIndexOf(":");
					if (index != -1) {
						localname = uri.substring(index + 1);
					}
				}
			}
			return localname;
		}
	}
	
	public static String[] nytLocationsLabel(int uriID)
	{
		try {
			Connection connNYT2011 = DBConnPool.getNYT2011();
			String sqlstr1 = "SELECT o FROM nyt_locations_quadruple WHERE s=? and p=?";
			PreparedStatement stmt1 = connNYT2011.prepareStatement(sqlstr1);
			
			String label = null;
			
			stmt1.setString(1,"u"+uriID);
			stmt1.setString(2,"u72");
			ResultSet rs1 = stmt1.executeQuery();
			while (rs1.next()) 
				label = rs1.getString(1);
			rs1.close();
			stmt1.close();
			connNYT2011.close();
			String[] preLabel = {"",label.substring(1)};
			return preLabel;
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			return null;
		}
	}
	
	public static String nytOrganizationsURI(int uriID)
	{
		try {
			Connection connNYT2011 = DBConnPool.getNYT2011();
			String sqlstr1 = "SELECT uri FROM nyt_organizations_uri WHERE uri_id=?";
			PreparedStatement stmt1 = connNYT2011.prepareStatement(sqlstr1);
			
			String uri = null;
			stmt1.setInt(1, uriID);
			ResultSet rs1 = stmt1.executeQuery();
			while (rs1.next()) 
				uri = rs1.getString(1);
			rs1.close();
			stmt1.close();
			connNYT2011.close();
			return uri;
		} catch (SQLException e) {
			logger.error(e.getMessage());
			return null;
		}
	}

	public static String nytOrganizationsLocalname(int uriID)
	{
		String uri = nytOrganizationsURI(uriID);
		
		if (uri == null || uri.trim().equals("")) {
			return null;
		} else {
			String localname = null;
			int index = uri.lastIndexOf("#");
			if (index != -1) {
				localname = uri.substring(index + 1);
			} else {
				index = uri.lastIndexOf("/");
				if (index != -1) {
					localname = uri.substring(index + 1);
				} else {
					index = uri.lastIndexOf(":");
					if (index != -1) {
						localname = uri.substring(index + 1);
					}
				}
			}
			return localname;
		}
	}
	
	public static String[] nytOrganizationsLabel(int uriID)
	{
		try {
			Connection connNYT2011 = DBConnPool.getNYT2011();
			String sqlstr1 = "SELECT o FROM nyt_organizations_quadruple WHERE s=? and p=?";
			PreparedStatement stmt1 = connNYT2011.prepareStatement(sqlstr1);
			
			String label = null;
			
			stmt1.setString(1,"u"+uriID);
			stmt1.setString(2,"u72");
			ResultSet rs1 = stmt1.executeQuery();
			while (rs1.next()) 
				label = rs1.getString(1);
			rs1.close();
			stmt1.close();
			connNYT2011.close();
			String[] preLabel = {"",label.substring(1)};
			return preLabel;
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			return null;
		}
	}
	
	public static String nytPeopleURI(int uriID)
	{
		try {
			Connection connNYT2011 = DBConnPool.getNYT2011();
			String sqlstr1 = "SELECT uri FROM nyt_people_uri WHERE uri_id=?";
			PreparedStatement stmt1 = connNYT2011.prepareStatement(sqlstr1);
			
			String uri = null;
			stmt1.setInt(1, uriID);
			ResultSet rs1 = stmt1.executeQuery();
			while (rs1.next()) 
				uri = rs1.getString(1);
			rs1.close();
			stmt1.close();
			connNYT2011.close();
			return uri;
		} catch (SQLException e) {
			logger.error(e.getMessage());
			return null;
		}
	}

	public static String nytPeopleLocalname(int uriID)
	{
		String uri = nytPeopleURI(uriID);
		
		if (uri == null || uri.trim().equals("")) {
			return null;
		} else {
			String localname = null;
			int index = uri.lastIndexOf("#");
			if (index != -1) {
				localname = uri.substring(index + 1);
			} else {
				index = uri.lastIndexOf("/");
				if (index != -1) {
					localname = uri.substring(index + 1);
				} else {
					index = uri.lastIndexOf(":");
					if (index != -1) {
						localname = uri.substring(index + 1);
					}
				}
			}
			return localname;
		}
	}
	
	public static String[] nytPeopleLabel(int uriID)
	{
		try {
			Connection connNYT2011 = DBConnPool.getNYT2011();
			String sqlstr1 = "SELECT o FROM nyt_people_quadruple WHERE s=? and p=?";
			PreparedStatement stmt1 = connNYT2011.prepareStatement(sqlstr1);
			
			String label = null;
			
			stmt1.setString(1,"u"+uriID);
			stmt1.setString(2,"u72");
			ResultSet rs1 = stmt1.executeQuery();
			while (rs1.next()) 
				label = rs1.getString(1);
			rs1.close();
			stmt1.close();
			connNYT2011.close();
			String reverseLabel = null;
			String reverseLabelArray[] = label.substring(1).split(",");
			if(reverseLabelArray.length >= 2)
				reverseLabel = reverseLabelArray[1].trim()+"_"+reverseLabelArray[0].trim();	
			else
				reverseLabel = reverseLabelArray[0].trim();	
			String[] preLabel = {"",reverseLabel};
			return preLabel;
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			return null;
		}
	}
	
	public static String geonamesURI(int uriID)
	{
		try {
			Connection connNYT2011 = DBConnPool.getNYT2011();
			String sqlstr1 = "SELECT uri FROM geonames_uri WHERE uri_id=?";
			PreparedStatement stmt1 = connNYT2011.prepareStatement(sqlstr1);
			
			String uri = null;
			stmt1.setInt(1, uriID);
			ResultSet rs1 = stmt1.executeQuery();
			while (rs1.next()) 
				uri = rs1.getString(1);
			rs1.close();
			stmt1.close();
			connNYT2011.close();
			return uri;
		} catch (SQLException e) {
			logger.error(e.getMessage());
			return null;
		}
	}
	
	public static String geonamesLocalname(int uriID)
	{
		String uri = geonamesURI(uriID);
		
		if (uri == null || uri.trim().equals("")) {
			return null;
		} else {
			String localname = null;
			int index = uri.lastIndexOf("#");
			if (index != -1) {
				localname = uri.substring(index + 1);
			} else {
				index = uri.lastIndexOf("/");
				if (index != -1) {
					localname = uri.substring(index + 1);
				} else {
					index = uri.lastIndexOf(":");
					if (index != -1) {
						localname = uri.substring(index + 1);
					}
				}
			}
			return localname;
		}
	}
	
	public static String[] geonamesLocationsLabel(int uriID)
	{
		try {
			Connection connNYT2011 = DBConnPool.getNYT2011();
			String sqlstr1 = "SELECT o FROM geonames_quadruple WHERE s=? and p=? and lang=?";
			PreparedStatement stmt1 = connNYT2011.prepareStatement(sqlstr1);
			
			String label = null;
			
			stmt1.setString(1,"u"+uriID);
			stmt1.setString(2,"u16");
			stmt1.setString(3,"en");
			ResultSet rs1 = stmt1.executeQuery();
			while (rs1.next()) 
				label = rs1.getString(1);
			rs1.close();
			stmt1.close();
			connNYT2011.close();
			
			String[] preLabel = {"",""};
			if(label != null)	preLabel[1] = label.substring(1);
			return preLabel;
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			return null;
		}
	}
}

