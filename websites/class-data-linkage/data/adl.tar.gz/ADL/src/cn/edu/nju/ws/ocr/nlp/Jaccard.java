package cn.edu.nju.ws.ocr.nlp;

import java.util.*;
import org.apache.log4j.*;

public class Jaccard 
{
	static Logger logger = Logger.getLogger(Jaccard.class);
	
	public static double getSimilarity(String s1, String s2)
	{
		String[] ss1 = s1.split(" "), ss2 = s2.split(" ");
		
		Set<String> union = new HashSet<String>();
		Set<String> set1 = new HashSet<String>(), set2 = new HashSet<String>();
		for (int i = 0; i < ss1.length; ++i) {
			union.add(ss1[i]);
			set1.add(ss1[i]);
		}
		for (int i = 0; i < ss2.length; ++i) {
			union.add(ss2[i]);
			set2.add(ss2[i]);
		}

		return (set1.size() + set2.size() - union.size()) / (double) union.size();
	}
}
