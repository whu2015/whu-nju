package cn.edu.nju.ws.ocr.train.btc;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.HashSet;
import java.util.Iterator;
import java.util.Set;

import org.apache.log4j.PropertyConfigurator;

import cn.edu.nju.ws.ocr.datab.DBParam;

public class BTC_Evaluator3 {

	Set<Integer> goldenCorefURIIDs = new HashSet<Integer>();
	Set<Integer> testCorefURIIDs = new HashSet<Integer>();
	Set<Integer> totalGoldenCorefURIIDs = new HashSet<Integer>();
	Set<Integer> totalResults = new HashSet<Integer>();
	Set<Integer> totalSameAsOrgResults = new HashSet<Integer>();
	Set<Integer> totalObjectCorefResults = new HashSet<Integer>();
	
	
	void goldenLoad(String id){
	
		File file = new File("./data/golden_standard/"+id+".txt");
		BufferedReader reader = null;
		try{
			reader = new BufferedReader(new FileReader(file));
			String tempString = null;
			
			while((tempString = reader.readLine()) != null){
				goldenCorefURIIDs.add(BTC_NameFinder.uriID(tempString));
			}
			reader.close();
		}catch(FileNotFoundException e){
			e.printStackTrace();
		}catch(IOException e){
			e.printStackTrace();
		}
	}
	
	void totalGoldenWrite(){
		File file = new File("./data/golden_standard/golden_standard");
		BufferedWriter writer = null;
		try{
			writer = new BufferedWriter(new FileWriter(file));
			
			for(int id = 1; id<=20 ;id++){
				File file1 = new File("./data/golden_standard/"+id+".txt");
				BufferedReader reader = null;
				
				reader = new BufferedReader(new FileReader(file1));
				String tempString = null;
				
				while((tempString = reader.readLine()) != null){
					System.out.println(tempString);
					writer.write(tempString);
					writer.newLine();
				}
				reader.close();
			}
			writer.close();
		}catch(FileNotFoundException e){
			e.printStackTrace();
		}catch(IOException e){
			e.printStackTrace();
		}
	}
	
	void totalGoldenLoad(){
		
		File file = new File("./data/golden_standard/golden_standard");
		BufferedReader reader = null;
		try{
			reader = new BufferedReader(new FileReader(file));
			String tempString = null;
			
			while((tempString = reader.readLine()) != null){
				totalGoldenCorefURIIDs.add(BTC_NameFinder.uriID(tempString));
			}
			reader.close();
		}catch(FileNotFoundException e){
			e.printStackTrace();
		}catch(IOException e){
			e.printStackTrace();
		}
	}
	
	void totalSameAsOrgLoad(){
		
		File file = new File("./data/golden_standard/sameAs.org");
		BufferedReader reader = null;
		try{
			reader = new BufferedReader(new FileReader(file));
			String tempString = null;
			
			while((tempString = reader.readLine()) != null){
				if(tempString.split(" ").length >= 2)
					totalSameAsOrgResults.add(BTC_NameFinder.uriID(tempString.split(" ")[1]));
				else
					totalSameAsOrgResults.add(BTC_NameFinder.uriID(tempString));
			}
			reader.close();
		}catch(FileNotFoundException e){
			e.printStackTrace();
		}catch(IOException e){
			e.printStackTrace();
		}
	}
	
	void totalResultsLoad(){
		
		File file = new File("./data/golden_standard/results");
		BufferedReader reader = null;
		try{
			reader = new BufferedReader(new FileReader(file));
			String tempString = null;
			
			while((tempString = reader.readLine()) != null){
				totalResults.add(BTC_NameFinder.uriID(tempString));
			}
			reader.close();
		}catch(FileNotFoundException e){
			e.printStackTrace();
		}catch(IOException e){
			e.printStackTrace();
		}
	}
	
	void totalOCLoad(){
		
		File file = new File("./data/golden_standard/oc");
		BufferedReader reader = null;
		try{
			reader = new BufferedReader(new FileReader(file));
			String tempString = null;
			
			while((tempString = reader.readLine()) != null){
				if(tempString.split(" ").length >= 2)
					totalObjectCorefResults.add(BTC_NameFinder.uriID(tempString.split(" ")[1]));
				else
					totalObjectCorefResults.add(BTC_NameFinder.uriID(tempString));
			}
			reader.close();
		}catch(FileNotFoundException e){
			e.printStackTrace();
		}catch(IOException e){
			e.printStackTrace();
		}
	}
	
	void testLoad(String id){
		
		File file = new File("./data/golden_standard/"+id);
		BufferedReader reader = null;
		try{
			reader = new BufferedReader(new FileReader(file));
			String tempString = null;
			
			while((tempString = reader.readLine()) != null){
				if(tempString.split(" ").length >= 2)
					testCorefURIIDs.add(BTC_NameFinder.uriID(tempString.split(" ")[1]));
				else
					testCorefURIIDs.add(BTC_NameFinder.uriID(tempString));
			}
			reader.close();
		}catch(FileNotFoundException e){
			e.printStackTrace();
		}catch(IOException e){
			e.printStackTrace();
		}
	}
	
	void difference(Set<Integer> setA, Set<Integer> setB, String out) {
        int s = 0;
        int count = 0;
        Iterator<Integer> iterA = setA.iterator();
        while (iterA.hasNext()) {
            s = iterA.next();
            if(!setB.contains(s)) {
                //System.out.println("--------"+out+": "+BTC_NameFinder.uri(s));
                count++;
            }
        }
        System.out.println("--------"+out+": "+count);
    }
	
	void goldenSizeGroupByType(){
		
		for(int i = 1; i<=20 ; i++){
			goldenLoad(Integer.toString(i));
			System.out.println(goldenCorefURIIDs.size());
			goldenCorefURIIDs.clear();
		}
	}
	
	/**
	 * @param args
	 */
	public static void main(String[] args) {
		
		PropertyConfigurator.configure("./config/log4j.properties");
		DBParam.init();
		// TODO Auto-generated method stub
		BTC_Evaluator3 e = new BTC_Evaluator3();
		String testID = "20";
		
		e.goldenLoad(testID);
		e.testLoad(testID+"_kernel");
		e.difference(e.goldenCorefURIIDs, e.testCorefURIIDs, "miss");
		e.difference(e.testCorefURIIDs, e.goldenCorefURIIDs, "wrong");
		
		e.testCorefURIIDs.clear();
		e.goldenLoad(testID);
		e.testLoad(testID+"_sameAs.org");
		e.difference(e.goldenCorefURIIDs, e.testCorefURIIDs, "miss");
		e.difference(e.testCorefURIIDs, e.goldenCorefURIIDs, "wrong");
		
		e.testCorefURIIDs.clear();
		e.goldenLoad(testID);
		e.testLoad(testID+"_oc");
		e.difference(e.goldenCorefURIIDs, e.testCorefURIIDs, "miss");
		e.difference(e.testCorefURIIDs, e.goldenCorefURIIDs, "wrong");
		
//		e.totalGoldenLoad();
//		e.totalOCLoad();
//		e.totalResultsLoad();
//		e.totalSameAsOrgLoad();
//		e.totalGoldenCorefURIIDs.retainAll(e.totalResults);
//		System.out.println("本方法命中数: "+e.totalGoldenCorefURIIDs.size());
//		
//		e.totalGoldenLoad();
//		e.totalGoldenCorefURIIDs.retainAll(e.totalSameAsOrgResults);
//		System.out.println("sameAs.org命中数: "+e.totalGoldenCorefURIIDs.size());
//		
//		e.totalGoldenLoad();
//		e.totalGoldenCorefURIIDs.retainAll(e.totalObjectCorefResults);
//		System.out.println("oc命中数: "+e.totalGoldenCorefURIIDs.size());
//		
//		e.totalGoldenLoad();
//		e.totalGoldenCorefURIIDs.retainAll(e.totalResults);
//		e.totalGoldenCorefURIIDs.retainAll(e.totalSameAsOrgResults);
//		System.out.println("本方法与sameAs共同命中数: "+e.totalGoldenCorefURIIDs.size());
//		
//		e.totalGoldenLoad();
//		e.totalGoldenCorefURIIDs.retainAll(e.totalResults);
//		e.totalGoldenCorefURIIDs.retainAll(e.totalObjectCorefResults);
//		System.out.println("本方法与oc共同命中数: "+e.totalGoldenCorefURIIDs.size());
//		
//		e.totalGoldenLoad();
//		e.totalGoldenCorefURIIDs.retainAll(e.totalSameAsOrgResults);
//		e.totalGoldenCorefURIIDs.retainAll(e.totalObjectCorefResults);
//		System.out.println("sameAs.org与oc共同命中数: "+e.totalGoldenCorefURIIDs.size());
//		
//		e.totalGoldenLoad();
//		e.totalGoldenCorefURIIDs.retainAll(e.totalResults);
//		e.totalGoldenCorefURIIDs.retainAll(e.totalSameAsOrgResults);
//		e.totalGoldenCorefURIIDs.retainAll(e.totalObjectCorefResults);
//		System.out.println("本方法与sameAs.org与oc共同命中数: "+e.totalGoldenCorefURIIDs.size());
	}

}
