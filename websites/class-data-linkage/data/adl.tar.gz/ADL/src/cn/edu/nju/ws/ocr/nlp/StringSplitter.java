package cn.edu.nju.ws.ocr.nlp;

import java.util.*;
import org.apache.log4j.*;

public class StringSplitter
{
	static Logger logger = Logger.getLogger(StringSplitter.class);
	
	private static StringSplitter split;

	public final String delimit = " \t\n\r\f~!@#$%^&*()_+|`-=\\{}[]:\";'<>?,./'";

	private StringSplitter() {}

	public static StringSplitter getStringSplitter()
	{
		if (split == null) 
			split = new StringSplitter();
		
		return split;
	}

	public String splitByDelimit(String s) 
	{
		StringTokenizer tokens = new StringTokenizer(s, delimit);
		List<String> list = new LinkedList<String>();
		while (tokens.hasMoreTokens()) {
			String str = tokens.nextToken();
			int i = 0, j = 0;
			while (i < str.length() - 1) {
				char cur = str.charAt(i);
				char next = str.charAt(i + 1);
				if (Character.isLowerCase(cur) 
						&& Character.isUpperCase(next)) {
					list.add(str.substring(j, i + 1));
					j = i + 1;
				}
				++i;
			}
			list.add(str.substring(j, i + 1)); //.toLowerCase());
		}
		String t = "";
		for (int i = 0; i < list.size(); ++i) 
			t += list.get(i) + " ";
		
		return t.trim();
	}
}
