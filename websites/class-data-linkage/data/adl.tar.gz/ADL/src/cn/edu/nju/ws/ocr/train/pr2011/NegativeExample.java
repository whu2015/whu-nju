package cn.edu.nju.ws.ocr.train.pr2011;

import java.sql.*;
import java.util.*;
import java.util.concurrent.*;
import org.apache.log4j.*;
import cn.edu.nju.ws.ocr.datab.*;
import cn.edu.nju.ws.ocr.prep.btc.*;
import cn.edu.nju.ws.ocr.train.btc.*;

public class NegativeExample
{
	static Logger logger = Logger.getLogger(NegativeExample.class);
	
	public void execNegExam1()
	{
		try {
			Connection connPR = DBConnPool.getPR();
			String sqlstr1 = "SELECT instance_uri_id1,instance_uri_id2 FROM positive_persons1 WHERE fold_id=?";
			PreparedStatement stmt1 = connPR.prepareStatement(sqlstr1);
			
			int typeURIID = 110;
			
			Map<Integer, Set<Integer>> instURIIDs = Collections.synchronizedMap(
					new HashMap<Integer, Set<Integer>>());
			stmt1.setInt(1, typeURIID);
			ResultSet rs1 = stmt1.executeQuery();
			while (rs1.next()) {
				int instURIID = rs1.getInt(1);
				int corefURIID = rs1.getInt(2);
				if (instURIIDs.containsKey(instURIID)) {
					Set<Integer> corefURIIDs = instURIIDs.get(instURIID);
					corefURIIDs.add(corefURIID);
				} else {
					Set<Integer> corefURIIDs = Collections.synchronizedSet(new HashSet<Integer>());
					corefURIIDs.add(corefURIID);
					instURIIDs.put(instURIID, corefURIIDs);
				}
			}
			rs1.close();
			stmt1.close();
			
			String sqlstr2 = "SELECT DISTINCT s FROM person12_quadruple WHERE p=? AND o=? AND s LIKE 'u%';";
			PreparedStatement stmt2 = connPR.prepareStatement(sqlstr2);
			
			Set<Integer> uriIDs = Collections.synchronizedSet(new HashSet<Integer>());
			Map<Integer, String[]> uris = Collections.synchronizedMap(new HashMap<Integer, String[]>());
			stmt2.setString(1, "u" + 2);
			stmt2.setString(2, "u" + 3);
			ResultSet rs2 = stmt2.executeQuery();
			while (rs2.next()) {
				String s = rs2.getString(1);
				int uriID = Integer.parseInt(s.substring(1));
				uriIDs.add(uriID);
			}
			rs2.close();
			stmt2.close();
			connPR.close();
			
			BlockingQueue<Runnable> queue = new LinkedBlockingQueue<Runnable>();  
			ThreadPoolExecutor exec = new ThreadPoolExecutor(4, 5, 7, TimeUnit.DAYS, queue);
			for (int instURIID : instURIIDs.keySet()) {
				NegExamThread1 net1 = new NegExamThread1(
						typeURIID, instURIID, instURIIDs.get(instURIID), uriIDs, uris);
				exec.execute(net1);
			}
			exec.shutdown();
		} catch (SQLException e) {
			logger.error(e.getMessage());
		}
	}
	
	
	public static void main(String args[])
	{
		PropertyConfigurator.configure("./config/log4j.properties");
		DBParam.init();
		
		NegativeExample ne = new NegativeExample();
		//ne.execNegExam1();
		ne.execNegExam1();
	}
	
	public class NegExamThread1 implements Runnable
	{
		private int typeURIID;
		private int instURIID;
		private Set<Integer> posURIIDs;
		private Set<Integer> negURIIDs;
		private Map<Integer, String[]> uris; 
		
		public NegExamThread1(int tid, int uid, 
				Set<Integer> pids, Set<Integer> nids, Map<Integer, String[]> uris)
		{
			this.typeURIID = tid;
			this.instURIID = uid;
			this.posURIIDs = pids;
			this.negURIIDs = nids;
			this.uris = uris;
		}
		
		public void run()
		{
			try {
				logger.debug("type_uri_id=" + typeURIID + ", inst_uri_id=" + instURIID);
					
				Connection connPR = DBConnPool.getPR();
				String sqlstr1 = "INSERT IGNORE INTO negative_persons1 VALUES(?,?,?,?,?,?);";
				PreparedStatement stmt1 = connPR.prepareStatement(sqlstr1);
					
				String[] instQName = null;
				if (uris.containsKey(instURIID)) {
					instQName = uris.get(instURIID);
				} else {
					instQName = PRNameFinder.Qname(instURIID, "person11_uri");
					uris.put(instURIID, instQName);
				}
				for (int negURIID : negURIIDs) {
					if (!posURIIDs.contains(negURIID) && instURIID != negURIID) {
						String[] negQName = null;
						if (uris.containsKey(negURIID)) {
							negQName = uris.get(negURIID);
						} else {
							negQName = PRNameFinder.Qname(negURIID, "person12_uri");
							uris.put(negURIID, negQName);
						}
						if (instQName[0].equals(negQName[0])) {
							stmt1.setInt(1, typeURIID);
							stmt1.setInt(2, 15);
							stmt1.setInt(3, 3);
							stmt1.setInt(4, instURIID);
							stmt1.setInt(5, negURIID);
							int letterMatch = 0;
							for(int i = 14; i<instQName[1].length() && i<negQName[1].length(); i++){
								
								if (instQName[1].charAt(i) != negQName[1].charAt(i)) {
									break;
								}
								letterMatch++;
							}
							logger.debug(instQName[1]+ " " + negQName[1] + " || "+letterMatch);
							if(letterMatch >= 0){
								stmt1.setInt(6, letterMatch);
								stmt1.addBatch();
							}
						}
						
					}
				}
				stmt1.executeBatch();
				stmt1.close();
				connPR.close();
			} catch (SQLException e) {
				logger.error(e.getMessage());
			}
		}
	}
	

}
