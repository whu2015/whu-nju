package cn.edu.nju.ws.ocr.train.btc;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.sql.*;
import java.util.Collections;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.Map;
import java.util.Set;
import org.apache.log4j.Logger;
import org.apache.log4j.PropertyConfigurator;

import cn.edu.nju.ws.ocr.datab.DBConnPool;
import cn.edu.nju.ws.ocr.datab.DBParam;
import cn.edu.nju.ws.ocr.nlp.StringReplace;
import cn.edu.nju.ws.ocr.prep.btc.BTC_SpecialProp;


public class BTC_Evaluator2 {
	static Logger logger = Logger.getLogger(BTC_Evaluator2.class);
	/**
	 * @param args
	 */
	
	Set<Integer> BTC_StopPropURIIDs = new HashSet<Integer>();
	Set<Integer> tempCorefURIIDs = new HashSet<Integer>();
	Set<Integer> goldenCorefURIIDs = new HashSet<Integer>();
	int propCount = 10;
	
	BTC_Evaluator2(){
		
		BTC_StopPropURIIDs.add(596219);
		BTC_StopPropURIIDs.add(1603);
		BTC_StopPropURIIDs.add(966216);
		BTC_StopPropURIIDs.add(1235);
		BTC_StopPropURIIDs.add(129);
		BTC_StopPropURIIDs.add(1133);
		BTC_StopPropURIIDs.add(2195239);
		BTC_StopPropURIIDs.add(334267);
		BTC_StopPropURIIDs.add(3000);
		BTC_StopPropURIIDs.add(2538963);
		BTC_StopPropURIIDs.add(2623251);
		BTC_StopPropURIIDs.add(1985720);
		BTC_StopPropURIIDs.add(1782);
		BTC_StopPropURIIDs.add(377827);
		BTC_StopPropURIIDs.add(3014);
		BTC_StopPropURIIDs.add(130);
		BTC_StopPropURIIDs.add(2494046);
//		BTC_StopPropURIIDs.add(231);
		BTC_StopPropURIIDs.add(2492072);
		BTC_StopPropURIIDs.add(2490455);
//		BTC_StopPropURIIDs.add(2195292);
		BTC_StopPropURIIDs.add(244);
//		BTC_StopPropURIIDs.add(2195287);
//		BTC_StopPropURIIDs.add(2195239);
//		BTC_StopPropURIIDs.add(1985714);
		BTC_StopPropURIIDs.add(124);
		BTC_StopPropURIIDs.add(58892);
		BTC_StopPropURIIDs.add(1404);
		
	}
	
	void evaluator2(String uri ,String type){
		
		try {	
			
			int uriID = BTC_NameFinder.uriID(uri);
			
			Connection connBTC2011 = DBConnPool.getBTC2011();
			
			int[] propArray = new int[propCount*2];
			Statement stmt3 = connBTC2011.createStatement();
			ResultSet rs3 = stmt3.executeQuery("select prop_id1,prop_id2 from btc.btc2011_stattest_"+type+"_pp_infogain order by info_gain desc");
			for (int i=0; i<propCount; i++){
				rs3.next();
				propArray[2*i] = rs3.getInt(1);
				propArray[2*i+1] = rs3.getInt(2);
				//logger.info(BTC_NameFinder.uri(propArray[2*i]) + BTC_NameFinder.uri(propArray[2*i+1]));
			}
			
			String sqlstr1 = null, sqlstr2 = null, sqlstr4 = null;
			sqlstr1 = "SELECT DISTINCT o FROM  btc2011_quadruple " 
						+ "WHERE s=? AND p=? AND o NOT LIKE 'b%';";
			sqlstr2 = "SELECT distinct s FROM  btc2011_quadruple " 
					   	+ "WHERE p=? AND o =?;";
			sqlstr4 = "SELECT uri_id FROM  btc2011_localname " 
					   	+ "WHERE localname =?;";

			PreparedStatement stmt1 = connBTC2011.prepareStatement(sqlstr1);
			PreparedStatement stmt2 = connBTC2011.prepareStatement(sqlstr2);
			PreparedStatement stmt4 = connBTC2011.prepareStatement(sqlstr4);
			
			Instance inst = new Instance(uriID);
			for(int i=0 ; i<propCount;i++){				
				stmt1.setString(1, "u" + uriID);
				stmt1.setString(2, "u" + propArray[2*i]);
				ResultSet rs1 = stmt1.executeQuery();
				while (rs1.next()) {
					String o = rs1.getString(1);
					inst.addPropValue(propArray[2*i], o);
				}
				rs1.close();
			}
			
			int tempCorefURIID = -1;
			for(int i=0 ; i<propCount;i++){
				//logger.info("--------------------propURIID1: "+propArray[2*i]+" propURIID2: "+propArray[2*i+1]);
				if(inst.propValues.get(propArray[2*i]) != null && !BTC_StopPropURIIDs.contains(propArray[2*i]) && !BTC_StopPropURIIDs.contains(propArray[2*i+1])){
					
					for(String obj:inst.propValues.get(propArray[2*i])){
						if(propArray[2*i] == BTC_SpecialProp.OWL_sameAs_ID){
							tempCorefURIID =  Integer.parseInt(obj.substring(1));
							if(!tempCorefURIIDs.contains(tempCorefURIID)){
								logger.info("propURIID: "+propArray[2*i]+" obj: "+obj+" corefURI: "+ BTC_NameFinder.uri(tempCorefURIID));
								tempCorefURIIDs.add(tempCorefURIID);
								//fetchWikiPageRedirects(tempCorefURIID,tempCorefURIIDs);
							}
							
						}
						if(!obj.equals("l") && !obj.equals("l ")){
							stmt2.setString(1, "u" + propArray[2*i+1]);
							stmt2.setString(2, obj);
							ResultSet rs2 = stmt2.executeQuery();
							while (rs2.next()) {
								if(rs2.getString(1).startsWith("u")){
									tempCorefURIID = Integer.parseInt(rs2.getString(1).substring(1));
									if(!tempCorefURIIDs.contains(tempCorefURIID)){
										logger.info("propURIID1: "+propArray[2*i]+" propURIID2: "+propArray[2*i+1]+" obj: "+obj+" corefURI: "+ BTC_NameFinder.uri(tempCorefURIID));
										tempCorefURIIDs.add(tempCorefURIID);
										//fetchWikiPageRedirects(tempCorefURIID,tempCorefURIIDs);
									}
								}
							}
							
							stmt2.setString(1, "u" + propArray[2*i]);
							stmt2.setString(2, obj);
							rs2 = stmt2.executeQuery();
							while (rs2.next()) {
								if(rs2.getString(1).startsWith("u")){
									tempCorefURIID = Integer.parseInt(rs2.getString(1).substring(1));
									if(!tempCorefURIIDs.contains(tempCorefURIID)){
										logger.info("propURIID1: "+propArray[2*i]+" propURIID2: "+propArray[2*i]+" obj: "+obj+" corefURI: "+ BTC_NameFinder.uri(tempCorefURIID));
										tempCorefURIIDs.add(tempCorefURIID);
										//fetchWikiPageRedirects(tempCorefURIID,tempCorefURIIDs);
									}
								}
							}							
							rs2.close();
						}
					}
					
				}
			}
			
			stmt1.setString(1, "u"+uriID);
			stmt1.setString(2, "u"+BTC_SpecialProp.OWL_sameAs_ID);
			ResultSet rs1 = stmt1.executeQuery();
			while(rs1.next()){
				if(rs1.getString(1).startsWith("u")){
					tempCorefURIID = Integer.parseInt(rs1.getString(1).substring(1));
					if(!tempCorefURIIDs.contains(tempCorefURIID)){
						logger.info(BTC_NameFinder.uri(tempCorefURIID));
						tempCorefURIIDs.add(tempCorefURIID);
						//fetchWikiPageRedirects(tempCorefURIID,tempCorefURIIDs);
					}
				}
			}
			
			stmt2.setString(1, "u"+BTC_SpecialProp.OWL_sameAs_ID);
			stmt2.setString(2, "u"+uriID);
			ResultSet rs2 = stmt2.executeQuery();
			while (rs2.next()) {
				if(rs2.getString(1).startsWith("u")){
					tempCorefURIID = Integer.parseInt(rs2.getString(1).substring(1));
					if(!tempCorefURIIDs.contains(tempCorefURIID)){
						logger.info(BTC_NameFinder.uri(tempCorefURIID));
						tempCorefURIIDs.add(tempCorefURIID);
						//fetchWikiPageRedirects(tempCorefURIID,tempCorefURIIDs);
					}
				}
			}
			rs2.close();
			
//			String localname= BTC_NameFinder.localname(uriID);
//			stmt4.setString(1, localname);
//			ResultSet rs4 = stmt4.executeQuery();
//			while (rs4.next()){
//				tempCorefURIID = rs4.getInt(1);
//				if(!tempCorefURIIDs.contains(tempCorefURIID)){
//					//logger.info("by localname:  "+localname);
//					System.out.println(BTC_NameFinder.uri(tempCorefURIID));
//					tempCorefURIIDs.add(tempCorefURIID);
//					//fetchWikiPageRedirects(tempCorefURIID,tempCorefURIIDs);
//				}
//			}
//			rs4.close();
			
			stmt1.close();
			stmt2.close();
			stmt4.close();
			connBTC2011.close();
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
	void goldenLoad(String id){
		
		File file = new File("./data/golden_standard/"+id+".txt");
		BufferedReader reader = null;
		try{
			reader = new BufferedReader(new FileReader(file));
			String tempString = null;
			
			while((tempString = reader.readLine()) != null){
				goldenCorefURIIDs.add(BTC_NameFinder.uriID(tempString));
			}
			reader.close();
		}catch(FileNotFoundException e){
			e.printStackTrace();
		}catch(IOException e){
			e.printStackTrace();
		}
	}
	
	void difference(Set<Integer> setA, Set<Integer> setB, String out) {
        int s = 0;
        Iterator<Integer> iterA = setA.iterator();
        while (iterA.hasNext()) {
            s = iterA.next();
            if(!setB.contains(s)) {
                logger.info("--------"+out+": "+BTC_NameFinder.uri(s));
            }
        }
    }
	
	public class Instance
	{
		public int uriID;
		public Map<Integer, Set<String>> propValues;
		
		public Instance(int uid)
		{
			this.uriID = uid;
			this.propValues = new HashMap<Integer, Set<String>>();
		}
		
		public void addPropValue(int pid, String v)
		{
			if (propValues.containsKey(pid)) {
				Set<String> values = propValues.get(pid);
				values.add(v);
			} else {
				Set<String> values = new HashSet<String>();
				values.add(v);
				propValues.put(pid, values);
			}
		}
	}
	
	
//	public static int fetchWikiPageRedirects(int uriID,Set<Integer> rset){
//		try {
//			Connection connBTC2011 = DBConnPool.getBTC2011();
//			String sqlstr1 = "SELECT s FROM btc.btc2011_quadruple where p = ? and o = ?;";
//			PreparedStatement stmt1 = connBTC2011.prepareStatement(sqlstr1);
//			stmt1.setString(1, "u"+205859);
//			stmt1.setString(2, "u"+uriID);
//			ResultSet rs1 = stmt1.executeQuery();
//			int redirectURIID = -1;
//			while(rs1.next()){
//				redirectURIID = Integer.parseInt(rs1.getString(1).substring(1));
//				rset.add(redirectURIID);
//				logger.info(BTC_NameFinder.uri(redirectURIID));
//			}
//			rs1.close();
//			stmt1.close();
//			connBTC2011.close();
//			return redirectURIID;
//			
//		} catch (SQLException e) {
//			// TODO Auto-generated catch block
//			e.printStackTrace();
//		}
//		return -1;
//	}
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		PropertyConfigurator.configure("./config/log4j.properties");
		DBParam.init();

		BTC_Evaluator2 e = new BTC_Evaluator2();
		//e.NytGeonamesEvaluator1();
		long startTime = System.currentTimeMillis(); 
		e.evaluator2("http://www.w3.org/People/Berners-Lee/card#i","person");
		long endTime = System.currentTimeMillis();  
		
		e.goldenLoad("1");
		e.difference(e.goldenCorefURIIDs, e.tempCorefURIIDs, "miss");
		e.difference(e.tempCorefURIIDs, e.goldenCorefURIIDs, "wrong");
		System.out.println("程序运行时间：" + (endTime - startTime) + "ms");    //输出程序运行时间  
		//e.Evaluator2Counters("persons2");
		
		for(int uriID:e.tempCorefURIIDs){
			System.out.println(BTC_NameFinder.uri(uriID));
		}
	}

}
