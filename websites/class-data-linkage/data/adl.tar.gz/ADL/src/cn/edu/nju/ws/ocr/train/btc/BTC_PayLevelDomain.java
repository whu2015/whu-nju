package cn.edu.nju.ws.ocr.train.btc;

import java.net.*;
import java.sql.*;
import java.util.HashMap;
import java.util.Map;

import org.apache.log4j.*;
import org.apache.nutch.util.*;
import cn.edu.nju.ws.ocr.datab.*;

public class BTC_PayLevelDomain 
{
	static Logger logger = Logger.getLogger(BTC_PayLevelDomain.class);
	
	public static String getPLDName(String lexicalURL) 
	{
		if (lexicalURL == null || lexicalURL.trim().equals("")
				|| !lexicalURL.startsWith("http://"))
			return null;
		
		try {
			return URLUtil.getDomainName(lexicalURL);
		} catch (MalformedURLException e) {
			logger.error(e.getMessage());
			return null;
		}
	}
	

	public void test()
	{
		try {
			Connection connBTC2011 = DBConnPool.getBTC2011();
			String sqlstr1 = "SELECT s,p FROM btc2011_ifp_triple WHERE p='u1057' OR p='u127'";
			PreparedStatement stmt1 = connBTC2011.prepareStatement(sqlstr1);
			String sqlstr2 = "SELECT uri FROM btc2011_uri WHERE uri_id=?";
			PreparedStatement stmt2 = connBTC2011.prepareStatement(sqlstr2);
			
			Map<String, Integer> mbox = new HashMap<String, Integer>();
			Map<String, Integer> mbox_sha1sum = new HashMap<String, Integer>();
			ResultSet rs1 = stmt1.executeQuery();
			while (rs1.next()) {
				String s = rs1.getString(1), p = rs1.getString(2);
				int uriID = Integer.parseInt(s.substring(1));
				String pld = null;
				stmt2.setInt(1, uriID);
				ResultSet rs2 = stmt2.executeQuery();
				while (rs2.next()) {
					String uri = rs2.getString(1);
					pld = getPLDName(uri);
				}
				rs2.close();
				System.out.println(uriID);
				if (p.equals("u1057")) {
					if (mbox.containsKey(pld)) {
						mbox.put(pld, mbox.get(pld) + 1);
					} else mbox.put(pld, 1);
				} else {
					if (mbox_sha1sum.containsKey(pld)) {
						mbox_sha1sum.put(pld, mbox_sha1sum.get(pld) + 1);
					} else mbox_sha1sum.put(pld, 1);
				}
			}
			rs1.close();
			
			for (String pld : mbox.keySet())
				System.out.println("PLD=" + pld + ", " + mbox.get(pld));
			System.out.println("--");
			for (String pld : mbox_sha1sum.keySet())
				System.out.println("PLD=" + pld + ", " + mbox_sha1sum.get(pld));
			
			stmt1.close();
			stmt2.close();
			connBTC2011.close();
		} catch (SQLException e) {
			logger.error(e.getMessage());
		}
	}
	
	public void addPLD(String className, int pos){
		try{
			Connection connBTC2011 = DBConnPool.getBTC2011();
			String query1 = null, query2 = null;
			if(pos == 1){
				query1 = "select distinct uri_id1 from btc2011_stattest_"+className+"_pp";
				query2 = "update btc2011_stattest_"+className+"_pp set pld = ? where uri_id1 = ?";
			}
			else{
				query1 = "select distinct uri_id1 from btc2011_stattest_"+className+"_pp_neg";
				query2 = "update btc2011_stattest_"+className+"_pp_neg set pld = ? where uri_id1 = ?";
			}
				
			Statement stmt1 = connBTC2011.createStatement();
			PreparedStatement stmt2 = connBTC2011.prepareStatement(query2);
			ResultSet rs1 = stmt1.executeQuery(query1);
			int count = 0;
			while(rs1.next()){
				String pld = getPLDName(BTC_NameFinder.uri(rs1.getInt(1)));
				if(pld != null){
					stmt2.setString(1, pld);
					stmt2.setInt(2, rs1.getInt(1));
					stmt2.addBatch();
				}
				logger.debug(++count);
			}
			stmt2.executeBatch();
			stmt1.close();
			stmt2.close();
			connBTC2011.close();
		}
		catch(SQLException e){
			logger.error(e.getMessage());
		}
		
	}
	
	public static void main(String args[])
	{
		PropertyConfigurator.configure("./config/log4j.properties");
		DBParam.init();
		
		/* try {
			Connection connBTC2011 = DBConnPool.getBTC2011();
			String sqlstr1 = "SELECT st.uri_id,u.uri FROM btc2011_stattest_webservices st LEFT OUTER JOIN btc2011_uri u ON st.uri_id=u.uri_id";
			PreparedStatement stmt1 = connBTC2011.prepareStatement(sqlstr1);
			String sqlstr2 = "UPDATE btc2011_stattest_webservices SET pld=? WHERE uri_id=?";
			PreparedStatement stmt2 = connBTC2011.prepareStatement(sqlstr2);
			
			ResultSet rs1 = stmt1.executeQuery();
			while (rs1.next()) {
				int uriID = rs1.getInt(1);
				String uri = rs1.getString(2);
				String pld = BTC_PayLevelDomain.getPLDName(uri);
				stmt2.setString(1, pld);
				stmt2.setInt(2, uriID);
				stmt2.executeUpdate();
			}
			rs1.close();
			stmt1.close();
			stmt2.close();
			connBTC2011.close();
		} catch (SQLException e) {
			logger.error(e.getMessage());
		} */
		new BTC_PayLevelDomain().addPLD("film",-1);
	}
}
