package cn.edu.nju.ws.ocr.train.pr2011;

import java.sql.*;

import org.apache.log4j.*;
import cn.edu.nju.ws.ocr.datab.*;

public class PRNameFinder 
{
	static Logger logger = Logger.getLogger(PRNameFinder.class);
	
	public static String URI(int uriID, String dbname)
	{
		try {
			//logger.debug(dbname);
			Connection connPR = DBConnPool.getPR();
			String sqlstr1 = "SELECT uri FROM "+dbname+" WHERE uri_id=?";
			
			PreparedStatement stmt1 = connPR.prepareStatement(sqlstr1);
			
			String uri = null;
			stmt1.setInt(1, uriID);
			ResultSet rs1 = stmt1.executeQuery();
			while (rs1.next()) {
				uri = rs1.getString(1);
			}
			rs1.close();
			stmt1.close();
			connPR.close();
			return uri;
		} catch (SQLException e) {
			logger.error(e.getMessage());
			return null;
		}
	}
	
	public static String[] Qname(int uriID, String dbname)
	{
		String uri = URI(uriID, dbname);
		
		if (uri == null || uri.trim().equals("")) {
			return null;
		} else {
			String namespace = null, localname = null;
			int index = uri.lastIndexOf("#");
			if (index != -1) {
				namespace = uri.substring(0, index + 1);
				localname = uri.substring(index + 1);
			} else {
				index = uri.lastIndexOf("/");
				if (index != -1) {
					namespace = uri.substring(0, index + 1);
					localname = uri.substring(index + 1);
				} else {
					index = uri.lastIndexOf(":");
					if (index != -1) {
						namespace = uri.substring(0, index + 1);
						localname = uri.substring(index + 1);
					}
				}
			}
			String[] qname = {namespace, localname};
			return qname;
		}
	}
	
	public static String nameLabel(int uriID, String dbname, int pid)
	{
		try {
			//logger.debug(dbname);
			Connection connPR = DBConnPool.getPR();
			String sqlstr1 = "SELECT o FROM "+dbname+"_quadruple WHERE s=? and p=?";
			
			PreparedStatement stmt1 = connPR.prepareStatement(sqlstr1);
			
			String label = null;
			stmt1.setString(1, "u"+uriID);
			stmt1.setString(2, "u"+pid);
			ResultSet rs1 = stmt1.executeQuery();
			while (rs1.next()) {
				label = rs1.getString(1);
			}
			rs1.close();
			stmt1.close();
			connPR.close();
			if(label != null)
				return label.substring(1);
			else
				return null;
		} catch (SQLException e) {
			logger.error(e.getMessage());
			return null;
		}
	}
}

