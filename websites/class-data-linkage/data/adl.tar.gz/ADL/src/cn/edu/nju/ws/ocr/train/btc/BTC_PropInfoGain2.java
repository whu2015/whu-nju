package cn.edu.nju.ws.ocr.train.btc;

import java.sql.*;
import java.util.*;

import org.apache.log4j.Logger;
import org.apache.log4j.PropertyConfigurator;

import cn.edu.nju.ws.ocr.datab.DBConnPool;
import cn.edu.nju.ws.ocr.datab.DBParam;
import cn.edu.nju.ws.ocr.train.btc.BTC_NameFinder;


class Point2{
	int propURIID1;
    int propURIID2;
    double infoGain;
  
    public Point2( int x,int y,double z){
        this.propURIID1 = x;
        this.propURIID2 = y;
        this.infoGain = z;
    }   
    
    
    public void print(){
        System.out.println("\t" + BTC_NameFinder.uri(propURIID1)+"(" +propURIID1 +")" + "\t"+ BTC_NameFinder.uri(propURIID2)+"(" +propURIID2 +")"+"\t" + infoGain );
    }

}

public class BTC_PropInfoGain2 {
	
	static Logger logger = Logger.getLogger(BTC_PropInfoGain2.class);
	
	double threshold = 0.9;
	String type;
	String pld;
	private double infoD = 0;
	int negNum;
    int posNum;
    int sumNum;
    
	PriorityQueue<Point2> queue = new PriorityQueue<Point2>( 1, new Comparator<Point2>(){
		public int compare( Point2 a, Point2 b ){
			if( a.infoGain < b.infoGain ){
				return 1;
            }
            else if( a.infoGain == b.infoGain ){
                return 0;
            }
            else{
                return -1;
            }
        }
    });
	
	BTC_PropInfoGain2(String type, String pld){
		this.type = type;
		this.pld = pld;
		try {
			Connection connBTC2011 = DBConnPool.getBTC2011();
			String query1 = "SELECT count(distinct uri_id1,uri_id2) FROM btc.btc2011_stattest_"+type+"_pp_neg where pld = ?";
			PreparedStatement stmt1 = connBTC2011.prepareStatement(query1);
			String query2 = "SELECT count(distinct uri_id1,uri_id2) FROM btc.btc2011_stattest_"+type+"_pp where pld = ?";
			PreparedStatement stmt2 = connBTC2011.prepareStatement(query2);
			
			stmt1.setString(1, pld);
			ResultSet rs1 = stmt1.executeQuery();
			rs1.next();
			this.negNum = rs1.getInt(1);
			stmt2.setString(1, pld);
			ResultSet rs2 = stmt2.executeQuery();
			rs2.next();
			this.posNum = rs2.getInt(1);
			this.sumNum = this.negNum + this.posNum;
			rs1.close();
			rs2.close();
			stmt1.close();
			stmt2.close();
			connBTC2011.close();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}	
		info();
	}
	
	private void info(){		
		infoD =  -((double)posNum/sumNum)*Math.log((double)posNum/sumNum) - ((double)negNum/sumNum)*Math.log((double)negNum/sumNum);
	}
	
	public double info(int propURIID1, int propURIID2){
		try {
			Connection connBTC2011 = DBConnPool.getBTC2011();
			String query1 = "SELECT uri_id1, uri_id2 FROM btc.btc2011_stattest_"+type+"_pp " +
					"where prop_id1 = ? and prop_id2 = ? and sim >= ? and pld = ?;";
			PreparedStatement stmt1 = connBTC2011.prepareStatement(query1);
			String query2 = "SELECT uri_id1, uri_id2 FROM btc.btc2011_stattest_"+type+"_pp_neg " +
					"where prop_id1 = ? and prop_id2 = ? and sim >= ? and pld = ?;";
			PreparedStatement stmt2 = connBTC2011.prepareStatement(query2);
			
			Set<Integer> countSet = new HashSet<Integer>();
			countSet.clear();
			
			stmt1.setInt(1, propURIID1);
			stmt1.setInt(2, propURIID2);
			stmt1.setDouble(3, threshold);
			stmt1.setString(4, pld);
			ResultSet rs1 = stmt1.executeQuery(); 
			while(rs1.next()){
				countSet.add(rs1.getInt(1)+rs1.getInt(2));
			}
			int posNumP = countSet.size();
			int posNumN = posNum - posNumP;
			countSet.clear();
			
			stmt2.setInt(1, propURIID1);
			stmt2.setInt(2, propURIID2);
			stmt2.setDouble(3, threshold);
			stmt2.setString(4, pld);
			ResultSet rs2 = stmt2.executeQuery();
			while(rs2.next()){
				//int temp[] = {rs1.getInt(1),rs1.getInt(2)};
				countSet.add(rs2.getInt(1)+rs2.getInt(2));
			}
			int negNumP = countSet.size();
			int negNumN = negNum - negNumP;
			
			int sumNumP = posNumP + negNumP;
			int sumNumN = posNumN + negNumN;
			
			logger.info(propURIID1+ " " +propURIID2+ " "+ posNumP + " " + negNumP);
			rs1.close();
			rs2.close();
			stmt1.close();
			stmt2.close();
			connBTC2011.close();
			if(posNumP != 0 && negNumP != 0 && posNumN != 0 && negNumN != 0)			
				return ((double)sumNumP/sumNum)*(-((double)posNumP/sumNumP)*Math.log((double)posNumP/sumNumP) - ((double)negNumP/sumNumP)*Math.log((double)negNumP/sumNumP)) + 
					   ((double)sumNumN/sumNum)*(-((double)posNumN/sumNumN)*Math.log((double)posNumN/sumNumN) - ((double)negNumN/sumNumN)*Math.log((double)negNumN/sumNumN));
			else if(posNumP != 0 && negNumP != 0)
				return ((double)sumNumP/sumNum)*(-((double)posNumP/sumNumP)*Math.log((double)posNumP/sumNumP) - ((double)negNumP/sumNumP)*Math.log((double)negNumP/sumNumP));
			else if(posNumN != 0 && negNumN != 0)
				return ((double)sumNumN/sumNum)*(-((double)posNumN/sumNumN)*Math.log((double)posNumN/sumNumN) - ((double)negNumN/sumNumN)*Math.log((double)negNumN/sumNumN));
			else
				return 0;
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return 0;
	}
	
//	public double splitInfo(int prop_uri_id, int threshold){
//		try {
//			Connection connDC7900 = DBConnPool.getDC7900();
//			Statement stmt1 = connDC7900.createStatement();
//			
//
//			int sumNum = negNum + posNum;
//			logger.info("negNum = " + negNum + " posNum = " + posNum + " sumNum = "+sumNum);
//					
//			infoD =  -((double)posNum/sumNum)*Math.log((double)posNum/sumNum) - ((double)negNum/sumNum)*Math.log((double)negNum/sumNum);
//
//		} catch (SQLException e) {
//			// TODO Auto-generated catch block
//			e.printStackTrace();
//		}
//	}

	public void GenPropPQ(){
		try {
			Connection connBTC2011 = DBConnPool.getBTC2011();
			String query1 = "SELECT distinct prop_id1,prop_id2 FROM btc2011_stattest_"+type+"_pp where pld = ?";
			PreparedStatement stmt1 = connBTC2011.prepareStatement(query1);
			String query2 = "SELECT distinct prop_id1,prop_id2 FROM btc2011_stattest_"+type+"_pp_neg where pld = ?";
			PreparedStatement stmt2 = connBTC2011.prepareStatement(query2);
			
			stmt1.setString(1, pld);
			ResultSet rs1 = stmt1.executeQuery();
			while(rs1.next()){
//				logger.info("positive property_uri_id1 "+ rs1.getInt(1));
				Point2 temp = new Point2(rs1.getInt(1),rs1.getInt(2), infoD-info(rs1.getInt(1),rs1.getInt(2)) );
				queue.add(temp);
			}
			stmt2.setString(1, pld);
			ResultSet rs2 = stmt2.executeQuery();
			while(rs2.next()){
				//logger.info("negative property_uri_id1 "+ rs1.getInt(1));
				if(!PQcontains(rs2.getInt(1),rs2.getInt(2))){
					Point2 temp = new Point2(rs2.getInt(1),rs2.getInt(2), infoD-info(rs2.getInt(1),rs2.getInt(2)) );
					queue.add(temp);
				}
			}
			
			rs1.close();
			rs2.close();
			stmt1.close();
			stmt2.close();
			connBTC2011.close();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
	public boolean PQcontains(int x,int y){
		Iterator<Point2> it = queue.iterator();
		while(it.hasNext()){
			Point2 temp = it.next();
			if(x == temp.propURIID1 && y == temp.propURIID2)
				return true;
		}
		return false;
	}
	
	public void printPQ(){
		System.out.println( type);
		int count = 20;
		while( queue.size() > 0 && count > 0){
            Point2 p = ( Point2 )queue.poll();
            count--;
            p.print();
            
        }
	}
	
	public void storePQtoDB(){
		try {
			Connection connBTC2011 = DBConnPool.getBTC2011();
			String insertQuery = "insert into btc.btc2011_stattest_"+type+"_pp_infogain values(?,?,?)";
			PreparedStatement stmt1 = connBTC2011.prepareStatement(insertQuery);
			Statement stmt2 = connBTC2011.createStatement();
			stmt2.executeUpdate("truncate  btc.btc2011_stattest_"+type+"_pp_infogain");
			
			int count = 20;
			while( queue.size() > 0 && count > 0){
	            Point2 p = ( Point2 )queue.poll();
	            count--;
	            p.print();
	            stmt1.setInt(1, p.propURIID1);
	            stmt1.setInt(2, p.propURIID2);
	            stmt1.setDouble(3, p.infoGain);
	            stmt1.addBatch();
	        }
			stmt1.executeBatch();
			stmt1.close();
			stmt2.close();
			connBTC2011.close();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
	public static void printPQ2(String type){
		try {
			Connection connBTC2011 = DBConnPool.getBTC2011();
			String sqlstr1 = "select * from btc2011_stattest_"+type+"_pp_infogain order by info_gain desc limit 20";
			PreparedStatement stmt1 = connBTC2011.prepareStatement(sqlstr1);
			ResultSet rs1 = stmt1.executeQuery();
			while(rs1.next()){
				System.out.println("\t" + BTC_NameFinder.uri(rs1.getInt(1))+"(" +rs1.getInt(1) +")" + "\t"+ BTC_NameFinder.uri(rs1.getInt(2))+"(" +rs1.getInt(2) +")"+"\t" + rs1.getFloat(3) );
			}
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
	public static void main(String[] args) {
		PropertyConfigurator.configure("./config/log4j.properties");
		DBParam.init();
		
		BTC_PropInfoGain2 ig = new BTC_PropInfoGain2("person","dbpedia.org");
		ig.GenPropPQ();
		ig.storePQtoDB();
		//BTC_PropInfoGain2.printPQ2("city");
	}

}
 