package cn.edu.nju.ws.ocr.train.btc;

import java.sql.*;
import org.apache.log4j.*;
import cn.edu.nju.ws.ocr.datab.*;

public class BTC_NameFinder 
{
	static Logger logger = Logger.getLogger(BTC_NameFinder.class);
	
	public static String uri(int uriID)
	{
		try {
			Connection connBTC2011 = DBConnPool.getBTC2011();
			String sqlstr1 = "SELECT uri FROM btc2011_uri WHERE uri_id=?";
			PreparedStatement stmt1 = connBTC2011.prepareStatement(sqlstr1);
			
			String uri = null;
			stmt1.setInt(1, uriID);
			ResultSet rs1 = stmt1.executeQuery();
			while (rs1.next()) 
				uri = rs1.getString(1);
			rs1.close();
			stmt1.close();
			connBTC2011.close();
			return uri;
		} catch (SQLException e) {
			logger.error(e.getMessage());
			return null;
		}
	}
	
	public static int uriID(String uri)
	{
		try {
			Connection connBTC2011 = DBConnPool.getBTC2011();
			String sqlstr1 = "SELECT uri_id FROM btc2011_uri WHERE uri=?";
			PreparedStatement stmt1 = connBTC2011.prepareStatement(sqlstr1);
			
			int uriID = 0;
			stmt1.setString(1, uri);
			ResultSet rs1 = stmt1.executeQuery();
			while (rs1.next()) 
				uriID = rs1.getInt(1);
			rs1.close();
			stmt1.close();
			connBTC2011.close();
			return uriID;
		} catch (SQLException e) {
			logger.error(e.getMessage());
			return 0;
		}
	}
	
	public static String namespace(int uriID)
	{
		String uri = uri(uriID);
			
		if (uri == null || uri.trim().equals("")) {
			return null;
		} else {
			String namespace = null;
			int index = uri.lastIndexOf("#");
			if (index != -1) {
				namespace = uri.substring(0, index + 1);
			} else {
				index = uri.lastIndexOf("/");
				if (index != -1) {
					namespace = uri.substring(0, index + 1);
				} else {
					index = uri.lastIndexOf(":");
					if (index != -1)
						namespace = uri.substring(0, index + 1);
				}
			}
			return namespace;
		}
	}
	
	public static String localname(int uriID)
	{
		String uri = uri(uriID);
		
		if (uri == null || uri.trim().equals("")) {
			return null;
		} else {
			String localname = null;
			int index = uri.lastIndexOf("#");
			if (index != -1) {
				localname = uri.substring(index + 1);
			} else {
				index = uri.lastIndexOf("/");
				if (index != -1) {
					localname = uri.substring(index + 1);
				} else {
					index = uri.lastIndexOf(":");
					if (index != -1)
						localname = uri.substring(index + 1);
				}
			}
			return localname;
		}
	}
	
	public static String[] qname(int uriID)
	{
		String uri = uri(uriID);
		
		if (uri == null || uri.trim().equals("")) {
			return null;
		} else {
			String namespace = null, localname = null;
			int index = uri.lastIndexOf("#");
			if (index != -1) {
				namespace = uri.substring(0, index + 1);
				localname = uri.substring(index + 1);
			} else {
				index = uri.lastIndexOf("/");
				if (index != -1) {
					namespace = uri.substring(0, index + 1);
					localname = uri.substring(index + 1);
				} else {
					index = uri.lastIndexOf(":");
					if (index != -1) {
						namespace = uri.substring(0, index + 1);
						localname = uri.substring(index + 1);
					}
				}
			}
			String[] qname = {namespace, localname};
			return qname;
		}
	}
	
	public static String[] qname(String uri)
	{
		if (uri == null || uri.trim().equals("")) {
			return null;
		} else {
			String namespace = null, localname = null;
			int index = uri.lastIndexOf("#");
			if (index != -1) {
				namespace = uri.substring(0, index + 1);
				localname = uri.substring(index + 1);
			} else {
				index = uri.lastIndexOf("/");
				if (index != -1) {
					namespace = uri.substring(0, index + 1);
					localname = uri.substring(index + 1);
				} else {
					index = uri.lastIndexOf(":");
					if (index != -1) {
						namespace = uri.substring(0, index + 1);
						localname = uri.substring(index + 1);
					}
				}
			}
			String[] qname = {namespace, localname};
			return qname;
		}
	}
}

