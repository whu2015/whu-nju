package cn.edu.nju.ws.ocr.train.nyt;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Iterator;
import java.util.TreeSet;

import org.apache.log4j.PropertyConfigurator;

import cn.edu.nju.ws.ocr.datab.DBConnPool;
import cn.edu.nju.ws.ocr.datab.DBParam;


public class IGmPVS {

	
	public void IGmPVS(int fid, double thd, int pcnt, String dbname) throws SQLException{
		
		TreeSet<Double> ts = new TreeSet<Double>();
		TreeSet<Double> ts1 = new TreeSet<Double>();
		
		Evaluator2 e = new Evaluator2(101,0.8,5);
		e.evaluator2(dbname);
		
		PropInfoGain ig = new PropInfoGain(dbname,fid);
		ig.GenPropPQ(thd);
		
		Point point[] = new Point[5];
		for (int i=0; i<pcnt&& ig.queue2.size()>0; i++){
			point[i] = ig.queue2.poll();
		}
		
		Connection connNYT2011 = DBConnPool.getNYT2011();
		String sqlstr1 = "select max(similarity) from positive_nyt_"+dbname+"_property_pair where instance_uri_id1 = ? and instance_uri_id2 = ? "
					+"and property_uri_id1 = ? and property_uri_id2 = ?";
		PreparedStatement stmt1 = connNYT2011.prepareCall(sqlstr1);
		
		for(int instURIID: e.instURIIDs.keySet()){
			for(int corefURIID: e.instURIIDs.get(instURIID)){
				if(corefURIID != -1){
					double tmp = 0, tmp1 = 0;
					for (int i=0; i<pcnt; i++){
					
						stmt1.setInt(1, instURIID);
						stmt1.setInt(2, corefURIID);
						stmt1.setInt(3, point[i].propURIID1);
						stmt1.setInt(4, point[i].propURIID2);
						ResultSet rs1 = stmt1.executeQuery();
						double sim  = 0;
						while(rs1.next()){
							sim = rs1.getDouble(1);
						}
						tmp += point[i].infoGain * sim;
						tmp1 += 0.2*sim;
					}
					if(tmp>0){
						ts.add(tmp);
					}
					if(tmp1>0)
						ts1.add(tmp1);
				}
			}
			
		}
		
		System.out.println("nyt_"+dbname+" threshold: "+thd+" property: "+pcnt+" type: "+fid);
		Iterator it =ts.iterator();
		int i = 0;
		while(it.hasNext() && i <5)
        {
              System.out.println(it.next());
              i++;
        }
		System.out.println("****************************************");
		Iterator it1 =ts1.iterator();
		i = 0;
		while(it.hasNext() && i <5)
        {
              System.out.println(it1.next());
              i++;
        }
	}
	/**
	 * @param args
	 * @throws SQLException 
	 */
	public static void main(String[] args) throws SQLException {
		// TODO Auto-generated method stub
		PropertyConfigurator.configure("./config/log4j.properties");
		DBParam.init();
		IGmPVS i = new IGmPVS();
		
		i.IGmPVS(101, 0.8, 5, "geonames");
		
	}

}
