package cn.edu.nju.ws.ocr.train.nyt;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Collections;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;
import java.util.concurrent.BlockingQueue;
import java.util.concurrent.LinkedBlockingQueue;
import java.util.concurrent.ThreadPoolExecutor;
import java.util.concurrent.TimeUnit;

import org.apache.log4j.Logger;
import org.apache.log4j.PropertyConfigurator;

import cn.edu.nju.ws.ocr.datab.DBConnPool;
import cn.edu.nju.ws.ocr.datab.DBParam;

class ClassInstancePair{
	
	int instanceURIID;
	int classURIID2;
	ClassInstancePair(int iuriid, int curiid){
		
		this.instanceURIID = iuriid;
		this.classURIID2 = curiid;
	}
	
}

public class NegativeExample {
	
	static Logger logger = Logger.getLogger(NegativeExample.class);
	private int nytRDFTypeID = 32;
	
	public void execNegExam1(String dbname, int foldID){
		try {
			Connection connNYT2011 = DBConnPool.getNYT2011();
			String sqlstr1 = "SELECT instance_uri_id1,instance_uri_id2,class_uri_id2 FROM positive_nyt_"+dbname+" WHERE fold_id=?";
			PreparedStatement stmt1 = connNYT2011.prepareStatement(sqlstr1);
			
			Map<ClassInstancePair, Set<Integer>> instURIIDs = Collections.synchronizedMap(
					new HashMap<ClassInstancePair, Set<Integer>>());
			stmt1.setInt(1, foldID);
			ResultSet rs1 = stmt1.executeQuery();
			while (rs1.next()) {
				int instURIID = rs1.getInt(2);
				int corefURIID = rs1.getInt(1);
				int classURIID2 = rs1.getInt(3);
				ClassInstancePair cip = new ClassInstancePair(instURIID,classURIID2);
				if (instURIIDs.containsKey(instURIID)) {
					Set<Integer> corefURIIDs = instURIIDs.get(cip);
					corefURIIDs.add(corefURIID);
				} else {
					Set<Integer> corefURIIDs = Collections.synchronizedSet(new HashSet<Integer>());
					corefURIIDs.add(corefURIID);
					instURIIDs.put(cip, corefURIIDs);
				}
			}
			rs1.close();
			stmt1.close();
			//connNYT2011.close();
			
			String sqlstr2 = null;
			if(foldID > 100 && foldID <=110 )
				sqlstr2 = "SELECT DISTINCT s FROM nyt_locations_quadruple WHERE p=? AND o=? AND s LIKE 'u%';";
			else if(foldID > 200 && foldID <=210)
				sqlstr2 = "SELECT DISTINCT s FROM nyt_organizations_quadruple WHERE p=? AND o=? AND s LIKE 'u%';";
			else
				sqlstr2 = "SELECT DISTINCT s FROM nyt_people_quadruple WHERE p=? AND o=? AND s LIKE 'u%';";
			PreparedStatement stmt2 = connNYT2011.prepareStatement(sqlstr2);
			
			Set<Integer> uriIDs = Collections.synchronizedSet(new HashSet<Integer>());
			Map<ClassInstancePair, String[]> uris = Collections.synchronizedMap(new HashMap<ClassInstancePair, String[]>());
			stmt2.setString(1, "u" + nytRDFTypeID);
			stmt2.setString(2, "u" + 64);
			ResultSet rs2 = stmt2.executeQuery();
			while (rs2.next()) {
				String s = rs2.getString(1);
				int uriID = Integer.parseInt(s.substring(1));
				uriIDs.add(uriID);
			}
			rs2.close();
			stmt2.close();
			connNYT2011.close();
			
			BlockingQueue<Runnable> queue = new LinkedBlockingQueue<Runnable>();  
			ThreadPoolExecutor exec = new ThreadPoolExecutor(4, 5, 7, TimeUnit.DAYS, queue);
			for (ClassInstancePair instURIID : instURIIDs.keySet()) {
				NegExamThread1 net1 = new NegExamThread1(
						dbname, foldID, instURIID, instURIIDs.get(instURIID), uriIDs, uris);
				exec.execute(net1);
			}
			exec.shutdown();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
	public class NegExamThread1 implements Runnable
	{
		private String dbname; 
		private int foldID;
		private ClassInstancePair instURIIDcip;
		private Set<Integer> posURIIDs;
		private Set<Integer> negURIIDs;
		private Map<ClassInstancePair, String[]> uris; 
		
		public NegExamThread1(String dbname, int fid, ClassInstancePair instURIIDcip, 
				Set<Integer> set, Set<Integer> nids, Map<ClassInstancePair, String[]> uris2)
		{
			this.dbname = dbname;
			this.foldID = fid;
			this.instURIIDcip = instURIIDcip;
			this.posURIIDs = set;
			this.negURIIDs = nids;
			this.uris = uris2;
		}
		
		public void run()
		{
			try {
					
				Connection connNYT2011 = DBConnPool.getNYT2011();
				String sqlstr1 = "INSERT IGNORE INTO negative_nyt_"+dbname+" VALUES(?,?,?,?,?,?);";
				PreparedStatement stmt1 = connNYT2011.prepareStatement(sqlstr1);
					
				String[] instQName = null;
				if (uris.containsKey(instURIIDcip)) {
					instQName = uris.get(instURIIDcip);
				} else {
					if(dbname.equals("geonames"))
						instQName = NameFinder.geonamesLocationsLabel(instURIIDcip.instanceURIID);
					else if(dbname.equals("dbpedia"))
						instQName = NameFinder.dbpediaQname(instURIIDcip.instanceURIID);
					else if(dbname.equals("freebase_alternative"))
						instQName = NameFinder.freebaseAlternativeQname(instURIIDcip.instanceURIID);
					uris.put(instURIIDcip, instQName);
				}
				for (int negURIID : negURIIDs) {
					if (!posURIIDs.contains(negURIID) && instURIIDcip.instanceURIID != negURIID) {
						String[] negQName = null;
						if (uris.containsKey(new ClassInstancePair(negURIID,instURIIDcip.instanceURIID))) {
							negQName = uris.get(new ClassInstancePair(negURIID,instURIIDcip.instanceURIID));
						} else {
							if(foldID > 100 && foldID <=110 )
								negQName = NameFinder.nytLocationsLabel(negURIID);
							else if(foldID > 200 && foldID <=210)
								negQName = NameFinder.nytOrganizationsLabel(negURIID);
							else
								negQName = NameFinder.nytPeopleLabel(negURIID);
							uris.put(new ClassInstancePair(negURIID,instURIIDcip.instanceURIID), negQName);
						}
//						if (instQName[0].equals(negQName[0])) {
							stmt1.setInt(1, foldID);
							stmt1.setInt(2, 64);
							stmt1.setInt(3, instURIIDcip.classURIID2);
							stmt1.setInt(4, negURIID);
							stmt1.setInt(5, instURIIDcip.instanceURIID);
							int letterMatch = 0;
							for(int matchIndex = 0; matchIndex < instQName[1].length() && matchIndex < negQName[1].length(); matchIndex++ ){
								if (instQName[1].charAt(matchIndex) != negQName[1].charAt(matchIndex))
									break;
								letterMatch++;		
							}
							if(letterMatch >= 2){
								logger.debug("type_uri_id=" + instURIIDcip.classURIID2 + ", inst_uri_id=" + instURIIDcip.instanceURIID + ", neg_uri_id=" + negURIID+" "+" "+instQName[1]+" "+negQName[1]);
								stmt1.setInt(6, letterMatch);
								stmt1.addBatch();
							}
							
//						}
					}
				}
				stmt1.executeBatch();
				stmt1.close();
				connNYT2011.close();
			} catch (SQLException e) {
				logger.error(e.getMessage());
			}
		}
	}
	
//	public void execNegExam2(){
//		try {
//			Connection connNYT2011 = DBConnPool.getNYT2011();
//			String sqlstr1 = "SELECT instance_uri_id1,instance_uri_id2 FROM positive_nyt_geonames WHERE class_uri_id1=?";
//			PreparedStatement stmt1 = connNYT2011.prepareStatement(sqlstr1);
//			
//			int nytTypeURIID = 64;
//			
//			Map<Integer, Set<Integer>> instURIIDs = Collections.synchronizedMap(
//					new HashMap<Integer, Set<Integer>>());
//			stmt1.setInt(1, nytTypeURIID);
//			ResultSet rs1 = stmt1.executeQuery();
//			while (rs1.next()) {
//				int instURIID = rs1.getInt(2);
//				int corefURIID = rs1.getInt(1);
//				if (instURIIDs.containsKey(instURIID)) {
//					Set<Integer> corefURIIDs = instURIIDs.get(instURIID);
//					corefURIIDs.add(corefURIID);
//				} else {
//					Set<Integer> corefURIIDs = Collections.synchronizedSet(new HashSet<Integer>());
//					corefURIIDs.add(corefURIID);
//					instURIIDs.put(instURIID, corefURIIDs);
//				}
//			}
//			rs1.close();
//			stmt1.close();
//			//connNYT2011.close();
//			
//			String sqlstr2 = "SELECT DISTINCT s FROM nyt_locations_quadruple WHERE p=? AND o=? AND s LIKE 'u%';";
//			PreparedStatement stmt2 = connNYT2011.prepareStatement(sqlstr2);
//			
//			Set<Integer> uriIDs = Collections.synchronizedSet(new HashSet<Integer>());
//			Map<Integer, String[]> uris = Collections.synchronizedMap(new HashMap<Integer, String[]>());
//			stmt2.setString(1, "u" + 32);
//			stmt2.setString(2, "u" + nytTypeURIID);
//			ResultSet rs2 = stmt2.executeQuery();
//			while (rs2.next()) {
//				String s = rs2.getString(1);
//				int uriID = Integer.parseInt(s.substring(1));
//				uriIDs.add(uriID);
//			}
//			rs2.close();
//			stmt2.close();
//			connNYT2011.close();
//			
//			BlockingQueue<Runnable> queue = new LinkedBlockingQueue<Runnable>();  
//			ThreadPoolExecutor exec = new ThreadPoolExecutor(4, 5, 7, TimeUnit.DAYS, queue);
//			for (int instURIID : instURIIDs.keySet()) {
//				NegExamThread2 net2 = new NegExamThread2(
//						nytTypeURIID, instURIID, instURIIDs.get(instURIID), uriIDs, uris);
//				exec.execute(net2);
//			}
//			exec.shutdown();
//		} catch (SQLException e) {
//			// TODO Auto-generated catch block
//			e.printStackTrace();
//		}
//	}
//	
//	public class NegExamThread2 implements Runnable
//	{
//		private int typeURIID;
//		private int instURIID;
//		private Set<Integer> posURIIDs;
//		private Set<Integer> negURIIDs;
//		private Map<Integer, String[]> uris; 
//		
//		public NegExamThread2(int tid, int uid, 
//				Set<Integer> pids, Set<Integer> nids, Map<Integer, String[]> uris)
//		{
//			this.typeURIID = tid;
//			this.instURIID = uid;
//			this.posURIIDs = pids;
//			this.negURIIDs = nids;
//			this.uris = uris;
//		}
//		
//		public void run()
//		{
//			try {
//					
//				Connection connNYT2011 = DBConnPool.getNYT2011();
//				String sqlstr1 = "INSERT IGNORE INTO negative_nyt_geonames VALUES(?,?,?,?);";
//				PreparedStatement stmt1 = connNYT2011.prepareStatement(sqlstr1);
//					
//				String[] instQName = null;
//				if (uris.containsKey(instURIID)) {
//					instQName = uris.get(instURIID);
//				} else {
//					instQName = NameFinder.geonamesLocationsLabel(instURIID);
//					uris.put(instURIID, instQName);
//				}
//				for (int negURIID : negURIIDs) {
//					if (!posURIIDs.contains(negURIID) && instURIID != negURIID) {
//						String[] negQName = null;
//						if (uris.containsKey(negURIID)) {
//							negQName = uris.get(negURIID);
//						} else {
//							negQName = NameFinder.nytLocationsLabel(negURIID);
//							uris.put(negURIID, negQName);
//						}
////						if (instQName[0].equals(negQName[0])) {
//							stmt1.setInt(1, typeURIID);
//							stmt1.setInt(2, negURIID);
//							stmt1.setInt(3, instURIID);
//							int letterMatch = 0;
//							for(int matchIndex = 0; matchIndex < instQName[1].length() && matchIndex < negQName[1].length(); matchIndex++ ){
//								if (instQName[1].charAt(matchIndex) != negQName[1].charAt(matchIndex))
//									break;
//								letterMatch++;		
//							}
//							if(letterMatch >= 2){
//								logger.debug("type_uri_id=" + typeURIID + ", inst_uri_id=" + instURIID + ", neg_uri_id=" + negURIID+" "+" "+instQName[1]+" || "+negQName[1]);
//								stmt1.setInt(4, letterMatch);
//								stmt1.addBatch();
//							}
//							
////						}
//					}
//				}
//				stmt1.executeBatch();
//				stmt1.close();
//				connNYT2011.close();
//			} catch (SQLException e) {
//				logger.error(e.getMessage());
//			}
//		}
//	}
//	
	public static void main(String args[])
	{
		PropertyConfigurator.configure("./config/log4j.properties");
		DBParam.init();
		NegativeExample ne = new NegativeExample();
		//ne.execNegExam1();
		ne.execNegExam1("dbpedia", 308);

	}
}
