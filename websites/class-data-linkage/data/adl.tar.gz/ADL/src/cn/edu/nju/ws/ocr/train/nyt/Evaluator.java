package cn.edu.nju.ws.ocr.train.nyt;

import java.io.File;
import java.sql.*;
import java.util.Collections;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;
import java.util.concurrent.BlockingQueue;
import java.util.concurrent.LinkedBlockingQueue;
import java.util.concurrent.ThreadPoolExecutor;
import java.util.concurrent.TimeUnit;

import org.apache.log4j.Logger;
import org.apache.log4j.PropertyConfigurator;

import cn.edu.nju.ws.ocr.datab.DBConnPool;
import cn.edu.nju.ws.ocr.datab.DBParam;
import cn.edu.nju.ws.ocr.nlp.ISub;

public class Evaluator {
	static Logger logger = Logger.getLogger(Evaluator.class);
	/**
	 * @param args
	 */
	
	Map<Integer, Set<Integer>> instURIIDs = Collections.synchronizedMap(
			new HashMap<Integer, Set<Integer>>());
	int trainFID = 309;
	double threshold = 0.8;
	
	void Evaluator1(String dbname){

		int tp = 0,fp = 0,fn = 0,tn = 0, p =0, n =0;
		
		PropInfoGain ig = new PropInfoGain(dbname,trainFID);
		ig.GenPropPQ(threshold);

		int propCount = 5;
		int[] propArray = new int[propCount*2];
		for (int i=0; i<propCount&& ig.queue2.size()>0; i++){
			Point point = ig.queue2.poll();
			propArray[i*2] = point.propURIID1;
			propArray[i*2+1] = point.propURIID2;
			logger.info(propArray[i*2] + " "+propArray[i*2+1]);
		}	

		try {
			Connection connNYT2011 = DBConnPool.getNYT2011();
			
			Statement stmt3 = connNYT2011.createStatement();		
			ResultSet rs3 = stmt3.executeQuery("SELECT distinct instance_uri_id1,instance_uri_id2 FROM nyt.positive_nyt_"+dbname+" where fold_id<>"+trainFID+" " +
							"and fold_id<="+(trainFID+10)+" " +
							"and fold_id>="+(trainFID-10));
			while(rs3.next()){
				int URIID1 = rs3.getInt(1);
				int URIID2 = rs3.getInt(2);
				String sqlstr2 = "SELECT max(similarity) from positive_nyt_"+dbname+"_property_pair" +
						" where instance_uri_id1=? and instance_uri_id2=? and property_uri_id1=? and property_uri_id2=?"; 
				PreparedStatement stmt2 = connNYT2011.prepareStatement(sqlstr2);
				int k = 0;
				for(k=0; k<propCount; k++){
					//logger.debug(URIID1 + " " + URIID2 + " " + propArray[k*2] + " " + propArray[k*2+1] + " "+tp);
					stmt2.setInt(1, URIID1);
					stmt2.setInt(2, URIID2);
					stmt2.setInt(3, propArray[k*2]);
					stmt2.setInt(4, propArray[k*2+1]);
					ResultSet rs2 = stmt2.executeQuery();
					if(rs2.next())
						if(rs2.getFloat(1) > threshold){
							tp++;
							break;
						}
					rs2.close();
				}
				if(k == propCount)
					logger.info("fn_instance_pair: "+URIID1+" | "+URIID2);
				p++;
				stmt2.close();
			}
			fn = p - tp;
			
			Statement stmt1 = connNYT2011.createStatement();		
			ResultSet rs1 = stmt1.executeQuery("SELECT distinct instance_uri_id1,instance_uri_id2 FROM nyt.negative_nyt_"+dbname+" where fold_id<>"+trainFID+" " +
					"and fold_id<="+(trainFID+10)+" " +
					"and fold_id>="+(trainFID-10));					
			while(rs1.next()){
				int URIID1 = rs1.getInt(1);
				int URIID2 = rs1.getInt(2);
				String sqlstr2 = "SELECT max(similarity) from negative_nyt_"+dbname+"_property_pair" +
						" where instance_uri_id1=? and instance_uri_id2=? and property_uri_id1=? and property_uri_id2=?"; 
				PreparedStatement stmt2 = connNYT2011.prepareStatement(sqlstr2);			
				for(int i=0; i<propCount; i++){
					//logger.debug(URIID1 + " " + URIID2 + " " + propArray[i*2] + " " + propArray[i*2+1] + " "+fp);
					stmt2.setInt(1, URIID1);
					stmt2.setInt(2, URIID2);
					stmt2.setInt(3, propArray[i*2]);
					stmt2.setInt(4, propArray[i*2+1]);
					ResultSet rs2 = stmt2.executeQuery();
					if(rs2.next())
						if(rs2.getFloat(1)  > threshold){
							fp++;
							logger.info("fp_instance_pair: "+URIID1+" | "+URIID2);
							break;
						}
					rs2.next();
				}		
				n++;
				stmt2.close();
			}
			tn = n - fp;
					
			
			connNYT2011.close();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		System.out.println("tp: "+tp +" fp: "+ fp + " tn: "+tn +" fn: "+ fn);
		System.out.println("precision: "+(double)tp/(tp+fp) +" recall: "+ (double)tp/(tp+fn));
	}
	
//	void Evaluator2(String dbname){
//
//		int tp = 0,fp = 0,fn = 0,tn = 0, p =0, n =0;
//		
//		PropInfoGain ig = new PropInfoGain(dbname,trainFID);
//		ig.GenPropPQ(threshold);
//
//		int propCount = 5;
//		int[] propArray = new int[propCount*2];
//		for (int i=0; i<propCount&& ig.queue2.size()>0; i++){
//			Point point = ig.queue2.poll();
//			propArray[i*2] = point.propURIID1;
//			propArray[i*2+1] = point.propURIID2;
//			logger.info(propArray[i*2] + " "+propArray[i*2+1]);
//		}	
//
//		try {
//			Connection connNYT2011 = DBConnPool.getNYT2011();
//			
//			File[] files = new File("./data/mappings/10-fold/").listFiles();
//			for (int i = 0; i < files.length; ++i) {
//				File f = files[i];
//				if (f.getName().startsWith("nyt-geonames-mappings")) {
//					AlignmentReader ar = new AlignmentReader(f.getPath());
//					Alignment a = ar.read();
//					if((i+1)%10 != trainFID%100){
//						for(int j = 0; j < a.size(); j++){
//							int URIID1 = URIHelper.uriID(a.mapping(j).entity1(), "nyt_uri");
//							int URIID2 = URIHelper.uriID(a.mapping(j).entity2(), "geonames_uri");
//							
//							String sqlstr2 = "SELECT max(similarity) from positive_nyt_geonames_property_pair" +
//									" where instance_uri_id1=? and instance_uri_id2=? and property_uri_id1=? and property_uri_id2=?"; 
//							PreparedStatement stmt2 = connNYT2011.prepareStatement(sqlstr2);			
//							for(int k=0; k<propCount; k++){
//								logger.debug(URIID1 + " " + URIID2 + " " + propArray[k*2] + " " + propArray[k*2+1] + " "+tp);
//								stmt2.setInt(1, URIID1);
//								stmt2.setInt(2, URIID2);
//								stmt2.setInt(3, propArray[k*2]);
//								stmt2.setInt(4, propArray[k*2+1]);
//								ResultSet rs2 = stmt2.executeQuery();
//								if(rs2.next())
//									if(rs2.getInt(1) > threshold){
//										tp++;
//										break;
//									}
//							}		
//						}
//						p = p+a.size();
//					}
//				}
//			}	
//			fn = p - tp;
//			
//			Statement stmt1 = connNYT2011.createStatement();		
//			ResultSet rs1 = stmt1.executeQuery("SELECT instance_uri_id1,instance_uri_id2 FROM nyt.negative_nyt_geonames where fold_id<>"+trainFID+" " +
//					"and fold_id<="+(trainFID+10)+" " +
//					"and fold_id>="+(trainFID-10));					
//			while(rs1.next()){
//				int URIID1 = rs1.getInt(1);
//				int URIID2 = rs1.getInt(2);
//				String sqlstr2 = "SELECT max(similarity) from negative_nyt_geonames_property_pair" +
//						" where instance_uri_id1=? and instance_uri_id2=? and property_uri_id1=? and property_uri_id2=?"; 
//				PreparedStatement stmt2 = connNYT2011.prepareStatement(sqlstr2);			
//				for(int i=0; i<propCount; i++){
//					stmt2.setInt(1, URIID1);
//					stmt2.setInt(2, URIID2);
//					stmt2.setInt(3, propArray[i*2]);
//					stmt2.setInt(4, propArray[i*2+1]);
//					ResultSet rs2 = stmt2.executeQuery();
//					if(rs2.next())
//						if(rs2.getInt(1) > threshold){
//							fp++;
//							break;
//						}
//				}		
//				n++;
//			}
//			tn = n - fp;
//					
//			
//			connNYT2011.close();
//		} catch (SQLException e) {
//			// TODO Auto-generated catch block
//			e.printStackTrace();
//		}
//		System.out.println("tp: "+tp +" fp: "+ fp + " tn: "+tn +" fn: "+ fn);
//		System.out.println("precision: "+(double)tp/(tp+fp) +" recall: "+ (double)tp/(tp+fn));
//	}


	
	public void pr2(){
		
		try {
			Connection connNYT2011 = DBConnPool.getNYT2011();
			int r = 0;
			int t = 0;
			int rn = 0;
			
			String sqlstr2 = "select instantce_uri_id1 from positive_nyt_geonames where instantce_uri_id2=?";
			PreparedStatement stmt2 = connNYT2011.prepareStatement(sqlstr2);
			for(int instURIID: instURIIDs.keySet()){
				stmt2.setInt(1, instURIID);
				ResultSet rs2 = stmt2.executeQuery();
				while(rs2.next()){
					if(instURIIDs.get(instURIID).contains(rs2.getInt(1)))
						rn++;
				}
				r += instURIIDs.get(instURIID).size();
			}
			
			PreparedStatement stmt3 = connNYT2011.prepareStatement("select count(distinct instance_uri_id1,instance_uri_id2) from positive_nyt_geonames where fold_id<>?");
			stmt3.setInt(1, trainFID);
			ResultSet rs3 = stmt3.executeQuery();
			while(rs3.next()){
				t = rs3.getInt(1);
			}
			
			System.out.println("precision: "+(double)rn/r + " recall: "+(double)rn/t);
			stmt2.close();
			stmt3.close();
			connNYT2011.close();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		PropertyConfigurator.configure("./config/log4j.properties");
		DBParam.init();

		Evaluator e = new Evaluator();
		//e.NytGeonamesEvaluator1();
		e.Evaluator1("freebase_alternative");
		//e.pr1(101);
	}

}
