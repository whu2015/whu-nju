package cn.edu.nju.ws.ocr.train.pr2011;

import java.sql.*;
import java.util.*;
import java.util.concurrent.*;
import org.apache.log4j.*;
import cn.edu.nju.ws.ocr.datab.*;
import cn.edu.nju.ws.ocr.nlp.ISub;
import cn.edu.nju.ws.ocr.prep.btc.*;
import cn.edu.nju.ws.ocr.train.btc.*;

public class PosExamPropPair 
{
	static Logger logger = Logger.getLogger(PosExamPropPair.class);
	
	private int persons1RDFTypeID = 2;
	
	public void execPosExamPropPair1()
	{
		try {
			Connection connPR = DBConnPool.getPR();
			String sqlstr1 = "SELECT instance_uri_id1,instance_uri_id2 "
					       + "FROM positive_restaurants WHERE fold_id=?;";
			PreparedStatement stmt1 = connPR.prepareStatement(sqlstr1);
			
			Map<Integer, Set<Integer>> positiveExamples = 
					Collections.synchronizedMap(new HashMap<Integer, Set<Integer>>());
			
			int foldID = 110;
			stmt1.setInt(1, foldID);
			ResultSet rs1 = stmt1.executeQuery();
			while (rs1.next()) {
				int instURIID1 = rs1.getInt(1);
				int instURIID2 = rs1.getInt(2);
				if (positiveExamples.containsKey(instURIID1)) {
					Set<Integer> instances = positiveExamples.get(instURIID1);
					instances.add(instURIID2);
				} else {
					Set<Integer> instances = new HashSet<Integer>();
					instances.add(instURIID2);
					positiveExamples.put(instURIID1, instances);
				}
			}
			rs1.close();
			stmt1.close();
			connPR.close();
			
			BlockingQueue<Runnable> queue = new LinkedBlockingQueue<Runnable>();  
			ThreadPoolExecutor exec = new ThreadPoolExecutor(4, 5, 7, TimeUnit.DAYS, queue);
			for (int instURIID1 : positiveExamples.keySet()) {
				Set<Integer> instances = positiveExamples.get(instURIID1);
				PosExamPropPairThread1 peppt1 = 
						new PosExamPropPairThread1(foldID, instURIID1, instances);
				exec.execute(peppt1);
			}
			exec.shutdown();
		} catch (SQLException e) {
			logger.error(e.getMessage());
		}
	}
	
	public static void main(String args[])
	{
		PropertyConfigurator.configure("./config/log4j.properties");
		DBParam.init();
		
		PosExamPropPair pepp = new PosExamPropPair();
		pepp.execPosExamPropPair1();
	}
	
	public class PosExamPropPairThread1 implements Runnable
	{
		private int typeURIID;
		private int instURIID;
		private Set<Integer> corefURIIDs;
		
		public PosExamPropPairThread1(int tid, int uid, Set<Integer> cuids)
		{
			this.typeURIID = tid;
			this.instURIID = uid;
			this.corefURIIDs = cuids;
		}
		
		public void run()
		{
			try {
				logger.debug("foldID=" + typeURIID + ", inst_uri_id=" + instURIID);
				
				Connection connPR = DBConnPool.getPR();
				String sqlstr1 = "SELECT DISTINCT p,o FROM  restaurant1_quadruple " 
							   + "WHERE s=? AND p<>? AND o NOT LIKE 'b%';";
				PreparedStatement stmt1 = connPR.prepareStatement(sqlstr1);
				String sqlstr2 = "SELECT DISTINCT p,o FROM  restaurant2_quadruple " 
						   + "WHERE s=? AND p<>? AND o NOT LIKE 'b%';";
				PreparedStatement stmt2 = connPR.prepareStatement(sqlstr2);
				
				Instance inst = new Instance(instURIID);
				stmt1.setString(1, "u" + instURIID);
				stmt1.setString(2, "u" + persons1RDFTypeID);
				ResultSet rs1 = stmt1.executeQuery();
				while (rs1.next()) {
					
					String p = rs1.getString(1);
					String o = rs1.getString(2);
					
					int propURIID = Integer.parseInt(p.substring(1));
					if (o.startsWith("u")) {
						int objURIID = Integer.parseInt(o.substring(1));
						String obj = PRNameFinder.Qname(objURIID, "restaurant1_uri")[1];
						if (obj != null && !obj.trim().equals(""))
							inst.addPropValue(propURIID, obj);
					} else { // o.startsWith("l")
						String obj = o.substring(1);
						if (obj != null && !obj.trim().equals(""))
							inst.addPropValue(propURIID, obj);
					}
				}
				rs1.close();
				
				Set<Instance> corefs = new HashSet<Instance>();
				for (int corefURIID : corefURIIDs) {
					Instance coref = new Instance(corefURIID);
					stmt2.setString(1, "u" + corefURIID);
					stmt2.setString(2, "u" + persons1RDFTypeID);
					ResultSet rs2 = stmt2.executeQuery();
					while (rs2.next()) {
						String p = rs2.getString(1);
						String o = rs2.getString(2);
						int propURIID = Integer.parseInt(p.substring(1));
						if (o.startsWith("u")) {
							int objURIID = Integer.parseInt(o.substring(1));
							String obj = PRNameFinder.Qname(objURIID, "restaurant2_uri")[1];
							if (obj != null && !obj.trim().equals(""))
								coref.addPropValue(propURIID, obj);
						} else {
							String obj = o.substring(1);
							if (obj != null && !obj.equals(""))
								coref.addPropValue(propURIID, obj);
						}
					}
					rs2.close();
					corefs.add(coref);
				}
				stmt1.close();
				stmt2.close();
				
				String sqlstr3 = "INSERT IGNORE INTO positive_restaurants_property_pair VALUES(?,?,?,?,?,?,?,?,?,?)";
				PreparedStatement stmt3 = connPR.prepareStatement(sqlstr3);
				
				Map<Integer, Set<String>> instPropValues = inst.propValues;
				for (Instance coref : corefs) {
					Map<Integer, Set<String>> corefPropValues = coref.propValues;
					for (int instPropURIID : instPropValues.keySet()) {
						Set<String> instValues = instPropValues.get(instPropURIID);
						for (int corefPropURIID : corefPropValues.keySet()) {
							Set<String> corefValues = corefPropValues.get(corefPropURIID);
							for (String instValue : instValues) {
								for (String corefValue : corefValues) {
									double sim = ISub.getSimilarity(instValue, corefValue);
									if (sim >= 0.7) {
										stmt3.setInt(1, typeURIID);
										stmt3.setInt(2, 19);
										stmt3.setInt(3, 3);
										stmt3.setInt(4, instURIID);
										stmt3.setInt(5, coref.uriID);
										stmt3.setInt(6, instPropURIID);
										stmt3.setInt(7, corefPropURIID);
										stmt3.setString(8, instValue);
										stmt3.setString(9, corefValue);
										stmt3.setFloat(10, (float) sim);
										stmt3.addBatch();
									}
								}
							}
						}
					}
					stmt3.executeBatch();
				}
				stmt3.close();
				connPR.close();
			} catch (SQLException e) {
				logger.error(e.getMessage());
			}
		}
	}
	
	public class Instance
	{
		public int uriID;
		public Map<Integer, Set<String>> propValues;
		
		public Instance(int uid)
		{
			this.uriID = uid;
			this.propValues = new HashMap<Integer, Set<String>>();
		}
		
		public void addPropValue(int pid, String v)
		{
			if (propValues.containsKey(pid)) {
				Set<String> values = propValues.get(pid);
				values.add(v);
			} else {
				Set<String> values = new HashSet<String>();
				values.add(v);
				propValues.put(pid, values);
			}
		}
	}
}
