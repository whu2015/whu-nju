package cn.edu.nju.ws.ocr.train.nyt;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;

public class AveragePr {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		File file = new File("./data/nyt_precision_recall_raw.txt");
		BufferedReader reader = null;
		try{
			reader = new BufferedReader(new FileReader(file));
			String tempString = null;
			
			while((tempString = reader.readLine()) != null){
				if(tempString.split(" ").length >= 5){
					double sumP = 0.0, sumR = 0.0;
					for(int i = 0; i < 10 ;i++){
						String prStrings = reader.readLine();
						sumP += Double.parseDouble(prStrings.split(" ")[1]);
						sumR += Double.parseDouble(prStrings.split(" ")[3]);
					}
					double p = (double)sumP/10;
					double r = (double)sumR/10;
					double f1 = 2*p*r/(p+r);
					System.out.println(tempString+"||"+p+"||"+r+"||"+f1);
				}
			}
			 reader.close();
		}catch(FileNotFoundException e){
			e.printStackTrace();
		}catch(IOException e){
			e.printStackTrace();
		}
	}

}
