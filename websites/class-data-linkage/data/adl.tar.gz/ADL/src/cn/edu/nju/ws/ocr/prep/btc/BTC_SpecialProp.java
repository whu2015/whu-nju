package cn.edu.nju.ws.ocr.prep.btc;

import java.sql.*;
import org.apache.log4j.*;
import cn.edu.nju.ws.ocr.datab.*;

public class BTC_SpecialProp 
{
	static Logger logger = Logger.getLogger(BTC_SpecialProp.class);
	
	public static final String OWL_sameAs = "http://www.w3.org/2002/07/owl#sameAs";
	public static final int OWL_sameAs_ID = 423;
	public static final String OWL_sameAs_dispname = "owl:sameAs";
	
	public static final String OWL_IFP = "http://www.w3.org/2002/07/owl#InverseFunctionalProperty";
	public static final int OWL_IFP_ID = 1059;
	
	public static final String OWL_FP = "http://www.w3.org/2002/07/owl#FunctionalProperty";
	public static final int OWL_FP_ID = 1055;
	
	public static final String OWL_cardinality = "http://www.w3.org/2002/07/owl#cardinality";
	public static final int OWL_cardinality_ID = 352;
	
	public static final String OWL_maxCardinality = "http://www.w3.org/2002/07/owl#maxCardinality";
	public static final int OWL_maxCardinality_ID = 190;
	
	public static final String SKOS_exactMatch = "http://www.w3.org/2004/02/skos/core#exactMatch";
	public static final int SKOS_exactMatch_ID = 37479; 
	public static final String SKOS_exactMatch_dispname = "skos:exactMatch";
	
	// http://www.w3.org/1999/02/22-rdf-syntax-ns#type
	public static final int RDF_type_ID = 2;
	
	// http://www.w3.org/2002/07/owl#onProperty
	public static final int OWL_onProperty_ID = 187;
	
	// http://www.w3.org/2002/07/owl#Restriction
	public static final int OWL_Restriction_ID = 189;
	
	// http://www.w3.org/2002/07/owl#equivalentClass
	public static final int OWL_equivalentClass_ID = 632;
	
	// http://www.w3.org/2000/01/rdf-schema#subClassOf
	public static final int RDFS_subClassOf_ID = 198;
	
	// http://xmlns.com/foaf/0.1/mbox
	public static final int FOAF_mbox_ID = 1057;
	
	// http://xmlns.com/foaf/0.1/mbox_sha1sum
	public static final int FOAF_mbox_sha1sum_ID = 127;
	
	// http://xmlns.com/foaf/0.1/homepage
	public static final int FOAF_homepage_ID = 130;
	
	// http://www.w3.org/2000/01/rdf-schema#domain
	public static final int RDFS_domain_ID = 269;
	// http://www.w3.org/2000/01/rdf-schema#range
	public static final int RDFS_range_ID = 248;
	
	/* sameas.org */
	public static final String RKB_coreferenceData = "http://www.rkbexplorer.com/ontologies/coref#coreferenceData";
	public static final int RKB_coreferenceData_ID = 0;
	public static final String RKB_coreferenceData_dispname = "rkb:coreferenceData";
	
	public static final String UMBEL_isLike = "http://umbel.org/umbel/sc/isLike";
	public static final int UMBEL_isLike_ID = 0;
	public static final String UMBEL_isLike_dispname = "umbel:isLike";
	
	public static final String SKOS_closeMatch = "http://www.w3.org/2004/02/skos/core#closeMatch";
	public static final int SKOS_closeMatch_ID = 3488;
	public static final String SKOS_closeMatch_dispname = "skos:closeMatch";
	
	public static final String VOCAB_similarTo = "http://open.vocab.org/terms/similarTo";
	public static final int VOCAB_similarTo_ID = 78898;
	public static final String VOCAB_similarTo_dispname = "vocab:similarTo";
	
	public static final String OBO_hasExactSynonym = "http://www.geneontology.org/formats/oboInOwl#hasExactSynonym";
	public static final int OBO_hasExactSynonym_ID = 39956;
	public static final String OBO_hasExactSynonym_dispname = "obo:hasExactSynonym";
	
	public void findProperty()
	{
		try {
			Connection connBTC2011 = DBConnPool.getBTC2011();
			String sqlstr1 = "SELECT DISTINCT s,c FROM btc2011_quadruple WHERE o=? AND p=?";
			PreparedStatement stmt1 = connBTC2011.prepareStatement(sqlstr1);
			
			String sqlstr2 = "INSERT INTO btc2011_special_property(property,c,category) VALUES(?,?,?)";
			PreparedStatement stmt2 = connBTC2011.prepareStatement(sqlstr2);
			
			// OWL_IFP_ID, OWL_FP_ID
			stmt1.setString(1, "u" + OWL_FP_ID);
			stmt1.setString(2, "u" + RDF_type_ID);
				
			ResultSet rs1 = stmt1.executeQuery();
			while (rs1.next()) {
				String s = rs1.getString(1);
				int c = rs1.getInt(2);		
				stmt2.setString(1, s);
				stmt2.setInt(2, c);
				stmt2.setString(3, "f"); // "i"=IFP, "f"=FP
				stmt2.executeUpdate();
			}
			rs1.close();
			stmt1.close();
			stmt2.close();
			connBTC2011.close();
		} catch (SQLException e) {
			logger.error(e.getMessage());
		}
	}
	
	public static void main(String args[])
	{
		PropertyConfigurator.configure("./config/log4j.properties");
		DBParam.init();
		
		new BTC_SpecialProp().findProperty();
	}
}
