package cn.edu.nju.ws.ocr.datab;

import java.io.*;
import java.util.*;
import org.apache.log4j.*;

public class DBParam 
{
	static Logger logger = Logger.getLogger(DBParam.class);
	
	public static final String DBConnFile = "./config/dbconn.properties";
	
	public static final String DRV = "com.mysql.jdbc.Driver";

	public static String URL_ObjectCoref;
	public static String USR_ObjectCoref;
	public static String PWD_ObjectCoref;

	/* public static String URL_FalconetV04;
	public static String USR_FalconetV04;
	public static String PWD_FalconetV04;

	public static String URL_FCrawlerV04;
	public static String USR_FCrawlerV04;
	public static String PWD_FCrawlerV04; */
	
	public static String URL_FalconetV05;
	public static String USR_FalconetV05;
	public static String PWD_FalconetV05;
	
	public static String URL_BTC2011;
	public static String USR_BTC2011;
	public static String PWD_BTC2011;
	
	public static String URL_OMAnalysis;
	public static String USR_OMAnalysis;
	public static String PWD_OMAnalysis;
	
	public static String URL_DC7900;
	public static String USR_DC7900;
	public static String PWD_DC7900;
	
	public static String URL_NYT2011;
	public static String USR_NYT2011;
	public static String PWD_NYT2011;
	
	public static String URL_PR;
	public static String USR_PR;
	public static String PWD_PR;
	
	public static String URL_NYTLocal;
	public static String USR_NYTLocal;
	public static String PWD_NYTLocal;
	
	private static Properties getProperties()
	{
		FileInputStream fis = null;
		try {
			fis = new FileInputStream(DBConnFile);
		} catch (FileNotFoundException e) {
			logger.error(e.getMessage());
			return null;
		}
		
		Properties properties = new Properties();
		try {
			properties.load(fis);
			return properties;
		} catch (IOException e) {
			logger.error(e.getMessage());
			return null;
		} finally {
			try {
				fis.close();
			} catch (IOException e) {
				// ignored
			}
		}
	}
	
	public static void init()
	{
		Properties properties = getProperties();
		
		String s = properties.getProperty("URL_ObjectCoref");
        if (s != null) 
        	URL_ObjectCoref = s.trim();
        s = properties.getProperty("USR_ObjectCoref");
        if (s != null) 
        	USR_ObjectCoref = s.trim();
        s = properties.getProperty("PWD_ObjectCoref");
        if (s != null)
        	PWD_ObjectCoref = s.trim();
        
        /* String t = properties.getProperty("URL_FalconetV04");
        if (t != null) 
        	URL_FalconetV04 = t.trim();
        t = properties.getProperty("USR_FalconetV04");
        if (t != null) 
        	USR_FalconetV04 = t.trim();
        t = properties.getProperty("PWD_FalconetV04");
        if (t != null) 
        	PWD_FalconetV04 = t.trim();
        
        String r = properties.getProperty("URL_FCrawlerV04");
        if (r != null) 
        	URL_FCrawlerV04 = r.trim();
        r = properties.getProperty("USR_FCrawlerV04");
        if (r != null) 
        	USR_FCrawlerV04 = r.trim();
        r = properties.getProperty("PWD_FCrawlerV04");
        if (r != null) 
        	PWD_FCrawlerV04 = r.trim(); */
        
        String u = properties.getProperty("URL_FalconetV05");
        if (u != null)
        	URL_FalconetV05 = u.trim();
        u = properties.getProperty("USR_FalconetV05");
        if (u != null)
        	USR_FalconetV05 = u.trim();
        u = properties.getProperty("PWD_FalconetV05");
        if (u != null)
        	PWD_FalconetV05 = u.trim();
        
        String v = properties.getProperty("URL_BTC2011");
        if (v != null)
        	URL_BTC2011 = v.trim();
        v = properties.getProperty("USR_BTC2011");
        if (v != null)
        	USR_BTC2011 = v.trim();
        v = properties.getProperty("PWD_BTC2011");
        if (v != null)
        	PWD_BTC2011 = v.trim();
        
        String w = properties.getProperty("URL_OMAnalysis");
        if (w != null)
        	URL_OMAnalysis = w.trim();
        w = properties.getProperty("USR_OMAnalysis");
        if (w != null)
        	USR_OMAnalysis = w.trim();
        w = properties.getProperty("PWD_OMAnalysis");
        if (w != null)
        	PWD_OMAnalysis = w.trim();
        
        String x = properties.getProperty("URL_DC7900");
        if (x != null)
        	URL_DC7900 = x.trim();
        x = properties.getProperty("USR_DC7900");
        if (x != null)
        	USR_DC7900 = x.trim();
        x = properties.getProperty("PWD_DC7900");
        if (x != null)
        	PWD_DC7900 = x.trim();
        
        String y = properties.getProperty("URL_NYT2011");
        if (y != null)
        	URL_NYT2011 = y.trim();
        y = properties.getProperty("USR_NYT2011");
        if (y != null)
        	USR_NYT2011 = y.trim();
        y = properties.getProperty("PWD_NYT2011");
        if (y != null)
        	PWD_NYT2011 = y.trim();
        
        String p = properties.getProperty("URL_PR");
        if (p != null)
        	URL_PR = p.trim();
        p = properties.getProperty("USR_PR");
        if (p != null)
        	USR_PR = p.trim();
        p = properties.getProperty("PWD_PR");
        if (p != null)
        	PWD_PR = p.trim();
        
        String n = properties.getProperty("URL_NYTLocal");
        if (n != null)
        	URL_NYTLocal = n.trim();
        n = properties.getProperty("USR_NYTLocal");
        if (n != null)
        	USR_NYTLocal = n.trim();
        n = properties.getProperty("PWD_NYTLocal");
        if (n != null)
        	PWD_NYTLocal = n.trim();
        
//        logger.info(URL_ObjectCoref + "?usr=" + USR_ObjectCoref + "&pwd=" + PWD_ObjectCoref);
//        // logger.info(URL_FalconetV04 + "?usr=" + USR_FalconetV04 + "&pwd=" + PWD_FalconetV04);
//        // logger.info(URL_FCrawlerV04 + "?usr=" + USR_FCrawlerV04 + "&pwd=" + PWD_FCrawlerV04);
//        logger.info(URL_FalconetV05 + "?usr=" + USR_FalconetV05 + "&pwd=" + PWD_FalconetV05);
//        logger.info(URL_BTC2011 + "?usr=" + USR_BTC2011 + "&pwd=" + PWD_BTC2011);
//        logger.info(URL_DC7900 + "?usr=" + USR_DC7900 + "&pwd=" + PWD_DC7900);
//        logger.info(URL_NYT2011 + "?usr=" + USR_NYT2011 + "&pwd=" + PWD_NYT2011);
//        logger.info(URL_PR + "?usr=" + USR_PR + "&pwd=" + PWD_PR);
//        logger.info(URL_NYTLocal + "?usr=" + USR_NYTLocal + "&pwd=" + PWD_NYTLocal);
	}
	
	public static void main(String args[])
	{
		PropertyConfigurator.configure("./config/log4j.properties");
		DBParam.init();
	}
}
