package cn.edu.nju.ws.ocr.train.nyt;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.text.DecimalFormat;

import org.apache.log4j.PropertyConfigurator;

import cn.edu.nju.ws.ocr.datab.DBConnPool;
import cn.edu.nju.ws.ocr.datab.DBParam;
import cn.edu.nju.ws.ocr.nlp.EditDistance;

public class temp {
	
	static int nytLat = 49;
	static int nytLong = 52;
	static int geonamesLat = 21;
	static int geonamesLong = 17;

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		PropertyConfigurator.configure("./config/log4j.properties");
		DBParam.init();
		
		//geoMatchTest("geonames");
		//DecimalFormat df2  = new DecimalFormat("###.00");  
		//System.out.println(df2.format(Xround(1.2)));
		System.out.println(EditDistance.getSimilarity("08 42787650", "08 42877650"));
	}
	
	public static double Xround(double x){
		return (double) ((int)(x*10000)/10000.0);
	}

	public static void  geoMatchTest(String dbname){
		try {
			Connection connNYT2011 = DBConnPool.getNYT2011();
			String sqlstr1 = "select distinct instance_uri_id1,instance_uri_id2 from positive_nyt_"+dbname;
			PreparedStatement stmt1 = connNYT2011.prepareStatement(sqlstr1);
			String sqlstr2 = "SELECT p,o FROM nyt.nyt_locations_quadruple where s = ? and (p = ? or p = ?)";
			PreparedStatement stmt2 = connNYT2011.prepareStatement(sqlstr2);
			String sqlstr3 = "SELECT p,o FROM nyt."+dbname+"_quadruple where s = ? and (p = ? or p = ?)";
			PreparedStatement stmt3 = connNYT2011.prepareStatement(sqlstr3);
			
			int testCount = 0, correctCount = 0;
			ResultSet rs1 = stmt1.executeQuery();
			while(rs1.next()){
				testCount++;
				
				double lat1 = 0, long1 = 0, lat2 = 0, long2 = 0;
				int id1 = rs1.getInt(1);
				int id2 = rs1.getInt(2);
				stmt2.setString(1, "u"+id1);
				stmt2.setString(2, "u"+nytLat);
				stmt2.setString(3, "u"+nytLong);
				ResultSet rs2 = stmt2.executeQuery();
				while(rs2.next()){
					if(Integer.parseInt(rs2.getString(1).substring(1)) == nytLat)
						lat1 = Double.parseDouble(rs2.getString(2).substring(1));
					else if(Integer.parseInt(rs2.getString(1).substring(1)) == nytLong)
						long1 = Double.parseDouble(rs2.getString(2).substring(1));
				}
				stmt3.setString(1, "u"+id2);
				stmt3.setString(2, "u"+geonamesLat);
				stmt3.setString(3, "u"+geonamesLong);
				ResultSet rs3 = stmt3.executeQuery();
				while(rs3.next()){
					if(Integer.parseInt(rs3.getString(1).substring(1)) == geonamesLat)
						lat2 = Double.parseDouble(rs3.getString(2).substring(1));
					else if(Integer.parseInt(rs3.getString(1).substring(1)) == geonamesLong)
						long2 = Double.parseDouble(rs3.getString(2).substring(1));
				}
				
				lat1 = Xround(lat1);
				long1 = Xround(long1);
				lat2 = Xround(lat2);
				long2 = Xround(long2);
				System.out.println(testCount+" "+correctCount+" "+lat1+" "+long1+" "+lat2+" "+long2);
				if(lat1 == lat2 && long1 == long2){
					correctCount++;
				}
			}
			System.out.println(dbname+" geoMatchTest: "+ (double)correctCount/testCount);
			
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
}
