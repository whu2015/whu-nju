package cn.edu.nju.ws.ocr.train.pr2011;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Collections;
import java.util.HashMap;
import java.util.Map;
import java.util.Set;

import org.apache.log4j.Logger;
import org.apache.log4j.PropertyConfigurator;

import cn.edu.nju.ws.ocr.datab.DBConnPool;
import cn.edu.nju.ws.ocr.datab.DBParam;
import cn.edu.nju.ws.ocr.nlp.ISub;

public class Evaluator2 {
	static Logger logger = Logger.getLogger(Evaluator2.class);
	
	int trainFID = 101;
	double threshold = 0.7;
	int propCount = 5;
	
	Map<Integer, Set<Integer>> instURIIDs = Collections.synchronizedMap(
			new HashMap<Integer, Set<Integer>>());
	
	public void evaluator2(String dbname){	
		
		PropInfoGain ig;
		if(dbname.equals("person1"))
			ig = new PropInfoGain("persons1",trainFID);
		else if (dbname.equals("person2"))
			ig = new PropInfoGain("persons2",trainFID);
		else
			ig = new PropInfoGain("restaurants",trainFID);
		ig.GenPropPQ(threshold);
	
		int[] propArray = new int[propCount*2];
		for (int i=0; i<propCount&& ig.queue2.size()>0; i++){
			Point point = ig.queue2.poll();
			propArray[i*2] = point.propURIID1;
			propArray[i*2+1] = point.propURIID2;
			logger.info(propArray[i*2] + " "+propArray[i*2+1]);
		}	
		
		try {
			Connection connPR = DBConnPool.getPR();
			String sqlstr1 = "select distinct s,o from "+dbname+"1_quadruple where p = ?";
			String sqlstr2 = "select distinct s,o from "+dbname+"2_quadruple where p = ?";
			PreparedStatement stmt1 = connPR.prepareStatement(sqlstr1);
			PreparedStatement stmt2 = connPR.prepareStatement(sqlstr2);
			
			for(int i = 0; i <propCount ; i++){
				stmt1.setString(1, "u"+propArray[i*2]);
				
				
				ResultSet rs1 = stmt1.executeQuery();				
				while(rs1.next()){
					int URIID1 = Integer.parseInt(rs1.getString(1).substring(1));
					String obj1 = rs1.getString(2).substring(1);
					stmt2.setString(1, "u"+propArray[i*2+1]);
					
					Map<Integer,Integer> tempCorefURIIDs = new HashMap<Integer,Integer>();
					
					ResultSet rs2 = stmt2.executeQuery();
					while(rs2.next()){
						int URIID2 = Integer.parseInt(rs2.getString(1).substring(1));
						String obj2 = rs2.getString(2).substring(1);
						
						if(ISub.getSimilarity(obj1, obj2) >= threshold){
							if(tempCorefURIIDs.containsKey(URIID2)){
								int count = tempCorefURIIDs.get(URIID2);
								tempCorefURIIDs.remove(URIID2);
								tempCorefURIIDs.put(URIID2, count+1);
								
							}
							else{
								tempCorefURIIDs.put(URIID2, 1);
							}
						}
						
						System.out.println(URIID2);
					}
					
					int maxSim = -1, tempCorefURIID = -1;
					for(int URIID: tempCorefURIIDs.keySet()){
						if(tempCorefURIIDs.get(URIID) > maxSim){
							maxSim = tempCorefURIIDs.get(URIID);
							tempCorefURIID = URIID;
						}
					}
					
				}
			}
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		PropertyConfigurator.configure("./config/log4j.properties");
		DBParam.init();
		
		Evaluator2 e = new Evaluator2();
		e.evaluator2("person1");
	}

}
