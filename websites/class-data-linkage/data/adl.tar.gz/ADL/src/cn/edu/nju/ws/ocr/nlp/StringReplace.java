package cn.edu.nju.ws.ocr.nlp;

import java.util.StringTokenizer;

public class StringReplace {

	/**
	 * @param args
	 */
	 public static String strReplace(String from,String to,String source) {
		    StringBuffer bf= new StringBuffer("");
		    StringTokenizer st = new StringTokenizer(source,from,true);
		    while (st.hasMoreTokens()) {
		      String tmp = st.nextToken();
		      if(tmp.equals(from)) {
		        bf.append(to);
		      } else {
		        bf.append(tmp);
		      }
		    }
		    return bf.toString();
		  }
}
