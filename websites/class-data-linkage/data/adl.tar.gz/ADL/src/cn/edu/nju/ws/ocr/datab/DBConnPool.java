package cn.edu.nju.ws.ocr.datab;

import java.sql.*;
import org.apache.commons.dbcp.*;
import org.apache.log4j.*;

public class DBConnPool 
{
	static Logger logger = Logger.getLogger(DBConnPool.class);
	
	private static BasicDataSource dsObjectCoref;
	// private static BasicDataSource dsFalconetV04;
	// private static BasicDataSource dsFCrawlerV04;
	private static BasicDataSource dsFalconetV05;
	private static BasicDataSource dsBTC2011;
	private static BasicDataSource dsOMAnalysis;
	private static BasicDataSource dsDC7900;
	private static BasicDataSource dsNYT2011;
	private static BasicDataSource dsPR;
	private static BasicDataSource dsNYTLocal;
	
	synchronized private static void initObjectCoref()
	{
		dsObjectCoref = new BasicDataSource();
		
		dsObjectCoref.setDriverClassName(DBParam.DRV);
		dsObjectCoref.setUrl(DBParam.URL_ObjectCoref);
		dsObjectCoref.setUsername(DBParam.USR_ObjectCoref);
		dsObjectCoref.setPassword(DBParam.PWD_ObjectCoref);
		
		dsObjectCoref.setMaxActive(5);
		dsObjectCoref.setMaxIdle(2);
		dsObjectCoref.setDefaultTransactionIsolation(Connection.TRANSACTION_SERIALIZABLE);
		
		dsObjectCoref.setTestOnBorrow(true);
		String sqlstr = "SHOW TABLES";
		dsObjectCoref.setValidationQuery(sqlstr);
	}
	
	synchronized public static Connection getObjectCoref() throws SQLException
	{
		if (dsObjectCoref == null)
			initObjectCoref();
		return dsObjectCoref.getConnection();
	}
	
	synchronized public static void shutObjectCoref() throws SQLException
	{
		if (dsObjectCoref != null) 
			dsObjectCoref.close();
	}
	
	/* synchronized private static void initFalconetV04()
	{
		dsFalconetV04 = new BasicDataSource();
		
		dsFalconetV04.setDriverClassName(DBParam.DRV);
		dsFalconetV04.setUrl(DBParam.URL_FalconetV04);
		dsFalconetV04.setUsername(DBParam.USR_FalconetV04);
		dsFalconetV04.setPassword(DBParam.PWD_FalconetV04);
		
		dsFalconetV04.setMaxActive(5);
		dsFalconetV04.setMaxIdle(2);
		dsFalconetV04.setDefaultTransactionIsolation(Connection.TRANSACTION_SERIALIZABLE);
		
		dsFalconetV04.setTestOnBorrow(true);
		String sqlstr = "SHOW TABLES";
		dsFalconetV04.setValidationQuery(sqlstr);
	}
	
	synchronized public static Connection getFalconetV04() throws SQLException
	{
		if (dsFalconetV04 == null)
			initFalconetV04();
		return dsFalconetV04.getConnection();
	}
	
	synchronized public static void shutFalconetV04() throws SQLException
	{
		if (dsFalconetV04 != null) 
			dsFalconetV04.close();
	}

	synchronized private static void initFCrawlerV04()
	{
		dsFCrawlerV04 = new BasicDataSource();
		
		dsFCrawlerV04.setDriverClassName(DBParam.DRV);
		dsFCrawlerV04.setUrl(DBParam.URL_FCrawlerV04);
		dsFCrawlerV04.setUsername(DBParam.USR_FCrawlerV04);
		dsFCrawlerV04.setPassword(DBParam.PWD_FCrawlerV04);
		
		dsFCrawlerV04.setMaxActive(5);
		dsFCrawlerV04.setMaxIdle(2);
		dsFCrawlerV04.setDefaultTransactionIsolation(Connection.TRANSACTION_SERIALIZABLE);
		
		dsFCrawlerV04.setTestOnBorrow(true);
		String sqlstr = "SHOW TABLES";
		dsFCrawlerV04.setValidationQuery(sqlstr);
	}
	
	synchronized public static Connection getFCrawlerV04() throws SQLException
	{
		if (dsFCrawlerV04 == null)
			initFCrawlerV04();
		return dsFCrawlerV04.getConnection();
	}
	
	synchronized public static void shutFCrawlerV04() throws SQLException
	{
		if (dsFCrawlerV04 != null) 
			dsFCrawlerV04.close();
	} */
	
	synchronized private static void initFalconetV05()
	{
		dsFalconetV05 = new BasicDataSource();
		
		dsFalconetV05.setDriverClassName(DBParam.DRV);
		dsFalconetV05.setUrl(DBParam.URL_FalconetV05);
		dsFalconetV05.setUsername(DBParam.USR_FalconetV05);
		dsFalconetV05.setPassword(DBParam.PWD_FalconetV05);
		
		dsFalconetV05.setMaxActive(15);
		dsFalconetV05.setMaxIdle(2);
		dsFalconetV05.setDefaultTransactionIsolation(Connection.TRANSACTION_SERIALIZABLE);
		
		dsFalconetV05.setTestOnBorrow(true);
		String sqlstr = "SHOW TABLES";
		dsFalconetV05.setValidationQuery(sqlstr);
	}
	
	synchronized public static Connection getFalconetV05() throws SQLException
	{
		if (dsFalconetV05 == null)
			initFalconetV05();
		return dsFalconetV05.getConnection();
	}
	
	synchronized public static void shutFalconetV05() throws SQLException
	{
		if (dsFalconetV05 != null) 
			dsFalconetV05.close();
	}
	
	synchronized private static void initBTC2011()
	{
		dsBTC2011 = new BasicDataSource();
		
		dsBTC2011.setDriverClassName(DBParam.DRV);
		dsBTC2011.setUrl(DBParam.URL_BTC2011);
		dsBTC2011.setUsername(DBParam.USR_BTC2011);
		dsBTC2011.setPassword(DBParam.PWD_BTC2011);
		
		dsBTC2011.setMaxActive(25);
		dsBTC2011.setMaxIdle(2);
		dsBTC2011.setDefaultTransactionIsolation(Connection.TRANSACTION_SERIALIZABLE);
		
		dsBTC2011.setTestOnBorrow(true);
		String sqlstr = "SHOW TABLES";
		dsBTC2011.setValidationQuery(sqlstr);
	}
	
	synchronized public static Connection getBTC2011() throws SQLException
	{
		if (dsBTC2011 == null)
			initBTC2011();
		return dsBTC2011.getConnection();
	}
	
	synchronized public static void shutBTC2011() throws SQLException
	{
		if (dsBTC2011 != null) 
			dsBTC2011.close();
	}
	
	synchronized private static void initOMAnalysis()
	{
		dsOMAnalysis = new BasicDataSource();
		
		dsOMAnalysis.setDriverClassName(DBParam.DRV);
		dsOMAnalysis.setUrl(DBParam.URL_OMAnalysis);
		dsOMAnalysis.setUsername(DBParam.USR_OMAnalysis);
		dsOMAnalysis.setPassword(DBParam.PWD_OMAnalysis);
		
		dsOMAnalysis.setMaxActive(25);
		dsOMAnalysis.setMaxIdle(2);
		dsOMAnalysis.setDefaultTransactionIsolation(Connection.TRANSACTION_SERIALIZABLE);
		
		dsOMAnalysis.setTestOnBorrow(true);
		String sqlstr = "SHOW TABLES";
		dsOMAnalysis.setValidationQuery(sqlstr);
	}
	
	synchronized public static Connection getOMAnalysis() throws SQLException
	{
		if (dsOMAnalysis == null)
			initOMAnalysis();
		return dsOMAnalysis.getConnection();
	}
	
	synchronized public static void shutOMAnalysis() throws SQLException
	{
		if (dsOMAnalysis != null) 
			dsOMAnalysis.close();
	}
	
	synchronized private static void initDC7900()
	{
		dsDC7900 = new BasicDataSource();
		
		dsDC7900.setDriverClassName(DBParam.DRV);
		dsDC7900.setUrl(DBParam.URL_DC7900);
		dsDC7900.setUsername(DBParam.USR_DC7900);
		dsDC7900.setPassword(DBParam.PWD_DC7900);
		
		dsDC7900.setMaxActive(5);
		dsDC7900.setMaxIdle(2);
		dsDC7900.setDefaultTransactionIsolation(Connection.TRANSACTION_SERIALIZABLE);
		
		dsDC7900.setTestOnBorrow(true);
		String sqlstr = "SHOW TABLES";
		dsDC7900.setValidationQuery(sqlstr);
	}
	
	synchronized public static Connection getDC7900() throws SQLException
	{
		if (dsDC7900 == null)
			initDC7900();
		return dsDC7900.getConnection();
	}
	
	synchronized public static void shutDC7900() throws SQLException
	{
		if (dsDC7900 != null) 
			dsDC7900.close();
	}
	
	synchronized private static void initNYT2011()
	{
		dsNYT2011 = new BasicDataSource();
		
		dsNYT2011.setDriverClassName(DBParam.DRV);
		dsNYT2011.setUrl(DBParam.URL_NYT2011);
		dsNYT2011.setUsername(DBParam.USR_NYT2011);
		dsNYT2011.setPassword(DBParam.PWD_NYT2011);
		
		dsNYT2011.setMaxActive(5);
		dsNYT2011.setMaxIdle(2);
		dsNYT2011.setDefaultTransactionIsolation(Connection.TRANSACTION_SERIALIZABLE);
		
		dsNYT2011.setTestOnBorrow(true);
		String sqlstr = "SHOW TABLES";
		dsNYT2011.setValidationQuery(sqlstr);
	}
	
	synchronized public static Connection getNYT2011() throws SQLException
	{
		if (dsNYT2011 == null)
			initNYT2011();
		return dsNYT2011.getConnection();
	}
	
	synchronized public static void shutNYT2011() throws SQLException
	{
		if (dsNYT2011 != null) 
			dsNYT2011.close();
	}
	
	synchronized private static void initPR()
	{
		dsPR = new BasicDataSource();
		
		dsPR.setDriverClassName(DBParam.DRV);
		dsPR.setUrl(DBParam.URL_PR);
		dsPR.setUsername(DBParam.USR_PR);
		dsPR.setPassword(DBParam.PWD_PR);
		
		dsPR.setMaxActive(5);
		dsPR.setMaxIdle(2);
		dsPR.setDefaultTransactionIsolation(Connection.TRANSACTION_SERIALIZABLE);
		
		dsPR.setTestOnBorrow(true);
		String sqlstr = "SHOW TABLES";
		dsPR.setValidationQuery(sqlstr);
	}
	
	synchronized public static Connection getPR() throws SQLException
	{
		if (dsPR == null)
			initPR();
		return dsPR.getConnection();
	}
	
	synchronized public static void shutPR() throws SQLException
	{
		if (dsPR != null) 
			dsPR.close();
	}
	
	synchronized private static void initNYTLocal()
	{
		dsNYTLocal = new BasicDataSource();
		
		dsNYTLocal.setDriverClassName(DBParam.DRV);
		dsNYTLocal.setUrl(DBParam.URL_NYTLocal);
		dsNYTLocal.setUsername(DBParam.USR_NYTLocal);
		dsNYTLocal.setPassword(DBParam.PWD_NYTLocal);
		
		dsNYTLocal.setMaxActive(5);
		dsNYTLocal.setMaxIdle(2);
		dsNYTLocal.setDefaultTransactionIsolation(Connection.TRANSACTION_SERIALIZABLE);
		
		dsNYTLocal.setTestOnBorrow(true);
		String sqlstr = "SHOW TABLES";
		dsNYTLocal.setValidationQuery(sqlstr);
	}
	
	synchronized public static Connection getNYTLocal() throws SQLException
	{
		if (dsNYTLocal == null)
			initNYTLocal();
		return dsNYTLocal.getConnection();
	}
	
	synchronized public static void shutNYTLocal() throws SQLException
	{
		if (dsNYTLocal != null) 
			dsNYTLocal.close();
	}
	
	public static void main(String args[]) throws SQLException
	{
		PropertyConfigurator.configure("./config/log4j.properties");
		DBParam.init();
			
		getObjectCoref().close();
		shutObjectCoref();
		
		// getFalconetV04().close();
		// shutFalconetV04();
		
		// getFCrawlerV04().close();
		// shutFCrawlerV04();
		
		getFalconetV05().close();
		shutFalconetV05();
		
		getBTC2011().close();
		shutBTC2011();
		
		getDC7900().close();
		shutDC7900();
	}
}
