package cn.edu.nju.ws.ocr.train.nyt;

import java.sql.*;
import java.util.Collections;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.Map;
import java.util.Set;
import java.util.concurrent.BlockingQueue;
import java.util.concurrent.LinkedBlockingQueue;
import java.util.concurrent.ThreadPoolExecutor;
import java.util.concurrent.TimeUnit;

import org.apache.log4j.Logger;
import org.apache.log4j.PropertyConfigurator;

import com.hp.hpl.jena.sparql.procedure.library.debug;

import cn.edu.nju.ws.ocr.datab.DBConnPool;
import cn.edu.nju.ws.ocr.datab.DBParam;
import cn.edu.nju.ws.ocr.train.nyt.Evaluator2.Evaluator2Thread1;

public class DataPrep {

	static Logger logger = Logger.getLogger(DataPrep.class);
		
	void initNytLocal(String dbname){
		try {
			Connection connNYT2011 = DBConnPool.getNYT2011();
			Statement stmt1 = connNYT2011.createStatement();
			ResultSet rs1 = stmt1.executeQuery("SELECT max(uri_id) FROM "+dbname+"_uri;");
			int maxURIID = -1;
			while(rs1.next()){
				maxURIID = rs1.getInt(1);
			}
			rs1.close();
			stmt1.close();
			connNYT2011.close();
			
			Set<Integer> propSet = new HashSet<Integer>();
			int propCount = 5;
			
			if(dbname.equals("geonames")){
				PropInfoGain ig = new PropInfoGain(dbname,101);
				ig.GenPropPQ(0.8);
				for (int i=0; i<propCount&& ig.queue2.size()>0; i++){
					Point point = ig.queue2.poll();
					propSet.add(point.propURIID2);
				}
			}
			else{
				PropInfoGain ig = new PropInfoGain(dbname,101);
				ig.GenPropPQ(0.8);
				for (int i=0; i<propCount&& ig.queue2.size()>0; i++){
					Point point = ig.queue2.poll();
					propSet.add(point.propURIID2);
				}
				PropInfoGain ig2 = new PropInfoGain(dbname,201);
				ig2.GenPropPQ(0.8);
				for (int i=0; i<propCount&& ig2.queue2.size()>0; i++){
					Point point = ig2.queue2.poll();
					propSet.add(point.propURIID2);
				}
				PropInfoGain ig3 = new PropInfoGain(dbname,301);
				ig3.GenPropPQ(0.8);
				for (int i=0; i<propCount&& ig3.queue2.size()>0; i++){
					Point point = ig3.queue2.poll();
					propSet.add(point.propURIID2);
				}
			}
			
			BlockingQueue<Runnable> queue = new LinkedBlockingQueue<Runnable>();  
			ThreadPoolExecutor exec = new ThreadPoolExecutor(4, 5, 7, TimeUnit.DAYS, queue);
			for (int i=1 ; i<=maxURIID; i++) {
				initNytLocalThread1 peppt1 = 
						new initNytLocalThread1(i, propSet, dbname);
				exec.execute(peppt1);
			}
			exec.shutdown();
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
	public class initNytLocalThread1 implements Runnable{
		
		private int URIID;
		private Set<Integer> propSet;
		private String dbname;

		public initNytLocalThread1(int id, Set<Integer> propSet, String dbname) {
			// TODO Auto-generated constructor stub
			this.URIID = id;
			this.propSet = propSet;
			this.dbname = dbname;
		}

		@Override
		public void run() {
			// TODO Auto-generated method stub
			try {
				Connection connNYT2011 = DBConnPool.getNYT2011();
				String sqlstr1 = "select o from "+dbname+"_quadruple where s=? and p=?";
				PreparedStatement stmt1 = connNYT2011.prepareStatement(sqlstr1);
				Connection connNYTLocal = DBConnPool.getNYTLocal();
				String sqlstr2 = "insert into nyt_"+dbname+"_prop_value value(?,?,?)";
				PreparedStatement stmt2 = connNYTLocal.prepareStatement(sqlstr2);
				logger.debug(URIID);
				stmt1.setString(1, "u"+URIID);
				for(int propURIID: propSet){
					
					
					if(propURIID != 0){
						stmt1.setString(2, "u"+propURIID);
						ResultSet rs1 = stmt1.executeQuery();
						while(rs1.next()){
							String o = rs1.getString(1);
							if(dbname.equals("geonames")){
								if (o.startsWith("u")) {
									int objURIID = Integer.parseInt(o.substring(1));
									String obj = NameFinder.geonamesLocalname(objURIID);
									if (obj != null && !obj.trim().equals("")){
										stmt2.setInt(1, URIID);
										stmt2.setInt(2, propURIID);
										stmt2.setString(3, obj);
										stmt2.addBatch();
									}
								} else {
									String obj = o.substring(1);
									if (obj != null && !obj.trim().equals("")){
										stmt2.setInt(1, URIID);
										stmt2.setInt(2, propURIID);
										stmt2.setString(3, obj);
										stmt2.addBatch();
									}
								}
							}
							else if(dbname.equals("dbpedia")){
								if (o.startsWith("u")) {
									int objURIID = Integer.parseInt(o.substring(1));
									String obj = NameFinder.dbpediaQname(objURIID)[1];
									if (obj != null && !obj.trim().equals("")){
										stmt2.setInt(1, URIID);
										stmt2.setInt(2, propURIID);
										stmt2.setString(3, obj);
										stmt2.addBatch();
									}
								} else {
									String obj = o.substring(1);
									if (obj != null && !obj.trim().equals("")){
										stmt2.setInt(1, URIID);
										stmt2.setInt(2, propURIID);
										stmt2.setString(3, obj);
										stmt2.addBatch();
									}
								}
							}
							else if(dbname.equals("freebase_alternative")){
								if (o.startsWith("u")) {
									int objURIID = Integer.parseInt(o.substring(1));
									String obj = NameFinder.freebaseAlternativeQname(objURIID)[1];
									if (obj != null && !obj.trim().equals("")){
										stmt2.setInt(1, URIID);
										stmt2.setInt(2, propURIID);
										stmt2.setString(3, obj);
										stmt2.addBatch();
									}
								} else {
									String obj = o.substring(1);
									if (obj != null && !obj.trim().equals("")){
										stmt2.setInt(1, URIID);
										stmt2.setInt(2, propURIID);
										stmt2.setString(3, obj);
										stmt2.addBatch();
									}
								}
							}
						}
						rs1.close();
					}
					else{
						if(dbname.equals("dbpedia")){
							String obj =  NameFinder.dbpediaQname(URIID)[1];
							if(obj.lastIndexOf(",")>0){
								stmt2.setInt(1, URIID);
								stmt2.setInt(2, propURIID);
								stmt2.setString(3, obj.substring(0,obj.lastIndexOf(",")));
								stmt2.addBatch();
							}
							else{
								stmt2.setInt(1, URIID);
								stmt2.setInt(2, propURIID);
								stmt2.setString(3, obj);
								stmt2.addBatch();
							}
						}
						else if(dbname.equals("freebase_alternative")){
							String o[] =  NameFinder.freebaseAlternativeQname(URIID)[1].split(".");
							if(o != null){
								if(o.length >= 2){
									stmt2.setInt(1, URIID);
									stmt2.setInt(2, propURIID);
									stmt2.setString(3, o[1]);
									stmt2.addBatch();
								}
								else if(o.length == 1){
									stmt2.setInt(1, URIID);
									stmt2.setInt(2, propURIID);
									stmt2.setString(3, o[0]);
									stmt2.addBatch();
								}
							}
						}
					}
				}
				stmt2.executeBatch();
				stmt2.close();
				connNYTLocal.close();
				stmt1.close();
				connNYT2011.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}

		
	}
	
	void initPropDataType(String dbname){
		try {
			Connection connNYT2011 = DBConnPool.getNYT2011();
			
			Set<Integer> propSet = new HashSet<Integer>();
			Map<Integer,Integer> propTypeMap = Collections.synchronizedMap(
					new HashMap<Integer, Integer>());
			int propCount = 5;
			
			if(dbname.equals("geonames")){
				PropInfoGain ig = new PropInfoGain(dbname,101);
				ig.GenPropPQ(0.8);
				for (int i=0; i<propCount&& ig.queue2.size()>0; i++){
					Point point = ig.queue2.poll();
					propSet.add(point.propURIID2);
				}
			}
			else{
				PropInfoGain ig = new PropInfoGain(dbname,101);
				ig.GenPropPQ(0.8);
				for (int i=0; i<propCount&& ig.queue2.size()>0; i++){
					Point point = ig.queue2.poll();
					propSet.add(point.propURIID2);
				}
				PropInfoGain ig2 = new PropInfoGain(dbname,201);
				ig2.GenPropPQ(0.8);
				for (int i=0; i<propCount&& ig2.queue2.size()>0; i++){
					Point point = ig2.queue2.poll();
					propSet.add(point.propURIID2);
				}
				PropInfoGain ig3 = new PropInfoGain(dbname,301);
				ig3.GenPropPQ(0.8);
				for (int i=0; i<propCount&& ig3.queue2.size()>0; i++){
					Point point = ig3.queue2.poll();
					propSet.add(point.propURIID2);
				}
			}
			
			Connection connNYTLocal = DBConnPool.getNYTLocal();
			String sqlstr2 = "insert into "+dbname+"_prop_type(?,?)";
			PreparedStatement stmt2 = connNYTLocal.prepareStatement(sqlstr2);
			
			String sqlstr3 = "select o from "+dbname+"_quadruple where p=? limit 1";
			PreparedStatement stmt3 = connNYT2011.prepareStatement(sqlstr3);
			
			for(int propURIID : propSet){
				
				stmt3.setString(1, "u"+propURIID);
				ResultSet rs3 = stmt3.executeQuery();
				int typeID = -1;
				if(propURIID == 0){
					typeID = 0;
				}
				else{
					while(rs3.next()){
						String obj = rs3.getString(1);
						//logger.debug(i+"||"+propURIID+"||"+obj);
						if(obj.charAt(0) == 'u')
							typeID = 2;
						else
							typeID = 1;
					}
				}
				rs3.close();
					
				propTypeMap.put(propURIID, typeID);
				//logger.debug(propTypeMap.keySet().size()+"||"+propSet.size());
			}
			
			for(int i : propTypeMap.keySet()){
				logger.debug(i+"||"+propTypeMap.get(i));
			}
			
			connNYT2011.close();
			connNYTLocal.close();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
	/**
	 * @param args
	 */
	public static void main(String[] args) {
		PropertyConfigurator.configure("./config/log4j.properties");
		DBParam.init();
		// TODO Auto-generated method stub
		DataPrep dp = new DataPrep();
		//dp.initNytLocal("dbpedia");
		dp.initPropDataType("freebase_alternative");
	}

}
