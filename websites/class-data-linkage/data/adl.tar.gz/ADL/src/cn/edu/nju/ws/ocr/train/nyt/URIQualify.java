package cn.edu.nju.ws.ocr.train.nyt;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import org.apache.log4j.PropertyConfigurator;

import cn.edu.nju.ws.ocr.datab.DBConnPool;
import cn.edu.nju.ws.ocr.datab.DBParam;

public class URIQualify {
	
	public static int fetchWikiPageRedirects(int uriID){
		try {
			Connection connNYT2011 = DBConnPool.getNYT2011();
			String sqlstr1 = "SELECT o FROM nyt.dbpedia_quadruple where s = ? and p = ?;";
			PreparedStatement stmt1 = connNYT2011.prepareStatement(sqlstr1);
			stmt1.setString(1, "u"+uriID);
			stmt1.setString(2, "u"+2446081);
			ResultSet rs1 = stmt1.executeQuery();
			int redirectURIID = -1;
			while(rs1.next()){
				redirectURIID = Integer.parseInt(rs1.getString(1).substring(1));
			}
			rs1.close();
			stmt1.close();
			connNYT2011.close();
			return redirectURIID;
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return -1;
	}
	
	public static int quandtrupleCount(int uriID, String dbname){
		try {
			Connection connNYT2011 = DBConnPool.getNYT2011();
			String sqlstr1 = "SELECT count(*) FROM "+dbname+"_quadruple where s =?;";
			PreparedStatement stmt1 = connNYT2011.prepareStatement(sqlstr1);
			stmt1.setString(1, "u"+uriID);
			ResultSet rs1 = stmt1.executeQuery();
			int count = -1;
			while(rs1.next()){
				count = rs1.getInt(1);
			}
			rs1.close();
			stmt1.close();
			connNYT2011.close();
			return count;
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return 1;
	}

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		PropertyConfigurator.configure("./config/log4j.properties");
		DBParam.init();
		// TODO Auto-generated method stub
		System.out.println(quandtrupleCount(2727102,"dbpedia"));
	}

}
