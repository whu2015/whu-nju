package cn.edu.nju.ws.ocr.train.pr2011;

import java.sql.*;
import java.util.Collections;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;
import java.util.concurrent.BlockingQueue;
import java.util.concurrent.LinkedBlockingQueue;
import java.util.concurrent.ThreadPoolExecutor;
import java.util.concurrent.TimeUnit;

import org.apache.log4j.Logger;
import org.apache.log4j.PropertyConfigurator;

import cn.edu.nju.ws.ocr.datab.DBConnPool;
import cn.edu.nju.ws.ocr.datab.DBParam;
import cn.edu.nju.ws.ocr.nlp.EditDistance;
import cn.edu.nju.ws.ocr.nlp.ISub;
import cn.edu.nju.ws.ocr.nlp.StringReplace;


public class Evaluator {
	static Logger logger = Logger.getLogger(Evaluator.class);
	/**
	 * @param args
	 */
	int RDFTypeID = 2;
	int Person11Type = 15;
	int Person12Type = 3;
	int Person21Type = 19;
	int Person22Type = 3;
	int Restaurant1Type = 6;
	int Restaurant2Type = 3;
	
	Map<Integer, Set<Integer>> instURIIDs = Collections.synchronizedMap(
			new HashMap<Integer, Set<Integer>>());
	int trainFID = 101;
	double threshold = 0.9;
	int propCount = 5;
	
	public Evaluator(int tfid, double thd, int pcnt) {
		this.trainFID = tfid;
		this.threshold = thd;
		this.propCount = pcnt;
	}

//	void Evaluator1(String dbname){
//
//		int tp = 0,fp = 0,fn = 0,tn = 0, p =0, n =0;
//		
//		PropInfoGain ig = new PropInfoGain(dbname,trainFID);
//		ig.GenPropPQ(threshold);
//
//		int[] propArray = new int[propCount*2];
//		for (int i=0; i<propCount&& ig.queue2.size()>0; i++){
//			Point point = ig.queue2.poll();
//			propArray[i*2] = point.propURIID1;
//			propArray[i*2+1] = point.propURIID2;
//			logger.info(propArray[i*2] + " "+propArray[i*2+1]);
//		}	
//
//		try {
//			Connection connPR = DBConnPool.getPR();
//			
//			Statement stmt3 = connPR.createStatement();		
//			ResultSet rs3 = stmt3.executeQuery("SELECT distinct instance_uri_id1,instance_uri_id2 FROM positive_"+dbname+" where fold_id="+trainFID);
//			while(rs3.next()){
//				int URIID1 = rs3.getInt(1);
//				int URIID2 = rs3.getInt(2);
//				String sqlstr2 = "SELECT max(similarity) from positive_"+dbname+"_property_pair" +
//						" where instance_uri_id1=? and instance_uri_id2=? and property_uri_id1=? and property_uri_id2=?"; 
//				PreparedStatement stmt2 = connPR.prepareStatement(sqlstr2);
//				int k = 0;;
//				for(k=0; k<propCount; k++){
//					//logger.debug(URIID1 + " " + URIID2 + " " + propArray[k*2] + " " + propArray[k*2+1] + " "+tp);
//					
//					stmt2.setInt(1, URIID1);
//					stmt2.setInt(2, URIID2);
//					stmt2.setInt(3, propArray[k*2]);
//					stmt2.setInt(4, propArray[k*2+1]);
//					ResultSet rs2 = stmt2.executeQuery();
//					if(rs2.next()){
//						//logger.debug(URIID1 + " " + URIID2 + " " + propArray[k*2] + " " + propArray[k*2+1] + " "+rs2.getFloat(1));
//						if(rs2.getFloat(1) > threshold){
//							tp++;
//							break;
//						}
//					}
//					rs2.close();
//				}
//				if(k == propCount)
//					logger.info("fn_instance_pair: "+URIID1+" | "+URIID2);
//				p++;
//				stmt2.close();
//			}
//			fn = p - tp;
//			
//			Statement stmt1 = connPR.createStatement();		
//			ResultSet rs1 = stmt1.executeQuery("SELECT distinct instance_uri_id1,instance_uri_id2 FROM negative_"+dbname+" where fold_id="+trainFID);					
//			while(rs1.next()){
//				int URIID1 = rs1.getInt(1);
//				int URIID2 = rs1.getInt(2);
//				String sqlstr2 = "SELECT max(similarity) from negative_"+dbname+"_property_pair" +
//						" where instance_uri_id1=? and instance_uri_id2=? and property_uri_id1=? and property_uri_id2=?"; 
//				PreparedStatement stmt2 = connPR.prepareStatement(sqlstr2);	
//				int i = 0;
//				for(i=0; i<propCount; i++){
//					//logger.debug(URIID1 + " " + URIID2 + " " + propArray[i*2] + " " + propArray[i*2+1] + " "+fp);
//					stmt2.setInt(1, URIID1);
//					stmt2.setInt(2, URIID2);
//					stmt2.setInt(3, propArray[i*2]);
//					stmt2.setInt(4, propArray[i*2+1]);
//					ResultSet rs2 = stmt2.executeQuery();
//					if(rs2.next())
//						if(rs2.getInt(1) > threshold){
//							logger.info("fp_instance_pair: "+URIID1+" | "+URIID2);
//							fp++;
//							break;
//						}
//					rs2.next();
//				}		
//				n++;
//				stmt2.close();
//			}
//			tn = n - fp;
//					
//			
//			connPR.close();
//		} catch (SQLException e) {
//			// TODO Auto-generated catch block
//			e.printStackTrace();
//		}
//		System.out.println("tp: "+tp +" fp: "+ fp + " tn: "+tn +" fn: "+ fn);
//		System.out.println("precision: "+(double)tp/(tp+fp) +" recall: "+ (double)tp/(tp+fn));
//	}
	
	void Evaluator2(String dbname){
		
		PropInfoGain ig = new PropInfoGain(dbname,trainFID);
		ig.GenPropPQ(threshold);

		int[] propArray = new int[propCount*2];
		for (int i=0; i<propCount&& ig.queue2.size()>0; i++){
			Point point = ig.queue2.poll();
			propArray[i*2] = point.propURIID1;
			propArray[i*2+1] = point.propURIID2;
			logger.info(propArray[i*2] + " "+propArray[i*2+1]);
		}
		
		try {
			Connection connPR = DBConnPool.getPR();
			//Statement stmt1 = connPR.createStatement();		
			//ResultSet rs1 = stmt1.executeQuery("SELECT distinct instance_uri_id2 FROM positive_"+dbname+" where fold_id="+trainFID);
			String query1 = null, query2 = null;
			if(dbname.equals("persons1")){
				query1 = "SELECT distinct s FROM pr.person12_quadruple where p=? and o =?;";
				query2 = "SELECT distinct s FROM pr.person11_quadruple where p=? and o =?;";
			}
			else if(dbname.equals("persons2")){
				query1 = "SELECT distinct s FROM pr.person22_quadruple where p=? and o =?;";
				query2 = "SELECT distinct s FROM pr.person21_quadruple where p=? and o =?;";
			}
			else if(dbname.equals("restaurants")){
				query1 = "SELECT distinct s FROM pr.restaurant2_quadruple where p=? and o =?;";
				query2 = "SELECT distinct s FROM pr.restaurant1_quadruple where p=? and o =?;";
			}
			PreparedStatement stmt1 = connPR.prepareStatement(query1);
			PreparedStatement stmt2 = connPR.prepareStatement(query2);
			Set<Integer> rawCorefs = new HashSet<Integer>();
			stmt1.setString(1, "u"+RDFTypeID);
			stmt2.setString(1, "u"+RDFTypeID);
			if(dbname.equals("persons1")){
				stmt1.setString(2, "u"+Person12Type);
				stmt2.setString(2, "u"+Person11Type);
			}
			else if(dbname.equals("persons2")){
				stmt1.setString(2, "u"+Person22Type);
				stmt2.setString(2, "u"+Person21Type);
			}
			else if(dbname.equals("restaurants")){
				stmt1.setString(2, "u"+Restaurant2Type);
				stmt2.setString(2, "u"+Restaurant1Type);
			}
			ResultSet rs2 = stmt2.executeQuery();
			while(rs2.next()){
				rawCorefs.add(Integer.parseInt(rs2.getString(1).substring(1)));
			}
			Map<Integer, Set<Integer>> rawInstPairs = 
					Collections.synchronizedMap(new HashMap<Integer, Set<Integer>>());
			ResultSet rs1 = stmt1.executeQuery();
			while(rs1.next()){
				rawInstPairs.put(Integer.parseInt(rs1.getString(1).substring(1)), rawCorefs);
			}
			rs1.close();
			rs2.close();
			stmt1.close();
			stmt2.close();
			connPR.close();
			
			BlockingQueue<Runnable> queue = new LinkedBlockingQueue<Runnable>();  
			ThreadPoolExecutor exec = new ThreadPoolExecutor(4, 5, 7, TimeUnit.DAYS, queue);
			for (int instURIID1 : rawInstPairs.keySet()) {
				Set<Integer> instances = rawInstPairs.get(instURIID1);
				Evaluator2Thread1 peppt1 = 
						new Evaluator2Thread1(instURIID1, instances, propArray, dbname);
				exec.execute(peppt1);
			}
			exec.shutdown();
			while(true){
				if(exec.getActiveCount() == 0){
					Evaluator2Counters(dbname);
					break;
				}
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
	void Evaluator2Counters(String dbname){
		int tp = 0, fp = 0, ttp = 0, tttp = 0;
		Map<Integer, Set<Integer>> testInstURIIDs = Collections.synchronizedMap(
					new HashMap<Integer, Set<Integer>>());
		
		try {
			Connection connPR = DBConnPool.getPR();
			Statement stmt1 = connPR.createStatement();		
			//ResultSet rs1 = stmt1.executeQuery("SELECT distinct instance_uri_id1,instance_uri_id2 FROM positive_"+dbname+" where fold_id="+trainFID);
			ResultSet rs1 = stmt1.executeQuery("SELECT distinct instance_uri_id1,instance_uri_id2 FROM positive_"+dbname);
			while(rs1.next()){
				int instURIID = rs1.getInt(1);
				int corefURIID = rs1.getInt(2);
				if (testInstURIIDs.containsKey(instURIID)) {
					Set<Integer> corefURIIDs = testInstURIIDs.get(instURIID);
					corefURIIDs.add(corefURIID);
				} else {
					Set<Integer> corefURIIDs = Collections.synchronizedSet(new HashSet<Integer>());
					corefURIIDs.add(corefURIID);
					testInstURIIDs.put(instURIID, corefURIIDs);
				}
				ttp++;
			}
			
			
			for(int instURIID: instURIIDs.keySet()){
				if (testInstURIIDs.containsKey(instURIID)) {
					Set<Integer> corefURIIDs = testInstURIIDs.get(instURIID);
					for(int testCorefURIID: instURIIDs.get(instURIID)){
						if(corefURIIDs.contains(testCorefURIID))
							tp++;
						else {
							logger.debug(instURIID+"||"+testCorefURIID);
							//if(testCorefURIID != -1)
								fp++;
						}
						//tttp++;
					}
				}
				else{
					logger.debug(instURIID);
					for(int testCorefURIID: instURIIDs.get(instURIID)){
						logger.debug(testCorefURIID+"****");
					}
					if(instURIID != -1){
						fp++;
					}
				}
			}
			//System.out.println(dbname+" recall: "+(double)tp/(ttp));
			System.out.println("precision: "+(double)tp/(tp+fp)+" recall: "+(double)tp/ttp);
			System.out.println(tp+"||"+ttp+"||"+tttp);
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
	public class Evaluator2Thread1 implements Runnable
	{
		private int instURIID;
		private Set<Integer> corefURIIDs;
		private int[] propArray;
		private String dbname1;
		private String dbname2;
		
		public Evaluator2Thread1(int uid, Set<Integer> cuids, int[] propArray, String dbname)
		{
			this.instURIID = uid;
			this.corefURIIDs = cuids;
			this.propArray = propArray;
			if(dbname.equals("persons1")){
				this.dbname1 = "person11";
				this.dbname2 = "person12";
			}
			else if(dbname.equals("persons2")){
				this.dbname1 = "person21";
				this.dbname2 = "person22";
			}
			else if(dbname.equals("restaurants")){
				this.dbname1 = "restaurant1";
				this.dbname2 = "restaurant2";
			}
		}
		
		public void run()
		{
			try {
				//logger.debug(instURIID);
				Connection connPR = DBConnPool.getPR();
				String sqlstr1 = null, sqlstr2 = null;
				sqlstr1 = "SELECT DISTINCT o FROM  "+dbname1+"_quadruple " 
							   + "WHERE s=? AND p=? AND o NOT LIKE 'b%';";
					
				sqlstr2 = "SELECT DISTINCT o FROM  "+dbname2+"_quadruple " 
						   	   + "WHERE s=? AND p=? AND o NOT LIKE 'b%';";
				PreparedStatement stmt1 = connPR.prepareStatement(sqlstr1);
				PreparedStatement stmt2 = connPR.prepareStatement(sqlstr2);

				
				int tempCorefURIID = -1;
//				double tempMaxSim = -1.0;		
				Map<Integer,Integer> tempCorefURIIDs = new HashMap<Integer,Integer>();
				
				Instance inst = new Instance(instURIID);
				for(int i=0 ; i<propCount;i++){
					
					stmt2.setString(1, "u" + instURIID);
					stmt2.setString(2, "u" + propArray[2*i+1]);
					ResultSet rs2 = stmt2.executeQuery();
					while (rs2.next()) {

//						String o = rs2.getString(1);
//						if (o.startsWith("u")) {
//							int objURIID = Integer.parseInt(o.substring(1));
//							String obj = PRNameFinder.Qname(objURIID, dbname2+"_uri")[1];
//							if (obj != null && !obj.trim().equals(""))
//								inst.addPropValue(propArray[2*i+1], obj);
//						} else { // o.startsWith("l")
//							String obj = o.substring(1);
//							if (obj != null && !obj.trim().equals(""))
//								inst.addPropValue(propArray[2*i+1], obj);
//						}
						

						String o1 = rs2.getString(1) , obj1 = null;
						if (o1.startsWith("u")) {
							int objURIID = Integer.parseInt(o1.substring(1));
							obj1 = PRNameFinder.Qname(objURIID, dbname2+"_uri")[1];
						} else { // o.startsWith("l")
							obj1 = o1.substring(1);
						}
						
						for (int corefURIID : corefURIIDs) {
							stmt1.setString(1, "u" + corefURIID);
							stmt1.setString(2, "u" + propArray[2*i]);
							ResultSet rs1 = stmt1.executeQuery();
							while (rs1.next()) {
								String o2 = rs1.getString(1), obj2 = null;
								if (o2.startsWith("u")) {
									int objURIID = Integer.parseInt(o2.substring(1));
									obj2 = PRNameFinder.Qname(objURIID, dbname1+"_uri")[1];
								} else {
									obj2 = o2.substring(1);
									if(dbname1.equals("restaurant1") && propArray[2*i] == 7){
										
										obj2 = StringReplace.strReplace("/", "-", obj2);
										//logger.debug(obj2 + "||" + obj1);
									}
								}
								//logger.debug(obj2 + "||" + obj1);
								double sim = ISub.getSimilarity(obj1, obj2);
								if (sim >= threshold ||  (propArray[2*i+1] == 8 && EditDistance.getSimilarity(obj1, obj2) >= 0.9 && dbname1.equals("person21"))) {
								//if (instValue.equals(corefValues)) {
								//if (sim >= threshold) {
									tempCorefURIID = corefURIID;
//									tempMaxSim = sim;									
									if(tempCorefURIIDs.containsKey(tempCorefURIID)){
										int count = tempCorefURIIDs.get(tempCorefURIID);
										tempCorefURIIDs.remove(tempCorefURIID);
										tempCorefURIIDs.put(tempCorefURIID, count+1);
										
									}
									else{
										tempCorefURIIDs.put(tempCorefURIID, 1);
									}
								}
								
							}
							rs1.close();
						}
						
					}
					rs2.close();
				}
				
				
//				Set<Instance> corefs = new HashSet<Instance>();
//				for (int corefURIID : corefURIIDs) {
//					Instance coref = new Instance(corefURIID);
//					for(int i=0 ; i<propCount;i++){
//						stmt1.setString(1, "u" + corefURIID);
//						stmt1.setString(2, "u" + propArray[2*i]);
//						ResultSet rs1 = stmt1.executeQuery();
//						while (rs1.next()) {
//							String o = rs1.getString(1);
//							if (o.startsWith("u")) {
//								int objURIID = Integer.parseInt(o.substring(1));
//								String obj = PRNameFinder.Qname(objURIID, dbname1+"_uri")[1];
//								if (obj != null && !obj.trim().equals(""))
//									coref.addPropValue(propArray[2*i], obj);
//							} else {
//								String obj = o.substring(1);
//								if (obj != null && !obj.equals(""))
//									coref.addPropValue(propArray[2*i], obj);
//							}
//						}
//						rs1.close();
//						corefs.add(coref);
//					}
//				}
				stmt1.close();
				stmt2.close();
				
				
				
//				int tempCorefURIID = -1;
//				double tempMaxSim = -1.0;
//				Map<Integer, Set<String>> instPropValues = inst.propValues;
//				for (Instance coref : corefs) {
//					Map<Integer, Set<String>> corefPropValues = coref.propValues;
//					int weight = -1;
//					for (int instPropURIID : instPropValues.keySet()) {
//						weight++;
//						Set<String> instValues = instPropValues.get(instPropURIID);
//						for (int corefPropURIID : corefPropValues.keySet()) {
//							Set<String> corefValues = corefPropValues.get(corefPropURIID);
//							for (String instValue : instValues) {
//								for (String corefValue : corefValues) {
//									double sim = ISub.getSimilarity(instValue, corefValue);
//									if (sim > tempMaxSim && sim >= threshold) {
//									//if (instValue.equals(corefValues)) {
//										tempCorefURIID = coref.uriID;
//										tempMaxSim = sim;									
//										if(tempCorefURIIDs.containsKey(tempCorefURIID)){
//											int count = tempCorefURIIDs.get(tempCorefURIID);
//											tempCorefURIIDs.remove(tempCorefURIID);
//											tempCorefURIIDs.put(tempCorefURIID, count+1);
//											
//										}
//										else{
//											tempCorefURIIDs.put(tempCorefURIID, 1);
//										}
//									}
//								}
//							}
//						}
//					}
//				}
				
				int maxSim = -1;
				tempCorefURIID = -1;
				for(int URIID: tempCorefURIIDs.keySet()){
					if(tempCorefURIIDs.get(URIID) > maxSim){
						maxSim = tempCorefURIIDs.get(URIID);
						tempCorefURIID = URIID;
					}
				}
				
				logger.debug(instURIID + " || " + tempCorefURIID + " || " + maxSim);

				if (instURIIDs.containsKey(tempCorefURIID)) {
					Set<Integer> corefURIIDs = instURIIDs.get(tempCorefURIID);
					corefURIIDs.add(instURIID);
				} else {
					Set<Integer> corefURIIDs = Collections.synchronizedSet(new HashSet<Integer>());
					corefURIIDs.add(instURIID);
					instURIIDs.put(tempCorefURIID, corefURIIDs);
				}
				connPR.close();
			} catch (SQLException e) {
				logger.error(e.getMessage());
			}
		}
	}
	
	public class Instance
	{
		public int uriID;
		public Map<Integer, Set<String>> propValues;
		
		public Instance(int uid)
		{
			this.uriID = uid;
			this.propValues = new HashMap<Integer, Set<String>>();
		}
		
		public void addPropValue(int pid, String v)
		{
			if (propValues.containsKey(pid)) {
				Set<String> values = propValues.get(pid);
				values.add(v);
			} else {
				Set<String> values = new HashSet<String>();
				values.add(v);
				propValues.put(pid, values);
			}
		}
	}
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		PropertyConfigurator.configure("./config/log4j.properties");
		DBParam.init();

		Evaluator e = new Evaluator(101, 0.8, 5);
		//e.NytGeonamesEvaluator1();
		e.Evaluator2("persons2");
		//e.Evaluator2Counters("persons2");
	}

}
