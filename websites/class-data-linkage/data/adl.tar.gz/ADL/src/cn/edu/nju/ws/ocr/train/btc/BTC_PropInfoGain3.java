package cn.edu.nju.ws.ocr.train.btc;

public class BTC_PropInfoGain3 {

	public double infoD(int pos, int neg){
		int sum = pos+neg;
		return -((double)pos/sum)*Math.log((double)pos/sum)
			   -((double)neg/sum)*Math.log((double)neg/sum);
	}
	
	public double infoDpp(int posNumP,int posNumN, int negNumP, int negNumN){
		int sumNumP = posNumP + negNumP;
		int sumNumN = posNumN + negNumN;
		int sumNum = sumNumP + sumNumN;
		if(posNumP != 0 && negNumP != 0 && posNumN != 0 && negNumN != 0)			
			return ((double)sumNumP/sumNum)*(-((double)posNumP/sumNumP)*Math.log((double)posNumP/sumNumP) - ((double)negNumP/sumNumP)*Math.log((double)negNumP/sumNumP)) + 
				   ((double)sumNumN/sumNum)*(-((double)posNumN/sumNumN)*Math.log((double)posNumN/sumNumN) - ((double)negNumN/sumNumN)*Math.log((double)negNumN/sumNumN));
		else if(posNumP != 0 && negNumP != 0)
			return ((double)sumNumP/sumNum)*(-((double)posNumP/sumNumP)*Math.log((double)posNumP/sumNumP) - ((double)negNumP/sumNumP)*Math.log((double)negNumP/sumNumP));
		else if(posNumN != 0 && negNumN != 0)
			return ((double)sumNumN/sumNum)*(-((double)posNumN/sumNumN)*Math.log((double)posNumN/sumNumN) - ((double)negNumN/sumNumN)*Math.log((double)negNumN/sumNumN));
		else
			return 0;
	}
	
	public double gain(int posNumP,int posNumN, int negNumP, int negNumN){
		return infoD(posNumP+posNumN, negNumP+negNumN) - infoDpp(posNumP, posNumN, negNumP, negNumN);
	}
	
	public static void main(String[] args) {
		BTC_PropInfoGain3 p = new BTC_PropInfoGain3();
		System.out.println(p.infoD(2,3));
		System.out.println(p.infoDpp(2,0,0,3));
		System.out.println(p.infoDpp(2,0,1,2));
		System.out.println(p.gain(1,1,0,3));
		System.out.println(p.gain(2,0,2,1));
	}
}
