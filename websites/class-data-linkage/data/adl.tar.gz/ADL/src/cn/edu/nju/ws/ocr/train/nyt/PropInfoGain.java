package cn.edu.nju.ws.ocr.train.nyt;

import java.sql.*;
import java.util.*;

import org.apache.log4j.Logger;
import org.apache.log4j.PropertyConfigurator;

import cn.edu.nju.ws.ocr.datab.DBConnPool;
import cn.edu.nju.ws.ocr.datab.DBParam;

class Point{
    int propURIID1;
    int propURIID2;
    double infoGain;
  
    public Point( int x,int y,double z){
        this.propURIID1 = x;
        this.propURIID2 = y;
        this.infoGain = z;
    }   
    
    
    public void print(){
    	if(propURIID2 != 0)
    		System.out.println(NameFinder.nytURI(propURIID1) +"\t----\t"+ NameFinder.freebaseAlternativeURI(propURIID2) + "\t" + infoGain );
    	else
    		System.out.println(NameFinder.nytURI(propURIID1) +"\t----\t"+ "localname" + "\t" + infoGain );
    }

}

public class PropInfoGain {
	
	static Logger logger = Logger.getLogger(PropInfoGain.class);
	
	private double infoD = 0;
	int negNum;
    int posNum;
    int sumNum;
    String dbname;
    int trainFID;
    
	PriorityQueue<Point> queue1 = new PriorityQueue<Point>( 1, new Comparator<Point>(){
		public int compare( Point a, Point b ){
			if( a.infoGain < b.infoGain ){
				return 1;
            }
            else if( a.propURIID1 == b.propURIID1 && a.propURIID2 == b.propURIID2){
                return 0;
            }
            else{
                return -1;
            }
        }
    });
	
	PriorityQueue<Point> queue2 = new PriorityQueue<Point>( 1, new Comparator<Point>(){
		public int compare( Point a, Point b ){
			if( a.infoGain < b.infoGain ){
				return 1;
            }
            else if( a.propURIID1 == b.propURIID1 && a.propURIID2 == b.propURIID2){
                return 0;
            }
            else{
                return -1;
            }
        }
    });
	
	PropInfoGain(String dbname,int tfid){
		this.dbname = dbname;
		this.trainFID = tfid;
		try {
			Connection connNYT2011 = DBConnPool.getNYT2011();
			Statement stmt1 = connNYT2011.createStatement();
			
			ResultSet rs1 = stmt1.executeQuery("select count(distinct instance_uri_id1,instance_uri_id2) from negative_nyt_"+dbname+
					" where fold_id="+trainFID);
			rs1.next();
			this.negNum = rs1.getInt(1);
			rs1 = stmt1.executeQuery("select count(distinct instance_uri_id1,instance_uri_id2) from positive_nyt_"+dbname+
					" where fold_id="+trainFID);
			rs1.next();
			this.posNum = rs1.getInt(1);
			this.sumNum = this.negNum + this.posNum;
			
			rs1.close();
			stmt1.close();
			connNYT2011.close();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}	
		info();
	}
	
	private void info(){		
		infoD =  -((double)posNum/sumNum)*Math.log((double)posNum/sumNum) - ((double)negNum/sumNum)*Math.log((double)negNum/sumNum);
	}
	
	public double gain(int prop_uri_id1,int prop_uri_id2, double threshold){
		try {
			Connection connNYT2011 = DBConnPool.getNYT2011();
			Statement stmt1 = connNYT2011.createStatement();
			
			Set<Integer> countSet = new HashSet<Integer>();
			countSet.clear();
			
			ResultSet rs1 = stmt1.executeQuery("SELECT distinct instance_uri_id1, instance_uri_id2 FROM positive_nyt_"+dbname+"_property_pair " +
					"where property_uri_id1 = "+prop_uri_id1+" and property_uri_id2 = "+prop_uri_id2+" and similarity >= "+threshold+" and fold_id="+trainFID+";"); 
			while(rs1.next()){
				//int temp[] = {rs1.getInt(1),rs1.getInt(2)};
				countSet.add(rs1.getInt(1)+rs1.getInt(2));
			}
			int posNumP = countSet.size();
			int posNumN = posNum - posNumP;
			countSet.clear();
			
			rs1 = stmt1.executeQuery("SELECT distinct instance_uri_id1, instance_uri_id2 FROM negative_nyt_"+dbname+"_property_pair " +
					"where property_uri_id1 = "+prop_uri_id1+" and property_uri_id2 = "+prop_uri_id2+" and similarity >= "+threshold+" and fold_id="+trainFID+";");
			while(rs1.next()){
				//int temp[] = {rs1.getInt(1),rs1.getInt(2)};
				countSet.add(rs1.getInt(1)+rs1.getInt(2));
			}
			int negNumP = countSet.size();
			int negNumN = negNum - negNumP;
			
			int sumNumP = posNumP + negNumP;
			int sumNumN = posNumN + negNumN;
			
			//logger.info(prop_uri_id+ " " + posNumP + " " + negNumP);
			connNYT2011.close();
			if(posNumP != 0 && negNumP != 0 && posNumN != 0 && negNumN != 0)			
				return infoD - (((double)sumNumP/sumNum)*(-((double)posNumP/sumNumP)*Math.log((double)posNumP/sumNumP) - ((double)negNumP/sumNumP)*Math.log((double)negNumP/sumNumP)) + 
					   ((double)sumNumN/sumNum)*(-((double)posNumN/sumNumN)*Math.log((double)posNumN/sumNumN) - ((double)negNumN/sumNumN)*Math.log((double)negNumN/sumNumN)));
			else if(posNumP != 0 && negNumP != 0)
				return infoD - (((double)sumNumP/sumNum)*(-((double)posNumP/sumNumP)*Math.log((double)posNumP/sumNumP) - ((double)negNumP/sumNumP)*Math.log((double)negNumP/sumNumP)));
			else if(posNumN != 0 && negNumN != 0)
				return infoD - (((double)sumNumN/sumNum)*(-((double)posNumN/sumNumN)*Math.log((double)posNumN/sumNumN) - ((double)negNumN/sumNumN)*Math.log((double)negNumN/sumNumN)));
			else
				return 0;
			
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return 0;
	}
	
	public double gainRatio(int prop_uri_id1,int prop_uri_id2, double threshold){
		try {
			Connection connNYT2011 = DBConnPool.getNYT2011();
			Statement stmt1 = connNYT2011.createStatement();
			
			Set<Integer> countSet = new HashSet<Integer>();
			countSet.clear();
			
			ResultSet rs1 = stmt1.executeQuery("SELECT distinct instance_uri_id1, instance_uri_id2 FROM positive_nyt_"+dbname+"_property_pair " +
					"where property_uri_id1 = "+prop_uri_id1+" and property_uri_id2 = "+prop_uri_id2+" and similarity >= "+threshold+" and fold_id="+trainFID+";"); 
			while(rs1.next()){
				//int temp[] = {rs1.getInt(1),rs1.getInt(2)};
				countSet.add(rs1.getInt(1)+rs1.getInt(2));
			}
			int posNumP = countSet.size();
			int posNumN = posNum - posNumP;
			countSet.clear();
			
			rs1 = stmt1.executeQuery("SELECT distinct instance_uri_id1, instance_uri_id2 FROM negative_nyt_"+dbname+"_property_pair " +
					"where property_uri_id1 = "+prop_uri_id1+" and property_uri_id2 = "+prop_uri_id2+" and similarity >= "+threshold+" and fold_id="+trainFID+";");
			while(rs1.next()){
				//int temp[] = {rs1.getInt(1),rs1.getInt(2)};
				countSet.add(rs1.getInt(1)+rs1.getInt(2));
			}
			int negNumP = countSet.size();
			int negNumN = negNum - negNumP;
			
			int sumNumP = posNumP + negNumP;
			int sumNumN = posNumN + negNumN;
			
			//logger.info( " " + posNumP + " " + negNumP);
			connNYT2011.close();
			if(posNumP != 0 && negNumP != 0 && posNumN != 0 && negNumN != 0)			
				return (infoD - (((double)sumNumP/sumNum)*(-((double)posNumP/sumNumP)*Math.log((double)posNumP/sumNumP) - ((double)negNumP/sumNumP)*Math.log((double)negNumP/sumNumP)) + 
					   ((double)sumNumN/sumNum)*(-((double)posNumN/sumNumN)*Math.log((double)posNumN/sumNumN) - ((double)negNumN/sumNumN)*Math.log((double)negNumN/sumNumN)))) /
					   (((double)sumNumP/sumNum)*(-Math.log((double)sumNumP/sumNum)) - ((double)sumNumN/sumNum)*(Math.log((double)sumNumN/sumNum)));
			else if(posNumP != 0 && negNumP != 0)
				return (infoD - (((double)sumNumP/sumNum)*(-((double)posNumP/sumNumP)*Math.log((double)posNumP/sumNumP) - ((double)negNumP/sumNumP)*Math.log((double)negNumP/sumNumP)))) /
						((double)sumNumP/sumNum)*(-Math.log((double)sumNumP/sumNum));
			else if(posNumN != 0 && negNumN != 0)
				return (infoD - (((double)sumNumN/sumNum)*(-((double)posNumN/sumNumN)*Math.log((double)posNumN/sumNumN) - ((double)negNumN/sumNumN)*Math.log((double)negNumN/sumNumN)))) /
						((double)sumNumN/sumNum)*(-Math.log((double)sumNumN/sumNum));
			else
				return 0;
			
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return 0;
	}
	
//	public double splitInfo(int prop_uri_id, int threshold){
//		try {
//			Connection connDC7900 = DBConnPool.getDC7900();
//			Statement stmt1 = connDC7900.createStatement();
//			
//
//			int sumNum = negNum + posNum;
//			logger.info("negNum = " + negNum + " posNum = " + posNum + " sumNum = "+sumNum);
//					
//			infoD =  -((double)posNum/sumNum)*Math.log((double)posNum/sumNum) - ((double)negNum/sumNum)*Math.log((double)negNum/sumNum);
//
//		} catch (SQLException e) {
//			// TODO Auto-generated catch block
//			e.printStackTrace();
//		}
//	}

	public void GenPropPQ(double threshold){
		try {
			Connection connNYT2011 = DBConnPool.getNYT2011();
			Statement stmt1 = connNYT2011.createStatement();
			ResultSet rs1 = stmt1.executeQuery("SELECT distinct property_uri_id1,property_uri_id2 FROM positive_nyt_"+dbname+"_property_pair where fold_id="+trainFID);
			while(rs1.next()){
				//logger.info("positive property_uri_id1 "+ rs1.getInt(1));
				Point temp1 = new Point(rs1.getInt(1),rs1.getInt(2), gainRatio(rs1.getInt(1),rs1.getInt(2),threshold) );
				Point temp2 = new Point(rs1.getInt(1),rs1.getInt(2), gain(rs1.getInt(1),rs1.getInt(2),threshold) );
				queue1.add(temp1);
				queue2.add(temp2);
			}
			rs1 = stmt1.executeQuery("SELECT distinct property_uri_id1,property_uri_id2 FROM negative_nyt_"+dbname+"_property_pair where fold_id="+trainFID);
			while(rs1.next()){
				//logger.info("negative property_uri_id1 "+ rs1.getInt(1));
				if(!PQcontains(rs1.getInt(1),rs1.getInt(2))){
					Point temp1 = new Point(rs1.getInt(1),rs1.getInt(2), gainRatio(rs1.getInt(1),rs1.getInt(2),threshold) );
					Point temp2 = new Point(rs1.getInt(1),rs1.getInt(2), gain(rs1.getInt(1),rs1.getInt(2),threshold) );
					queue1.add(temp1);
					queue2.add(temp2);
				}
			}
			
			connNYT2011.close();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
	
	
	public boolean PQcontains(int x,int y){
		Iterator<Point> it = queue1.iterator();
		while(it.hasNext()){
			Point temp = it.next();
			if(x == temp.propURIID1 && y == temp.propURIID2)
				return true;
		}
		return false;
	}
	
	public void printPQ(){
		while( queue1.size() > 0 ){
            Point p = ( Point )queue1.poll();
            p.print();
        }
		
		System.out.println("************************************************");
		
		while( queue2.size() > 0 ){
            Point p = ( Point )queue2.poll();
            p.print();
        }
		System.out.println("================================================");
	}
	
	
	public static void main(String[] args) {
		PropertyConfigurator.configure("./config/log4j.properties");
		DBParam.init();
		
		PropInfoGain ig = new PropInfoGain("freebase_alternative",201);
		ig.GenPropPQ(0.95);
		ig.printPQ();
	}

}
